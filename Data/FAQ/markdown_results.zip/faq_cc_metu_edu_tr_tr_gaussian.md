[Jump to navigation](https://faq.cc.metu.edu.tr/tr/gaussian#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-06-2024 **Görüntüleme:** 12907


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/gaussian "GAUSSIAN")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/gaussian "GAUSSIAN")

# GAUSSIAN

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **GAUSSIAN** **09** **—**

**_GAUSSIAN_** **_09_** _, Gaussian elektronik yapı programlarının en sonuncusudur. Çok çeşitli şartlar altında bulunan ve geniş bir yelpaze oluşturan moleküler sistemleri modellemek için tasarlanmış olan Gaussian, kuantum mekaniğinin temel yasalarını kullanarak hesaplamalar yapar._

_Gaussian kimyacılar, fizikçiler ve mühendisler tarafından, kimya ile ilgili yerleşmiş ve yeni gelişmekte olan ilgi alanlarında araştırma yapmak, moleküller üzerinde ve deneysel olarak incelenmesi imkansız veya çok zor olan durağan türleri ve bileşikleri de içeren (mesela kısa ömürlü ara birimler, geçiş yapıları ve benzerleri gibi) kesin veya potansiyel reaksiyonlar üzerinde çalışmak için kullanılmaktadır._

* * *

**_\[1\] Not:_**_Gaussian 09; (Intel EM64T veya Intel Itanium2 IA64 mimarileri üzerindeki) Linux platformlarda veya bunlardan oluşan PC kümelerinde (paralel ortamda) çalıştırılabilmektedir._

* * *

**ⵐ** Gaussian 09 ODTU BİDB bünyesindeki PC Kümesi üzerinde paralel ortamda ve yüksek performanslı donanım imkanları ile kullanılabilir.

**ⵐ**PC Kümesi ULAKBİM Yüksek Başarımlı ve Grid Hesaplama Merkezi, TR-Grid servisi tarafından yönetilmekte ve yazılımları kullanmak için TR-Grid üyesi olmak gerekmektedir.

**ⵐ** Konuyla ilgili bilgi almak için **[http://www.truba.gov.tr/](http://www.truba.gov.tr/)** adresine göz atabilir ve grid kullanıcısı olmak için _**grid-teknik (at) ulakbim.gov.tr**_ adresine elektronik posta gönderebilirsiniz.

**FAYDALI BAĞLANTILAR**

- **[https://docs.truba.gov.tr/TRUBA/kullanici-el-kitabi/arf/uygulama-kilavuzlari/Gaussian/index.html](https://docs.truba.gov.tr/TRUBA/kullanici-el-kitabi/arf/uygulama-kilavuzlari/Gaussian/index.html)**

* * *

_**Bize ulaşın:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *