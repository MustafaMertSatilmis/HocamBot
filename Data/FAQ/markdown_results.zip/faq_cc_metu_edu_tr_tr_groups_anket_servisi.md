[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Anket Servisi

|     |
| --- |
| [ODTÜ anket servisine nasıl başvurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-basvurabilirim) |
| [Anket servisi ile anonim (yanıtların kime ait olduğu bilinmeyen) veya anonim olmayan (yanıtların kime ait olduğu bilinen) ya da herkese açık/sadece belli kişilere açık anketler oluşturabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/anket-servisi-ile-anonim-yanitlarin-kime-ait-oldugu-bilinmeyen-veya-anonim-olmayan-yanitlarin) |
| [Anket servisi üzerinde nasıl anket oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/anket-servisi-uzerinde-nasil-anket-olusturabilirim) |
| [Bir anketi aktive ettikten sonra üzerinde değişiklik yapabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/bir-anketi-aktive-ettikten-sonra-uzerinde-degisiklik-yapabilir-miyim) |
| [Erişim bileti (token) nedir?](https://faq.cc.metu.edu.tr/tr/sss/erisim-bileti-token-nedir) |
| [ODTÜ anket servisi ile ilgili soru veya sorunlarımı nereye iletebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-ile-ilgili-soru-veya-sorunlarimi-nereye-iletebilirim) |
| [ODTÜ Anket Servisi kapsamında kullanılan Limesurvey yazılımı hakkında nereden bilgi alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-kapsaminda-kullanilan-limesurvey-yazilimi-hakkinda-nereden-bilgi-alabilirim) |
| [ODTÜ anket servisinden kimler yararlanabilir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisinden-kimler-yararlanabilir) |
| [ODTÜ anket servisine nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-erisebilirim) |
| [Oluşturduğum anketleri yayınlamadan test edebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketleri-yayinlamadan-test-edebilir-miyim) |
| [Oluşturduğum anketlerin yanıtlarını nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketlerin-yanitlarini-nasil-gorebilirim) |

[![Subscribe to Anket Servisi](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/33/all/feed "Subscribe to Anket Servisi")