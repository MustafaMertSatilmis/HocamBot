[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# IP ve MAC

|     |
| --- |
| [Android Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [BİDB neden IP erişimlerini kısıtlıyor?](https://faq.cc.metu.edu.tr/tr/sss/bidb-neden-ip-erisimlerini-kisitliyor) |
| [Bilgisayarımın Ethernet kartının MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [Bilgisayarımın IP erişimi kısıtlanmış. Nedenini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisimi-kisitlanmis-nedenini-nasil-ogrenebilirim) |
| [Bilgisayarımın IP erişiminin yeniden açılması için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisiminin-yeniden-acilmasi-icin-ne-yapmaliyim) |
| [Bilgisayarımın kablosuz ağ kartının MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-kablosuz-ag-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [Blackberry Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/blackberry-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [IP adresimi nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim) |
| [Nintendo DS için MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/nintendo-ds-icin-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [Nintendo Wii üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/nintendo-wii-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [Nokia E5/E7 üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/nokia-e5e7-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [Samsung Akıllı Telefonlarda MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/samsung-akilli-telefonlarda-mac-fiziksel-adresini-nasil-ogrenebilirim) |
| [Windows Mobil Cihazında MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-mobil-cihazinda-mac-fiziksel-adresini-nasil-ogrenebilirim) |

[![Subscribe to IP ve MAC](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/47/all/feed "Subscribe to IP ve MAC")