[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yeni-kayit-olan-ogrenciler#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-11-2024 **Görüntüleme:** 91304


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/new-students "New Students")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yeni-kayit-olan-ogrenciler "Yeni Kayıt Olan Öğrenciler")

# Yeni Kayıt Olan Öğrenciler

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

**Yeni Kayıt Olan Öğrenciler için Bilişim Hizmetleri Konusunda Yardımcı Bilgiler**

**YKS Kayıt programı ile ilgili bilgiler için [https://oidb.metu.edu.tr/tr/duyuru/yks-kayit-kilavuzu](https://oidb.metu.edu.tr/tr/duyuru/yks-kayit-kilavuzu) sayfasını inceleyiniz.**

Bunların dışında kalan YKS Kayıt Programı hakkında iletmek istediğiniz sorularınız için [tıklayınız](https://www.metu.edu.tr/tr/form/yks-kayit-programi-basvurulari-ile-ilgili-bilgi-talebi). **(Lütfen, gönderilecek birim kısmını seçerken konunun muhatabı olan birimi seçiniz)**.

ODTÜ İnteraktif Harita servisine ulaşmak için  [http://map.metu.edu.tr/](http://map.metu.edu.tr/) adresini ziyaret edebilirsiniz.

![ODTÜ Harita Servisi](https://faq.cc.metu.edu.tr/tr/system/files/u2/harita_servisi_1.png)

**YKS KAYIT PROGRAMI ilgili sıkça sorulan sorulara ve cevaplara bu [bağlantıdan](https://oidb.metu.edu.tr/tr/duyuru/yks-kayit-kilavuzu) erişebilirsiniz.**

**Yeni Kayıt Yaptıracak ODTÜ Öğrencilerinin Yapması Gereken İşlemler**

**İlk defa ODTÜ öğrencisi olanlar**

Üniversitemize yeni kayıt yaptıracak öğrencilerimiz, tüm işlemlerden önce [https://useraccount.metu.edu.tr/newstudent](https://useraccount.metu.edu.tr/newstudent/) adresinden kullanıcı kodu oluşturma işlemlerini tamamlamalıdırlar. Bu işlem sonunda, edineceğiniz kullanıcı kodu ve şifre ile ODTÜ Kayıt Programı ve ODTÜ Bilişim Servislerini kullanabilirsiniz. Başvurunuz sırasında mümkünse hotmail.com, outlook.com, live.com dışında bir eposta adresi kullanınız. Microsoft e-posta hizmetlerine gönderimlerde sıkıntı yaşanabilmektedir.

Kullanıcı kodu ( **kullanıcı kodunuz “e” harfi ile başlayıp öğrenci numaranızın ilk 6 rakamı olarak sistemlerimize otomatik olarak tanımlanmıştır. e123456 gibi)** ve şifrenizi (şifrenizi siz belirliyorsunuz) oluşturduktan sonra, **ODTÜ Kayıt Programı ve ODTÜ Bilişim Servislerini** bu kullanıcı kodunuz ve şifreniz ile kullanabilirsiniz.

**Sistemlere girişte kullanıcı kodunuzu yazarken @metu.edu.tr uzantısını yazmayınız.**

**Tüm** **ODTÜ Bilişim Servislerine giriş yapabilmek için ODTÜ kullanıcı** **kodu** **kullanılmalıdır (sadece e123456 şeklinde olmalı, sonunda @metu.edu.tr uzantısı içermemelidir, ayrıca [isim.soyisim@metu.edu.tr](mailto:isim.soyisim@metu.edu.tr) şeklinde de ODTÜ Bilişim Servislerine giriş yapılamamaktadır.**)

**Daha önce ODTÜ öğrencisi olanlar**

Daha önce ODTÜ öğrencisi olan ve en fazla bir dönem ara verdikten sonra yeniden kayıt yaptıran öğrencilerin kullanıcı kodları kapatılmamıştır. Bu durumdaki öğrencilerimize yeni şifre verilmeyecek olup mevcut kullanıcı kodu ve şifrelerini kullanabileceklerdir.

Bu durumda olup kullanıcı şifresini hatırlamayan öğrenciler [useraccount.metu.edu.tr](https://useraccount.metu.edu.tr/) adresinde yer alan ODTÜ Kullanıcı Hesap Yönetimi sayfasındaki “Şifremi Unuttum” bağlantısına tıklayarak yeni şifrelerini elde edebilirler.

Bir dönemden fazla öğrenciliğe ara vermiş olan eski öğrencilerin kullanıcı kodları yeniden açılmaktadır. Bu durumdaki öğrencilerimiz ilk defa ODTÜ öğrencisi olanların izleyeceği adımları uygulayacaklardır.

**Kullanıcı Kodları**

Üniversitemizin bilişim kaynaklarını kullanabilmeniz için sunucularımızda kayıtlı kullanıcı kodu ve parolanızın olması gerekir. Kullanıcı kodunuz ve parolanız ile Öğrenci İşleri Bilgi Sistemi, ODTÜClass, ODTÜ kablolu ve kablosuz ağları, e-posta servisi, PC salonları gibi ODTÜ Bilişim Servislerini kullanabilirsiniz.

Üniversitemize kayıt hakkı kazanan, kullanıcı kodu olmayan tüm yeni öğrenciler için merkezi sunucu sistemler üzerinde otomatik olarak kullanıcı kodları açılmaktadır. Kullanıcı kodunuz, öğrenci numaranızın ilk 6 rakamının başına “e” harfi getirilerek oluşmaktadır. ( **Öğrenci numaranız 123456-7 ise kullanıcı kodunuz e123456’dır.**)

Kullanıcı kodları ve parolalarla ilgili genel bilgilere; [http://kullanicikodu.bidb.odtu.edu.tr](http://kullanicikodu.bidb.odtu.edu.tr/) adresinden ulaşabilirsiniz.

Kullanıcı kodları Üniversite yönetimince kabul edilmiş olan ODTÜ Bilişim Kaynakları Kullanım Politikaları’na uygun şekilde kullanılmalıdır. Bu politikaya [http://bilisim-etigi.odtu.edu.tr](http://bilisim-etigi.odtu.edu.tr/) adresinden erişilebilir.

**Parola İşlemleri**

[useraccount.metu.edu.tr](https://useraccount.metu.edu.tr/) adresinde bulunan ODTÜ Kullanıcı Hesap Yönetim sayfasını istediğiniz zaman parolanızı değiştirmek ve kurtarma e-posta adresinizi güncellemek için kullanabilirsiniz. İlgili adrese kullanıcı kodunuz ve eposta adresinize gönderilen etkinleştirme bağlantısı aracılığı ile giriş yapıp “Şifre Değiştir” düğmesine tıklayınız.

**Parola unutulduğunda ne yapılır?**

Bu konu hakkında bilgiye [https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-koduma-ait-sifremi-unut...](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim) adresinden ulaşabilirsiniz.

**YKS kayıt formu nasıl doldurulur?**

YKS kayıt formu, [ykskayit.metu.edu.tr](https://ykskayit.metu.edu.tr/) adresindeki yönergeler dikkatle takip edilerek doldurulmalıdır.

**Öğrenci İşleri Daire Başkanlığı'nın Sıkça Sorulan Soruları:**

Öğrenci İşleri Daire Başkanlığı'nın sıkça sorulan sorularına [http://oidb.metu.edu.tr/sikca-sorulan-sorular-sss](http://oidb.metu.edu.tr/sikca-sorulan-sorular-sss) adresinden erişebilirsiniz.

**Kimlik kartları ilgili soru-cevaplar**

Öğrencilerimiz kimlik kartları ilgili işlemleri ve süreci [Kayıt Kılavuzundaki](https://oidb.metu.edu.tr/tr/duyuru/yks-kayit-kilavuzu) **Kayıt İşlemleri** başlığının altındaki **Öğrenci Kimlik Kartları** bölümünden takip edebilir.

**PC salonları ve diğer servislerin tanıtımı**

[PC Salonları Çalışma Saatleri](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-calisma-saatleri)

[PC Salonları Kullanım Kuralları](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-kullanim-kurallari)

**Kablolu/kablosuz ağa nasıl bağlanılır?**

[ODTÜ'de kablosuz bilgisayar ağı var mı, nasıl faydalanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kablosuz-bilgisayar-agi-var-mi-nasil-faydalanabilirim)

Kablosuz ağa erişmek isteyen kullanıcılarımız, kampüsümüzdeki [eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam) ve [meturoam](https://faq.cc.metu.edu.tr/tr/sss/meturoam) yayınlarına kullanabilirler.

**Bilgi güvenliği hakkında önemli bilgiler**

Bilgi güvenliği hakkında sıkça sorulan sorulara ve dikkat edilmesi gereken bilgilere aşağıdaki bağlantıdan erişebilirsiniz.

[https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

Kullanıcı kodu **(kullanıcı kodunuz “e” harfi ile başlayıp öğrenci numaranızın ilk 6 rakamı olarak sistemlerimize otomatik olarak tanımlanmıştır. e123456 gibi)** ve şifrenizi (şifrenizi siz belirliyorsunuz) oluşturduktan sonra, **ODTÜ Kayıt Programı** ve **ODTÜ Bilişim Servislerini** bu kullanıcı kodunuz ve şifreniz ile kullanabilirsiniz.