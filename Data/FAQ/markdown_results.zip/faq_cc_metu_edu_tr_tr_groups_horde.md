[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/horde#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Horde

|     |
| --- |
| [Beyaz listeye e-posta adreslerini nasıl eklerim?](https://faq.cc.metu.edu.tr/tr/sss/beyaz-listeye-e-posta-adreslerini-nasil-eklerim) |
| [Gelen e-postaları nasıl filtreleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-postalari-nasil-filtreleyebilirim) |
| [Horde 5 sürümünde yenilikler](https://faq.cc.metu.edu.tr/tr/sss/horde-5-surumunde-yenilikler) |
| [Horde bir iletinin tam başlık bilgisini nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim) |
| [Horde dizin listesinde görünmeyen posta kutularını nasıl görüntüleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-dizin-listesinde-gorunmeyen-posta-kutularini-nasil-goruntuleyebilirim) |
| [Horde Eposta iletilerimi nasıl silebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-eposta-iletilerimi-nasil-silebilirim) |
| [Horde göndericileri karaliste veya beyaz listeye nasıl ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-gondericileri-karaliste-veya-beyaz-listeye-nasil-ekleyebilirim) |
| [Horde ile gönderilen e-postalarda eklerin kaydedilmesini nasıl sağlayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-gonderilen-e-postalarda-eklerin-kaydedilmesini-nasil-saglayabilirim) |
| [Horde ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim) |
| [Horde ile tüm e-postalarımı nasıl indirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim) |
| [Horde iletilere nasıl imza ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletilere-nasil-imza-ekleyebilirim) |
| [Horde iletileri farklı klasörlere nasıl kopyalayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-kopyalayabilirim) |
| [Horde iletileri farklı klasörlere nasıl taşıyabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-tasiyabilirim) |
| [Horde iletileri nasıl filtreleyebilir, iletebilir, engelleyebilir veya otomatik olarak cevap verebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-nasil-filtreleyebilir-iletebilir-engelleyebilir-veya-otomatik-olarak-cevap) |
| [Horde nasıl okundu bildirimi alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-nasil-okundu-bildirimi-alabilirim) |
| [Horde oluşturduğum bir iletiye nasıl dosya ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-olusturdugum-bir-iletiye-nasil-dosya-ekleyebilirim) |
| [Horde Webmail de bir adresi yanlışlıkla kara listeye ekledim. Nasıl geri alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-webmail-de-bir-adresi-yanlislikla-kara-listeye-ekledim-nasil-geri-alabilirim) |
| [Horde Yardım sayfasına nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-yardim-sayfasina-nasil-ulasabilirim) |
| [Horde'de çöp kutusunu nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/hordede-cop-kutusunu-nasil-kullanabilirim) |
| [Kara listeye nasıl e-posta eklerim?](https://faq.cc.metu.edu.tr/tr/sss/kara-listeye-nasil-e-posta-eklerim) |
| [Posta kutusu ve dizin görüntüleme seçenekleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/posta-kutusu-ve-dizin-goruntuleme-secenekleri-nelerdir) |

[![Subscribe to Horde](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/60/all/feed "Subscribe to Horde")