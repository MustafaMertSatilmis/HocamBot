[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/windows-10-bilgisayarimdan-eduroam-agina-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 13362


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-eduroam-wireless-network-using-my-windows-10-computer "How can I connect to eduroam wireless network using my Windows 10 computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/windows-10-bilgisayarimdan-eduroam-agina-nasil-baglanabilirim "Windows 10 bilgisayarımdan eduroam ağına nasıl bağlanabilirim?")

# Windows 10 bilgisayarımdan eduroam ağına nasıl bağlanabilirim?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Windows 10 işletim sistemi kullanıyorsanız eduroam bağlantısı için bir program kurulmasına gerek yoktur.

İşletim sisteminde görüntülenen kablosuz ağlar listesinde eduroam ağını seçerek kullanıcı kodu ve şifrenizi kullanarak bağlantı sağlayabilirsiniz. Lütfen kullanıcı kodunuzun sonuna @metu.edu.tr yazmayı unutmayınız (kullanıcı@metu.edu.tr şeklinde yazılmalıdır)