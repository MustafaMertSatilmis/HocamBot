[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kamu-kurumu-olmayan-kurumlara-kep-ile-evrak-gonderebilir-miyim-nasil#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 1446


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kamu-kurumu-olmayan-kurumlara-kep-ile-evrak-gonderebilir-miyim-nasil)

# Kamu kurumu olmayan kurumlara KEP ile evrak gönderebilir miyim, nasıl?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Kurum dışı evrakın dağıtım ekleme bölümünde gönderilecek yer tanımlama ekranında "Tüzel Şahıs" seçilir.

Açılan ekranda bulunan Tüzel Şahıs açılır listesine bastıktan sonra sağ tarafta açılan bölümden üstteki "ARA" metin kutusuna ilgili kurumun ismi yazılarak aranır. Halihazırda kayıt var ise seçiliri, yok ise önceki ekrana dönülür.

Hazır kayıt seçildiğinde KEP adresi gelmez ise veya zaten halihazırda kurum kayıtlı değil ise Tüzel Şahıs ekranındaki ilgili zorunlu alanlar doldurulur.

Üstteki Tamam butonuna basılarak işlem tamamlanır.

Evrak imzaları tamamlandıktan sonra KEP ile iletilmek üzere Evrak ve Arşiv Müdürlüğüne ulaşacaktır. Daha fazla bilgi için Evrak ve Arşiv Müdürlüğüne ulaşılabilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.