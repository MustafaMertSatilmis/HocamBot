[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Elektronik Listeler

|     |
| --- |
| [E-liste Servisi hakkında genel bilgilere nasıl ulaşırım?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-servisi-hakkinda-genel-bilgilere-nasil-ulasirim) |
| [ODTÜ personeliyim fakat "genel-duyuru", "aras-gor-duyuru" ve/ya "ogr-uye-duyuru" listelerine gelen mesajları göremiyorum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-fakat-genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-gelen) |
| [ODTÜ'de ögrenciyim; "genel-duyuru" listesine üye olabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-ogrenciyim-genel-duyuru-listesine-uye-olabilir-miyim) |

[![Subscribe to Elektronik Listeler](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/11/all/feed "Subscribe to Elektronik Listeler")