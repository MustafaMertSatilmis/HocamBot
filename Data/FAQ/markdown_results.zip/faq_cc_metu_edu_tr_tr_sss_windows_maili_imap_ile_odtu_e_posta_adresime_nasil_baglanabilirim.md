[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/windows-maili-imap-ile-odtu-e-posta-adresime-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-03-2021 **Görüntüleme:** 17502


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-windows-mail-my-metu-mail-address-imap "How can I connect Windows mail to my METU mail address with IMAP?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/windows-maili-imap-ile-odtu-e-posta-adresime-nasil-baglanabilirim "Windows Mail’i IMAP ile ODTÜ e-posta adresime nasıl bağlanabilirim?")

# Windows Mail’i IMAP ile ODTÜ e-posta adresime nasıl bağlanabilirim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

- Başlat çubuğuna “mail” yazarak mail uygulamasını aratın ve Windows’un mail uygulamasını başlatın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/winmail_imap_tr_1.png)

- Uygulama açıldıktan sonra sol taraftaki menüden en üstteki üç çizgi sembolüne tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/winmail_imap_tr_2.png)

- Yeni açılan pencerede Hesaplar butonuna tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/winmail_imap_tr_3.png)

- Sağ tarafta açılan pencerede Hesap ekle butonuna tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/winmail_imap_tr_4.png)

- Yeni açılan pencerede Gelişmiş kurulum seçeneğini tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/windows-mail-tr-1.png)

Ardından İnternet e-posta seçeneğini seçin.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/windows-mail-tr-2.png)

- Açılan pencerede alanları doğru şekilde doldurun. Bilgilerinizi doğru bir şekilde girdikten sonra oturum aç butonuna tıklayın.
- ![](https://faq.cc.metu.edu.tr/tr/system/files/u2/windows-mail-tr-3.png)