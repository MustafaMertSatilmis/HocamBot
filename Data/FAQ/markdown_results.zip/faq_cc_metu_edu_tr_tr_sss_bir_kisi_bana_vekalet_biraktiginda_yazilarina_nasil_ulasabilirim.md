[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-kisi-bana-vekalet-biraktiginda-yazilarina-nasil-ulasabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-12-2022 **Görüntüleme:** 5674


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-kisi-bana-vekalet-biraktiginda-yazilarina-nasil-ulasabilirim)

# Bir kişi bana vekalet bıraktığında yazılarına nasıl ulaşabilirim?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Bir kişiye vekalet ederken, o kişiye vekaleten yapılan sevk işlemleri ise vekalet edilen kişinin adına yapılmaktadır. Bunun için kendi hesabınızdan EBYS'ye giriş yaptıktan sonra "Vekaletler" bölümünden vekalet edilen kişinin hesabına geçiş yapılması gerekmektedir.

Bir kişiye vekalet ederken, o kişiye vekaleten imzalanan belgeler kişisel olarak imzalandığından, imzayı atan kişinin hesabından görünmektedir. Vekaleten imzalanan belgelere daha sonra erişmek istenirse aşağıda ismi verilen menüler kullanılabilir:

EBYS -> Kurum Dışı Yazışma -> Giden Yazışmalar -> Vekalet Ettiğim Belgeler

EBYS -> Kurum İçi Yazışma -> Giden Yazışmalar -> Vekalet Ettiğim Belgeler

**ÖNEMLİ:** Mevcut EBYS altyapısında evrak üzerinde e-imzalama işlemi yapılacağı zaman, evrakta belirtilen imzacı ile e-imzalama işlemini yapacak kişinin karşılaştırması yapılamamaktadır. Bu nedenle vekaleten evrak imzalamanız gerektiğinde, vekalet alan kişi olarak evrak üzerindeki imzacı alanında kendi bilgilerinizin göründüğünü kontrol etmeniz; eğer evrakın imzacı alanında vekalet ettiğiniz kişinin bilgileri görünüyor ise, evrakı iade ederek yazıyı oluşturan kişiden imzacı alanında sizin bilgilerinizin vekaleten seçilmesini sağlamanız gerekmektedir. Bu değişiklik sonrasında evrakı vekaleten imzalayabilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.