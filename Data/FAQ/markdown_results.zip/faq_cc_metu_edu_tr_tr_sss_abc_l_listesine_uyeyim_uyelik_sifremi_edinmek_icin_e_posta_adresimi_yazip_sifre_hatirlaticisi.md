[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-uyelik-sifremi-edinmek-icin-e-posta-adresimi-yazip-sifre-hatirlaticisi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8308


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-member-xyz-l-list-i-clicked-password-reminder-button-obtain-my-list-membership-password-i "I am a member of \"xyz-l\" list. I  clicked on the password reminder button to obtain my list membership password; but  I did not receive the password yet. Is there something wrong? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-uyelik-sifremi-edinmek-icin-e-posta-adresimi-yazip-sifre-hatirlaticisi "\"abc-l\" listesine üyeyim. Üyelik  şifremi edinmek için e-posta adresimi yazıp şifre hatırlatıcısı butonuna  tıkladım ancak şifre bana ulaşmadı. Neden olabilir?")

# "abc-l" listesine üyeyim. Üyelik şifremi edinmek için e-posta adresimi yazıp şifre hatırlatıcısı butonuna tıkladım ancak şifre bana ulaşmadı. Neden olabilir?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Büyük olasılıkla girdiğiniz e-posta adresi listeye üye bir adres değildir. Bir listeye üye olmadiğınız halde liste mesajlarını alıyorsanız bunun sebebi mesaj yönlendirme olabilir. Yani eğer mesajlarınızı birden fazla e-posta adresi ile takip ediyor ve bu adresler arasında yönlendirme kullanıyorsanız, liste mesajlarının gönderildiği e-posta adresiniz ile listeye üyelik için kullandığıniz e-posta adresi farklı olabilir. Bu konuyla ilgili olarak listenin yöneticisiyle görüşebilirsiniz.

Liste yöneticisinin e-posta adresini bilmiyorsanız **abc-l-owner![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr** adresinden liste yöneticisine ulaşabilirsiniz.

(Yukarıda geçen "abc-l" ifadesi liste ismi için örnek olarak verilmiştir)