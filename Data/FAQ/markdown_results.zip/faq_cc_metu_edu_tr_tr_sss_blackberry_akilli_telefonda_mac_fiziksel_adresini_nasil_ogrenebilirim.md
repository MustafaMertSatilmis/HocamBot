[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/blackberry-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 9201


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-blackberry-smartphone "How can I find out the MAC (physical) address on a BlackBerry Smartphone?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/blackberry-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim "Blackberry Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Blackberry Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

**BlackBerry 4.5 - 5.0 arası cihaz yazılım sürümleri için:**

1.  Ana ekrandan Seçenekler> Durum a gelin.
2. WLAN MAC alanında akıllı telefonun MAC adresini gösterilmektedir.


**BlackBerry 6 - 7.1 arası sürümler için:**

1. Kurulum>Seçenekler>Cihaz>Cihaz ve Durum Bilgisini seçin.
2. WLAN MAC alanında akıllı telefonun MAC adresi gösterilmektedir.

**BlackBerry 10 OS sürümü için:**

1. Ana ekrandan Ayarlar>Ağ Bağlantıları>Kablosuz (WiFi)> Gelişmişi seçin.
2. Tanı Bilgisi açılır menüsünden, Cihaz Bilgileri’ne gelin.
3. Fiziksel adress alan akıllı telefon için MAC adresini göstermektedir.

**Blackberry Playbook Tablet bilgisayar için:**

1. Ana ekranda Seçeneklere gelin.
2. Hakkında’yı seçin.
3. Açılır menüden Ağ’ı seçin.