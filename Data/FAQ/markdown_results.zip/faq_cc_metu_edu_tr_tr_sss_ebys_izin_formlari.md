[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebys-izin-formlari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 01-08-2023 **Görüntüleme:** 34289


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebys-izin-formlari)

# EBYS İzin Formları ile ilgili Sıkça Sorulanlar

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

**EBYS İzin Formlarını Kimler Doldurabilir?**

EBYS’de yer alan Yıllık ve Mazeret İzin Formları Üniversitemizde görev yapmakta olan Akademik Personel;

- öğretim üyeleri
- öğretim görevlileri
- araştırma görevlileri
- sözleşmeli yabancı uyruklu öğretim elemanları

ve İdari Personel;

- devlet memurları
- 657 Sayılı Devlet Memurları Kanunu’nun 4/B maddesi kapsamında görev yapmakta olan sözleşmeli personel
- projelerde proje süresince istihdam edilmek üzere sözleşmesinde belirtilen süre ile görev yapan proje sözleşmeli personeli
- doktora sonrası sözleşmeli araştırmacı olarak görev yapan personel
- sürekli işçi ve geçici işçi personel

tarafından doldurulabilir.

**EBYS’den Doldurulacak İzin Formları ile ilgili Genel Kurallar Nelerdir?**

EBYS’den doldurulacak yıllık ve mazeret İzin formları için bilgilendirme dokümanına [**bu bağlantıdan**](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-formlari-bilgilendirme-dokumani_2023.pdf) erişebilirsiniz.

**EBYS'den İzin Formu Dolduracağım, Forma Nasıl Ulaşabilirim?**

- EBYS'ye [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) adresinden giriş yapınız. Girişte sorun yaşarsanız [https://faq.cc.metu.edu.tr/tr/sss/ebysye-nasil-giris-yapilir](https://faq.cc.metu.edu.tr/tr/sss/ebysye-nasil-giris-yapilir) adresindeki bilgilere göz atınız. EBYS'ye kampus dışından [VPN yoluyla](http://faq.cc.metu.edu.tr/tr/sss/kampus-disindan-ebysye-giris-yapilabilir-mi) erişilebilmektedir.
- Sisteme girdikten sonra, solda bulunan "E-Formlar > İzin Formları" başlığına tıklayarak **Yıllık İzin Formu** ve **Mazeret İzin Formu** bağlantılarından ilgili forma erişebilirsiniz.

**EBYS'den İzin Formu Doldururken Nelere Dikkat Etmeliyim?**

- İzin formunda yer alan personel bilgileri (Sicil, Ad, Soyad, Statü, Unvan, Birimi) ile geçmiş izinlere göre hesaplanan izin bilgileri (Geçen Yıldan Devreden Gün, Bu Yıl Hak Edilen Gün, Toplam Gün, Bu Yıl Kullanılan Gün, Kalan Gün) İnsan Kaynakları Yönetim Sisteminden (İKYS) anlık olarak çekilerek gösterilir. Bu nedenle form üzerinde sadece talep ettiğiniz izne ait bilgileri (İznin Süresi, Başlama Tarihi, Bitiş Tarihi, Göreve Başlama Tarihi), iletişim bilgilerini (Telefon Numarası, Adres), vekalet verilecek Kullanıcıyı (isteğe bağlı) ve formu sevk edeceğiniz yöneticiyi ekranda görülen uyarılara uygun şekilde doldurmanız ya da seçmeniz yeterlidir.
- Formda yanında \* (yıldız) işareti olan alanların doldurulması zorunludur.

- **İzin bitiş tarihi** olarak izinli olunan son günün tarihi belirtilir.

- Yıllık ve Mazeret izni sonunda “göreve başlama tarihi” için iznin bitiş tarihini takip eden ilk iş günü seçilmelidir.

- Örneğin 18 Ocak 2021 Pazartesi günü başlayıp 22 Ocak 2021 Cuma gününü kapsayarak tamamlanan 5 günlük bir izin yazılmak istendiğinde başlangıç tarihi 18.01.2021, bitiş tarihi 22.01.2021 ve göreve başlama tarihi 25 Ocak 2021 Pazartesi olarak seçilmelidir. Vardiyalı çalışanlar tarih seçimlerini doldurma ekranındaki kutucuğu işaretleyerek yapmalıdır.
- Tam günden farklı bir izin ihtiyacı olması durumunda (örnek: 0,5 gün, 1,5 gün vb.) amir onayı alınarak izin kullanılabilir.

- İzin formu dolduran personel, yerine vekâlet edecek kişinin ismini **"Vekalet Verilecek Kullanıcı"** alanının yanındaki oka tıkladığında gelecek listeden seçebilir. Bu listede tüm üniversite personelinin bilgisi görüntülenmekte olup, vekalet vereceğiniz kişinin bilgisini "Ara" alanına girmeye başlarak görüntüleyip seçebilirsiniz. Vekalet izin formu aracılığı ile aynı anda sadece tek bir kişiye bırakılabilmektedir. Buna ek olarak başka kişilere de vekalet bırakılacak ise EBYS'nin vekalet verme bölümünden ilgili tanımlamalar ayrıca yapılmalıdır. [http://faq.cc.metu.edu.tr/tr/sss/ebysde-vekalet-verme-islemi-nasil-yapilir](http://faq.cc.metu.edu.tr/tr/sss/ebysde-vekalet-verme-islemi-nasil-yapilir) İzin formunda belirtilen vekalet tanımı sistem tarafından otomatik olarak yapılacaktır.

- Formun gönderilebilmesi için “Yönetici Bilgileri” kısmında görünen amirin mutlaka işaretlenmesi gerekmektedir.

**EBYS'den İzin formu Doldurdum, Formun Ne Aşamada Olduğunu Nasıl Görebilirim?**

- EBYS’den doldurduğunuz tüm izin formlarına EBYS'de **İş Akış Yönetimi > Geçmiş** bölümüne giriş yaptığınızda görünecek olan "İzin Formu" başlığı altından erişebilirsiniz. Göremediğinizi düşündüğünüz formlar varsa bu ekrandaki tarih filtresinden doldurduğunuz formların tarihini içeren bir tarih aralığı (Başlangıç - Bitiş) seçmeniz gerekmektedir. Kişiler kendi doldurdukları izin formlarını görebilmek için aynı ekranda bulunan "Tür" alanından "Gönderilenler" seçeneğini seçmelidir.
- Yönetici konumundaki kişiler kendi doldurdukları izin formlarını görebilmek için aynı ekranda bulunan "Tür" alanından "Gönderilenler" seçeneğini seçmelidir. (Buradaki seçeneklerden "Onaylar" seçeneği yöneticinin kendi birimindeki personelin onayladığı izin formlarını; "Gönderilenler" seçeneği ise yöneticinin kendi doldurduğu izin formlarını görmek için kullanılmaktadır.)

**İzinden Erken ya da Geç Dönmem Gerekti; İzin Formunda Tarih Değişikliği Yapabilir miyim?**

İzinden erken dönecek ya da izin süresini uzatacak olursanız yine EBYS'deki "E-Formlar > İzin Formları" bölümü altından ulaşılan **İzin İptal İşlemi** bağlantısını kullanarak akışta olan izin formunuzu iptal etmelisiniz. İzin İptal İşlemi bağlantısına tıkladıktan sonra gelen ekranda iptal etmek istediğiniz formu seçip iptal işlemini gerçekleştirmek için "İptal" butonuna tıklamalısınız. Bir form iptal edildiğinde bu işlem geri alınamaz; bu nedenle iptal işlemi öncesinde gerçekten iptal etmek istediğinizden emin olunuz. İlgili form iptal edildikten sonra, değişecek tarihlere göre yeniden yıllık ya da mazeret izin formu doldurmalı ve tekrar onaya göndermelisiniz.

**EBYS üzerinden doldurulan yıllık izin ve mazeret izin formları sürecinde, Genel Sekreterlik kararı gereği 10.04.2023 tarihinden itibaren geçerli olmak üzere “İzin İptal Süreci” ile ilgili yeni bir düzenlemeye gidilmiştir. Bu düzenlemeye göre;**

> - İzin formu doldurulduktan sonra izin kullanımına ilişkin tarih değişikliği veya izin iptali için;
>
>   - İzin dönüşü göreve başlama tarihi geçmeyen bir form olması durumunda, ilgili form “İzin İptal” bölümünden görülebilir ve henüz tamamlanmayan izin sürecini sonlandırmak üzere iptal işlemi başlatılır.
>   - “İzin iptal” bölümünde görülen izin formu henüz “İzin İşleme” işlemi yapılmamışsa, yönetici onayı gerekmeden personel tarafından doğrudan iptal edilebilir.
>   - İptal işlemi sonrası akış sonlanır. Farklı tarihlerde izin kullanılacak ise yeni bir izin formu doldurulur.
>
> - Doldurulan izin formunun “İzin İşleme” işlemi yapıldıktan sonra izin uzatma, izni yarıda kesme, sağlık raporu vb. nedenlerle EBYS üzerinden iptal edilmek istenmesi halinde;
>
>   - İzin dönüşü göreve başlama tarihi geçmeyen bir form olması durumunda, ilgili form “İzin İptal” bölümünden görülebilir ve personel tarafından iptal işlemi başlatılır.
>   - İptal edilmesi istenilen form, izin vermeye yetkili ilk amirin “Onayına” gider.
>   - İzin vermeye yetkili ilk amir iptal işlemini uygun görür ise “İptal et” butonu ile izin formunu iptal eder.
>   - İptal işlemi sonrası akış sonlanır. Yeni bir izin formu doldurulur.
>
> - İzin dönüşü göreve başlama tarihi geçen formlar iptal edilemez ve dolayısıyla bu formlar “İzin İptal” bölümünde listelenmez.

**Kullandığım İzin Esnasında Sağlık Raporu Almam Gerekti, Doldurduğum İzin Formum ile ilgili Ne Yapmalıyım?**

İzninizi kullanırken sağlık raporu almanız durumunda ve doldurduğunuz formda belirtilen göreve başlama tarihi geçmediyse; yukarıdaki belirtildiği şekilde akışta olan izin formunuzu iptal etmeli ve rapor tarihine kadar olan kısım için yeniden izin formu doldurmalısınız. Ancak, ilgili formda belirtilen göreve başlama tarihi geçtiyse form iptal edilemez. Bu durumda resmi yazı yoluyla PDB'ye başvurulmalıdır.

**İzin Formu Doldurmak İstediğimde "Daha önce doldurduğunuz 2020-IZIN-XXXXX belge numaralı formunuz halen akıştadır." şeklinde bir uyarı alıyorum, Ne Yapmalıyım?**

Bir kerede aynı tipte sadece bir izin formu akışta olabileceğinden bu uyarı alınmaktadır ve akışta olan bir formunuz olduğu anlamına gelmektedir. Yeni bir form doldurabilmek için önce uyarıda bilgisi verilen formu **İzin İptal İşlemi** yaparak iptal etmeniz veya sonlandırılması için birim sekreteriniz/yöneticinizle iletişime geçmeniz gerekmektedir.

**EBYS İzin Formlarıyla ilgili E-posta adresime Gelen Mesajlar Ne Anlama Geliyor?**

Doldurulan izin formuyla ilgili her bir adımda, formu dolduran personele, amirlere ve vekalet verilen kişiye e-posta ile bilgilendirme yapılmaktadır. Benzer şekilde bir izin formu iptal edildiğinde, izni onaylayan tüm amirlere ve varsa sekreterlerine e-posta ile bilgilendirme gider. E-posta bilgilendirmesi içerisinde bilgisi ulaşan forma, gelen e-posta içeriğindeki linke tıklayarak ya da [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) adresine giriş yaparak ulaşılabilir ve gerekiyorsa işlem yapılabilir. İzin formlarıyla ilgili çok fazla e-posta alıyorsanız [http://faq.cc.metu.edu.tr/tr/sss/e-posta-adresime-ebys-ile-ilgili-cok-fa...](http://faq.cc.metu.edu.tr/tr/sss/e-posta-adresime-ebys-ile-ilgili-cok-fazla-mesaj-geliyor) adresindeki bilgilere göz atabilirsiniz.

**Doldurduğum İzin Formunun Çıktısını Almam Gerekiyor mu?**

Normal koşullarda izin taleplerinin gönderim ve onay süreçlerinin EBYS üzerinden elektronik olarak yürütülmesi yeterli görülmekte ve bu nedenle çıktısının alınması gerekmemektedir. Yine de ihtiyaç varsa, doldurulan izin formunun herhangi bir aşamasında söz konusu formun görüntülendiği ekranda bulunan "Yazdır" butonu ile kâğıt çıktısı alınabilir. Çıktısı alınan formun herhangi bir sebeple kurum dışındaki paydaşlara sunulması gerekecekse; alınan çıktı mutlaka formu dolduran personelin birim yöneticisi tarafından ıslak imza ile onaylanmalıdır.

**İzin Formlarıyla ya da EBYS ile İlgili Nereden Destek Alabilirim?**

İzin formlarıyla ilgili karşılaşılabilecek temel sorun formda görüntülenen izin bilgilerinde hata olması olabilir. İzin bilgilerinizde hata olduğunu düşünüyorsanız lütfen bölüm/birim sekreterliğinizle iletişime geçiniz. Bölüm/birim sekreterliğiniz çözülemeyen bir durum olması halinde resmi yazı yoluyla PDB'ye başvurabilir. İzin bilgileri dışında form doldurmaya dair karşılaşılabilecek teknik hatalar [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine eposta ile iletilebilir.

**İzin Formlarıyla ilgili raporlar mevcut mudur?**

EBYS İzin Formları ile ilgili Yönetici ve Sekreterlere Sunulan Raporlarla ilgili bilgilere [**bu adresten**](https://faq.cc.metu.edu.tr/tr/ebys-izin-formlari-raporlar) ulaşabilirsiniz.