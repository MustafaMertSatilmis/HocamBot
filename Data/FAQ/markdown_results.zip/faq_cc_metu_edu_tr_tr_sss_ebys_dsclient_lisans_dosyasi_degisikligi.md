[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-02-2025 **Görüntüleme:** 1730


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/ebys-dsclient-license-file-change "EBYS E-signature Application (DSClient) License File Change")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi "EBYS E-imza Uygulaması (DSClient) Lisans Dosyası Değişikliği")

# EBYS E-imza Uygulaması (DSClient) Lisans Dosyası Değişikliği

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

_**ÖNEMLİ NOT:** Bilgisayarındaki DSClient uygulaması halen 1.5.5 öncesi versiyonda bulunan kullanıcılarımızın bu sayfada belirtilen güncellemeyi yapması gerekmektedir. Ya da lisans dosyası ile ilgili herhangi bir değişiklik yapılması gerekmeden, mevcut DSClient uygulamasını 1.5.5 veya üzeri bir versiyona güncellemek daha pratik bir yöntem olabilir._

* * *

TÜBİTAK Kamu Sertifikasyon Merkezi (KamuSM) e-imza kütüphanelerinin güncellemesi nedeniyle KamuSM altyapısı ile entegre çalışan e-imza uygulamalarında güncelleme yapılması gerektiğini duyurmuştur. Bu doğrultuda, EBYS'de elektronik imza işlemleri için kullanılan DSClient e-imza uygulamasının yeni e-imza kütüphaneleri ile uyumlu hale getirilmesi amacıyla geliştirici firma tarafından bir çalışma yapılmış ve uygulamanın kullandığı lisans dosyası yenilenmiştir. EBYS'de elektronik imzalama işlemi yapan tüm kullanıcılarımızın duyurulan altyapı değişikliğinden etkilenmeden imzalama yapmaya devam edebilmesi için, DSClient uygulamasının lisans dosyasını 14.01.2025 tarihine kadar güncellemesi gerekmektedir. Güncellemenin yapılmaması halinde imza kart okuyucu ve sertifika görüntülenemeyecek; imza atılsa bile 9999 hata kodu alınması söz konusu olacaktır.

Bu değişiklik için herhangi bir kurulum gerekmeyecek olup, kullanıcılarımızın yalnızca "licence.xml" isimli güncel lisans dosyasını [https://portal.synergynow.io/#/\_redirect/A1mLJJ72thgboqTCISfV4s](https://portal.synergynow.io/#/_redirect/A1mLJJ72thgboqTCISfV4s) bağlantısından bilgisayarlarına indirmeleri ve kullanılan işletim sistemi özelinde aşağıda belirtildiği şekilde lisans dosyasını değiştirmeleri yeterli olacaktır.

**Windows kullanıcıları:**

- Windows Görev Yöneticisi > Servisler ekranından JAVA ve DSClient servisleri durdurulmalıdır.
- Güncel lisans dosyası yukarıda belirtilen bağlantıdan bilgisayara indirildikten sonra, ismi yine "licence.xml" olacak şekilde C:\\\Program Files\\DSClient\\lisans dizinine konmalıdır. Sonrasında Windows Görev Yöneticisi > Servisler ekranından DSClient servisi yeniden başlatılmalıdır.
- Bilgisayar yeniden başlatılmalıdır.
- Kullanılan tarayıcı üzerinde [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) sayfası yeniden yüklenerek kullanılmaya devam edilebilir.
- İhtiyaç olması halinde [https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilim...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim) sayfasından Windows için DSClient kurulum bilgilerine; [https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuk...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuklerim) sayfasından JAVA kurulum bilgilerine tekrar göz atılabilir.

**MacOS kullanıcıları:**

- Güncel lisans dosyası yukarıda belirtilen bağlantıdan bilgisayara indirildikten sonra, ismi yine "licence.xml" olacak şekilde /Downloads dizinine kopyalanır.

- Terminal ekranı açılarak aşağıdaki komutlar ile dosya değişikliği işlemi yapılır:

sudo cp Downloads/licence.xml /usr/local/bin/SetupFiles/lisans

sudo launchctl stop com.dsclient.bms

sudo launchctl start com.dsclient.bms

- Kullanılan tarayıcı üzerinde [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) sayfası yeniden yüklenerek kullanılmaya devam edilebilir.
- İhtiyaç olması halinde [https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimin...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimini-nasil-yuklerim) sayfasından MacOS için DSClient kurulum bilgilerine; [https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim) sayfasından JAVA kurulum bilgilerine tekrar göz atılabilir.

**Linux-Ubuntu kullanıcıları:**

- Güncel lisans dosyası yukarıda belirtilen bağlantıdan bilgisayara indirilir (Farklı bir dizine indirilmişse, ismi yine "licence.xml" olacak şekilde ev dizini altındaki Downloads dizinine kopyalanır.)
- Terminal ekranı açılarak aşağıdaki komutlar ile dosya değişikliği işlemi yapılır ve DSclient hizmeti yeniden başlatılır:

sudo cp ~/Downloads/licence.xml /opt/SetupFiles/lisans/sudo systemctl restart dsclientservice.service

- Kullanılan tarayıcı üzerinde [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) sayfası yeniden yüklenerek kullanılmaya devam edilebilir.
- İhtiyaç olması halinde [https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kul...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim) sayfasından Linux-Ubuntu için DSClient ve JAVA kurulum bilgilerine tekrar göz atılabilir.

**Linux-Debian kullanıcıları:**

- Güncel lisans dosyası yukarıda belirtilen bağlantıdan bilgisayara indirilir (Farklı bir dizine indirilmişse, ismi yine "licence.xml" olacak şekilde ev dizini altındaki Downloads dizinine kopyalanır.)
- Terminal ekranı açılarak aşağıdaki komut ile dosya değişikliği işlemi yapılır ve bilgisayar restart edilir:

sudo cp ~/Downloads/licence.xml /opt/SetupFiles/lisans/

sudo systemctl restart dsclientservice.service

- Kullanılan tarayıcı üzerinde [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) sayfası yeniden yüklenerek kullanılmaya devam edilebilir.
- İhtiyaç olması halinde [https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kul...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim) sayfasından Linux-Debian için DSClient ve JAVA kurulum bilgilerine tekrar göz atılabilir.

* * *

Yukarıda tarif edilen adımları uygulamanıza rağmen EBYS'de e-imza kullanımıyla ilgili problem yaşıyorsanız ya da e-imza ile ilgili farklı sorularınız olursa [https://faq.cc.metu.edu.tr/tr/groups/e-imza](http://faq.cc.metu.edu.tr/tr/groups/e-imza) adresindeki sıkça sorulan soruları inceleyebilirsiniz.

EBYS ilgili sorularınızı [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletebilirsiniz.

* * *