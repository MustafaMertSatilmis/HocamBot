[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ssh-secure-shell-programi-ile-merkezi-sunuculara-baglanmaya-calistigimda-algorithm-negotiation#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 9516


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-get-algorithm-negotiation-failed-error-when-i-try-connect-servers-ssh-secure-shell-program "I get \"Algorithm negotiation failed\" error when I try to connect servers with SSH Secure Shell program. What can I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ssh-secure-shell-programi-ile-merkezi-sunuculara-baglanmaya-calistigimda-algorithm-negotiation "SSH Secure Shell programı ile merkezi sunuculara bağlanmaya çalıştığımda \"Algorithm negotiation failed\" hatası veriyor. Ne yapabilirim?")

# SSH Secure Shell programı ile merkezi sunuculara bağlanmaya çalıştığımda "Algorithm negotiation failed" hatası veriyor. Ne yapabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

Kullanmış olduğunuz SSH programının sürümü sunucunun şifreleme algoritmalarından birini desteklemiyor olabilir. Bu nedenle ssh programının güncel sürümünü veya farklı bir program kullanabilirsiniz. Size yardımcı olabilecek programlar içerisinde, WinScp Web sitesi olan kişiler için kullanılabilir FTP programlarından biridir. WinSCP sayesinde sunucuda bulunan dosyalarınızdaki izin haklarının değiştirilmesi, dosya kopyalama/taşıma gibi işlemleri yapabilirsiniz. WinSCP (Windows Güvenli Kopyalama –Secure Copy-) için bir açık kaynak SFTP ve FTP istemcisidir. Ayrıca komut sistemi olarak, PuTTY Unix/Linux sunuculara, ağ cihazlarına kadar SSH, Telnet ve COM bağlantıları ile çalışan cihaz ve bilgisayarlara uzaktan oturum açarak işlemler yapmanızı sağlayan ücretsiz bir yazılımdır. PuTTY, genellikle Windows işletim sisteminde SSH bağlantısı desteklenmediğinden dolayı SSH bağlantıları yapmak için kullanılmaktadır. WinSCP programı ile klasör, dosya ve alt dosyalara topluca erişim hak izinlerini ayarlayabilirsiniz.

İki program için de indirme bağlantısı olarak [https://winscp.net/eng/download.php](https://winscp.net/eng/download.php) adresi kullanılabilir.