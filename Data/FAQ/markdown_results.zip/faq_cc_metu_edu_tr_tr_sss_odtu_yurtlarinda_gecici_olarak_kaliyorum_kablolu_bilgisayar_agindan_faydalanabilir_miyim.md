[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurtlarinda-gecici-olarak-kaliyorum-kablolu-bilgisayar-agindan-faydalanabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-07-2022 **Görüntüleme:** 3561


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurtlarinda-gecici-olarak-kaliyorum-kablolu-bilgisayar-agindan-faydalanabilir-miyim)

# ODTÜ Yurtlarında geçici olarak kalıyorum, kablolu bilgisayar ağından faydalanabilir miyim?

[ODTÜKENT/Yurtlar/Lojmanlar](https://faq.cc.metu.edu.tr/tr/groups/odtukentyurtlarlojmanlar)

ODTÜ Yurtlarında kalan ODTÜ mensubu olmayan kullanıcılarımız ODTÜ Yurt Odaları Bilgisayar Ağı Kullanım Kuralları belgesine uygun hareket etmek koşuluyla ODTÜ kablolu bilgisayar ağından faydalanabilmektedir. Kayıt olmak için [başvuru formunu](https://faq.cc.metu.edu.tr/tr/system/files/u2/yurt_misafirkullanici.pdf) doldurmaları ve kaldıkları Yurt Müdürlüğünden onaylatarak [Bilgi İşlem Daire Başkanlığına](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=ycoord) iletmeleri yeterlidir.

Başvurunuz sonrasında kayıt işleminiz tamamlanacaktır, ardından bulunduğunuz odadaki ağ prizlerinden ağ bağlantısı sağlayabilirsiniz.

Bağlantı işlemleri ve sorunlarınız için [https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim](https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim) adresini inceleyebilirsiniz.