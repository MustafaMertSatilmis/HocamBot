[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/benim-icin-olusturulan-misafir-kullanici-bilgisi-ile-meturoam-agina-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-08-2023 **Görüntüleme:** 7300


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/guest-account-created-me-how-can-i-connect-meturoam-wireless-network "A guest account created for me. How can I connect meturoam wireless network?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/benim-icin-olusturulan-misafir-kullanici-bilgisi-ile-meturoam-agina-nasil-baglanabilirim "Benim için oluşturulan misafir kullanıcı bilgisi ile meturoam ağına nasıl bağlanabilirim?")

# Benim için oluşturulan misafir kullanıcı bilgisi ile meturoam ağına nasıl bağlanabilirim?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

Bir kablosuz cihazın ODTÜ kablosuz ağına bağlanabilmesi için WPA2 Kurumsal sistemini ve PEAP/MSCHAPv2 algoritmalarını desteklemesi gerekmektedir. meturoam yayını ile uyumlu OLMADIĞI bilinen popüler cihazlar için [bu bağlantıyı](https://faq.cc.metu.edu.tr/tr/sss/hangi-cihazlar-meturoam-baglantisini-desteklememektedir) ziyaret edebilirsiniz.

**Bağlantı ayarları**

- meturoam bağlantısı için size iletilen kullanıcı bilgisi ve şifresini kullanarak tüm kablosuz cihazlarınız ile meturoam yayınına bağlanabilirsiniz, her cihaz için ayrı bir şifre oluşturmanız gerekmemektedir.
- Bağlantı protokolleri olarak **PEAP** ve **MSCHAPv2** seçilmelidir.
- Kullanıcı adı / kodu / kimliği olarak size bildirilen kullanıcı adını (username) ve şifreyi (password) kullanmalısınız.
- Windows 10 işletim sistemi için herhangi bir protokol seçilmeden sadece kullanıcı kodu ve şifre ile bağlantı kurulabilir. [Linux işletim sistemleri](https://faq.cc.metu.edu.tr/tr/system/files/u2/meturoam-ubuntu.png) ile Windows 10 öncesi işletim sistemlerinde **WPA2-Enterprise (WPA2-Kurumsal)** ve **AES** şifreleme seçilerek elle ayar yapılmalıdır.
- Mobil cihazlarınızın klavyesindeki otomatik tamamlama özelliğini kullanıyorsanız, kullanıcı kodunuzu yazarken son karaktere dikkat ediniz. Otomatik tamamlama sonrasında eklenen boşluk karakterini silmeniz gerekmektedir.
- Sertifika sorulursa DOĞRULAMA seçeneğini seçebilir veya boş bırakabilirsiniz. (Bazı Android cihazlarda sertifika alanı zorunlu olabilir, bu cihazlarda "Sistem Sertifikalarını Kullan" seçeneğini işaretleyerek border.metu.edu.tr netlogin.metu.edu.tr adresini yazabilirsiniz.)
- Anonim kimlik alanını boş bırakabilirsiniz. (Cihazınızda zorunlu olması durumunda [anonim@metu.edu.tr](mailto:anonim@metu.edu.tr) yazılabilir.)
- **!!! Android 6 ve önceki sürümleri kullanan bazı Android cihazlarda kablosuz ağa bağlanma ile ilgili problemler yaşandığı tespit edildi. Zaman zaman bu cihazların ekranında kablosuz ağ bağlantısı kurulmuş olarak görünmesine rağmen cihaz İnternet'e erişememektedir. Bu sorun Android yazılımı içerisindeki bir hatadan kaynaklanmakta ve bu hata nedeniyle bahsi geçen cihazlar geçerlilik süresi dolmuş olmasına rağmen daha önceden DHCP üzerinden aldıkları ip adresini kullanmaya çalışmaktadır. Bu sorun ile karşılaştığınızda lütfen cihazınızın Wi-Fi bağlantısını kapatıp tekrar aktif hale getirin.**