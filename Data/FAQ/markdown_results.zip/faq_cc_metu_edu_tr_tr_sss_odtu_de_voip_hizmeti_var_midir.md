[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-de-voip-hizmeti-var-midir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-09-2015 **Görüntüleme:** 7875


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/there-voip-service-metu "Is there a VOIP Service at METU?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-de-voip-hizmeti-var-midir "ODTÜ' de VOIP Hizmeti var mıdır?")

# ODTÜ' de VOIP Hizmeti var mıdır?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

ODTÜ VOIP Hizmeti hakkında daha fazla bilgi almak için lütfen [tıklayınız.](https://bidb.metu.edu.tr/odtude-voip-hizmeti)