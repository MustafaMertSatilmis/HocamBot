[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/sonlandirdigim-evraki-nasil-geri-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4533


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/sonlandirdigim-evraki-nasil-geri-alabilirim)

# Sonlandırdığım evrakı nasıl geri alabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Kurum içi veya kurum dışı gelen evraklarınızı "Gereği Yapılmıştır" veya "Bilgi Edinilmiştir" düğmeleri ile sonlandırdıktan sonra evrakı tekrar bir yere veya bir kişiye sevk etmeniz gerekirse Evrak Geri Al menüsünden yazıyı tekrar onaylarınıza düşürmeniz gerekir.

Bunun için:

EBYS menüsünden Evrak Geri Al'a tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/evrakgerial-1.png)

Karşınıza şu şekilde bir ekran çıkacaktır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/evrakgerial-2.png)

Bu ekranda eğer ilgili evrakı göremiyorsanız öncelikle doğru evrak türünü seçtiğinizden emin olunuz (kurum içi, kurum dışı). Daha sonra tarih aralığını genişletiniz.

İlgili evrakı işaretledikten sonra **"Seçilen Akışları Geri Al"** düğmesine basarak evrakı onaylarınıza düşürünüz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.