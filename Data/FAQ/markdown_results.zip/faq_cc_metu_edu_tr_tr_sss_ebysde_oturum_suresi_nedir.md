[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-oturum-suresi-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5949


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-oturum-suresi-nedir)

# EBYS'de oturum süresi nedir?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS'ye kullanıcı adınız ve parolanız ile giriş yaptıktan sonra herhangi bir işlem yapmazsanız 1 saat süresince oturumunuz açık kalmaya devam edecektir. İşlem yapılmadan açık kalan oturum 1 saatin sonunda kapanacak ve sisteme tekrar giriş yapmanız gerekecektir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.