[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-bolumbirim-kablolu-ag-baglanti-yonetimi-nasil-yapilmaktadir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-09-2015 **Görüntüleme:** 7649


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-managed-metu-departmentsunits-wired-network "How to managed METU Departments/Units Wired Network?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-bolumbirim-kablolu-ag-baglanti-yonetimi-nasil-yapilmaktadir "ODTÜ Bölüm/Birim Kablolu Ağ Bağlantı yönetimi nasıl yapılmaktadır?")

# ODTÜ Bölüm/Birim Kablolu Ağ Bağlantı yönetimi nasıl yapılmaktadır?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

ODTÜ Bölüm/Birim Kablolu Ağ Bağlantı yönetimi hakkında daha fazla bilgi almak için lütfen [tıklayınız.](https://bidb.metu.edu.tr/bolumbirim-kablolu-ag-baglantilari)