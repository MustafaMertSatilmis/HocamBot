[Jump to navigation](https://faq.cc.metu.edu.tr/tr/autodesk-ecotect-analysis#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-01-2022 **Görüntüleme:** 10675


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/autodesk-ecotect-analysis "AUTODESK ECOTECT ANALYSIS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/autodesk-ecotect-analysis "AUTODESK ECOTECT ANALYSIS")

# AUTODESK ECOTECT ANALYSIS

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

Tasarımcılara kavramsal tasarımın ilk aşamalarında binanın performansını benzetimleyen bir çevresel analiz aracıdır. Autodesk Ecotect programı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" adresinden temin edilebilir.

[Kurulum](https://faq.cc.metu.edu.tr/tr/autodesk-ecotect-analysis#kurulum)

Kurulum:

**1\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco1.png)**

**2\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco2.png)**

**3\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco3.png)**

**4\. Adım:** Kullanılacak olan seri numarası ve ürün anahtarı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" sitesinden edinilebilir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco4.png)**

**5\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco5.png)**

**6\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco6.png)**

**7\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco7.png)**

**8\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco8.png)**

**9\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco9.png)**

**10\. Adım:** Lisans sunucusu olarak "autodesk.cc.metu.edu.tr" girilir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco10.png)**

**11\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco11.png)**

**12\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eco12.png)**

**Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**