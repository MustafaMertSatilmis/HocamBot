[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bolumde-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 7427


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-about-source-my-network-connection-failure-departmentsunits "How can I find out about the source of my network connection failure at the Departments/Units?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bolumde-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim "Bölümde yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?")

# Bölümde yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?

[Kablolu Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablolu-ag)

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_01.jpg)