[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mailman-sisteminde-ne-tur-listeler-tanimlanabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 9537


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mailman-sisteminde-ne-tur-listeler-tanimlanabilir "Mailman sisteminde ne tür listeler tanımlanabilir?")

# Mailman sisteminde ne tür listeler tanımlanabilir?

[Başvuru ile İlgili Sorular](https://faq.cc.metu.edu.tr/tr/groups/basvuru-ile-ilgili-sorular)

Mesaj gönderebilme bakımından 3 ana liste türü vardır .

**a) Açık Liste:** Liste üyeleriyle birlikte listeye üye olmayanların da mesaj yollayabildikleri listedir.

**b) Standart Liste:** Sadece listeye üye olanlar mesaj gönderebilir.

**c) Duyuru Listesi:** Sadece liste yöneticisi listeye mesaj gönderebilir. (Listeyi denetleyen kişi -moderatör- liste yöneticisinden farklı biri olabilir). Diğer üyeler tarafından gönderilen mesajlar listeye iletilmez ve liste konfigürasyonuna bağlı olarak mesaj bir açıklama ile mesajı gönderene geri döner ya da hiç bir geri bildirim olmaz.

Ayrıca standart ya da açık liste olarak tanımlanmış bir liste isteğe bağlı olarak bir moderatörün denetiminden sonra dağıtılacak şekilde de tanımlanabilir. Bu bit listelere **denetimli (moderated) liste** denir.