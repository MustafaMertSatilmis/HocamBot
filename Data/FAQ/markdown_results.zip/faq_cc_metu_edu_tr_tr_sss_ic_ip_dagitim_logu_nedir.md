[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ic-ip-dagitim-logu-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 12127


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-internal-ip-distribution-log-turkish "What is Internal IP Distribution Log? (In Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ic-ip-dagitim-logu-nedir "İç IP dağıtım logu nedir?")

# İç IP dağıtım logu nedir?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

1 Kasım 2007 tarih ve 26687 sayılı Resmi Gazete'de yayınlanan yönetmelikteki tanıma göre, _"İç IP Dağıtım Logları, kendi iç ağlarında dağıtılan IP adres bilgilerini, kullanıma başlama ve bitiş tarih ve saatini ve bu IP adreslerini kullanan bilgisayarların tekil ağ cihaz numarasını (MAC adresi) gösteren bilgileri"_ ifade etmektedir.

Bu ifadede daha çok NAT (Network Adress Translation) gibi dinamik olarak IP alan sistemler tanımlanmış olsa da, genel olarak bir IP adresinin hangi bilgisayar tarafından kullanıldığının ve bu bilgiden yola çıkarak kullanıcı tespitinin yapılması amaçlanmaktadır.

Bu nedenle, birimlerde kişisel ve ortak kullanımda olan bilgisayarların IP adreslerinin bağlı olduğu MAC adreslerini kullanan kullanıcıların da kayıt altına alınması gereklidir.

Kendi yapılarında NAT gibi dinamik olarak IP dağıtan birimler, hangi IP adresinin hangi MAC adresli bilgisayar ve kim tarafından hangi zaman diliminde kullanıldığının tespitini sağlayacak bilgileri elektronik ortamda tutmakla yükümlüdür.

Kendi yapılarında dinamik olmayan, her bilgisayara ait sabit olarak tanımlanmış IP adresi kullanan birimler, hangi MAC adresli bilgisayara hangi IP adresinin verildiğini, kimin kullanımına tahsis edildiğini, kullanıma başlama-bitiş tarih ve saatini benzer şekilde elektronik ortamda kayıt altına almak zorundadır.