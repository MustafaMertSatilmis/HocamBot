[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vekalet-aldigimda-baskasinin-yerine-elektronik-form-onaylarini-nasil-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 3332


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vekalet-aldigimda-baskasinin-yerine-elektronik-form-onaylarini-nasil-yapabilirim)

# Vekalet aldığımda başkasının yerine elektronik form onaylarını nasıl yapabilirim?

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

EBYS üzerinden yazılan evraklarda eimza kullanıldığı için bir kişi vekalet bıraktığında yazının üzerinde vekalet bırakılan kişinin isminin yazması zorunluluğu vardır.

Ancak eimza olmayan elektronik formlarda bu zorunluluk olmadığından, sistemdeki vekalet bırakma özelliği sayesinde, vekalet bırakılan kişi, EBYS sayfasının üst kısmında bulunan vekalet düğmesinden kendisine vekalet bırakan kişinin hesabına geçiş yapar ve oradan başkasının yerine gerekli onaylama ve sevk işlemlerini gerçekleştirir.

Formlardaki işleyiş de EBYS üzerinden yazılan eimzalı evraklarda çalışan sistem gibi kurgulanabilirdi. Ancak öyle olsaydı, yazılmış bir form geçeceği adımlar üzerinden geçerken, onaycılardan en az bir tanesi vekalet bıraktığında formun baştan hazırlanması gerekirdi.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.