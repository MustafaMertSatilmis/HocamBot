[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Fonksiyonel Özellikler

|     |
| --- |
| [Birime özel not eklemek için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/birime-ozel-not-eklemek-icin-ne-yapmaliyim) |
| [E-Devlet Üzerinden Evrak Doğrulama](https://faq.cc.metu.edu.tr/tr/sss/e-devlet-uzerinden-evrak-dogrulama) |
| [E-posta adresime EBYS ile ilgili çok fazla mesaj geliyor, bu mesajları almamak için ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-adresime-ebys-ile-ilgili-cok-fazla-mesaj-geliyor) |
| [EBYS yazılarında görünen telefon numaram alanı boş veya yanlış, nasıl ekler veya değiştiririm?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm) |
| [EBYS'de kayıtlı telefon rehberinde nasıl arama yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kayitli-telefon-rehberinde-nasil-arama-yapilir) |
| [EBYS'de Oluşturulan Belgeler Nasıl Doğrulanır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-olusturulan-belgeler-nasil-dogrulanir) |
| [EBYS’de duyurular özelliği nedir? Nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-duyurular-ozelligi-nedir-nasil-goruntulenir) |
| [EBYS’de gelen bilgilendirmeler nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gelen-bilgilendirmeler-nasil-goruntulenir) |
| [EBYS’de vekalet verme işlemi nasıl yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-vekalet-verme-islemi-nasil-yapilir) |
| [Gelen bir yazı veya elektronik form ile ilgili işlem yapacağım butonları göremiyorum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/yazi-veya-elektronik-form-ile-ilgili-islem-yapacagim-butonlari-goremiyorum) |
| [Kapak Yazısı Yaz nedir?](https://faq.cc.metu.edu.tr/tr/sss/kapak-yazisi-yaz-nedir) |
| [Kişiye özel not eklemek için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kisiye-ozel-not-eklemek-icin-ne-yapmaliyim) |
| [Üniversitemizin KEP Adresi nedir?](https://faq.cc.metu.edu.tr/tr/sss/universitemizin-kep-adresi-nedir) |

[![Subscribe to Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/214/all/feed "Subscribe to Fonksiyonel Özellikler")