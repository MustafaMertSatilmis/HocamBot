[Jump to navigation](https://faq.cc.metu.edu.tr/tr/microsoft-visio#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-04-2022 **Görüntüleme:** 13526


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/microsoft-visio "MICROSOFT VISIO")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/microsoft-visio "MICROSOFT VISIO")

# MICROSOFT VISIO

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT VISIO** **2021** **—**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/microsoft-visio#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/microsoft-visio#aktivasyon)

* * *

**_\[1\] Personel için not:_** _Microsoft Visio yazılımı sadece personelin kullanımına açıktır._

**_\[2\] Öğrenciler için not:_** _Microsoft Visio yazılımını kullanabilmek için_ [_bu sayfada_](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware) _yer alan yönergeleri takip ederek Office 365 hizmetine metu.edu.tr uzantılı e-posta adresinizle kaydolunuz. Bu işlemden sonra ilgili yazılıma erişip kullanabilirsiniz._

**_\[3\] Windows kullanıcıları için not:_** _Kullanıcılarımız **“Visio 2021”** windows sürümü aktivasyon işlemi için **“kms\_office2021\_client.bat”** volume license dosyasını lisanslı yazılımlar web sayfasından indirmeli ve dosyaya sağ tıklayarak **“Run as administrator”** seçeneği ile çalıştırmalıdırlar. Bu işlemden sonra Microsoft Visio Windows sürümü etkinleştirilmiş olmalıdır._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“install”_**_butonuna tıklayarak kurulumu başlatınız. (Gerekiyor ise install dosyasının üzerine sağ tıklayıp yönetici olarak çalıştırınız.)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visio_2021_step1.png)

**_ADIM-2_**

_Kurulum başladıktan sonra ekranda aşağıda yer alan iki pencere açılacaktır. Kurulum tamamlanana kadar bu pencereleri kapatmayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visio_2021_step2.1.png)

**_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visio_2021_step2.2.png)_**

**_ADIM-3_**

**_“Close”_**_butonuna tıklayarak kurulum işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visio_2021_step3.png)

**_ADIM-4 <<<AKTİVASYON>>>_**

_Bilgisayarınızda ofis yazılımlarının aktivasyon işlemini daha önceden yapmış iseniz kurulumdan sonra Visio yazılımı arka planda aktivasyon işlemini gerçekleştirecektir._

_Aktivasyon ile ilgili sorun yaşıyorsanız Office yazılımı aktivasyon işlemini tekrarlayınız._

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *