[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2022 **Görüntüleme:** 10769


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/password-and-recovery-e-mail-procedures-metu-alumni-user-codes "Password and Recovery E-Mail Procedures for METU Alumni User Codes")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri "ODTÜ Mezun E-posta Kullanıcı Kodu Şifre ve Kurtarma E-Postası İşlemleri")

# ODTÜ Mezun E-posta Kullanıcı Kodu Şifre ve Kurtarma E-Postası İşlemleri

[Mezun E-posta](https://faq.cc.metu.edu.tr/tr/groups/mezun-e-posta)

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

**A-** **ODTÜ Mezun e-posta kullanıcı kodunuzun şifresini değiştirmek için:**

1. [https://alumniaccount.metu.edu.tr/](https://alumniaccount.metu.edu.tr/ "alumniaccount.metu.edu.tr") adresine giriniz,
2. Kullanmakta olduğunuz şu anki mezun e-posta kullanıcı kodunuz ve şifreniz ile giriş yapınız,
3. Gelen sayfada ŞİFRE DEĞİŞTİR düğmesine tıklayınız,
4. Yeni şifrenizi aşağıdaki D Bölümünde yer alan kurallara uygun olarak 2 defa yazıp DEĞİŞTİR düğmesine tıklayınız.
5. Şifre değişikliği başarıyla gerçekleştikten **_yaklaşık 5 dakika sonra_** yeni şifrenizi kullanabilirsiniz.

* * *

**B-** **Şifrenizi unutmanız veya şifrenizin sıfırlanması halinde yeni şifre belirlemek için:**

Şifrenizi unutmanız halinde kendinize yeni şifre belirleyebilmeniz için kullanıcı hesabınızda kurtarma e-postanızın tanımlı olması gerekmektedir. Belirlemiş olduğunuz ODTÜ dışı kurtarma e-posta adresinize (Gmail  vb.) talebiniz doğrultusunda yeni bir şifre aktivasyon linki gönderilecek olup; linkte yer alan bağlantı üzerinden şifrenizi 24 saat içinde aktive etmeniz beklenecektir. Eğer sistemde kurtarma e-postanız tanımlı değilse veya kurtarma e-postanızı unuttuysanız aşağıdaki bölümlerdeki adımları takip ediniz.

Kurtarma e-postanız sistemde tanımlı ise ve kurtarma e-postanızı biliyorsanız;

1. [https://alumniaccount.metu.edu.tr/](https://alumniaccount.metu.edu.tr/ "alumniaccount.metu.edu.tr") adresine giriniz,
2. Kullanıcı Girişi bölümünün altında “Şifrenizi mi unuttunuz?” düğmesine tıklayınız,
3. Gelen sayfada “mezun eposta kullanıcı adınızı”, sistemde tanımlı olan “kurtarma e-postanızı” ve hemen altında yer alan “resim doğrulama” karakterlerini ilgili yerlere girdikten sonra “E-POSTA GÖNDER” düğmesine tıklayınız.
4. Kurtarma e-posta adresinize giriniz. Adresinize yeni bir şifre aktivasyon linki gönderilmiş olacaktır. Gelen sayfadaki mavi renkli aktivasyon linkine tıklayınız.
5. Aktivasyon linkine tıkladığınızda yeni şifre oluşturabileceğiniz sayfaya yönlendirileceksiniz. D bölümünde belirtilen kriterlere uygun şekilde yeni bir şifre oluşturduğunuzda şifrenizin başarılı şekilde değiştirildiği mesajını göreceksiniz.
6. Şifre değişikliği başarıyla gerçekleştikten _**yaklaşık 5 dakika sonra**_ yeni şifrenizi kullanabilirsiniz.

* * *

**C-** **Kurtarma e-postası tanımlamak için:**

1. [https://alumniaccount.metu.edu.tr/](https://alumniaccount.metu.edu.tr/ "alumniaccount.metu.edu.tr") adresine giriniz,
2. Kullanmakta olduğunuz şu anki kullanıcı kodu-şifre ile giriş yapınız,
3. Gelen sayfada KURTARMA E-POSTASI BELİRLE düğmesine tıklayınız,
4. Kurtarma e-postanızı yazıp GÜNCELLE düğmesine tıklayınız.

* * *

**D-** **Kullanıcılarımız şifrelerini aşağıdaki** **kurallara** **göre oluşturmalıdır:**

**Zorunlu unsurlar:**

- Şifre tam olarak 8 karakter olmalıdır. 8 karakterden fazla ya da eksik olmadığına dikkat ediniz.
- Şifre en az bir büyük harf (ABCD….Z) içermelidir.
- Şifre en az bir küçük harf (abcd…z) içermelidir.
- Şifre en az bir sayı (1234567890) içermelidir.
- Şifre sadece parantez içindeki (\[ % ( ) \* + , - . / : ; < > ^ \_ { \| } ~ \]) özel karakterlerden en az bir tanesini içermelidir.

**Şifrede bulunmaması gereken unsurlar:**

- Şifre boşluk karakteri içeremez.
- Şifre 1900’lü veya 2000’li yılları içeremez. (1978, 1999, 2001 vb.)
- Şifre 4 ya da daha fazla karakterli ardışık sayı içeremez. (1234, 2345, 5678 vb.)
- Şifre kendisini 2 defadan fazla tekrar eden karakter içeremez (AAA, zzz vb.)
- Şifre Türkçe karakter içeremez. (ç, ğ, İ, ö, ş, ü…)
- ASCII karakteri olmayan karakter içeremez. (ä, é, Ý, Ð, Π vb.)
- Şifre tamamı büyük ya da tamamı küçük harf olan kolay tahmin edilebilir sözcük veya sözlük kelimesi içeremez. (Seçtiğiniz şifre sözlükte bulunmaktadır uyarısı alırsanız, şifrenizdeki harflerin çoğunluğunu ünsüz veya ünlü harflerden oluşturmanız önerilir.)
- Yeni şifre, son 5 şifre ile aynı olamaz.

**Örnek Şifreler:**

Polut36\*

Dem70:ka

2K/mReD

2F,646(w

EO\*A(/5y

g1>4YjT

o)5aDA-9