[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/windows-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-12-2021 **Görüntüleme:** 171537


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-vpn-service-windows-os-installed-devices "How can i use METU VPN Service on Windows OS installed devices?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/windows-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim "Windows işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?")

# Windows işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

**Windows işletim sistemi yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?**

ODTÜ VPN hizmeti ile birlikte, mensup ve öğrencilerimiz yerleşke dışında bulundukları sürelerde kullandıkları kişisel bilgisayarlara ya da mobil cihazlara kuracakları küçük bir paket program vasıtasıyla (VPN Client), üniversitemiz yerleşke içi ağ kaynaklarına erişebileceklerdir.

Önemli Uyarı: VPN üzerinden bağlanan kullanıcılarımızın bağlantı hızları kullanıcı başına 8 Mbps olarak şekillendirilmektedir. Bu nedenle VPN bağlantısına ihtiyacınız kalmadığı durumlarda VPN bağlantınızı sonlandırmanızı öneririz.

Windows işletim sistemi yüklü cihazınızla VPN hizmetini kullanabilmeniz için:

netregister.metu.edu.tr adresine giriş yaptıktan sonra VPN service bağlantısında gelen işletim sisteminize uygun yazılımı indirdikten sonra kurulumu çalıştırınız.

![win-vpn_1](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_1.jpg)

Gelen ekranda Next seçeneğine tıklayarak kurulumu başlatınız.

![win-vpn_2](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_2.jpg)

Gelen ekranda lisans sözleşmesini kabul edip, Next seçeneğine tıklayarak devam ediniz.

![win-vpn_3](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_3.jpg)

VPN yazılımını bilgisayarınızda nereye yükleyeceğinizi seçtikten sonra Next seçeneğine tıklayınız.

![win-vpn_4](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_4.jpg)

Install seçeneğine tıklayarak kuruluma devam ediniz.

![win-vpn_5](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_5.jpg)

![win-vpn_6](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_6.jpg)

Finish seçeneğine tıklayarak kurulumu bitiriniz.

![win-vpn_7](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_7.jpg)

VPN programı açıldıktan sonra karşınıza gelecek ekranda "Click to download VPN profile" butonuna tıklayınız.

![win-vpn_8](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_8.jpg)

Gelen ekranda Enter VPN Server URL yazan alana **border.metu.edu.tr** yazınız ve Download butonuna tıklayınız.

![Profile Selection](https://faq.cc.metu.edu.tr/system/files/u21699/profile_page.png)

**default** profili seçiniz.

![win-vpn_9](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_9.jpg)

Daha sonra karşınıza gelecek olan ekranda Username yazan boşluğa e000000 şeklinde olan ODTÜ kullanıcı adınızı (veya personel kullanıcı kodunuzu) ve Password yazan yere ise şifrenizi yazınız. Kullanıcı kodunuzun sonunda @metu.edu.tr gibi uzantılar bulunmamalı, sadece kullanıcı kodu ilgili alana yazılmalıdır. Daha sonra Proceed butonuna tıklayınız.

![win-vpn_11](https://faq.cc.metu.edu.tr/tr/system/files/u21699/win-vpn_11.jpg)

Artık ODTÜ ağına VPN ile bağlısınız.

Giriş yaptıktan sonra uygulama simge durumuna gelebilir. Görev çubuğundan simgeyi çift tıklayıp uygulamayı öne getirebilirsiniz. İşiniz bittiğinde VPN bağlantısını kesmek için görev çubuğundan simgeye sağ tıklayıp Disconnect seçeneğine tıklayınız.

**VPN programı veya bağlantısı ile ilgili sorun yaşıyorsanız [https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-bilgilerimi-dogru-girmem...](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-bilgilerimi-dogru-girmeme-ragmen-baglanamiyorum-sorun-ne-olabilir) ve [https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiy...](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiyorum-ne-yapmaliyim) adreslerindeki bilgileri inceleyerek tekrar denemenizi öneririz.**