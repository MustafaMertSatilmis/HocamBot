[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablolu-agi-nasil-yonetiliyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2021 **Görüntüleme:** 7859


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-metu-wired-network-managed "How is METU Wired Network managed?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablolu-agi-nasil-yonetiliyor "ODTÜ Kablolu Ağı nasıl yönetiliyor?")

# ODTÜ Kablolu Ağı nasıl yönetiliyor?

[Kablolu Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablolu-ag)

Orta Doğu Teknik Üniversitesi'nin Yerleşke Ağ Altyapısı, yerleşke genelindeki omurga ağına bağlı bölüm ağlarından ve çeşitli büyüklüklerdeki çok kullanıcılı sunuculardan oluşmaktadır. ODTÜ yerel alan ağı,  ODTÜ’ ne bağlı fakülte, bölüm, meslek yüksek okulu ve birimlerin bir ağ yapısı ile birbirine bağlayıp internet erişimini sağlamakta ve yönetimi BİDB merkezli yapılmaktadır.  Bölüm/Birimlere ait Yerel Alan Ağları gigabit üstbağlantılı ethernet anahtarları ile omurga ağına bağlanır. ODTÜ yerleşkesinde bulunan bölüm ve birimlerdeki omurga ağ cihazlarının gerekli her türlü konfigurasyonu ve yönetimi BİDB tarafından sağlanmaktadır. BİDB tarafından geliştirilen yönetim yazılımıyla IP-MAC eşlemesi yapılarak kullanıcılara kablolu bağlantı erişimi sağlanmaktadır. Aşağıda ODTÜ Kablolu Ağ Altyapısı çizimi bulunmaktadır.

![Odtü Ağ Alt Yapısı](https://faq.cc.metu.edu.tr/tr/system/files/u21699/odtu_ag_altyapisi_edited.png)