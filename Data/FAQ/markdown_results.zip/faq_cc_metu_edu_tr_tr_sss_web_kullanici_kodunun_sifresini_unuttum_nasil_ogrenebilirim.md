[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/web-kullanici-kodunun-sifresini-unuttum-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7884


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-forgot-web-user-accounts-password-how-can-i-learn-it "I forgot the web user account's password, How can I learn it?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/web-kullanici-kodunun-sifresini-unuttum-nasil-ogrenebilirim "Web Kullanıcı Kodunun şifresini unuttum nasıl öğrenebilirim?")

# Web Kullanıcı Kodunun şifresini unuttum nasıl öğrenebilirim?

[Web Servisleri](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri)

Web Kullanıcı kodunun şifresini unuttuysanız, yeni şifre için [http://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim](http://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim) adresindeki işlemleri yapabilirsiniz.

www\*\*\*\*\* şeklindeki web kullanıcı kodları için "kurtarma e-posta adresi"; ilgili web hesabından sorumlu kişisel kullanıcı kodudur. Öğrenci topluluklarına ait web hesaplarında sorumlu kullanıcı kodu ilgili topluluğun akademik danışmanına ait e-posta kodudur.

Bu bilgilerle şifre işlemlerinde sorun yaşarsanız ya da web hesabına ait sorumlu kişisel kullanıcı kodunu bilmiyorsanız webadmin![](https://faq.cc.metu.edu.tr/tr/system/files/img_et.gif)metu.edu.tr adresi ile iletişime geçiniz.