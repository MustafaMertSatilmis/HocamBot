[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# E-Liste Yönetim Soruları

|     |
| --- |
| [E-Liste yöneticisi olarak Mailman Arayüzünü nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-yoneticisi-olarak-mailman-arayuzunu-nasil-kullanabilirim) |
| ["abc-l" listesinin yöneticisiyim. Ancak şifresini bilmiyorum. Şifreyi nasıl edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesinin-yoneticisiyim-ancak-sifresini-bilmiyorum-sifreyi-nasil-edinebilirim) |
| [E-listenin arşivlenmesi ile ilgili ayarlara nereden ulaşabilirim ?](https://faq.cc.metu.edu.tr/tr/sss/e-listenin-arsivlenmesi-ile-ilgili-ayarlara-nereden-ulasabilirim) |
| [E-listeye (üye olan-olmayan) herkesin mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-uye-olan-olmayan-herkesin-mesaj-gonderebilmesi-icin-ne-yapmaliyim) |
| [E-listeye sadece liste üyelerinin mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-uyelerinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim) |
| [E-listeye sadece liste yöneticisinin mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-yoneticisinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim) |
| [E-listeye sadece moderatörün mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-moderatorun-mesaj-gonderebilmesi-icin-ne-yapmaliyim) |
| [Yöneticisi olduğum listemi artık kullanmıyorum, nasıl kapatabilirim?](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listemi-artik-kullanmiyorum-nasil-kapatabilirim) |
| [Yöneticisi olduğum listenin ismini değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listenin-ismini-degistirebilir-miyim) |
| [Yöneticisi olduğum listeye gönderilen mesajlarda boyut sınırlarını nasıl duzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listeye-gonderilen-mesajlarda-boyut-sinirlarini-nasil-duzenleyebilirim) |

[![Subscribe to E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/206/all/feed "Subscribe to E-Liste Yönetim Soruları")