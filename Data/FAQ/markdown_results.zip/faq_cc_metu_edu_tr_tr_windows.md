[Jump to navigation](https://faq.cc.metu.edu.tr/tr/windows#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-08-2022 **Görüntüleme:** 75590


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/windows "MICROSOFT WINDOWS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/windows "MICROSOFT WINDOWS")

# MICROSOFT WINDOWS

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**_WINDOWS 11_**

Başlamadan önce;

\[1\] Windows 11'i yüklemek istediğiniz aygıtın minimum sistem gereksinimlerini karşıladığından emin olun.

\[2\] Cihazınız şu anda Windows 10 çalıştırıyorsa, PC Health Check uygulamasını kullanarak minimum sistem gereksinimlerini doğrulamanızı öneririz.

\[3\] Microsoft, Windows 11'in gereksinimleri karşılamayan bir cihaza yüklenmesini önermez.

[Sistem gereksinimleri](https://www.microsoft.com/en-us/windows/windows-11-specifications)

[Uyumluluğu kontrol edin](https://www.microsoft.com/en-us/windows/windows-11?r=1#pchealthcheck)

[Windows 11 destekli Intel işlemciler](https://docs.microsoft.com/en-us/windows-hardware/design/minimum/supported/windows-11-supported-intel-processors)

* * *

**_\[1\] Not:_ _Windows 11 yazılımının aktivasyon işlemini Windows 10 etkinleştirme adımlarını takip edrek benzer şekilde gerçekleştirebilirsiniz!_**

* * *

**_WINDOWS 10_**

[Windows 10 Kurulumu](https://faq.cc.metu.edu.tr/tr/windows#Windows10Kurulum)

[Windows 10 Etkinleştirme](https://faq.cc.metu.edu.tr/tr/windows#Windows10Etkinlestirme)

[Windows 7 Kurulumu](https://faq.cc.metu.edu.tr/tr/windows#Windows7Kurulum)

[Windows 7 Etkinleştirme](https://faq.cc.metu.edu.tr/tr/windows#Windows7Etkinlestirme)

[Windows etkinleştirme problemi olması durumunda yapılması gerekenler - 1](https://faq.cc.metu.edu.tr/tr/windows#WindowsEtkinlestirmeProblemleri1)

[Windows etkinleştirme problemi olması durumunda yapılması gerekenler \- 2](https://faq.cc.metu.edu.tr/tr/windows#WindowsEtkinlestirmeProblemleri2)

* * *

**Windows 10 Kurulumu**

**Önemli not:  İşletim sistemleri sadece personelin kullanımına açıktır.**

**1.Adım:** Başlangıçta, Windows 10 DVD’sini bilgisayara taktıktan sonra karşınıza gelen “CD veya DVD’den önyükleme için bir tuşa basın. (Press any key to boot from CD or DVD)” uyarısını bir tuşa basarak geçmelisiniz.

![](http://faq.cc.metu.edu.tr/tr/system/files/u16319/beginning_0.png)

**2.Adım:** Karşınıza gelen ekranda yüklemek istediğiniz dili ve diğer seçenekleri seçip İleri ( **Next**) butonuna tıklamalısınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/01.png)

**3\. Adım:** Gelen ekranda Şimdi Yükle ( **Install Now**) butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/02.png)

**4.Adım:** Lisans koşullarını kabul et ( **I accept the license terms**) seçeneğinin yanındaki kutucuğu işaretleyip İleri ( **Next**) butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/03.png)

**5.Adım:** Karşınıza gelen ekrandan **Custom: Install Windows only advanced** seçeneğine tıklayın. Böylece temiz kurulum yapabilirsiniz. Eğer daha önceki bir windows sürümünden yükseltme yapıyorsanız “Yükselt: Windows’u yükle ve dosyaları, ayarları ve programları sakla ( **Upgrade: Install Windows and keep files, settings, and applications**)” seçeneğine tıklayın. Böylece Windows sürümünüzü 10'a yükseltirken dosyalarınızı da saklamış olursunuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/04.png)

**6.Adım:** Kurulumu yapmak istediğiniz disk bölümünü seçtikten sonra **Next** butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/05.png)

**7.Adım:** Yükleme işlemi başlayacaktır. Bu işlem biraz zaman alabilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/06.png)

**8.Adım:** Yükleme tamamlandıktan sonra karşınıza bilgisayarınızı kişiselleştirmeniz için ekranlar gelecek. Bu ekranlarda gerekli alanları doldurduktan sonra devam edin.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/10.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/11.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/12.png)

**9.Adım:** Bilgisayara bir kullanıcı seçme adımında -varsa- microsoft hesabınız ile devam edebilir veya **Domain join instead** yazısına tıklayarak bilgisayara bir yerel kullanıcı hesabı oluşturabilirsiniz.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/15.png)**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/16.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/17.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/18.png)

**10.Adım:** Bilgisayarınızın gizlilik ayarlarını seçerek kurulumu tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/19.png)

**11.Adım:** Windows 10 kurulum işlemi tamamlanmıştır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/22.png)

* * *

**Windows 10 Etkinleştirme**

**Birinci Yöntem**

Microsoft işletim sistemleri ve yazılımları toplu lisans anlaşmaları ile temin edildiğinden, ürünlerin etkinleştirilmesi bir ürün anahtarı (Product Key) girerek değil, kullanıcıların dahil olduğu yerleşke ağına ve ürün etkinleştirme (KMS) sunucularına bağlanılarak yapılmaktadır. Bu nedenle [https://yazilim.cc.metu.edu.tr/](https://yazilim.cc.metu.edu.tr/) adresinden indirilen Windows 10 işletim sisteminizi kurulum sonrasında aşağıdaki talimatlara uygun olarak etkinleştirmelisiniz.

**1\. Adım:**" **metu\_dns.bat**" dosyasını [buradan](https://yazilim.cc.metu.edu.tr/) indiriniz. (Sadece ODTÜ personel kullanıcı kodları tarafından erişim sağlanabilir.)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/23.png)

**2.Adım:** Dosyaya sağ tıklayıp açılan menüden Run as administrator ( **Yönetici olarak çalıştır**) satırını tıklayıp çalıştırmalısınız. Dosyayı çalıştırdıktan sonra bilgisayarı yeniden başlatmanız gerekecek.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/26.png)

**3.Adım:** Normal koşullarda ODTÜ yerleşke ağına bağlanmış bir Windows 10, herhangi bir kullanıcı müdahalesi olmadan 3 gün içinde otomatik olarak etkinleşecektir. Kurulum sonrasındaki 30 gün içinde yerleşke içinde bir defa ağa bağlanmış olmak ve aktivasyon sunucusundan onay almış olmak gerekmektedir. Bundan sonra Windows 10 kurulu bilgisayarınız 6 ay boyunca yerleşke dışında ya da ağa bağlı olmaksızın kullanılabilir. Windows 10 yüklü bilgisayarlar her 6 aylık dilim içinde değişik zamanlarda otomatik olarak aktivasyon sunucusuna bağlanıp aktivasyonu yenileyecekler ve bu süreyi sürekli olarak uzatacaklardır.

Aktivasyonun bir süre sonra kendiliğinden tamamlanmasını beklemeden hemen gerçekleştirmek için şu yolu izlemelisiniz:

**Settings > Activate Windows now > Troubleshoot**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/33.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/34.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/35.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/36.png)

**İkinci Yöntem**

Otomatik aktivasyon işlemi gerçekleşmezse, **C:\\Windows\\System32** konumundaki **cmd.exe** ya da başlat tuşuna basıldıktan sonra cmd yazılarak Komut Sistemi (Command Promt) uygulaması sağ tıklandıktan sonra Yönetici Olarak Çalıştır (Run as administrator) satırı seçilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/25.png)

Açılan pencereye

**slmgr /skms kms.cc.metu.edu.tr:1688**

komutu yazılmalı ve ilk komutun sisteme işlendiğini bildiren pencere Tamam (OK) seçeneği tıklanarak kapatılmalıdır. Sonrasında

**slmgr -ato**

komutu girilmeli ve aktivasyon onayı penceresinin görüntülenmesi beklenmelidir. Bu işlem biraz zaman alabilir. İşlem sonunda "Windows başarıyla etkinleştirildi. (Windows is activated succesfully)" şeklinde bir bildirim gelecektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/32.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/32-1.png)

* * *

**Windows 7 Kurulumu**

**1.Adım:** Başlangıçta, Windows 7 CD veya DVD’sini bilgisayara taktıktan sonra karşınıza gelen “CD veya DVD’den önyükleme için bir tuşa basın. (Press any key to boot from CD or DVD)” uyarısını bir tuşa basarak geçmelisiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/beginning.png)

**2.Adım:** Karşınıza gelen ekranda yüklemek istediğiniz dili seçip İleri ( **Next**) butonuna tıklamalısınız.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s1.png)**

**3\. Adım:** Gelen ekranda Şimdi Yükle ( **Install Now**) butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s2.png)

**4.Adım:** Lisans koşullarını kabul et ( **I accept the license terms**) seçeneğinin yanındaki kutucuğu işaretleyip İleri ( **Next**) butonuna tıklayınız.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s3.png)**

**5.Adım:** Karşınıza disk bölümlendirme ekranı gelecektir. Yeni ( **New**) seçeneğine tıkladıktan sonra Uygula ( **Apply**) butonuna tıklayarak yeni disk alanı oluşturacaksınız. (Belirtilen disk alanları örnektir. Disk alanları ihtiyaca göre ayarlanmalı.)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/edited3.png)

**6.Adım:** Bölünen disklerin arasından yanında Birincil ( **Primary**) yazan diski seçmelisiniz. Daha sonra İleri ( **Next**) butonuna tıklayarak devam ediniz.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s7.png)**

**7.Adım:** Yükleme işlemi başlayacaktır. Bu işlem biraz zaman alabilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s8.png)

**8.Adım:** Yükleme tamamlandıktan sonra karşınıza bilgisayarınızı kişiselleştirmeniz için bir ekran gelecek. Bu ekranda gerekli alanları doldurduktan sonra İleri ( **Next**) butonuna tıklayarak devam edin.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s10.png)**

**9.Adım:** Gelen ekranda Önerilen Ayarları Kullan ( **Use recommended settings**) butonuna tıklayarak devam edebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s11.png)

**10\. Adım:** Bu ekranda saat ve tarihi ayarlayınız. Daha sonra İleri ( **Next**) butonuna tıklayarak devam edin.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/edited1.png)**

**11\. Adım:** Windows 7 kurulum işlemini gerçekleştirdiniz.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/s13.png)**

* * *

**Windows 7 Etkinleştirme**

Microsoft işletim sistemleri ve yazılımları toplu lisans anlaşmaları ile temin edildiğinde, ürünlerin etkinleştirilmesi bir ürün anahtarı (Product Key) girerek değil, kullanıcıların dahil olduğu yerleşke ağına ve ürün etkinleştirme (KMS) sunucularına bağlanarak yapılmaktadır. Bu nedenle [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/) adresinden indirilen Windows 7 işletim sisteminizi kurulum sonrasında aşağıdaki talimatlara uygun olarak etkinleştirmelisiniz.

**1\. Adım:**" **metu\_dns.bat**" dosyasını [buradan](https://yazilim.cc.metu.edu.tr/) indiriniz.

**2.Adım:** Dosyaya sağ tıklayıp açılan menüde **Run as administrator** (Yönetici olarak çalıştır) satırını tıklayıp çalıştırmalısınız. Dosyayı çalıştırdıktan sonra bilgisayarı yeniden başlatmanız gerekecek.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sa1.png)

**3.Adım:** Normal koşullarda ODTÜ yerleşke ağına bağlanmış bir Windows 7, herhangi bir kullanıcı müdahalesi olmadan 3 gün içinde otomatik olarak etkinleşecektir. Kurulum sonrasındaki 30 gün içinde yerleşke içinde bir defa ağa bağlanmış olmak ve aktivasyon sunucusundan onay almış olmak gerekmektedir. Bundan sonra Windows 7 kurulu bilgisayarınız 6 ay boyunca yerleşke dışında ya da ağa bağlı olmaksızın kullanılabilir. Windows 7 yüklü bilgisayarlar her 6 aylık dilim içinde değişik zamanlarda otomatik olarak aktivasyon sunucusuna bağlanıp aktivasyonu yenileyecekler ve bu süreyi sürekli olarak uzatacaklardır.

Aktivasyonun bir süre sonra kendiliğinden tamamlanmasını beklemeden hemen gerçekleştirmek için şu yolu izlemelisiniz :

**Denetim Masası (Control Panel) -> Sistem ve Güvenlik (System and Security) -> Sistem (System)**

Karşınıza gelen ekranda, alt kısımdaki Windows Etkinleştirme (Windows Activation) kısmında Windows’u şimdi etkinleştir (Activate Windows Now) seçeneğine tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sa2.png)

**4\. Adım:** Windows’u Şimdi Çevrimiçi Etkinleştir ( **Activate Windows Online Now**) seçeneğine tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sa3.png)

**5.Adım:** Ekranda Windows 7 etkinleştirildi yazısı görülecektir.

Otomatik aktivasyon işlemi gerçekleşmezse, **C:\\Windows\\System32** konumundaki **cmd.exe** ya da başlat tuşuna basıldıktan sonra cmd yazılarak Komut Sistemi (Command Promt) uygulaması sağ tıklandıktan sonra Yönetici Olarak Çalıştır (Run as administrator) satırı seçilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sa4.png)

Açılan pencereye

**slmgr /skms kms.cc.metu.edu.tr:1688**

komutu yazılmalı ve ilk komutun sisteme işlendiğini bildiren pencere Tamam (OK) seçeneği tıklanarak kapatılmalıdır. Sonrasında

**slmgr -ato**

komutu girilmeli ve aktivasyon onayı penceresinin görüntülenmesi beklenmelidir. Bu işlem biraz zaman alabilir. İşlem sonunda "Windows başarıyla etkinleştirildi. (Windows is activated succesfully)" şeklinde bir bildirim gelecektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sa5.png)

* * *

**Windows etkinleştirme problemi olması durumunda yapılması gerekenler - 1**

1- Windows'un sistem saat ve tarihinin doğru olup olmadığını kontrol edip, doğru değilse düzeltip tekrar deneyiniz.

2- Kurulumdan sonra kritik güncellemeleri yapınız. Windows kritik güncellemelerini tamamladıktan sonra etkinleştirme işlemlerini tekrar deneyiniz.

3- Windows başarıyla etkinleştirildikten bir süre (birkaç ay gibi) sonra "Windows Orjinal değil", "Windows'u etkinleştirmeniz gerekiyor" gibi uyarılar alınırsa, yukardaki etkinleştirme işlemleri ve komutları tekrarlanmalıdır. Bu işlemler sırasında sonradan kurulan **Firewall türü güvenlik yazılımları devre dışı bırakılmalıdır**. Aktivasyon süresinin 6 aylık periyotlar halinde sistem tarafından otomatik olarak uzatılabilmesi için kullanılan güvenlik yazılımlarında 1688 nolu porttan iletişime izin verilmelidir.

**Windows etkinleştirme problemi olması durumunda yapılması gerekenler \- 2**

Windows İşletim Sistemini KMS ile aktive etmek için, yüklenmiş olan İşletim sisteminde öntanımlı bir uyumlu ürün anahtarı olması gerekmektedir. Eğer aktivasyon sırasında hata alırsanız aşağıdaki adresten bulabileceğiniz kendi işletim sisteminize uygun olan GVLK anahtarını yüklemeyi deneyebilirsiniz.

[https://docs.microsoft.com/en-us/windows-server/get-started/kmsclientkeys](https://docs.microsoft.com/en-us/windows-server/get-started/kmsclientkeys)

KMS istemcisi ürün anahtarını yüklemek için aşağıdaki komutu çalıştırın:

                 slmgr /ipk <Product Key obtained from Web site>

Ve KMS aktivasyonunu aşağıdaki komut ile tekrar deneyin:

                  slmgr /ato

* * *

**Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**