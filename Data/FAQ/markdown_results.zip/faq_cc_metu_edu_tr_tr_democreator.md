[Jump to navigation](https://faq.cc.metu.edu.tr/tr/democreator#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-11-2024 **Görüntüleme:** 6323


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/democreator "DEMOCREATOR")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/democreator "DEMOCREATOR")

# DEMOCREATOR

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— DEMO** **CREATOR** **—**

_Democreator_ _yazılımı öğretici videolar,_ _demo_ _videolar, sunum kayıtları, oyun_ _vlogları_ _ve diğer bilgi paylaşım videoları hazırlamak için kullanılabilen bir ekran kaydedici ve video düzenleme aracıdır._

_Üniversitemiz için temin edilen Democreator yazılımı lisansları için aşağıdaki sayfada listesi bulunan akademik bölümlerimiz ve enstitülerimizden ihtiyaç bildirenler için, her bir bölüm/enstitü adına ilgili bilgisayar koordinatörleri tarafından iletilen e-posta adreslerine yetkilendirme yapılmıştır._

**_URL>>_** _[http://www.metu.edu.tr/tr/fakulteler-enstituler-ve-okullar](http://www.metu.edu.tr/tr/fakulteler-enstituler-ve-okullar)_

_Democreator yazılım lisansına erişim için bölüm ve enstitülerimiz için bildirilen e-posta adresleri ve bu adreslerle ilişkili olarak oluşturulacak erişim parolası kullanılacak, yazılıma bölüm/enstitü içerisinde aynı anda sadece tek bir kişi erişim sağlayabilecektir. Bölüm/enstitü içerisinde yazılımı kullanma ihtiyacı olan öğretim üye ve görevlilerimiz ilgili bilgisayar koordinatörleri ile iletişime geçerek erişim için gerekli bilgileri edinebilirler._

* * *

**_\[1\] Not:_** _Democreator yazılımı sadece personelin kullanımına açıktır._

**_\[2\] Not:_** _Bölümünüz/enstitünüz için kullanıma sunulan Democreator yazılımına erişim için tanımlanan e-posta adresi ve erişim parolasının hem güvenlik hem de ortak kullanım açısından üçüncü kişilerle paylaşılmaması gerekmektedir._

**_\[3\] Not:_** _Lisans yetkilendirme ve parola işlemleriyle ilgili bölüm/enstitü için tanımlanan e-posta adreslerine otomatik gelen mesajların gönderici satırında Democreator yazılımı üreticisi_ _Wondershare_ _firmasının ismi ve adresi görüntülenmekte ve bu şekilde ulaşan mesajların_ _spam_ _olarak algılanmaması gerekmektedir._

**_Software Website_** **_:_** **_[https://democreator.wondershare.com/](https://democreator.wondershare.com/)_**

**_Download link for Windows:_** _**[https://download.wondershare.com/democreator\_full7743.exe](https://download.wondershare.com/democreator_full7743.exe)**_

**_Download link for macOS: [https://download.wondershare.com/democreator-mac\_full7744.zip](https://download.wondershare.com/democreator-mac_full7744.zip)_**

* * *

**BÖLÜM-1**

**Democreator yazılımına erişim için yetkilendirilen e-posta adresi ve erişim parolası bilgilerini edinen kullanıcılarımız yazılımı kullanmak için aşağıdaki adımları izleyebilir.**

**_ADIM-1_**

_Democreator yazılımının işletim sisteminize uygun sürümünü notlar bölümünde yer alan linklerden indiriniz ve kurunuz._

**_ADIM-2_**

_Kurulum tamamlandıktan ve program açıldıktan sonra yazılımın tüm özelliklerine erişebilmek için, ilgili bilgisayar koordinatöründen edinilen e-posta adresi ve parola bilgisi kullanılarak giriş (**sign**_**_in_** _) yapılmalıdır. Eğer program kurulduktan sonra giriş yapılmazsa yazılım kısıtlı özellikleriyle de kullanılabilmektedir._

**_ADIM-3_**

_Yazılım tüm özellikleriyle aynı anda sadece tek bir kişi tarafından kullanılabildiğinden, yazılımın kullanımı bittikten sonra mutlaka çıkış yapılması (**sign out**_ _) gerekmektedir; aksi durumda diğer kullanıcılar yazılımı tüm özellikleriyle kullanamaz._

* * *

* * *

* * *

**BÖLÜM-2**

**Democreator yazılımının kullanılacağı bölüm/enstitüden sorumlu bilgisayar koordinatörleri yazılıma erişim parolası oluşturmak için aşağıdaki adımları izleyebilir.**

**_ADIM-1_**

_Democreator yazılımının işletim sisteminize uygun sürümünü notlar bölümünde yer alan linklerden indiriniz ve kurunuz._

**_ADIM-2_**

_Kurulum tamamlandıktan ve program açıldıktan sonra, bölüm/enstitü için belirlenen e-posta adresi ile programa giriş yapılır ve **"Forget your password"**_ _linkine tıklanarak ilgili eposta adresine gönderilecek kod ile parola oluşturulabilir._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/democreator_step1.png)_

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/democreator_step2.png)_

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/democreator_step3.png)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/democreator_step4.png)

* * *

_**Bize**_ _**ulaşın**_ _**:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *