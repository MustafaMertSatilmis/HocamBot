[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-turkiye-katilimcilari-hangi-kurumlardir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7325


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/who-are-turkiye-eduroam-members "Who are the Türkiye eduroam members? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-turkiye-katilimcilari-hangi-kurumlardir "eduroam Türkiye katılımcıları hangi kurumlardır?")

# eduroam Türkiye katılımcıları hangi kurumlardır?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

**eduroam Türkiye Katılımcıları**

eduroam projesi'ne Türkiye'den katılımcı kurumların güncel listesine [bu linkten](http://eduroam.org.tr/participants.php) ulaşabilirsiniz.

- [eduroam Proje Ana Sayfası](http://www.eduroam.org/)