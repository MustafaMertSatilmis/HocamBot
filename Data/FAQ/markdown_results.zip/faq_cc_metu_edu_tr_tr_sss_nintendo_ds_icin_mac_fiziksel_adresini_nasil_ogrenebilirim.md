[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/nintendo-ds-icin-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 6595


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-nintendo-ds "How can I find out the MAC (physical) address on a Nintendo DS?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/nintendo-ds-icin-mac-fiziksel-adresini-nasil-ogrenebilirim "Nintendo DS için MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Nintendo DS için MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

Nintendo DS cihanızda MAC adresi bulmak için, Nintendo DS için kablosuz-etkin oyuna sahip olmalısınız. Daha sonra aşağıdaki adımları izleyin.

1. Oyun menüsünde yer alan Nintendo Kablosuz Bağlantı Kurulumu’na gelin.
2. Seçenekler ve Sistem Bilgisi’ni seçin.
3. MAC adresi en üstteki satırda gösterilecektir.