[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartima-yukledigim-sanal-para-hemen-veya-birkac-kullanimdan-sonra-sifirlandi-bu#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 27-04-2022 **Görüntüleme:** 7695


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/virtual-money-i-have-deposited-my-smartcard-was-set-zero-just-after-i-deposited-or-after-i-used "Virtual money that I have deposited on my smartcard was set to zero just after I deposited or after I used it for a few times. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartima-yukledigim-sanal-para-hemen-veya-birkac-kullanimdan-sonra-sifirlandi-bu "Akıllı kimlik kartıma yüklediğim sanal para hemen veya birkaç kullanımdan sonra sıfırlandı, bu durumda ne yapmalıyım?")

# Akıllı kimlik kartıma yüklediğim sanal para hemen veya birkaç kullanımdan sonra sıfırlandı, bu durumda ne yapmalıyım?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kimlik kartınızdaki sanal para, kullanımınızla orantısız olarak hesabınızdan düştüğünde durumu ODTÜ Bilgi İşlem [sorun bildir](https://bilisimdestek.metu.edu.tr/) adresinden yeni vaka kaydı açarak bildirebilirsiniz. Bu durumda kartın incelenmesi için ilgili birimlerle iletişime geçilir ve sorun tespit edilirse paranızın hesabınıza geri aktarımı sağlanır.