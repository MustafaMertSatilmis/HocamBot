[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtude-ogrenciyim-genel-duyuru-listesine-uye-olabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7084


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-metu-student-can-i-subscribe-genel-duyuru-list-turkish "I am a METU student; can I subscribe to \"genel-duyuru\" list? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtude-ogrenciyim-genel-duyuru-listesine-uye-olabilir-miyim "ODTÜ'de ögrenciyim; \"genel-duyuru\" listesine üye olabilir miyim?")

# ODTÜ'de ögrenciyim; "genel-duyuru" listesine üye olabilir miyim?

[Elektronik Listeler](https://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler)

"genel-duyuru" listesine ODTÜ personeli olan kisiler **`kullanici_adimetu.edu.tr`** seklindeki e-posta adresleri ile otomatik olarak kaydedilmektedir. Ögrencilerin üyelik talepleri kabul edilmemektedir.

Üniversite Rektörlüğünce Öğrencilere yönelik "a-ogrenci-duyuru" (Ankara ve Erdemli Kampusu öğrencilerine yönelik) ve "ogrenci-duyuru" (Ankara, Erdemli ve Kıbrıs Kampusu öğrencilerine yönelik) listeleri bulunmaktadır.  Ayrıca lisansüstü eğitim yapmakta olan öğrenciler için de eğitim durumlarına göre listeler oluşturulmuştur. Bu listelere üyelik sistem tarafından otomasyonla sağlanmaktadır.