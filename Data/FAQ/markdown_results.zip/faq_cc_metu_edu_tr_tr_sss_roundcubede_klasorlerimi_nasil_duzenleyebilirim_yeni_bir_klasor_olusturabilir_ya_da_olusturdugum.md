[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-klasorlerimi-nasil-duzenleyebilirim-yeni-bir-klasor-olusturabilir-ya-da-olusturdugum#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1445


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-klasorlerimi-nasil-duzenleyebilirim-yeni-bir-klasor-olusturabilir-ya-da-olusturdugum)

# Roundcube’de klasörlerimi nasıl düzenleyebilirim? Yeni bir klasör oluşturabilir ya da oluşturduğum klasörlerimi silebilir miyim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube’de ön tanımlı olarak “Gelen”, “Taslak”, “Giden”, “Çöp” klasörleri posta kutunuz altında oluşturulmaktadır. Bunlara ek olarak kendi klasörlerinizi oluşturabilir ve silebilirsiniz.

Klasörlerinizi düzenlemek, yeni klasör oluşturmak ya da bir klasörü silmek için ana menüde yer alan “Ayarlar” seçeneğiyle açılacak menüden “Klasörler” seçeneğini seçerek klasör düzenleme ekranına ulaşabilirsiniz. Açılacak olan sekmede “Ekle” butonuna tıklayarak yeni bir klasör oluşturabilirsiniz. Mevcut klasörlerinizden silmek istediğiniz bir klasör varsa bu klasörü seçtikten sonra “Sil” butonuna tıklayarak silebilirsiniz. Sistemde ön tanımlı olarak oluşturulmuş olan klasörlerinizi silemezsiniz, bu nedenle bu klasörlerden birini seçtiğinizde “Sil” butonu pasif hale gelecektir. Diğer klasörlerinizden birini seçtiğinizde ise “Sil” butonunun tekrar aktifleştiğini görebilirsiniz. Seçtiğiniz bir klasörün içindeki iletilerinizi silmek için ise “Boşalt” butonunu kullanabilirsiniz.