[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-haritasi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-09-2022 **Görüntüleme:** 15794


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/pc-rooms-map "How can I reach the PC Rooms Map?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-haritasi "PC Salonları Haritasına Nasıl Erişebilirim?")

# PC Salonları Haritasına Nasıl Erişebilirim?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

![](https://faq.cc.metu.edu.tr/tr/system/files/pcrooms-map.jpg)

## PC Salonları

1. Beşeri Bilimler

2. 1\. Yurt

3. 2\. Yurt (1,2,3)

4. İsa Demiray Yurdu

5.Faika Demiray Yurdu

6.Refika Aksoy Yurdu

![map icon](https://faq.cc.metu.edu.tr/system/files/mapicon.png)[ODTÜ Harita servisi](http://harita.odtu.edu.tr/kategori/25/bilgisayar_laboratuvarlari) üzerinden görüntüleyin.