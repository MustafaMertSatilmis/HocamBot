[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yanlislikla-sildigim-e-postalara-nasil-ulasabilirim-yedekten-donmek-mumkun-mudur#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 07-03-2022 **Görüntüleme:** 6558


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yanlislikla-sildigim-e-postalara-nasil-ulasabilirim-yedekten-donmek-mumkun-mudur)

# Yanlışlıkla sildiğim e-postalara nasıl ulaşabilirim? Yedekten dönmek mümkün müdür?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Yanlışlıkla sildiğiniz e-postalara ve klasörlerinize ulaşmak için [https://portal.metu.edu.tr/odtu\_bidb/yedekleme/yedekleme.xhtml](https://portal.metu.edu.tr/odtu_bidb/yedekleme/yedekleme.xhtml) adresinden karşınıza çıkan formu doldurmanız yeterli olacaktır. Yedekler her gün gece yarısından sonra alınmaktadır. Bu nedenle aynı gün içinde gelen ve silinen e-postaların yedeğine ulaşılması mümkün değildir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u37208/portal_yedek.png)

**Yedek tarihi seçilirken dikkat edilmesi gereken noktalar:**

\\* Yedekler gecelik olarak alındığı için belli bir günün yedeği isteniyorsa o günün yedeği en erken bir sonraki yedekte olabiliyor. Bu sebeple yedek tarihi bir sonraki günün tarihi olarak seçilmelidir. Örneğin: 20 Temmuz günü hesabınızda gelen bir e-posta ya da oluşturulan dosyayı bulmak için 21 Temmuz tarihli yedeği seçmeniz gerekmektedir.

\\* Herhangi bir yedek tarihinin seçilmesi o tarihte gelen e-postaların yedeğinin indirilmesi anlamına gelmemektedir. Size gönderilecek olan yedek o tarihte hesabınızdaki klasörün tümünü içerecektir. Örneğin: 20 Temmuz tarihinde gelmiş olan bir e-postanızı 30 Temmuz tarihinde silmişseniz 21-29 Temmuz tarihli herhangi bir INBOX yedeğinizde bu e-postayı bulabilirsiniz.

\\* Eğer yanlışlıkla hesabınızdaki bir e-posta klasörünün tamamını silerseniz yedek başvuru yaparken seçebileceğiniz en güncel yedek yanlışlıkla yapılan silme işleminden bir önceki gün alınan yedek olacaktır. Örneğin 30 Temmuz tarihinde hesabınızda bulunan INBOX klasörünceki tüm epostaları kaybederseniz isteyebileceğiniz en güncel yedek 29 Temmuz tarihli yedek olacaktır.

\\* Yedekleme sistemi bir grup donanım ve yazılım bileşenlerinin birlikte çalışmasını gerektirdiğinden her zaman sorunsuz çalışması garanti edilememektedir. Eğer istediğiniz tarihe ait yedek bulunmuyorsa ve eğer varsa en yakın tarihli yedek size gönderilecektir.

Not: Yedekler en fazla 30 gün geriye yönelik olarak alınabilmektedir.