[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/soa-yaklasimi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-10-2024 **Görüntüleme:** 1073


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/soa-yaklasimi)

# SOA Yaklaşımı

[BİDB hakkında](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda)

Bilgi İşlem Daire Başkanlığı özellikle yenilikçi hizmet sunumlarında servis odaklı mimari yaklaşımını benimsemektedir. Hizmetleri farklı sistemlerde yeniden kullanmak için bir kere yazılması ve diğer sistemlere sunulması şeklinde oluşturulmaktadır. Bütünleşik bilgi sistemi projesinde Servis Odaklı Mimari (SOM) yaklaşımı tercih edilen projede orijinal halinde SOM yığını Şekil-1’de gösterilmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u124260/ekran_resmi_2024-10-18_00.55.39.png)

Bu proje ile değişik hizmetler Servis Odaklı Mimariye uygun olarak tasarlanan altyapıdan sunulmaktadır. Özellikle Üniversite bütçe yönetimini sağlayan ana hizmetimiz ile birlikte aşağıda yer alan muhtelif hizmetler bu şekilde verilmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u124260/ekran_resmi_2024-10-18_01.23.24.png)

Üniversitemizde verilen hizmetler [https://portal.metu.edu.tr](https://portal.metu.edu.tr/) adresinde bütüncül olarak verilmekte olup, çeşitli hizmetler Single Sİgn On ile sağlanmakta, böylece bir kere kimlik yetkilendirme sistemi kurulduktan sonra diğer hizmetlerin bu merkezi kimlik yetkilendirme hizmetinden yararlanması sağlanmıştır.

Benzer şekilde sistemler arası web servisler ile entegrasyon sağlanmış, Insan Kaynakları Bilgi Sistemi, Öğrenci Bilgi Sistemi gibi ana veri kaynaklarından sunulan web serivislerin ihtiyaç duyulan sistemler ile paylaşımı sağlanmış, aynı veri servislerinin farklı sistemlerin de entegrasyonu için birden fazla kullanılabilmesi gerçekleştirilmiştir.