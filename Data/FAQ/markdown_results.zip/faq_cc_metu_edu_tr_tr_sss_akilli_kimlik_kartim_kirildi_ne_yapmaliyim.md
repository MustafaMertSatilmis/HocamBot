[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-kirildi-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-10-2024 **Görüntüleme:** 47936


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-smartcard-broken-what-should-i-do "My smartcard is broken, what should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-kirildi-ne-yapmaliyim "Akıllı kimlik kartım kırıldı, ne yapmalıyım?")

# Akıllı kimlik kartım kırıldı, ne yapmalıyım?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kimlik kartınız kırıldığında ya da fiziksel olarak zarar gördüğünde ve bu durumdan dolayı kullanamadığınızda kartınız ücretli olarak değiştirilir. Kart talebinde bulunmak için cardinfo websayfasını ( [https://cardinfo.metu.edu.tr/](https://cardinfo.metu.edu.tr/)) kullanabilirsiniz. Kartınızı teslim almak için; öğrenci iseniz bölümünüzün sekreterliğine, personel iseniz çalıştığınız birimin sekreterliğine başvurabilirsiniz. Yeni kart çıkartma işlemi için gereken evrakları ilgili daire başkanlıklarından öğrenebilirsiniz.