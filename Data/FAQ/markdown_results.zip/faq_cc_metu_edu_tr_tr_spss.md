[Jump to navigation](https://faq.cc.metu.edu.tr/tr/spss#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-04-2022 **Görüntüleme:** 51650


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/spss "SPSS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/spss "SPSS")

# SPSS

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— IBM SPSS STATISTICS 28—**

**_SPSS_** _betimsel istatistikler ve karmaşık istatistiksel analizler üreten bir programdır. SPSS geriye dönük olarak uyumludur, eski sürüm SPSS dosyaları ile sorunsuz şekilde çalışmaktadır._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

**_[KURULUM](https://faq.cc.metu.edu.tr/tr/spss#kurulum)_**

**_[AKTİVASYON](https://faq.cc.metu.edu.tr/tr/spss#aktivasyon)_**

**_[AKTİVASYON PROBLEMLERİ OLDUĞUNDA YAPILMASI GEREKENLER](https://faq.cc.metu.edu.tr/tr/spss#problem)_**

* * *

_**_\[1\] Öğrenciler için not:_**Lisans anlaşmamız gereği SPSS programı öğrenci kullanımına kampüs içi PC Salonlarından erişmeniz mümkündür. BİDB PC Salonlarında ilgili uygulama kurulu olup, bölüm/birimlerde kullanımı için bölüm/birim koordinatörleri ile iletişime geçebilirsiniz. Bölüm/birim koordinatörlerine ulaşmak için [http://coordinators.metu.edu.tr/koordinator-listesi](http://coordinators.metu.edu.tr/koordinator-listesi) adresini kullanabilirsiniz._

* * *

**_ADIM-1 <<<KURULUM>>>_**

_ISO dosyasının içerisinde yer alan_**_“SSC\_64-bit\_28.0.0.0\_MWindsMSE_** **_”_**_isimli kurulum dosyasına tıklayarak kuruluma başlayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step1.png)

**_ADIM-2_**

**_“Next_** **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step2.png)

**_ADIM-3_**

**_“I accept the terms in the license agreement”_** _seçeneğini işaretleyiniz ve**“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step3.png)

**_ADIM-4_**

**_“Next”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step4.png)

**_ADIM-5_**

**_“Install”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step5.png)

**_ADIM-6_**

**_“Start IBM SPSS Statistics now”_** _seçeneğini işaretleyiniz ve**“Finish”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step6.png)

**_ADIM-7 <<<AKTİVASYON>>>_**

**_“Launch License Wizard”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step7.png)

**_ADIM-8_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step8.png)

**_ADIM-9_**

**_“Concurrent user license_** **_”_** _seçeneğini işaretleyiniz ve**“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step9.png)

**_ADIM-10_**

_Aktivasyon işlemi için **“License manager server name or IP address”**_ _başlığı altında yer alan alana **“spss.cc.metu.edu.tr”**yazıp **“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step10.png)

**_ADIM-11_**

_Aşağıdaki ekran geldiğinde kurulumunuz sorunsuz bir şekilde tamamlanmış demektir. **“Finish”**_ _butonuna tıklayarak aktivasyon işlemini sonlandırınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/spss_28_step11.jpeg)

* * *

_**AKTİVASYON PROBLEMLERİ OLDUĞUNDA YAPILMASI GEREKENLER**_

1- Lisans anlaşması ve yeni lisans yönetimindeki teknik gereklilik nedeniyle, SPSS yazılımının yeni lisansı kullanıma alındığında kullanıcılar da yazılımın yeni versiyonunu kurmalıdır. Yeni versiyonun lisansının kullanılmaya başlanması sonrasında eski sürümler kullanılamaz. Lisans yenileme söz konusu olduğunda, yenileme tarihi öncesinde yerleşke genelinde duyurusu yapılır ve kullanıcıların bu duyuruları takip etmesi önerilmektedir.

2- Yazılım anlaşma koşulları gereği kullanılan ağ lisans sunucusu sistemi nedeniyle sadece ODTÜ yerleşke ağı içinde kullanılabilmektedir.

3- Yazılımı kurarken lisans aktivasyon sihirbazı çalışmaz ise lisans sunucusu yapılandırma bilgilerini değiştirmek için aşağıdaki manuel adımları uygulayabilirsiniz.

Son kullanıcı bilgisayarları için lisans sunucusu ayarlarını yapılandırmak için aşağıdaki adreste yer alan**"commutelicense.ini"** dosyasını notepad ile açınız ve dosyanın içeriğinin aşağıdaki gibi olduğundan emin olunuz (Windows İşletim Sistemi için).

**Dosya Konumu >>> C:\\Program Files\\IBM\\SPSS Statistics**

\[Commuter\]

DaemonHost=spss.cc.metu.edu.tr

Organization=IBM

CommuterMaxLife=7

\[Product\]

VersionMajor=28

VersionMinor=0

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *