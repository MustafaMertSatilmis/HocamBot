[Jump to navigation](https://faq.cc.metu.edu.tr/tr/microsoft365#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-02-2025 **Görüntüleme:** 30591


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/microsoft365 "MICROSOFT 365 ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/microsoft365 "MICROSOFT 365 ")

# MICROSOFT 365

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT** **365** **—**

_Üniversitemiz personeli ve öğrencileri_ **_aktif olarak üniversitede bulundukları süre boyunca_** _Word, Excel, PowerPoint, OneNote ve Microsoft Teams'in yanı sıra ek sınıf araçlarını içeren **Microsoft 365 hizmetlerine (eski adıyla Office 365)** ücretsiz olarak kaydolabilirler._

_Microsoft 365 hizmetlerinden yararlanabilmek için **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** şeklinde geçerli bir ODTÜ personeli veya öğrenci kullanıcı hesabı gereklidir. Talep eden personellerimize **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** şeklindeki hesapları; öğrencilerimize ise **[exxxxx@metu.edu.tr](mailto:exxxxx@metu.edu.tr)**şeklindeki ODTÜ hesapları([ad.soyad@medu.edu.tr](mailto:ad.soyad@medu.edu.tr) şeklindeki alias adreslere tanımlama yapılamamaktadır) ile ilişkili Microsoft kullanıcı hesapları oluşturulmakta ve lisans tanımlaması yapılmaktadır._

_Microsoft hizmetleri ile ilgili sorularınızı **_[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)_** şeklindeki ODTÜ e-posta adresinizi kullanarak **[_https://bilisimdestek.metu.edu.tr_](https://bilisimdestek.metu.edu.tr/)** üzerinden iletebilirsiniz._

* * *

**MICROSOFT HİZMETİNE İLK KEZ NASIL KAYIT OLUNUR? // Microsoft 365'i kullanmaya başlayın!**

1. _[https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/) sayfasına ODTÜ kullanıcı hesabınızı ve parolanızı kullanarak giriş yapınız. (Not: Bu sayfaya kampüs dışından erişmek için [VPN hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) kullanılmalıdır.)_
2. _Sayfaya giriş yaptığınızda üst menüde yer alan Microsoft sekmesine tıklayarak Microsoft hesabınızın durumunu kontrol ediniz. Daha önce açılmış bir Microsoft hesabınız yok ise bu ekranda yeni kullanıcı oluşturma sayfası açılacaktır. Buradaki formu doldurup gönderdiğinizde Microsoft kullanıcı hesabınız açılmış olacak; kullanıcı adınız ve belirlediğiniz şifre ile Microsoft uygulamalarını (Teams ve Office365) kullanmaya başlayabileceksiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ms1.png)_

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ms2.png)_

_NOT: Kullanıcı oluşturma butonuna basıldığında işlemin uzun sürmesi sebebiyle, işlemin bitmesini beklemeden (İşlem yapıldığını gösteren "spinner" ikonu dönerken) sayfadan çıkılmaması veya sayfanın yenilenmemesi gerekmektedir. İşlem başarılı şekilde tamamlandığında kullanıcınızın oluşturulduğu bilgisinin ekranda görünmesi gerekmektedir._

* * *

_**NASIL GİRİŞ YAPILIR? // Microsoft 365 Uygulamalarına erişin!**_

_Microsoft kullanıcı hesabınız oluşturulduktan sonra Microsoft 365 uygulamalarını kişisel cihazlarınıza indirip yüklemek için, Microsoft hesabınıza bağlı ODTÜ e-posta adresiniz ve parolanız ile aşağıdaki bağlantıdan giriş yapınız:_

**_[https://www.microsoft365.com/](https://www.microsoft365.com/)_**

* * *

**_**_SORUN GİDERME_**_**

_Daha önce **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** şeklindeki ODTÜ kullanıcı hesabı ile Microsoft 365 uygulamalarına kayıt olunduysa; bu uygulamaları kişisel cihazlara indirip yüklemek için, Microsoft kaydı sırasında kullanılan [xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr) şeklindeki ODTÜ kullanıcı hesabı ve bunun için oluşturulmuş Microsoft parolası ile [https://www.microsoft365.com/](https://www.microsoft365.com/) adresine giriş yapılmalıdır._

_Üniversitemizde geçtiğimiz aylarda duyurulan Microsoft altyapısı değişikliği nedeniyle, daha önce **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** şeklinde Microsoft kaydı oluşturmuş kullanıcılarımız yeni geçilen altyapıda Microsoft 365 uygulamalarına girişte hata ile karşılaşabilmektedir. Bu hata, daha önce bilgisayarda yüklü olan Microsoft servislerine açılmış ve kayıt edilmiş eski oturumlardan kaynaklanmaktadır._

_Giriş hatası yaşayan kullanıcılarımız Microsoft firması tarafından önerilen aşağıdaki adımları uygulayabilirler:_

_**Windows kullanıcıları için:**_

1. Windows tuşu + R tuşlarına basarak Çalıştır’ı (Run) açın, %localappdata%/Microsoft yazın ve Enter’a basın.
2. Oradan OneAuth ve IdentityCache klasörlerini silin.
3. Kimlik bilgisi yöneticisini (credential manager) açın ve Windows kimlik bilgilerine (windows credentials) tıklayın.
4. Office 365 ile ilgili tüm genel kimlik bilgilerini silin.
5. Kayıt defteri düzenleyicisini (Registry editor) açın ve şu yolu izleyin: HKEY\_CURRENT\_USER\\Software\\Microsoft\\Office<16.0>\\Common\\Identity.
6. Kimlik klasörünü (identity folder) silin.
7. Bilgisayarı yeniden başlatın ve uygulamalara **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** hesabı ve Microsoft için oluşturulmuş parola ile giriş yapmayı deneyin.

_**MAC kullanıcıları için:**_

1. Office paketini silin ve tekrar yükleyin. Sonrasında uygulamalara **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** hesabı ve Microsoft için oluşturulmuş parola ile giriş yapmayı deneyin.
2. Eğer işe yaramazsa, önbelleği silmek için aşağıdaki adımları kullanın:
3. Yöntem 1:
1. Finder’ı açın ve Shift + Command + G tuşlarına basarak Klasöre Git penceresini açın.
2. /Library/Containers//com.Microsoft.OsfWebHost/Data/ yazın ve Git’e (Go) basın.
3. Bu klasördeki tüm dosyaları seçin ve silin.
4. Uygulamalara **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** hesabı ve Microsoft için oluşturulmuş parola ile giriş yapmayı deneyin.
4. Yöntem 2:
1. Terminal’i kullanarak şu komutu yazın: rm -rf /Library/Containers/com.Microsoft.OsfWebHost/Data/\* ve Enter’a basın.
2. Uygulamalara **[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)** hesabı ve Microsoft için oluşturulmuş parola ile giriş yapmayı deneyin.

* * *

**_ÖNEMLİ NOTLAR_**

**_\[1\] Aktif olarak personel veya öğrenci olma durumunuza bağlı uygunluk notu_** _: Microsoft 365 mevcut tüm öğrencilere ve personele ücretsiz olarak sunulmaktadır. Microsoft 365 aboneliği ODTÜ'de öğrenci veya personel olarak geçirdiğiniz süre boyunca geçerli olacaktır. Mezun olduğunuzda veya üniversiteden ayrıldığınızda, hesabınız kapatılmadan önce kaydetmek istediğiniz verileri (e-postalar, ekler, OneDrive vb.) kopyalayın. Buna göre, hesap kapatıldığında bulut hizmetinde saklanan tüm veri ve bilgilere artık erişilemeyecek veya kurtarılamayacaktır. Dosya ve veri kaybını önlemek için lütfen tüm dosyaları düzenli olarak kişisel bilgisayarınıza yedekleyin veya senkronize edin._

**_\[2\] Lisans Etkinleştirme/Aktivasyon notu:_** _Office uygulamalarından birini açtıktan sonra istendiğinde Microsoft hesabınıza bağlı personel/öğrenci e-posta adresiniz ve parolanızla oturum açarak Microsoft 365'inizi etkinleştirin. Bu, Üniversitenin lisansına uygun olarak Microsoft 365'in tam sürümünü almanızı sağlayacaktır._

**_\[3\] Öğrenciler için not:_** _Microsoft 365 hizmetine kayıt olurken öğrencilerin [e123456@metu.edu.tr](mailto:e123456@metu.edu.tr) gibi bir e-posta adresi ile kayıt olmaları gerekmektedir. [ad.soyad@metu.edu.tr](mailto:ad.soyad@metu.edu.tr) gibi e-posta adreslerinde tanımlanan takma adlarla kayıt yapılması lisans anlaşmaları gereği kesinlikle yasaktır._

**_\[4\]_** **_Microsoft Office 365 Duyuru notu_** _: ODTÜ mail hesaplarına bağlı Microsoft Office 365 hizmetlerinde 30 Haziran 2024 itibari ile değişiklik gerçekleşecektir. Bu tarih itibari ile Office 365 hizmetlerinde yeni durumda OneDrive kotası olmayacaktır . Belirtilen tarihe kadar OneDrive, Teams hesabındaki (Kayıtlar ve kanallar dahil) ve Microsoft servislerinde bulunan tüm verilerinizi yedekleme/silme işlemini gerçekleştirmeniz gerekmektedir. Bu tarihe kadar hesaplarınızın yeni koşullara/şartlara uygun hale getirilmemesi durumunda yaşanacak olan hizmet kesintileri, veri kaybı vb. durumlardan ilgili e-posta sahibi kullanıcı sorumludur. Belirtilen şartlara göre hesaplarınızda depolanan verilerinizin geri dönüşü mümkün olmayan şekilde kaybolacağını hatırlatırız._

_**\[5\] Mezun ve Emekli kullanıcılar için not:** Mezun ve emekli kullanıcılarımız için eski verilerine ulaşma imkanları devam etmektedir. Yeni altyapı üzerinde mezun ve emekli kullanıcılarımız için yeni bir tanımlama yapılmamaktadır._

_**\[6\] _Microsoft tarafından küresel ölçekli politika değişikliği doğrultusunda Microsoft Office 365 kullanıcılarına kurumsal depolama alanı dahilinde sunulan OneDrive depolama alanı artık olmayacaktır._** _Bu kapsamda olası veri kayıplarının önüne geçmek için 1 Ağustos 2024 tarihine kadar OneDrive üzerinde bulunan verilerinizi harici bir depolama alanına yedeklemenizi ve bu alanı boşaltmanızı öneriyoruz.__

* * *

**FAYDALI BAĞLANTILAR**

- [_**Microsoft 365 Office'i yükleyin**_](https://support.microsoft.com/en-au/office/download-and-install-or-reinstall-microsoft-365-or-office-2021-on-a-pc-or-%20mac-4414eaaf-0478-48be-9c42-23adc4716658)
- [_**Microsoft 365 Office'i etkinleştirin**_](https://support.microsoft.com/en-au/office/activate-office-5bd38f38-db92-448b-a982-ad170b1e187e)
- [_**Windows için Office'i kaldırma**_](https://support.microsoft.com/en-au/office/uninstall-office-from-a-pc-9dd49b83-264a-477a-8fcc-2fdf5dbf61d8)
- [_**Mac için Office'i kaldırma**_](https://support.microsoft.com/en-au/office/uninstall-office-for-mac-eefa1199-5b58-43af-8a3d-b73dc1a8cae3)
- [_**Microsoft 365 Eğitim Merkezi**_](https://support.microsoft.com/en-us/training)
- [_**Microsoft 365 yardım ve öğrenme**_](https://support.microsoft.com/en-us/microsoft-365)
- [_**Microsoft 365 Hızlı Başlangıçlar**_](https://support.microsoft.com/en-us/office/microsoft-365-quick-starts-25f909da-3e76-443d-94f4-6cdf7dedc51e)
- [_**Dosyaları OneDrive'dan cihazınıza indirin**_](https://support.microsoft.com/tr-tr/office/dosyalar%C4%B1-onedrive-dan-cihaz%C4%B1n%C4%B1za-indirme-c81487ff-47e4-480e-98f8-7912f78b5246)
- [_**OneDrive'daki dosya veya klasörleri silin**_](https://support.microsoft.com/tr-tr/office/onedrive-da-dosya-veya-klas%C3%B6rleri-silme-21fe345a-e488-4fa7-932b-f053c1bebe8a)
- [_**Eğitim için Office 365 A1 Plus, 1 Ağustos 2024’te kullanımdan kaldırılacak**_](https://www.microsoft.com/tr-tr/education/products/office-365-a1-plus)


* * *

_Microsoft hizmetleri ile ilgili sorularınızı **_[xxxxxx@metu.edu.tr](mailto:xxxxxx@metu.edu.tr)_** şeklindeki ODTÜ e-posta adresinizi kullanarak **[_https://bilisimdestek.metu.edu.tr_](https://bilisimdestek.metu.edu.tr/)** üzerinden iletebilirsiniz._

* * *