[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uygundur-notlarini-cikti-olarak-alabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-02-2024 **Görüntüleme:** 4540


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uygundur-notlarini-cikti-olarak-alabilir-miyim)

# "Uygundur" notlarını çıktı olarak alabilir miyim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de "Notlar" alanının çıktısının alınması özelliği bulunmamaktadır. "Ekran Alıntısı Aracı" veya "Snipping Tool" isimli araç ile ekranın resmini çekip çıktısını alabilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.