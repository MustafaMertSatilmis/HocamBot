[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/casus-yazilimlardan-korunmak-icin-neler-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-03-2024 **Görüntüleme:** 15265


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-protect-my-computer-against-spyware "What should I do to protect my computer against spyware?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/casus-yazilimlardan-korunmak-icin-neler-yapmaliyim "Casus yazılımlardan korunmak için neler yapmalıyım?")

# Casus yazılımlardan korunmak için neler yapmalıyım?

[Virüs](https://faq.cc.metu.edu.tr/tr/groups/virus)

Casus yazılımlardan korunmanın en etkin yolu, bunların bulaşmasına yol açan kullanıcı alışkanlıklarının önüne geçmektir. İnternet'te gezinirken her türlü uyarı veya soru penceresini onaylamak birçok gereksiz yazılımın yüklenmesine sebep olmaktadır. Bilgisayar uzmanlığı ve tecrübesi yüksek kişiler herhangi bir anti-casus yazılım kullanmadan da sorunlardan uzak kalabilmektedirler. Bu nedenle herhangi bir web sayfasında karşılaştığınız uyarı veya diyalog penceresinin ne istediği iyice anlamadan ya da bilen birilerine sormadan onaylamamanız gerekir.

Buna ek olarak, İnternet hızlandırıcı, hızlı yükleme, dosya paylaşım vs. bazı ücretsiz yazılımlar kendi fonksiyonlarının dışında casus yazılım yüklemektedir. Hatta kendisinin anti-casus yazılımı olduğunu ve bilgisayarı zararlı yazılımlardan temizleyeceğini iddia ederek bilgisiz kullanıcıları yanıltan ve böylece birçok bilgisayara kurulan casus yazılımlar da mevcuttur. Bu tür ücretsiz bir yazılımı kurmadan önce İnternette hakkında araştırma yapmanız ya da başkalarından teknik destek almanız yararınıza olacaktır.

**Anti-casus yazılımlar**

Anti-casus yazılımlar, bilgisayarları casus yazılımlardan korumak amacıyla geliştirilmiş güvenlik yazılımlarıdır. Bazı anti-virüs yazılımları çok bilinen casus yazılımlara karşı bilgisayarları koruyabilmektedir, ancak anti-casus yazılımları bunları sistemden silme, kaldırma veya devre dışı bırakma ve yeni çıkan casus yazılımlara karşı kendini güncelleme konusunda uzmanlaşmıştır. Bu yazılımların bir kısmı ücretli olmakla beraber ücretsiz, yetkin ve çok kullanılan anti-casus yazılımlar da bulunmaktadır.

- **Windows Defender**
Microsoft firmasının Windows işletim sistemlerini casus yazılımlardan korumak üzere geliştirdiği ve lisanslı Windows kullanıcılarına İnternet üzerinden ücretsiz olarak sunduğu yazılımdır. Bu yazılım Windows Vista ve daha yeni işletim sistemleri üzerinde kurulu gelmektedir. Yazılımı etkinliştirmek için Windows Güvenliği ögesini arayıp açmanız ve "Eylem Gerekiyor" işlemini yapmanız gerekmektedir.