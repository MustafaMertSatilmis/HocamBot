[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeler-icin-nasil-ortak-bir-e-liste-sifresi-tanimlayabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8015


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-define-common-password-electronic-lists-i-have-subscribed-turkish "How can I define a common password for the electronic lists I have subscribed? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeler-icin-nasil-ortak-bir-e-liste-sifresi-tanimlayabilirim "Üye olduğum tüm e-listeler için nasıl ortak bir e-liste şifresi tanımlayabilirim?")

# Üye olduğum tüm e-listeler için nasıl ortak bir e-liste şifresi tanımlayabilirim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

E-liste servisindeki altyapı gereği, kullanıcıların üye oldukları her bir e-liste için farklı e-liste şifreleri tanımlanmaktadır. Dileyen kullanıcılarımız kolaylık olması açısından, tüm e-listeler için ortak bir e-liste şifresi tanımlayabilirler. Bunun için aşağıdaki işlemlerin yapılması gerekmektedir.

Not: Güvenlik önlemi olarak, merkezi kullanıcı kodları için kullanılan şifrelerin e-liste şifresi olarak kullanılmaması önerilmektedir.

Bir kullanıcı öncelikle üye olduğu herhangi bir listeye gönderilmiş bir mesajın sonunda yer alan e-liste web arayüzü bağlantısını kullanarak o e-listenin ayarları ile ilgili değişikliklerin yapılabildiği sayfaya ( **[http://mailman.metu.edu.tr/mailman/listinfo/liste\_adi](http://mailman.metu.edu.tr/mailman/listinfo/liste_adi)**) girmelidir.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_03.jpg)

Bu sayfanın en alt bölümünde yer alan e-posta adresi bölümüne, bu e-listeye üye olmak için kullandığı e-posta adresini yazarak, Listeden çık veya seçeneklerimi düzenle isimli butona tıklamalıdır.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_04.jpg)

Eğer e-liste şifresi daha önceden girilmiş ise, aşağıdaki şekilde olduğu gibi e-liste üyelik ayarlarının değiştirilebildiği ekran görünecektir. Aksi durumda, e-liste şifresi kullanılarak giriş yapılmalıdır:

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_05.jpg)

Üye olduğu tüm e-listelere yönelik ortak bir şifre tanımlamak isteyen kullanıcı bu sayfada yer alan Şifre Değişimi bölümüne mevcut e-liste şifresini veya kullanmak istediği herhangi bir şifreyi yazıp, Şifremi Değiştir butonuna Global Olarak Değiştir seçeneği seçili olacak şekilde tıklamalıdır.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_06.jpg)

Bu işlem başarılı bir şekilde gerçekleştirildiği takdirde, ekranda Şifre başarıyla değiştirildi. şeklinde bir mesaj görüntülenir. Kullanıcı tarafından tanımlanan yeni şifre artık aynı e-posta adresi ile üye olunan mevcut tüm e-listelerde kullanılabilir.

Şifre değiştirme işlemi sırasında Global Olarak Değiştir seçeneği seçili olmadığı durumda, sadece söz konusu e-listenin şifresi değiştirilmiş olur.

"Global Olarak Değiştir" seçeneği ile kullanıcının o ana kadar üye olduğu tüm listelerin şifreleri değiştirilir. Bu işlem sonrasında üye olunacak yeni e-listelerde de aynı şifrenin kullanılabilmesi için bu işlemin her üyelikten sonra tekrarlanması gerekir. Bu işlem yapılmadığında yeni üye olunan e-listelerde, üye olurken Mailman tarafından otomatik olarak tanımlanıp kullanıcıya gönderilen şifreler kullanılır.