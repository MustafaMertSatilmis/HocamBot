[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/mezun-e-posta#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Mezun E-posta

|     |
| --- |
| [Mezun E-posta Sistemi Kullanım Politikası](https://faq.cc.metu.edu.tr/tr/sss/mezun-e-posta-sistemi-kullanim-politikasi) |
| [Mezun Eposta Hesabı şifremi nasıl değiştirebilirim? Yeni şifre seçerken nelere dikkat etmeliyim?](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-hesabi-sifremi-nasil-degistirebilirim-yeni-sifre-secerken-nelere-dikkat-etmeliyim) |
| [Mezun Eposta Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-kullanici-hesabi-alirken-yasanabilecek-sorunlar) |
| [ODTÜ Mezun E-posta Kullanıcı Kodu Şifre ve Kurtarma E-Postası İşlemleri](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri) |
| [ODTÜ Mezun E-posta kullanıcı koduma ait şifremi unuttum. Nereden öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim) |

[![Subscribe to Mezun E-posta](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/386/all/feed "Subscribe to Mezun E-posta")