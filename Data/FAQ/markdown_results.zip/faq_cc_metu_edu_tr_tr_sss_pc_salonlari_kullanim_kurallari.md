[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-kullanim-kurallari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-01-2020 **Görüntüleme:** 11979


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/pc-rooms-regulations-turkish "What are PC Rooms Regulations? (In Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-kullanim-kurallari "PC Salonları Kullanım Kuralları Nelerdir?")

# PC Salonları Kullanım Kuralları Nelerdir?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

[http://bidb.metu.edu.tr/politikalar-ve-kurallar](http://bidb.metu.edu.tr/politikalar-ve-kurallar) adresinden PC Salonları Kullanım Kurallarına erişebilirsiniz.