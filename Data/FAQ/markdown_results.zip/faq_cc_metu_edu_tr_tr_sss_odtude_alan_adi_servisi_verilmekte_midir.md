[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtude-alan-adi-servisi-verilmekte-midir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-09-2015 **Görüntüleme:** 7780


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/there-domain-name-service-metu "Is there a Domain Name Service in METU?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtude-alan-adi-servisi-verilmekte-midir "ODTÜ'de Alan Adı Servisi verilmekte midir?")

# ODTÜ'de Alan Adı Servisi verilmekte midir?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

ODTÜ Alan Adı Servisi hakkında daha fazla bilgi almak için lütfen [tıklayınız.](https://bidb.metu.edu.tr/odtu-alan-adi-servisi)