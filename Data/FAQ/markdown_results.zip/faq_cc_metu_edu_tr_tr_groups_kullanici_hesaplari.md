[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Kullanıcı Hesapları

|     |
| --- |
| [BİDB'nin verdiği servislerden yararlanmak için yapılması gerekenler nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-verdigi-servislerden-yararlanmak-icin-yapilmasi-gerekenler-nelerdir) |
| [Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-alirken-yasanabilecek-sorunlar) |
| [Kullanıcı hesabı hangi durumlarda kapatılır?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-hangi-durumlarda-kapatilir) |
| ['ad.soyad@metu.edu.tr' biçimindeki e-posta adresimi değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/adsoyadmetuedutr-bicimindeki-e-posta-adresimi-degistirebilir-miyim) |
| [Kullanıcı hesabım kapatıldı. E-posta yedeklerimi (varsa) nasıl edinebilirim ve açabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabim-kapatildi-e-posta-yedeklerimi-varsa-nasil-edinebilirim-ve-acabilirim) |
| [Kullanıcı hesabımdan yanlışlıkla sildiğim dosyalara nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimdan-yanlislikla-sildigim-dosyalara-nasil-ulasabilirim) |
| [Kullanıcı hesabımın kapatılacağına dair bir e-posta aldım. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimin-kapatilacagina-dair-bir-e-posta-aldim-ne-yapmaliyim) |
| [Merkezi sunucu sistemlere yerleşke dışından nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-disindan-nasil-baglanabilirim) |
| [Merkezi sunucu sistemlere yerleşke içinden nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-icinden-nasil-baglanabilirim) |
| [Merkezi sunucular üzerinde bulunan dosyalarımı nasıl silebilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucular-uzerinde-bulunan-dosyalarimi-nasil-silebilirim) |
| [METUCloud](https://faq.cc.metu.edu.tr/tr/sss/metucloud) |
| [ODTÜ kullanıcı hesabımı kullanarak nasıl web sayfası oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nasil-web-sayfasi-olusturabilirim) |
| [ODTÜ kullanıcı hesabımı kullanarak oluşturduğum web sayfasında "not authorized" mesajı alıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-olusturdugum-web-sayfasinda-not-authorized-mesaji-aliyorum-ne) |
| [ODTÜ Kullanıcı Hesap Yönetimi sayfasından neler yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesap-yonetimi-sayfasindan-neler-yapabilirim) |
| [ODTÜ kullanıcı kodumu ve parolamı nerelerde kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumu-ve-parolami-nerelerde-kullanabilirim) |
| [ODTÜ Öğrencisiyim nasıl @metu.edu.tr uzantılı kullanıcı kodu edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-ogrencisiyim-nasil-metuedutr-uzantili-kullanici-kodu-edinebilirim) |
| [ODTÜ Personeliyim. Nasıl Kullanıcı Kodu Alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-nasil-kullanici-kodu-alabilirim) |
| [SSH Secure Shell programı ile merkezi sunuculara bağlanmaya çalıştığımda "Algorithm negotiation failed" hatası veriyor. Ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ssh-secure-shell-programi-ile-merkezi-sunuculara-baglanmaya-calistigimda-algorithm-negotiation) |

[![Subscribe to Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/7/all/feed "Subscribe to Kullanıcı Hesapları")