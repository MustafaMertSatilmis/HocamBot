[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ip-adresime-uygulanmis-bir-kisitlama-olup-olmadigini-nereden-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 31-01-2019 **Görüntüleme:** 14696


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-learn-whether-my-ip-address-has-restricted-or-not "How can I learn whether my ip address has restricted or not?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ip-adresime-uygulanmis-bir-kisitlama-olup-olmadigini-nereden-ogrenebilirim "IP adresime uygulanmış bir kısıtlama olup olmadığını nereden öğrenebilirim?")

# IP adresime uygulanmış bir kısıtlama olup olmadığını nereden öğrenebilirim?

[Kablolu Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablolu-ag)

SPAM, virus, izinsiz IP kullanımı, P2P programlar nedeni ile lisans ihlali gerçekleştirdikleri belirlenen IP adreslerinin ağ erişimi süreli ya da süresiz BİDB Ağ Grubu tarafından kapatılabilir. IP' nizin durumunu aşağıdaki adresten kontrol edebilirsiniz.

[https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/)-\> Restriction Menüsü

Ağ erişimi kısıtlanan kullanıcılar, erişim kısıtlamasına sebep olan durumu ortadan kaldırdıktan sonra [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) adresine ODTÜ merkezi kullanıcı adı ve şifreleri ile giriş yaparak IP adreslerine uygulanan kısıtlamayı kaldırabilirler.

Bazı kısıtlamalar Restriction menüsünde görünmeyebilir veya kısıtlamayı kaldırmanıza izin verilmeyebilir. Böyle bir durumda lütfen kısıtlanan MAC adresiniz ile birlikte, Bilişim Destek Ekibimize ODTÜ BİDB ana sayfasındaki “Bize Ulaşın” bağlantısından veya [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresini kullanarak iletişime geçiniz. Durumunuz incelenerek size dönüş yapılacaktır.