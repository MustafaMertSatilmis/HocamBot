[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/eduroam#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# eduroam

|     |
| --- |
| [Android işletim sistemi yüklü telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-isletim-sistemi-yuklu-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim) |
| [iPhone telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim) |
| [Mac bilgisayarımdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mac-bilgisayarimdan-eduroam-kablosuz-agina-nasil-baglanabilirim) |
| [Windows 10 bilgisayarımdan eduroam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-10-bilgisayarimdan-eduroam-agina-nasil-baglanabilirim) |
| [eduroam ağına bağlanabilmek için neden program yüklüyorum?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglanabilmek-icin-neden-program-yukluyorum) |
| [eduroam ağına bağlantım sürekli kesiliyor / bağlanamıyor?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglantim-surekli-kesiliyor-baglanamiyor) |
| [eduroam ağının güvenlik derecesi nedir?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-aginin-guvenlik-derecesi-nedir) |
| [eduroam farklı ortamlarda çalışır mı?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-farkli-ortamlarda-calisir-mi) |
| [eduroam nedir?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-nedir) |
| [eduroam şifremi unuttum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-sifremi-unuttum-ne-yapmaliyim) |
| [eduroam teknik yapısı nasıldır?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-teknik-yapisi-nasildir) |
| [eduroam Türkiye katılımcıları hangi kurumlardır?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-turkiye-katilimcilari-hangi-kurumlardir) |
| [eduroam'a nasıl bağlanılır?](https://faq.cc.metu.edu.tr/tr/sss/eduroama-nasil-baglanilir) |

[![Subscribe to eduroam](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/30/all/feed "Subscribe to eduroam")