[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 14812


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-central-e-mail-services-horde "How can I use METU Central E-Mail Services with Horde?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim "Horde ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?")

# Horde ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

Horde, ODTÜ merkezi kullanıcı hesabınıza bağlanarak e-postalarınızı görüntüleyebileceğiniz, takvim, görevler, notlar gibi uygulamalarla işlerinizi organize edebileceğiniz, şifre değişikliği yapma, dosya yükleme gibi ODTÜ Merkezi kullanıcı hesabınızla ilgili işlemleri kolaylıkla yapabileceğiniz bir servistir. Bu servise [http://metumail.metu.edu.tr/](http://metumail.metu.edu.tr/) adresindeki ilgili link tıklanarak ulaşılabileceği gibi (Şekil-1), [https://horde.metu.edu.tr/](https://horde.metu.edu.tr/) adresinden direk olarak da ulaşılabilir (Şekil-2).

![Metu mail main](https://faq.cc.metu.edu.tr/tr/system/files/u2/metumail_main.png)

**Şekil-1**

![Horde 5 giris](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde_giris.png)

**Şekil-2**

Horde servisinin e-posta uygulamaları ile ilgili yardım dosyalarına programa girdikten Posta ikonuna tıkladıktan sonra Yardım ikonuna tıklanarak erişilebilir.