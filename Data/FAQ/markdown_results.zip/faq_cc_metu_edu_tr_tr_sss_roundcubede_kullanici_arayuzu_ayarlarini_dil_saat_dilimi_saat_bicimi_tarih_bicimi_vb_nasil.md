[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-kullanici-arayuzu-ayarlarini-dil-saat-dilimi-saat-bicimi-tarih-bicimi-vb-nasil#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1273


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-kullanici-arayuzu-ayarlarini-dil-saat-dilimi-saat-bicimi-tarih-bicimi-vb-nasil)

# Roundcube'de kullanıcı arayüzü ayarlarını (Dil, saat dilimi, saat biçimi, tarih biçimi vb.) nasıl değiştirebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Ana menüde yer alan "Ayarlar" sekmesini açıp buradan "Kullanıcı Arayüzü" butonuna tıklayınız. Açılacak olan ekranda Roundcube'ün kullandığı arayüz dilini, saat dilimini, saat gösterim biçimini ve diğer arayüz seçeneklerini düzenleyebilirsiniz.