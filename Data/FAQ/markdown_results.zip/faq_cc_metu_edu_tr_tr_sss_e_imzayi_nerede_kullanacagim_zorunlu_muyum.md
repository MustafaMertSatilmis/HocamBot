[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imzayi-nerede-kullanacagim-zorunlu-muyum#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 10-03-2022 **Görüntüleme:** 11303


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/where-will-i-use-e-signature-it-compulsory "Where will I use the e-signature? Is it compulsory?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imzayi-nerede-kullanacagim-zorunlu-muyum "E-imzayı nerede kullanacağım? Zorunlu muyum?")

# E-imzayı nerede kullanacağım? Zorunlu muyum?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

**Elektronik Belge Yönetim Sistemi (EBYS), Mali Yönetim Sistemi v2** gibi kurum içi süreçlerde ya da  **TÜBİTAK başvuruları** gibi kurumlar arası süreçlerde kullanılması gerekmektedir.

Elektronik sertifika kullanımının ilerideki zamanlarda yaygınlaşması öngörülmektedir.

Yukarıda belirtilen amaçlarla kullanmayacaksanız e-imza sertifikası edinmeniz zorunlu değildir.