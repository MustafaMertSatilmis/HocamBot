[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-uygulama-yuklenirken-hata-olustu-mesaji-aliyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-05-2022 **Görüntüleme:** 7558


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-uygulama-yuklenirken-hata-olustu-mesaji-aliyorum-ne-yapmaliyim "EBYS'de \"Uygulama Yüklenirken Hata Oluştu!\" mesajı alıyorum. Ne yapmalıyım?")

# EBYS'de "Uygulama Yüklenirken Hata Oluştu!" mesajı alıyorum. Ne yapmalıyım?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Elektronik Belge Yönetim Sistemi ( **EBYS**)’de Java kurulumuna gerek kalmadan e-imza kullanımına olanak sağlayan **ArkSigner** programı düzenli olarak güncellenmektedir.

Güncellemesi çıkan program geçerliliğini yitirmekte ve yeni versiyon kurulumu zorunlu hale gelmektedir. Güncelleme yapılmadığı durumda “ **Uygulama yüklenirken hata oluştu**” hata mesajı çıkmaktadır.

Sorunu gidermek için [http://www.arksigner.com](http://www.arksigner.com/) adresinden sağ üst köşedeki “**Şimdi İndir**” bağlantısına tıklayarak işletim sistemine göre ilgili dosyayı indirip kurmak gerekmektedir.

Bazı durumlarda programın yeniden kurulması hatayı ortadan kaldırmamakta, AKIS kart okuyucu programını da yeniden kurmak vebilgisayarı açıp kapamak gerekmektedir.

AKIS kurulumu için [http://kamusm.gov.tr](http://kamusm.gov.tr/) sayfasından “**Sürücü**” bağlantısına tıklayarak işletim sistemi, versiyonu, tipi ve kart okuyucu türü seçilerek ilgili sürücüler indirilmeli ve kurulmalıdır.