[Jump to navigation](https://faq.cc.metu.edu.tr/tr#main-menu)

﻿

## Faq Sayısı - Tr

- [EBYS E-imza Uygulaması (DSClient) Lisans Dosyası Değişikliği](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi)

445

- [ÇEVRİMİÇİ DİLBİLGİSİ VE YAZIM DENETİMİ ARAÇLARI](https://faq.cc.metu.edu.tr/tr/spell-checking-tools)

444

- [SOA Yaklaşımı](https://faq.cc.metu.edu.tr/tr/sss/soa-yaklasimi)

443

- [MICROSOFT 365](https://faq.cc.metu.edu.tr/tr/microsoft365)

442

- [EBYS'de sağlık raporları formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-saglik-raporlari-formunu-nasil-doldurabilirim)

441

- [Akıllı kartımı kaybettim, yeni kart başvurusunda bulundum. Kısa bir süre sonra kayıp kartımı buldum ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-kaybettim-yeni-kart-basvurusunda-bulundum-kisa-bir-sure-sonra-kayip-kartimi)

440

- [Gradescope'ta Çoktan Seçmeli Sınavlar](https://faq.cc.metu.edu.tr/tr/sss/gradescopeta-coktan-secmeli-sinavlar)

439

- [EBYS'ye eklenebilecek dosya büyüklük limitleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/ebysye-eklenebilecek-dosya-buyukluk-limitleri-nelerdir)

438

- [E-Devlet Üzerinden Evrak Doğrulama](https://faq.cc.metu.edu.tr/tr/sss/e-devlet-uzerinden-evrak-dogrulama)

437

- [PC Salonlarına Uygulama Kurabilir Miyim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarina-uygulama-kurabilir-miyim)

436

- [EBYS'de E-imza Uygulaması DSClient'da Karşılaşılabilen Uyarılar](https://faq.cc.metu.edu.tr/tr/sss/dsclient-uygulamasinda-karsilasilabilen-uyarilar)

435

- [METUCloud](https://faq.cc.metu.edu.tr/tr/sss/metucloud)

434

- [EBYS'de E-imzayı nasıl kullanabilirim? \[Yeni client - DSClient Uygulaması\]](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client)

433

- [EBYS'de E-imzayı nasıl kullanabilirim? \[Linux\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim)

432

- [EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 3. Adım: DSClient uygulamasını nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimini-nasil-yuklerim)

431

- [EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 2. Adım: E-imza sürücülerini nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-2-adim-e-imza-suruculerini-nasil-yuklerim)

430

- [EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 1. Adım: Java'yı nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim)

429

- [EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 3. Adım: DSClient uygulamasını nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim)

428

- [EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 2. Adım: E-imza sürücülerini nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-2-adim-e-imza-suruculerini-nasil-yuklerim)

427

- [EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 1. Adım: Java'yı nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuklerim)

426

- [EBYS'de fiziksel posta gönderim formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-fiziksel-posta-gonderim-formunu-nasil-doldurabilirim)

425

- [GRADESCOPE](https://faq.cc.metu.edu.tr/tr/gradescope)

424

- [İnternet bağlantım çok yavaş. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir-0)

423

- [VPN Profil Silme Nasil Yapilir?](https://faq.cc.metu.edu.tr/tr/sss/vpn-profil-silme-nasil-yapilir)

422

- [Roundcube'de gelen e-postaları nasıl filtreleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gelen-e-postalari-nasil-filtreleyebilirim)

421

- [Roundcube'de e-postalarımı nasıl silebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-e-postalarimi-nasil-silebilirim)

420

- [Roundcube'de kullanıcı arayüzü ayarlarını (Dil, saat dilimi, saat biçimi, tarih biçimi vb.) nasıl değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-kullanici-arayuzu-ayarlarini-dil-saat-dilimi-saat-bicimi-tarih-bicimi-vb-nasil)

419

- [Roundcube'de posta kutusu ve klasör görüntüleme seçeneklerini nasıl düzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-posta-kutusu-ve-klasor-goruntuleme-seceneklerini-nasil-duzenleyebilirim)

418

- [Roundcube’de klasörlerimi nasıl düzenleyebilirim? Yeni bir klasör oluşturabilir ya da oluşturduğum klasörlerimi silebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-klasorlerimi-nasil-duzenleyebilirim-yeni-bir-klasor-olusturabilir-ya-da-olusturdugum)

417

- [Roundcube'de iletileri farklı klasörlere nasıl kopyalayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-kopyalayabilirim)

416

- [Roundcube'de iletileri farklı klasörlere nasıl taşıyabilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-tasiyabilirim)

415

- [Roundcube'de bir iletinin tam başlık bilgisini nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim)

414

- [Roundcube'de adres defterimi nasıl oluşturabilir ve düzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-adres-defterimi-nasil-olusturabilir-ve-duzenleyebilirim)

413

- [Roundcube'de oluşturduğum bir iletiye nasıl dosya (eklenti) ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-olusturdugum-bir-iletiye-nasil-dosya-eklenti-ekleyebilirim)

412

- [Roundcube'de iletilere nasıl imza ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletilere-nasil-imza-ekleyebilirim)

411

- [Roundcube'de gönderdiğim e-postalarımın biçimini (HTML ya da düz metin) nasıl değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gonderdigim-e-postalarimin-bicimini-html-ya-da-duz-metin-nasil-degistirebilirim)

410

- [Roundcube'de nasıl e-posta gönderebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-nasil-e-posta-gonderebilirim)

409

- [Roundcube ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcube-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim)

408

- [SoliClub uygulması ile akıllı kartıma nasıl bakiye yüklerim ve harcama yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/soliclub-uygulmasi-ile-akilli-kartima-nasil-bakiye-yuklerim-ve-harcama-yapabilirim)

407

- [EBYS'de "Uygulama Yüklenirken Hata Oluştu!" mesajı alıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-uygulama-yuklenirken-hata-olustu-mesaji-aliyorum-ne-yapmaliyim)

406

- [MICROSOFT EDITOR](https://faq.cc.metu.edu.tr/tr/microsoft-editor)

405

- [Toplu Yemek nasıl alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/toplu-yemek-nasil-alabilirim)

404

- [Kayıt sayfasındaki robot resim doğrulama (ben robot değilim) hakkında nereden bilgi edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/kayit-sayfasindaki-robot-resim-dogrulama-ben-robot-degilim-hakkinda-nereden-bilgi-edinebilirim)

403

- [Horde'de çöp kutusunu nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/hordede-cop-kutusunu-nasil-kullanabilirim)

402

- [Sonlandırdığım evrakı nasıl geri alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/sonlandirdigim-evraki-nasil-geri-alabilirim)

401

- [EBYS İzin Formları ile ilgili Yönetici ve Sekreterlere Sunulan Raporlar](https://faq.cc.metu.edu.tr/tr/ebys-izin-formlari-raporlar)

400

- [Akıllı kartıma yurt dışı menşei banka kartımla yükleme yapabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yurt-disi-mensei-banka-kartimla-yukleme-yapabilir-miyim)

399

- [ODTÜ Akıllı Kart Tarihçesi](https://faq.cc.metu.edu.tr/tr/sss/odtu-akilli-kart-tarihcesi)

398

- [Akıllı kartıma İş Bankası aracılığı ile nasıl bakiye yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-bankasi-araciligi-ile-nasil-bakiye-yuklerim)

397

- [Bölüm-Birim kartlı geçiş yetkilendirmesinden sorumlu kişiyim. Kartı geçiş yetkilendirme arayüzüne nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bb-kartli-gecis-listesi)

396

- [ADOBE ACROBAT TARAYICI UZANTISI](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi)

395

- [Odtucard websitesi aracılığı ile nasıl para yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/odtucard-websitesi-araciligi-ile-nasil-para-yuklerim)

394

- [EYP uzantılı dosyaları nasıl açabilirim?](https://faq.cc.metu.edu.tr/tr/sss/eyp-uzantili-dosyalari-nasil-acabilirim-0)

393

- [Kamu kurumu olmayan kurumlara KEP ile evrak gönderebilir miyim, nasıl?](https://faq.cc.metu.edu.tr/tr/sss/kamu-kurumu-olmayan-kurumlara-kep-ile-evrak-gonderebilir-miyim-nasil)

392

- [Evrak numara talebi nasıl yapılır, geçmiş taleplere nasıl erişilebilirim?](https://faq.cc.metu.edu.tr/tr/sss/evrak-numara-talebi-nasil-yapilir-gecmis-taleplere-nasil-erisilebilirim)

391

- [Geçmiş bölümünden evraklara bakarken bir evrak birden fazla kez listede görünebiliyor, neden?](https://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklara-bakarken-bir-evrak-birden-fazla-kez-listede-gorunebiliyor-neden)

390

- [Oluşturduğum bir evrakta imza açılırken bir sıralama yapmak gerekir mi? İmzacı ve parafçı eklerken belli bir sırada mı yazmak gerekiyor?](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-bir-evrakta-imza-acilirken-bir-siralama-yapmak-gerekir-mi-imzaci-ve-parafci)

389

- [Deneme amaçlı veya yanlışlıkla oluşturduğum yazılar silinebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/deneme-amacli-veya-yanlislikla-olusturdugum-yazilar-silinebilir-mi)

388

- [Birden fazla görevim/pozisyonum var, farklı görevimi/pozisyonumu kullanarak nasıl yazı oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/birden-fazla-gorevimpozisyonum-var-farkli-gorevimipozisyonumu-kullanarak-nasil-yazi)

387

- [Görevim değişti, ama eski görevimle ilgili evraklar gelmeye devam ediyor, neden?](https://faq.cc.metu.edu.tr/tr/sss/gorevim-degisti-ama-eski-gorevimle-ilgili-evraklar-gelmeye-devam-ediyor-neden)

386

- [Posta kutusu ve dizin görüntüleme seçenekleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/posta-kutusu-ve-dizin-goruntuleme-secenekleri-nelerdir)

385

- [Akıllı kartımı harcama/yükleme noktalarında okuttuğumda “kartınız okunamadı” / “kartınız tanınmadı” hatası almaktayım. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-harcamayukleme-noktalarinda-okuttugumda-kartiniz-okunamadi-kartiniz-taninmadi)

384

- [Akıllı kartıma yükleme yaptığım banka kartı e-ticarete açık değil, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yukleme-yaptigim-banka-karti-e-ticarete-acik-degil-ne-yapabilirim)

383

- [Mezun E-posta Sistemi Kullanım Politikası](https://faq.cc.metu.edu.tr/tr/sss/mezun-e-posta-sistemi-kullanim-politikasi)

382

- [Mezun Eposta Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-kullanici-hesabi-alirken-yasanabilecek-sorunlar)

381

- [ODTÜ Mezun E-posta Kullanıcı Kodu Şifre ve Kurtarma E-Postası İşlemleri](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri)

380

- [ODTÜ Mezun E-posta kullanıcı koduma ait şifremi unuttum. Nereden öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim)

379

- [Mezun Eposta Hesabı şifremi nasıl değiştirebilirim? Yeni şifre seçerken nelere dikkat etmeliyim?](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-hesabi-sifremi-nasil-degistirebilirim-yeni-sifre-secerken-nelere-dikkat-etmeliyim)

378

- [Apple Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/apple-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim)

377

- [E-imza nedir?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-nedir)

376

- [EBYS'ye hangi türde dosyalar eklenebilmektedir?](https://faq.cc.metu.edu.tr/tr/sss/ebysye-hangi-turde-dosyalar-eklenebilmektedir)

375

- [ARCGIS ONLINE](https://faq.cc.metu.edu.tr/tr/arcgis-online)

374

- [ODTÜ Kullanıcı Kodu Parola ve Kurtarma E-Postası İşlemleri](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodu-parola-ve-kurtarma-e-postasi-islemleri)

373

- [DEMOCREATOR](https://faq.cc.metu.edu.tr/tr/democreator)

372

- [PC salonlarındaki bilgisayarlara kampüs dışından nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarindaki-bilgisayarlara-kampus-disindan-nasil-erisebilirim)

371

- [ADOBE YAZILIMLARINA ERİŞİM](https://faq.cc.metu.edu.tr/tr/adobe)

370

- [PDF belgesine Acrobat Reader DC ile e-imza nasıl atlır?](https://faq.cc.metu.edu.tr/tr/sss/pdf-belgesine-acrobat-reader-dc-ile-e-imza-nasil-atlir)

369

- [VPN uygulaması kurulumunda sorun yaşıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiyorum-ne-yapmaliyim)

368

- [Ders kayıtları için hangi PC Salonlarını kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ders-kayitlari-icin-hangi-pc-salonlarini-kullanabilirim)

367

- [Gelen bir yazı veya elektronik form ile ilgili işlem yapacağım butonları göremiyorum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/yazi-veya-elektronik-form-ile-ilgili-islem-yapacagim-butonlari-goremiyorum)

366

- [EBYS'de Makale Ödülü başvuru formu neden görünmüyor?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-makale-odulu-basvuru-formu-neden-gorunmuyor)

365

- [Nitelikli Elektronik Sertifika (e-imza) için nasıl E-ONAY verilir?](https://faq.cc.metu.edu.tr/tr/sss/nitelikli-elektronik-sertifika-e-imza-icin-nasil-e-onay-verilir)

364

- [Görev Değişikliği / Atama durumlarında EBYS'de tanımlamalar nasıl yapılmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/gorev-degisikligi-atama-durumlarinda-ebysde-tanimlamalar-nasil-yapilmaktadir)

363

- [EBYS İzin Formları ile ilgili Sıkça Sorulanlar](https://faq.cc.metu.edu.tr/tr/sss/ebys-izin-formlari)

362

- [ODTÜ epostalarımı ve adres defterimi farklı bir eposta sistemine nasıl aktarabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-epostalarimi-ve-adres-defterimi-farkli-bir-eposta-sistemine-nasil-aktarabilirim)

361

- [MAXQDA](https://faq.cc.metu.edu.tr/tr/maxqda)

360

- [TÜBİTAK proje başvurularında e-imzamı nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/tubitak-proje-basvurularinda-e-imzami-nasil-kullanabilirim)

359

- [VPN uygulamasını nasıl indiririm?](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasini-nasil-indiririm)

358

- [Microsoft kullanıcı hesabı açıldığına dair bir e-posta aldım. Şimdi ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/microsoft-kullanici-hesabi-acildigina-dair-bir-e-posta-aldim-simdi-ne-yapmaliyim)

357

- [Horde ile gönderilen e-postalarda eklerin kaydedilmesini nasıl sağlayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-gonderilen-e-postalarda-eklerin-kaydedilmesini-nasil-saglayabilirim)

356

- [MICROSOFT TEAMS](https://faq.cc.metu.edu.tr/tr/microsoft-teams)

355

- [Bir Evrak için Gelen EBYS E-posta Bildirimindeki Bağlantıdan Diğer Evraklarıma Nasıl Ulaşırım?](https://faq.cc.metu.edu.tr/tr/sss/bir-evrak-icin-gelen-ebys-e-posta-bildirimindeki-baglantidan-diger-evraklarima-nasil-ulasirim)

354

- [Vekalet aldığımda başkasının yerine elektronik form onaylarını nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/vekalet-aldigimda-baskasinin-yerine-elektronik-form-onaylarini-nasil-yapabilirim)

353

- [MSC](https://faq.cc.metu.edu.tr/tr/msc)

352

- [Telefon Rehberinde (Phonebook) görünen bilgilerimi nasıl güncelleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/telefon-rehberinde-gorunen-bilgilerimi-nasil-guncelleyebilirim)

351

- [Üniversitemizin KEP Adresi nedir?](https://faq.cc.metu.edu.tr/tr/sss/universitemizin-kep-adresi-nedir)

350

- [Kullanıcı hesabım kapatıldı. E-posta yedeklerimi (varsa) nasıl edinebilirim ve açabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabim-kapatildi-e-posta-yedeklerimi-varsa-nasil-edinebilirim-ve-acabilirim)

349

- [EBYS'de kayıtlı telefon rehberinde nasıl arama yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kayitli-telefon-rehberinde-nasil-arama-yapilir)

348

- [ODTÜ Yurtlarında geçici olarak kalıyorum, kablolu bilgisayar ağından faydalanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurtlarinda-gecici-olarak-kaliyorum-kablolu-bilgisayar-agindan-faydalanabilir-miyim)

347

- [Benim için oluşturulan misafir kullanıcı bilgisi ile meturoam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/benim-icin-olusturulan-misafir-kullanici-bilgisi-ile-meturoam-agina-nasil-baglanabilirim)

346

- [ODTÜ adresime gönderilen e-postalar bana ulaşmıyor, sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-adresime-gonderilen-e-postalar-bana-ulasmiyor-sorun-ne-olabilir)

345

- [ARCGIS PRO](https://faq.cc.metu.edu.tr/tr/arcgis-pro)

344

- [EBYS'de Oluşturulan Belgeler Nasıl Doğrulanır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-olusturulan-belgeler-nasil-dogrulanir)

343

- [Kapak Yazısı Yaz nedir?](https://faq.cc.metu.edu.tr/tr/sss/kapak-yazisi-yaz-nedir)

342

- [Birime özel not eklemek için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/birime-ozel-not-eklemek-icin-ne-yapmaliyim)

341

- [E-imza kart okuyucumu kaybettim. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-kart-okuyucumu-kaybettim-ne-yapmaliyim)

340

- [ODTÜ e-posta yönlendirmeyi nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim)

339

- [Emekli oldum, artık ODTÜ'de çalışmıyorum, e-imza alabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/emekli-oldum-artik-odtude-calismiyorum-e-imza-alabilir-miyim)

338

- [ODTÜ Mobil Uygulaması](https://faq.cc.metu.edu.tr/tr/sss/odtu-mobil-uygulamasi)

337

- [ODTÜ kullanıcı koduma ait kurtarma e-posta adresim yok. Nasıl oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim)

336

- [E-imza SIM kartımın PIN (parola) kodunu nasıl oluşturabilirim? PIN kilidini nasıl çözebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sim-kartimin-pin-parola-kodunu-nasil-olusturabilirim-pin-kilidini-nasil-cozebilirim)

335

- [E-imza geçerlilik süresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-gecerlilik-suresini-nasil-ogrenebilirim)

334

- [E-imza sertifikamın geçerlilik süresi doldu/dolmak üzere, yenileme başvurusunu nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sertifikamin-gecerlilik-suresi-doldudolmak-uzere-yenileme-basvurusunu-nasil-yapabilirim)

333

- [Islak imzalı e-imza başvuru formu nereye iletilmelidir?](https://faq.cc.metu.edu.tr/tr/sss/islak-imzali-e-imza-basvuru-formu-nereye-iletilmelidir)

332

- [Kablosuz ağa bağlı görünüyorum ancak İnternet'e erişemiyorum. Ne Yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kablosuz-aga-bagli-gorunuyorum-ancak-internete-erisemiyorum-ne-yapmaliyim)

331

- ["Akıllı Kartınız Iptal Edilmiştir. Üniversitenize Başvurunuz" uyarısı almaktayım. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartiniz-iptal-edilmistir-universitenize-basvurunuz-uyarisi-almaktayim-ne-yapmaliyim)

330

- [Dağıtım Onayı Özelliği nasıl kullanılır?](https://faq.cc.metu.edu.tr/tr/sss/dagitim-onayi-ozelligi-nasil-kullanilir)

329

- [Horde ile tüm e-postalarımı nasıl indirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim)

328

- [Kurum dışı yazışmalarda dikkat edilecek hususlar nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/kurum-disi-yazismalarda-dikkat-edilecek-hususlar-nelerdir)

327

- [Olur/Uygunluk/Onay gerektiren yazılar nasıl hazırlanır?](https://faq.cc.metu.edu.tr/tr/sss/oluruygunlukonay-gerektiren-yazilar-nasil-hazirlanir)

326

- [EBYS'yi mobil cihazım (tablet/akıllı telefon) ile kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/ebys-yi-mobil-cihazim-ile-kullanabilirmiyim)

325

- [Hangi Standart Dosya Planını (SDP) seçmem gerekiyor?](https://faq.cc.metu.edu.tr/tr/sss/hangi-standart-dosya-planini-sdp-secmem-gerekiyor)

324

- [EBYS'de tarafıma bir evrak iletildi, ne yapmalıyım? Seçeneklerim nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarafima-bir-evrak-iletildi-ne-yapmaliyim-seceneklerim-nelerdir)

323

- [EBYS'de dilekçe yazabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-dilekce-yazabilir-miyim)

322

- [Evrak hazırlama sırasında "Kontrole Gönder" düğmesi ne işe yaramaktadır?](https://faq.cc.metu.edu.tr/tr/sss/evrak-hazirlama-sirasinda-kontrole-gonder-dugmesi-ne-ise-yaramaktadir)

321

- [Dağıtım gruplarını nasıl tanımlayabilir ve düzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/dagitim-gruplarini-nasil-tanimlayabilir-ve-duzenleyebilirim)

320

- [EBYS'de hazırlanmış ve imzalanmış bir yazı istendiği durumda tamamen yok edilebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirlanmis-ve-imzalanmis-bir-yazi-istendigi-durumda-tamamen-yok-edilebilir-mi)

319

- [Bir yazı için birden fazla ilgi seçebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/bir-yazi-icin-birden-fazla-ilgi-secebilir-miyim)

318

- [EBYS'de şablon olarak kaydetmeden imzaya gönderdiğim bir yazıyı şablon olarak nasıl kaydedebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-sablon-olarak-kaydetmeden-imzaya-gonderdigim-bir-yaziyi-sablon-olarak-nasil)

317

- [Bir yazı için "Cevapla" butonuna basınca yazıyı kaybettim, nereden ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bir-yazi-icin-cevapla-butonuna-basinca-yaziyi-kaybettim-nereden-ulasabilirim)

316

- [Gelen bir yazıyı tüm birim personeline duyuru şeklinde gönderebilir miyiz?](https://faq.cc.metu.edu.tr/tr/sss/gelen-bir-yaziyi-tum-birim-personeline-duyuru-seklinde-gonderebilir-miyiz)

315

- [Kopyala-yapıştır ile eklediğim metin üzerinde düzeltme yaptığım halde yazı görünümünü istediğim hale getiremiyorum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kopyala-yapistir-ile-ekledigim-metin-uzerinde-duzeltme-yaptigim-halde-yazi-gorunumunu-istedigim)

314

- ["Uygundur" notlarını çıktı olarak alabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/uygundur-notlarini-cikti-olarak-alabilir-miyim)

313

- [Kurum dışına yazdığım bir yazıyı kurum içinde bir birime de bilgi olarak gönderebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/kurum-disina-yazdigim-bir-yaziyi-kurum-icinde-bir-birime-de-bilgi-olarak-gonderebilir-miyim)

312

- [İmzalanmış bir yazıda sonradan farkedilen bir hatayı nasıl düzeltebilirim?](https://faq.cc.metu.edu.tr/tr/sss/imzalanmis-bir-yazida-sonradan-farkedilen-bir-hatayi-nasil-duzeltebilirim)

311

- [Anabilim dallarına nasıl evrak gönderirim?](https://faq.cc.metu.edu.tr/tr/sss/anabilim-dallarina-nasil-evrak-gonderirim)

310

- [Bana gönderilen bir evrakı nasıl arşivleyeceğim?](https://faq.cc.metu.edu.tr/tr/sss/bana-gonderilen-bir-evraki-nasil-arsivleyecegim)

309

- ["Gereği Yapıldı" dediğim bir evrakı nasıl bulabilirim?](https://faq.cc.metu.edu.tr/tr/sss/geregi-yapildi-dedigim-bir-evraki-nasil-bulabilirim)

308

- [Gönderdiğim bir evrakı geri çekmek için ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/gonderdigim-bir-evraki-geri-cekmek-icin-ne-yapabilirim)

307

- [Kurum dışı yazı hazırlarken yazının gönderileceği kurumun KEP adresi görünmüyor, ne yapılabilir?](https://faq.cc.metu.edu.tr/tr/sss/kurum-disi-yazi-hazirlarken-yazinin-gonderilecegi-kurumun-kep-adresi-gorunmuyor-ne-yapilabilir)

306

- [Bir yazıyı İngilizce olarak hazırlamak istiyoruz, ne yapabiliriz?](https://faq.cc.metu.edu.tr/tr/sss/bir-yaziyi-ingilizce-olarak-hazirlamak-istiyoruz-ne-yapabiliriz)

305

- [Bir kişi bana vekalet bıraktığında yazılarına nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bir-kisi-bana-vekalet-biraktiginda-yazilarina-nasil-ulasabilirim)

304

- [Aynı anda birden fazla kişiye vekalet verilebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/ayni-anda-birden-fazla-kisiye-vekalet-verilebilir-mi)

303

- [Vekalet verecek kişi ulaşılır olmadığında vekalet vermek/değişiklik yapmak nasıl mümkün olacak?](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verecek-kisi-ulasilir-olmadiginda-vekalet-vermekdegisiklik-yapmak-nasil-mumkun-olacak)

302

- [Vekalet verilen kişi vekaleti reddetme hakkına sahip mi?](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verilen-kisi-vekaleti-reddetme-hakkina-sahip-mi)

301

- [Üzerinde vekalet bulunan bir kişi bir başka kişiye vekalet verirse ilk vekalet veren kişinin vekaleti üçüncü kişiye aktarılıyor mu?](https://faq.cc.metu.edu.tr/tr/sss/uzerinde-vekalet-bulunan-bir-kisi-bir-baska-kisiye-vekalet-verirse-ilk-vekalet-veren-kisinin)

300

- [Evrakların ekleri nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/evraklarin-ekleri-nasil-goruntulenir)

299

- [EBYS'de bir evrakın son durumunu nasıl takip edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bir-evrakin-son-durumunu-nasil-takip-edebilirim)

298

- [E-imzası olmayan bir kişiye gönderilen yazı nasıl imzalanabilir?](https://faq.cc.metu.edu.tr/tr/sss/e-imzasi-olmayan-bir-kisiye-gonderilen-yazi-nasil-imzalanabilir)

297

- [Islak imzaya göndermek ile e-imzaya göndermek arasındaki farklar nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/islak-imzaya-gondermek-ile-e-imzaya-gondermek-arasindaki-farklar-nelerdir)

296

- [Kişiye özel not eklemek için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kisiye-ozel-not-eklemek-icin-ne-yapmaliyim)

295

- [E-posta adresime EBYS ile ilgili çok fazla mesaj geliyor, bu mesajları almamak için ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-adresime-ebys-ile-ilgili-cok-fazla-mesaj-geliyor)

294

- [Geçmiş bölümünden evrakları göremiyorum, nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum-nasil-gorebilirim)

293

- [Hatalı yazılar nasıl iade edilir?](https://faq.cc.metu.edu.tr/tr/sss/hatali-yazilar-nasil-iade-edilir)

292

- [Kurum içi yazı antetinde bulunan birim iletişim bilgilerim hatalı görünüyor, nasıl düzeltilebilir?](https://faq.cc.metu.edu.tr/tr/sss/kurum-ici-yazi-antetinde-bulunan-birim-iletisim-bilgilerim-hatali-gorunuyor-nasil-duzeltilebilir)

291

- [EBYS'de oturum süresi nedir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-oturum-suresi-nedir)

290

- [Konu kısmına yazdıklarım neden yazıldığı şekilde görünmüyor?](https://faq.cc.metu.edu.tr/tr/sss/konu-kismina-yazdiklarim-neden-yazildigi-sekilde-gorunmuyor)

289

- [Bir evrakın çıktısını nasıl alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bir-evrakin-ciktisini-nasil-alabilirim)

288

- [Kampus dışından EBYS'ye giriş yapılabilir mi?](https://faq.cc.metu.edu.tr/tr/sss/kampus-disindan-ebysye-giris-yapilabilir-mi)

287

- [EBYS yazılarında görünen telefon numaram alanı boş veya yanlış, nasıl ekler veya değiştiririm?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm)

286

- [EBYS'deki numaralar ne ifade ediyor?](https://faq.cc.metu.edu.tr/tr/say%C4%B1)

285

- [EBYS'de tarama nasıl yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarama-nasil-yapilir)

284

- [EBYS'yi kullanmak için hangi web tarayıcısını kullanmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysyi-kullanmak-icin-hangi-web-tarayicisini-kullanmaliyim)

283

- [EBYS'de gizli evraklar nasıl hazırlanır ve gönderilir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gizli-evraklar-nasil-hazirlanir-ve-gonderilir)

282

- [EBYS Yardım Videoları](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari)

281

- [EBYS](https://faq.cc.metu.edu.tr/tr/sss/ebys)

280

- [Cihazım ile kablosuz meturoam ağına bağlanırken sertifika uyarısı alıyorum. Ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/cihazim-ile-kablosuz-meturoam-agina-baglanirken-sertifika-uyarisi-aliyorum-ne-yapabilirim)

279

- [Yanlışlıkla sildiğim e-postalara nasıl ulaşabilirim? Yedekten dönmek mümkün müdür?](https://faq.cc.metu.edu.tr/tr/sss/yanlislikla-sildigim-e-postalara-nasil-ulasabilirim-yedekten-donmek-mumkun-mudur)

278

- [GAUSSIAN](https://faq.cc.metu.edu.tr/tr/gaussian)

277

- [AUTODESK REVIT ARCHITECTURE](https://faq.cc.metu.edu.tr/tr/autodesk-revit-architecture)

276

- [AUTODESK ECOTECT ANALYSIS](https://faq.cc.metu.edu.tr/tr/autodesk-ecotect-analysis)

275

- [AUTODESK AUTOCAD CIVIL 3D](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-civil-3d)

274

- [AUTODESK AUTOCAD INVENTOR](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-inventor)

273

- [ANSYS](https://faq.cc.metu.edu.tr/tr/ansys)

272

- [Hangi cihazlar meturoam bağlantısını desteklememektedir?](https://faq.cc.metu.edu.tr/tr/sss/hangi-cihazlar-meturoam-baglantisini-desteklememektedir)

271

- [Sertifikamı uluslararası yazışmalarda kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/sertifikami-uluslararasi-yazismalarda-kullanabilir-miyim)

270

- [Soyadı değişikliği durumunda ne yapılması gerekir? E-imzamı yine de kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/soyadi-degisikligi-durumunda-ne-yapilmasi-gerekir-e-imzami-yine-de-kullanabilir-miyim)

269

- [Kamu SM'den gelen NES başvuru erişim parolası ile erişemiyorum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nes-basvuru-erisim-parolasi-ile-erisemiyorum-ne-yapmaliyim)

268

- [E-imzamı kaybettim/çalındı, kimlik bilgim güncellendi; ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/e-imzami-kaybettimcalindi-kimlik-bilgim-guncellendi-ne-yapmaliyim)

267

- [Başka bir kurumdan e-imza alabilir miyim? E-imzam var kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/baska-bir-kurumdan-e-imza-alabilir-miyim-e-imzam-var-kullanabilir-miyim)

266

- [E-imzayı nerede kullanacağım? Zorunlu muyum?](https://faq.cc.metu.edu.tr/tr/sss/e-imzayi-nerede-kullanacagim-zorunlu-muyum)

265

- [eduroam şifremi unuttum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-sifremi-unuttum-ne-yapmaliyim)

264

- [meturoam şifremi unuttum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/meturoam-sifremi-unuttum-ne-yapabilirim)

263

- [Windows 10 bilgisayarımdan eduroam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-10-bilgisayarimdan-eduroam-agina-nasil-baglanabilirim)

262

- [ABBYY](https://faq.cc.metu.edu.tr/tr/abbyy)

261

- [SPAM E-posta önleme yöntemleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir)

260

- [EBYS'de yazı şablonları nasıl oluşturulur?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sablonlari-nasil-olusturulur)

259

- [EBYS'de hazırladığım yazının antetinde bağlı olduğum birim ismi yanlış görünüyor, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirladigim-yazinin-antetinde-bagli-oldugum-birim-ismi-yanlis-gorunuyor-ne-yapmaliyim)

258

- [EBYS üzerinden taşıt istem formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebys-uzerinden-tasit-istem-formunu-nasil-doldurabilirim)

257

- [EBYS'de ODTÜ Geliştirme Vakfı yayın ödüllerine nasıl başvurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-odtu-gelistirme-vakfi-yayin-odullerine-nasil-basvurabilirim)

256

- [EBYS'de bakım, onarım, imalat, tadilat ve çevre düzenleme formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bakim-onarim-imalat-tadilat-ve-cevre-duzenleme-formunu-nasil-doldurabilirim)

255

- [EBYS’de gelen bilgilendirmeler nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gelen-bilgilendirmeler-nasil-goruntulenir)

254

- [EBYS’de yazışma hazırlarken kullanabilecek içerik şablonları var mı, bunları nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazisma-hazirlarken-kullanabilecek-icerik-sablonlari-var-mi-bunlari-nasil-kullanabilirim)

253

- [EBYS’de duyurular özelliği nedir? Nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-duyurular-ozelligi-nedir-nasil-goruntulenir)

252

- [E-imzam yok, nasıl elde edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imzam-yok-nasil-elde-edebilirim)

251

- [EBYS'de evrak nasıl aranır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrak-nasil-aranir)

250

- [EBYS’de vekalet verme işlemi nasıl yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-vekalet-verme-islemi-nasil-yapilir)

249

- [EBYS’de geçmiş akışlar nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir)

248

- [EBYS’de onayda bekleyen akışlar nasıl görüntülenir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-onayda-bekleyen-akislar-nasil-goruntulenir)

247

- [EBYS'de evrakımı nasıl iptal edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrakimi-nasil-iptal-edebilirim)

246

- [EBYS'de yazı sevk edeceğim kişi/birim görünmüyor. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sevk-edecegim-kisibirim-gorunmuyor-ne-yapmaliyim)

245

- [EBYS'de yeni bir kurum içi yazı nasıl oluşturulur?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yeni-bir-kurum-ici-yazi-nasil-olusturulur)

244

- [EBYS'de görünen birim, görev ya da unvanınız hatalı ise ne yapmalısınız?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gorunen-birim-gorev-ya-da-unvaniniz-hatali-ise-ne-yapmalisiniz)

243

- [EBYS’de kullanıcı adı/parola hatası uyarısı alındığında ne yapılmalıdır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kullanici-adiparola-hatasi-uyarisi-alindiginda-ne-yapilmalidir)

242

- [EBYS'ye nasıl giriş yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysye-nasil-giris-yapilir)

241

- [Horde dizin listesinde görünmeyen posta kutularını nasıl görüntüleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-dizin-listesinde-gorunmeyen-posta-kutularini-nasil-goruntuleyebilirim)

240

- [Horde iletilere nasıl imza ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletilere-nasil-imza-ekleyebilirim)

239

- [Horde göndericileri karaliste veya beyaz listeye nasıl ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-gondericileri-karaliste-veya-beyaz-listeye-nasil-ekleyebilirim)

238

- [Horde iletileri farklı klasörlere nasıl kopyalayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-kopyalayabilirim)

237

- [Horde iletileri farklı klasörlere nasıl taşıyabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-tasiyabilirim)

236

- [Horde nasıl okundu bildirimi alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-nasil-okundu-bildirimi-alabilirim)

235

- [Horde iletileri nasıl filtreleyebilir, iletebilir, engelleyebilir veya otomatik olarak cevap verebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-nasil-filtreleyebilir-iletebilir-engelleyebilir-veya-otomatik-olarak-cevap)

234

- [Horde bir iletinin tam başlık bilgisini nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim)

233

- [Horde oluşturduğum bir iletiye nasıl dosya ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-olusturdugum-bir-iletiye-nasil-dosya-ekleyebilirim)

232

- [Horde Eposta iletilerimi nasıl silebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-eposta-iletilerimi-nasil-silebilirim)

231

- [Horde Yardım sayfasına nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-yardim-sayfasina-nasil-ulasabilirim)

230

- [Windows Mail’i IMAP ile ODTÜ e-posta adresime nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-maili-imap-ile-odtu-e-posta-adresime-nasil-baglanabilirim)

229

- [TURNITIN](https://faq.cc.metu.edu.tr/tr/turnitin)

228

- [meturoam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/meturoam)

227

- [MATHCAD](https://faq.cc.metu.edu.tr/tr/mathcad)

226

- [MICROSOFT PROJECT](https://faq.cc.metu.edu.tr/tr/microsoft-project)

225

- [MICROSOFT VISIO](https://faq.cc.metu.edu.tr/tr/microsoft-visio)

224

- [ODTÜ Kablosuz Ağı nasıl yönetiliyor?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablosuz-agi-nasil-yonetiliyor)

223

- [ODTÜ Kablolu Ağı nasıl yönetiliyor?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablolu-agi-nasil-yonetiliyor)

222

- [MATLAB](https://faq.cc.metu.edu.tr/tr/matlab)

221

- [Horde 5 sürümünde yenilikler](https://faq.cc.metu.edu.tr/tr/sss/horde-5-surumunde-yenilikler)

220

- [SPSS](https://faq.cc.metu.edu.tr/tr/spss)

219

- [SYMANTEC ENDPOINT PROTECTION](https://faq.cc.metu.edu.tr/tr/symantec)

218

- [MICROSOFT VISUAL STUDIO](https://faq.cc.metu.edu.tr/tr/microsoft-visual-studio)

217

- [MICROSOFT OFFICE](https://faq.cc.metu.edu.tr/tr/office)

216

- [MICROSOFT WINDOWS](https://faq.cc.metu.edu.tr/tr/windows)

215

- [Apple MAC bilgisayarımı daha güvenli yapmak için neler yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/apple-mac-bilgisayarimi-daha-guvenli-yapmak-icin-neler-yapabilirim)

214

- [BİDB tarafından işletilen PC salonlarında kullanıcı kodum ile giriş yapamıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-isletilen-pc-salonlarinda-kullanici-kodum-ile-giris-yapamiyorum-ne-yapmaliyim)

213

- [Yaz Okulu Servis Dersleri uygulaması](https://faq.cc.metu.edu.tr/tr/sss/yaz-okulu-servis-dersleri-uygulamasi)

212

- [Gmail hesabıma ODTÜ e-posta adresimi nasıl eklerim?](https://faq.cc.metu.edu.tr/tr/sss/gmail-hesabima-odtu-e-posta-adresimi-nasil-eklerim)

211

- [POP3 ve IMAP arasında ne fark vardır?](https://faq.cc.metu.edu.tr/tr/sss/pop3-ve-imap-arasinda-ne-fark-vardir)

210

- [BİDB Hizmetlerinin Kapsamı Nedir?](https://faq.cc.metu.edu.tr/tr/sss/bidb-hizmetlerinin-kapsami-nedir)

209

- [Merkezi Bilişim Hizmetlerine Destek Veren Çağrı Merkezi Yapısı Nasıldır?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-bilisim-hizmetlerine-destek-veren-cagri-merkezi-yapisi-nasildir)

208

- [Felaket Kurtarma Merkezi ve İş Sürekliliği Nasıl Sağlanmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/felaket-kurtarma-merkezi-ve-surekliligi-nasil-saglanmaktadir)

207

- [BİDB Tarafından Sağlanan Merkezi Servisler Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-saglanan-merkezi-servisler-nelerdir)

206

- [BİDB’nin Bilişimde Öncü Çalışmaları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-bilisimde-oncu-calismalari-nelerdir)

205

- [ODTÜ Öğrencisiyim nasıl @metu.edu.tr uzantılı kullanıcı kodu edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-ogrencisiyim-nasil-metuedutr-uzantili-kullanici-kodu-edinebilirim)

204

- [Beyaz listeye e-posta adreslerini nasıl eklerim?](https://faq.cc.metu.edu.tr/tr/sss/beyaz-listeye-e-posta-adreslerini-nasil-eklerim)

203

- [Kara listeye nasıl e-posta eklerim?](https://faq.cc.metu.edu.tr/tr/sss/kara-listeye-nasil-e-posta-eklerim)

202

- [ODTÜ Personel ve Öğrencilerine Sağlanan Dışarıdan İndirilen Yazılım Olanakları](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware)

201

- [Horde Webmail de bir adresi yanlışlıkla kara listeye ekledim. Nasıl geri alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-webmail-de-bir-adresi-yanlislikla-kara-listeye-ekledim-nasil-geri-alabilirim)

200

- [Farklı VPN yazılımları kullanarak ODTÜ VPN servisinden faydalanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/farkli-vpn-yazilimlari-kullanarak-odtu-vpn-servisinden-faydalanabilir-miyim)

199

- [Harcamalarımı ve yüklemelerimi nasıl takip edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/harcamalarimi-ve-yuklemelerimi-nasil-takip-edebilirim)

198

- [VPN Hizmeti ile ilgili sorun yaşıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-ne-yapmaliyim)

197

- [SSH Secure Shell programı ile merkezi sunuculara bağlanmaya çalıştığımda "Algorithm negotiation failed" hatası veriyor. Ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ssh-secure-shell-programi-ile-merkezi-sunuculara-baglanmaya-calistigimda-algorithm-negotiation)

196

- [Fidyeci (CryptoLocker) Nedir ve Bu Zararlı Yazılımdan Korunma Yolları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/fidyeci-cryptolocker-nedir-ve-bu-zararli-yazilimdan-korunma-yollari-nelerdir)

195

- [AUTODESK 3DS MAX DESIGN](https://faq.cc.metu.edu.tr/tr/autodesk-3ds-max-design)

194

- [Kamu SM'den gelen Nitelikli Elektronik Sertifika (E-imza) Başvuru E-postasını sildim. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nitelikli-elektronik-sertifika-basvuru-e-postasini-sildim-ne-yapmaliyim)

193

- [Kamu SM Nitelikli Elektronik Sertifika (E-imza) Başvuru Süreci Nasıldır?](https://faq.cc.metu.edu.tr/tr/sss/kamu-sm-nitelikli-elektronik-sertifika-e-imza-basvuru-sureci-nasildir)

192

- [PC Salonlarında Yüklü Yazılımlar Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-yuklu-yazilimlar-nelerdir)

191

- [Kurtarma e-posta adresi nedir, kurtarma e-postasını kullanıcı hesabımda nasıl tanımlarım?](https://faq.cc.metu.edu.tr/tr/kurtarma_eposta_adresleri)

190

- [ODTÜ Personeliyim. Nasıl Kullanıcı Kodu Alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-nasil-kullanici-kodu-alabilirim)

189

- [PC salonlarında öğrenci asistan olarak görev almak istiyorum, nereye başvurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-ogrenci-asistan-olarak-gorev-almak-istiyorum-nereye-basvurabilirim)

188

- [Kullanıcı hesabımın kapatılacağına dair bir e-posta aldım. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimin-kapatilacagina-dair-bir-e-posta-aldim-ne-yapmaliyim)

187

- [ODTÜ' de VOIP Hizmeti var mıdır?](https://faq.cc.metu.edu.tr/tr/sss/odtu-de-voip-hizmeti-var-midir)

186

- [ODTÜ BİDB FTP Servisi var mıdır?](https://faq.cc.metu.edu.tr/tr/sss/odtu-bidb-ftp-servisi-var-midir)

185

- [ODTÜ yerleşke dışı bağlantı istatistikleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yerleske-disi-baglanti-istatistikleri-nelerdir)

184

- [ODTÜ'de Alan Adı Servisi verilmekte midir?](https://faq.cc.metu.edu.tr/tr/sss/odtude-alan-adi-servisi-verilmekte-midir)

183

- [ODTÜ Bölüm/Birim Kablolu Ağ Bağlantı yönetimi nasıl yapılmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/odtu-bolumbirim-kablolu-ag-baglanti-yonetimi-nasil-yapilmaktadir)

182

- [ODTÜ Yerleşke Omurgası (METU-NET) istatistikleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yerleske-omurgasi-metu-net-istatistikleri-nelerdir)

181

- [IP adresime uygulanmış bir kısıtlama olup olmadığını nereden öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ip-adresime-uygulanmis-bir-kisitlama-olup-olmadigini-nereden-ogrenebilirim)

180

- [Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-alirken-yasanabilecek-sorunlar)

179

- [Yeni Kayıt Olan Öğrenciler](https://faq.cc.metu.edu.tr/tr/sss/yeni-kayit-olan-ogrenciler)

178

- [Birim ve Topluluk Web Sayfaları için Zorunlu ve Önerilen İçerikler Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir)

177

- [PC Salonları Donanım Bilgileri Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-donanim-bilgileri)

176

- [PC Salonları Kullanım Kuralları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-kullanim-kurallari)

175

- [PC Salon Görevlilerinin Görev ve Sorumlulukları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salon-gorevlilerinin-gorev-ve-sorumluluklari)

174

- [PC Salonları Haritasına Nasıl Erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-haritasi)

173

- [PC Salonları Çalışma Saatleri Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-calisma-saatleri)

172

- [metu.edu.tr uzantılı alan adı almak istiyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/metuedutr-uzantili-alan-adi-almak-istiyorum-ne-yapmaliyim)

171

- [ODTÜ’de yer alan bir bina ya da dersliğin yerini nasıl bulabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-yer-alan-bir-bina-ya-da-dersligin-yerini-nasil-bulabilirim)

170

- [ODTÜ kullanıcı kodumla blog oluşturmak için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumla-blog-olusturmak-icin-ne-yapmaliyim)

169

- [Web Kullanıcı Kodunun şifresini unuttum nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/web-kullanici-kodunun-sifresini-unuttum-nasil-ogrenebilirim)

168

- [Bölüm, Birim, Merkez, Laboratuvar, Öğrenci Topluluğu web sayfası nasıl yapılır?](https://faq.cc.metu.edu.tr/tr/sss/bolum-birim-merkez-laboratuvar-ogrenci-toplulugu-web-sayfasi-nasil-yapilir)

167

- [Unix işletim sisteminde 'chmod' komutu ile dosya ve dizin haklarını nasıl değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/unix-isletim-sisteminde-chmod-komutu-ile-dosya-ve-dizin-haklarini-nasil-degistirebilirim)

166

- [E-Liste yöneticisi olarak Mailman Arayüzünü nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-yoneticisi-olarak-mailman-arayuzunu-nasil-kullanabilirim)

165

- [E-liste üyelerinin gönderdikleri mesajların bir kopyasının kendilerine gelmemesini sağlamak için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyelerinin-gonderdikleri-mesajlarin-bir-kopyasinin-kendilerine-gelmemesini-saglamak-icin)

164

- [Yöneticisi olduğum listeye gönderilen mesajlarda boyut sınırlarını nasıl duzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listeye-gonderilen-mesajlarda-boyut-sinirlarini-nasil-duzenleyebilirim)

163

- [E-listenin arşivlenmesi ile ilgili ayarlara nereden ulaşabilirim ?](https://faq.cc.metu.edu.tr/tr/sss/e-listenin-arsivlenmesi-ile-ilgili-ayarlara-nereden-ulasabilirim)

162

- [E-listeye sadece liste üyelerinin mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-uyelerinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim)

161

- [E-listeye (üye olan-olmayan) herkesin mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-uye-olan-olmayan-herkesin-mesaj-gonderebilmesi-icin-ne-yapmaliyim)

160

- [E-listeye sadece liste yöneticisinin mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-yoneticisinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim)

159

- [E-listeye sadece moderatörün mesaj gönderebilmesi için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-moderatorun-mesaj-gonderebilmesi-icin-ne-yapmaliyim)

158

- [E-liste Servisi hakkında genel bilgilere nasıl ulaşırım?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-servisi-hakkinda-genel-bilgilere-nasil-ulasirim)

157

- [E-liste üyesi olarak E-Liste Servisi arayüzünü nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyesi-olarak-e-liste-servisi-arayuzunu-nasil-kullanabilirim)

156

- [COMSOL](https://faq.cc.metu.edu.tr/tr/comsol)

155

- [MATHEMATICA](https://faq.cc.metu.edu.tr/tr/mathematica)

154

- [AUTODESK AUTOCAD](https://faq.cc.metu.edu.tr/tr/autodesk-autocad)

153

- [ARCGIS DESKTOP](https://faq.cc.metu.edu.tr/tr/arcgis-desktop)

152

- [Akıllı kimlik kartım iptal edildiğinde içerisindeki sanal para banka kartıma ne zaman aktarılır?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-iptal-edildiginde-icerisindeki-sanal-para-banka-kartima-ne-zaman-aktarilir)

151

- [Kullanıcı hesabı hangi durumlarda kapatılır?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-hangi-durumlarda-kapatilir)

150

- [ODTÜ kullanıcı hesabım ve bilgisayarım arasında güvenli modda (SFTP) nasıl dosya transferi yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-guvenli-modda-sftp-nasil-dosya-transferi)

149

- [iPhone ya da iPad ile ODTÜ VPN servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-vpn-servisini-nasil-kullanabilirim)

148

- [Akıllı kimlik kartımı değiştirdim. Yeni kimliğimi kullanıma açmam gerekir mi?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirdim-yeni-kimligimi-kullanima-acmam-gerekir-mi)

147

- [VPN Servisine bağlanırken şifre sormuyor. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-baglanirken-sifre-sormuyor-ne-yapmaliyim)

146

- [Yurtlardan İnternete nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim)

145

- [Ubuntu işletim sistemi yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ubuntu-isletim-sistemi-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim)

144

- [ODTÜ personeliyim fakat "genel-duyuru", "aras-gor-duyuru" ve/ya "ogr-uye-duyuru" listelerine gelen mesajları göremiyorum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-fakat-genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-gelen)

143

- [eduroam teknik yapısı nasıldır?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-teknik-yapisi-nasildir)

142

- [ISO DOSYALARINDAN (CD/DVD KALIPLARINDAN) YAZILIM KURULUMU NASIL YAPILIR?](https://faq.cc.metu.edu.tr/tr/iso-dosyalarindan-cd-dvd-kaliplarindan-yazilim-kurulumu-nasil-yapilir)

141

- [E-posta gönderirken "blocked by SpamAssasin" uyarı mesaji alıyorum. Neden?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-blocked-spamassasin-uyari-mesaji-aliyorum-neden)

140

- [OLDINBOX, SPAMBOX ve benzeri dizinlerdeki e-postaları nasıl okuyabilirim?](https://faq.cc.metu.edu.tr/tr/sss/oldinbox-spambox-ve-benzeri-dizinlerdeki-e-postalari-nasil-okuyabilirim)

139

- [eduroam'a nasıl bağlanılır?](https://faq.cc.metu.edu.tr/tr/sss/eduroama-nasil-baglanilir)

138

- [Bilgisayarımın kablosuz ağ kartının MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-kablosuz-ag-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim)

137

- [ODTÜ kullanıcı hesabım ve bilgisayarım arasında Horde dosya yöneticisi ile nasıl dosya transferi yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-horde-dosya-yoneticisi-ile-nasil-dosya-transferi)

136

- [ODTÜ anket servisine nasıl başvurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-basvurabilirim)

135

- [Nintendo DS için MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/nintendo-ds-icin-mac-fiziksel-adresini-nasil-ogrenebilirim)

134

- [Bilgisayarıma virüs bulaşması durumunda ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarima-virus-bulasmasi-durumunda-ne-yapmaliyim)

133

- [ODTÜ hesabımdan, ODTÜ'de bir adrese yönlendirilmiş dış eposta adresine mesaj gönderemiyorum. Neden?](https://faq.cc.metu.edu.tr/tr/sss/odtu-hesabimdan-odtude-bir-adrese-yonlendirilmis-dis-eposta-adresine-mesaj-gonderemiyorum-neden)

132

- [E-posta alırken gelen eklenmiş dosyalarla ilgili herhangi bir kısıtlama var mı?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-alirken-gelen-eklenmis-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi)

131

- [Merkezi e-posta sunucusu üzerindeki e-postalarıma nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-e-posta-sunucusu-uzerindeki-e-postalarima-nasil-erisebilirim)

130

- [Kotam doldu, ne yapmam gerekir?](https://faq.cc.metu.edu.tr/tr/sss/kotam-doldu-ne-yapmam-gerekir)

129

- [Bir listeye üye olmak için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bir-listeye-uye-olmak-icin-ne-yapmaliyim)

128

- [Oluşturduğum anketleri yayınlamadan test edebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketleri-yayinlamadan-test-edebilir-miyim)

127

- [Nakit harcama/yükleme cihazlarına akıllı kimlik kartımı okuttuğumda ekranda farklı isim/soyisim görüyorum. Bunun sebebi nedir?](https://faq.cc.metu.edu.tr/tr/sss/nakit-harcamayukleme-cihazlarina-akilli-kimlik-kartimi-okuttugumda-ekranda-farkli-isimsoyisim)

126

- [MAC OS X işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mac-os-x-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim)

125

- [İç IP dağıtım logu nedir?](https://faq.cc.metu.edu.tr/tr/sss/ic-ip-dagitim-logu-nedir)

124

- [Talep etmiş olduğum iade hala akıllı kimlik kartıma yüklenmedi. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/talep-etmis-oldugum-iade-hala-akilli-kimlik-kartima-yuklenmedi-sorun-ne-olabilir)

123

- [Kullandığım disk alanını ve kotamın son durumunu nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/kullandigim-disk-alanini-ve-kotamin-son-durumunu-nasil-ogrenebilirim)

122

- [Android Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim)

121

- [BİDB'nin verdiği servislerden yararlanmak için yapılması gerekenler nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-verdigi-servislerden-yararlanmak-icin-yapilmasi-gerekenler-nelerdir)

120

- [Akıllı kartım değişti, eski kartımdaki nakit para yeni kartıma aktarılır mı?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartim-degisti-eski-kartimdaki-nakit-para-yeni-kartima-aktarilir-mi)

119

- [Parolamı nasıl değiştirebilirim? Yeni parola seçerken nelere dikkat etmeliyim?](https://faq.cc.metu.edu.tr/tr/sss/parolami-nasil-degistirebilirim-yeni-parola-secerken-nelere-dikkat-etmeliyim)

118

- [Üyesi olduğum herhangi bir listeye gönderilen mesajları toplu (digest) olarak almak istiyorum. Üyelik ayarlarımı nereden değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/uyesi-oldugum-herhangi-bir-listeye-gonderilen-mesajlari-toplu-digest-olarak-almak-istiyorum)

117

- [Android işletim sistemi yüklü telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-isletim-sistemi-yuklu-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim)

116

- [ODTÜ kullanıcı hesabımı kullanarak oluşturduğum web sayfasında "not authorized" mesajı alıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-olusturdugum-web-sayfasinda-not-authorized-mesaji-aliyorum-ne)

115

- [IMAP ve POP3 nedir?](https://faq.cc.metu.edu.tr/tr/sss/imap-ve-pop3-nedir)

114

- [Nintendo Wii üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/nintendo-wii-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim)

113

- [Spam ve Malware nedir?](https://faq.cc.metu.edu.tr/tr/sss/spam-ve-malware-nedir)

112

- [Pine ile nasıl filtreleme yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/pine-ile-nasil-filtreleme-yapabilirim)

111

- [BİDB spam/sahte e-postalar için ne yapmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/bidb-spamsahte-e-postalar-icin-ne-yapmaktadir)

110

- [ODTÜ'de kablosuz bilgisayar ağı var mı, nasıl faydalanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kablosuz-bilgisayar-agi-var-mi-nasil-faydalanabilirim)

109

- [E-posta gönderirken eklemek istediğim dosyalarla ilgili herhangi bir kısıtlama var mı?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-eklemek-istedigim-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi)

108

- [Bilgisayarımdaki işletim sistemini nasıl güncelleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-isletim-sistemini-nasil-guncelleyebilirim)

107

- [Zaman damgası nedir, niçin kullanılması gerekmektedir?](https://faq.cc.metu.edu.tr/tr/sss/zaman-damgasi-nedir-nicin-kullanilmasi-gerekmektedir)

106

- [Spyware nedir?](https://faq.cc.metu.edu.tr/tr/sss/spyware-nedir)

105

- [Horde ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim)

104

- [Linux tabanlı işletim sistemleri virüslerden etkilenir mi?](https://faq.cc.metu.edu.tr/tr/sss/linux-tabanli-isletim-sistemleri-viruslerden-etkilenir-mi)

103

- [Spam olmayan bazı e-postalar SPAMBOX dizinine geliyor. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/spam-olmayan-bazi-e-postalar-spambox-dizinine-geliyor-ne-yapmaliyim)

102

- [Yurtlarda yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/yurtlarda-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim)

101

- [Merkezi sunucu sistemlere yerleşke dışından nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-disindan-nasil-baglanabilirim)

100

- ["abc-l" listesinin yöneticisiyim. Ancak şifresini bilmiyorum. Şifreyi nasıl edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesinin-yoneticisiyim-ancak-sifresini-bilmiyorum-sifreyi-nasil-edinebilirim)

99

- [Bilgisayarımdaki virüsü temizledikten sonra ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-virusu-temizledikten-sonra-ne-yapmaliyim)

98

- [Bölüm koordinatörüne nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bolum-koordinatorune-nasil-ulasabilirim)

97

- [ODTÜ VPN Hizmeti Kullanım Politikası](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmeti-kullanim-politikasi)

96

- [ODTÜ Kullanıcı Hesap Yönetimi sayfasından neler yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesap-yonetimi-sayfasindan-neler-yapabilirim)

95

- [Akıllı kimlik kartımı kaybettim/çalındı, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-kaybettimcalindi-ne-yapmaliyim)

94

- [ODTÜ Anket Servisi kapsamında kullanılan Limesurvey yazılımı hakkında nereden bilgi alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-kapsaminda-kullanilan-limesurvey-yazilimi-hakkinda-nereden-bilgi-alabilirim)

93

- [iPhone telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim)

92

- [Yer Sağlayıcı Trafik Bilgisi Nedir?](https://faq.cc.metu.edu.tr/tr/sss/yer-saglayici-trafik-bilgisi-nedir)

91

- [Gelen e-posta mesajının başlığının tamamını (full header) görmek için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim)

90

- [ODTÜ'de ögrenciyim; "genel-duyuru" listesine üye olabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-ogrenciyim-genel-duyuru-listesine-uye-olabilir-miyim)

89

- [SPAMBOX nedir?](https://faq.cc.metu.edu.tr/tr/sss/spambox-nedir)

88

- [ODTÜ kullanıcı hesabıma gelen e-postalarımı nasıl yönlendirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabima-gelen-e-postalarimi-nasil-yonlendirebilirim)

87

- [ODTÜ VPN Hizmetinden aynı anda toplam kaç kullanıcı faydalanabilmektedir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmetinden-ayni-anda-toplam-kac-kullanici-faydalanabilmektedir)

86

- [IP adresimi nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim)

85

- [İnternet bağlantım çok yavaş. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir)

84

- [Yeni bir E-Liste başvurusunda bulunmak için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/yeni-bir-e-liste-basvurusunda-bulunmak-icin-ne-yapmaliyim)

83

- [Yöneticisi olduğum listemi artık kullanmıyorum, nasıl kapatabilirim?](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listemi-artik-kullanmiyorum-nasil-kapatabilirim)

82

- [ODTÜ kullanıcı kodumu ve parolamı nerelerde kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumu-ve-parolami-nerelerde-kullanabilirim)

81

- [ODTÜ Kablosuz Bilgisayar Ağı Kullanım Kuralları nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablosuz-bilgisayar-agi-kullanim-kurallari-nelerdir)

80

- [Mozilla Thunderbird ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mozilla-thunderbird-ile-odtu-e-posta-servisini-nasil-kullanabilirim)

79

- [eduroam ağının güvenlik derecesi nedir?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-aginin-guvenlik-derecesi-nedir)

78

- [Merkezi sunucular üzerinde bulunan dosyalarımı nasıl silebilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucular-uzerinde-bulunan-dosyalarimi-nasil-silebilirim)

77

- [ODTÜ dışından Kütüphane kaynaklarına nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-disindan-kutuphane-kaynaklarina-nasil-erisebilirim)

76

- ["genel-duyuru", "aras-gor-duyuru" ve/ya "ogr-uye-duyuru" listelerine üyeyim, fakat bu listelerden artık mesaj almak istemiyorum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-uyeyim-fakat-bu-listelerden-artik)

75

- ["abc-l" listesine üyeyim. Üyelik şifremi edinmek için e-posta adresimi yazıp şifre hatırlatıcısı butonuna tıkladım ancak şifre bana ulaşmadı. Neden olabilir?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-uyelik-sifremi-edinmek-icin-e-posta-adresimi-yazip-sifre-hatirlaticisi)

74

- [ODTÜ anket servisine nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-erisebilirim)

73

- [Bir anketi aktive ettikten sonra üzerinde değişiklik yapabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/bir-anketi-aktive-ettikten-sonra-uzerinde-degisiklik-yapabilir-miyim)

72

- [Microsoft Outlook ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-ile-odtu-e-posta-servisini-nasil-kullanabilirim)

71

- [Akıllı kimlik kartımda bulunan parayı hesabıma geri aktarabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimda-bulunan-parayi-hesabima-geri-aktarabilir-miyim)

70

- [Akıllı kimlik kartıma yüklediğim sanal para hemen veya birkaç kullanımdan sonra sıfırlandı, bu durumda ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartima-yukledigim-sanal-para-hemen-veya-birkac-kullanimdan-sonra-sifirlandi-bu)

69

- [Merkezi sunucu sistemlere yerleşke içinden nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-icinden-nasil-baglanabilirim)

68

- ["Tatildeyim" mesajını nasıl oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/tatildeyim-mesajini-nasil-olusturabilirim)

67

- [ODTÜ anket servisinden kimler yararlanabilir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisinden-kimler-yararlanabilir)

66

- [Üye olduğum tüm e-listeleri nasıl görüntülerim?](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeleri-nasil-goruntulerim)

65

- [Üye olduğum tüm e-listeler için nasıl ortak bir e-liste şifresi tanımlayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeler-icin-nasil-ortak-bir-e-liste-sifresi-tanimlayabilirim)

64

- [BİDB neden IP erişimlerini kısıtlıyor?](https://faq.cc.metu.edu.tr/tr/sss/bidb-neden-ip-erisimlerini-kisitliyor)

63

- [ODTÜ anket servisi ile ilgili soru veya sorunlarımı nereye iletebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-ile-ilgili-soru-veya-sorunlarimi-nereye-iletebilirim)

62

- [Koordinatör olarak sorumlu olduğum bilgisayarın IP erişiminin yeniden açılması için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/koordinator-olarak-sorumlu-oldugum-bilgisayarin-ip-erisiminin-yeniden-acilmasi-icin-ne)

61

- [eduroam farklı ortamlarda çalışır mı?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-farkli-ortamlarda-calisir-mi)

60

- [Bilgisayarımın Ethernet kartının MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim)

59

- [Hesabımdaki gelen kutusunda ya da diğer oluşturduğum dizinlerde saklayabileceğim e-posta ya da dosyaların bir sınırı var mı?](https://faq.cc.metu.edu.tr/tr/sss/hesabimdaki-gelen-kutusunda-ya-da-diger-olusturdugum-dizinlerde-saklayabilecegim-e-posta-ya-da)

58

- [Akıllı kartıma online bakiye yükleme sisteminden (odtucard) para yükledim, yüklediğim bakiye kartıma aktarılmadı. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-online-bakiye-yukleme-sisteminden-odtucard-para-yukledim-yukledigim-bakiye)

57

- [VPN Servisi Nedir?](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisi-nedir)

56

- [Mac bilgisayarımdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mac-bilgisayarimdan-eduroam-kablosuz-agina-nasil-baglanabilirim)

55

- [Bölümde yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bolumde-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim)

54

- [Kullanıcı hesabımdan yanlışlıkla sildiğim dosyalara nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimdan-yanlislikla-sildigim-dosyalara-nasil-ulasabilirim)

53

- [iPhone ya da iPad ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-e-posta-servisini-nasil-kullanabilirim)

52

- [Nokia E5/E7 üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/nokia-e5e7-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim)

51

- [Bilgisayarımın IP erişimi kısıtlanmış. Nedenini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisimi-kisitlanmis-nedenini-nasil-ogrenebilirim)

50

- [Üye olduğum bir e-listenin şifresini hatırlamıyorum; nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-bir-e-listenin-sifresini-hatirlamiyorum-nasil-ogrenebilirim)

49

- [Windows Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim)

48

- [Akıllı kimlik kartımı değiştirmek istediğimde kartımda bulunan para yeni kimliğime aktarılır mı?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirmek-istedigimde-kartimda-bulunan-para-yeni-kimligime-aktarilir-mi)

47

- [Anket servisi ile anonim (yanıtların kime ait olduğu bilinmeyen) veya anonim olmayan (yanıtların kime ait olduğu bilinen) ya da herkese açık/sadece belli kişilere açık anketler oluşturabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/anket-servisi-ile-anonim-yanitlarin-kime-ait-oldugu-bilinmeyen-veya-anonim-olmayan-yanitlarin)

46

- [ODTÜ kullanıcı koduma ait parolamı unuttum. Nereden öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim)

45

- [VPN Servisine bilgilerimi doğru girmeme rağmen bağlanamıyorum. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-bilgilerimi-dogru-girmeme-ragmen-baglanamiyorum-sorun-ne-olabilir)

44

- ['ad.soyad@metu.edu.tr' biçimindeki e-posta adresimi değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/adsoyadmetuedutr-bicimindeki-e-posta-adresimi-degistirebilir-miyim)

43

- [Phishing nedir?](https://faq.cc.metu.edu.tr/tr/sss/phishing-nedir)

42

- [ODTÜ Yurt Odaları Bilgisayar Ağı Kullanım Kuralları nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurt-odalari-bilgisayar-agi-kullanim-kurallari-nelerdir)

41

- [Mezun oldum, iptal edilen kartımdaki nakit para iade edilebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/mezun-oldum-iptal-edilen-kartimdaki-nakit-para-iade-edilebilir-mi)

40

- [Microsoft Outlook Express ile nasıl filtreleme yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-express-ile-nasil-filtreleme-yapabilirim)

39

- [Bilgisayarımın IP erişiminin yeniden açılması için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisiminin-yeniden-acilmasi-icin-ne-yapmaliyim)

38

- [ODTÜ'de kullanılan lisanslı bir antivirüs programı var mı? Varsa nereden edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kullanilan-lisansli-bir-antivirus-programi-var-mi-varsa-nereden-edinebilirim)

37

- [Blackberry Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/blackberry-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim)

36

- [Android yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim)

35

- ["abc-l" listesine üye olduğum adresi üyelikten çıkmadan değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uye-oldugum-adresi-uyelikten-cikmadan-degistirebilir-miyim)

34

- [Samsung Akıllı Telefonlarda MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/samsung-akilli-telefonlarda-mac-fiziksel-adresini-nasil-ogrenebilirim)

33

- ["abc-l" listesine üyeyim fakat listeden bana mesaj gelmiyor. Neden?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-fakat-listeden-bana-mesaj-gelmiyor-neden)

32

- [ODTÜ kullanıcı hesabımı kullanarak nasıl web sayfası oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nasil-web-sayfasi-olusturabilirim)

31

- [Spam e-postaları ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/spam-e-postalari-ne-yapmaliyim)

30

- [Casus yazılımlardan korunmak için neler yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/casus-yazilimlardan-korunmak-icin-neler-yapmaliyim)

29

- [Akıllı kimlik kartım kırıldı, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-kirildi-ne-yapmaliyim)

28

- [eduroam ağına bağlantım sürekli kesiliyor / bağlanamıyor?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglantim-surekli-kesiliyor-baglanamiyor)

27

- [Oluşturduğum anketlerin yanıtlarını nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketlerin-yanitlarini-nasil-gorebilirim)

26

- [Erişim bileti (token) nedir?](https://faq.cc.metu.edu.tr/tr/sss/erisim-bileti-token-nedir)

25

- [Windows Mobil Cihazında MAC (fiziksel) adresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-mobil-cihazinda-mac-fiziksel-adresini-nasil-ogrenebilirim)

24

- [Uzak masaüstü bağlantısı yapamıyorum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/uzak-masaustu-baglantisi-yapamiyorum-ne-yapmaliyim)

23

- [Kullanıcı kotası ne kadardır?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-kotasi-ne-kadardir)

22

- [Kablolu Ağa Nasıl Bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kablolu-aga-nasil-baglanabilirim)

21

- [Gelen e-postaları nasıl filtreleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-postalari-nasil-filtreleyebilirim)

20

- [Mailman sisteminde ne tür listeler tanımlanabilir?](https://faq.cc.metu.edu.tr/tr/sss/mailman-sisteminde-ne-tur-listeler-tanimlanabilir)

19

- [Mezun olduktan sonra ODTÜ kullanıcı hesabıma gelen e-postalarımı yönlendirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/mezun-olduktan-sonra-odtu-kullanici-hesabima-gelen-e-postalarimi-yonlendirebilir-miyim)

18

- [Windows işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim)

17

- ["abc-l" listesi üyeliğinden çıkmak istiyorum, nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesi-uyeliginden-cikmak-istiyorum-nasil-yapabilirim)

16

- [Web önbellekleme nedir?](https://faq.cc.metu.edu.tr/tr/sss/web-onbellekleme-nedir)

15

- [ODTÜ personeliyim. Yakınım için kimlik kartı çıkartabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-yakinim-icin-kimlik-karti-cikartabilir-miyim)

14

- [eduroam nedir?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-nedir)

13

- [eduroam Türkiye katılımcıları hangi kurumlardır?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-turkiye-katilimcilari-hangi-kurumlardir)

12

- [eduroam ağına bağlanabilmek için neden program yüklüyorum?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglanabilmek-icin-neden-program-yukluyorum)

11

- [MERKEZI LISANSLI YAZILIMLARDAN KIMLER, NASIL FAYDALANABILIR?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-lisansli-yazilimlardan-kimler-nasil-faydalanabilir)

10

- [Lojmanlardan İnternet'e nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/lojmanlardan-internete-nasil-baglanabilirim)

9

- [Bölüm binası kartlı geçişinden giriş-çıkış yapamıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bolum-binasi-kartli-gecisinden-giris-cikis-yapamiyorum-ne-yapmaliyim)

8

- [Virüslerden korunmak için neler yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/viruslerden-korunmak-icin-neler-yapmaliyim)

7

- [Anket servisi üzerinde nasıl anket oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/anket-servisi-uzerinde-nasil-anket-olusturabilirim)

6

- [Bilgisayarıma virüs bulaştığını nasıl anlayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarima-virus-bulastigini-nasil-anlayabilirim)

5

- [OLDINBOX ve benzeri dizinler nasıl silinir?](https://faq.cc.metu.edu.tr/tr/sss/oldinbox-ve-benzeri-dizinler-nasil-silinir)

4

- [Üyesi olduğum bir listeye gönderdiğim mesajlar neden dağılmıyor?](https://faq.cc.metu.edu.tr/tr/sss/uyesi-oldugum-bir-listeye-gonderdigim-mesajlar-neden-dagilmiyor)

3

- [Yöneticisi olduğum listenin ismini değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listenin-ismini-degistirebilir-miyim)

2

- [Android yüklü cihazımla ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-yuklu-cihazimla-odtu-e-posta-servisini-nasil-kullanabilirim)

1


_ODTÜ SSS Sayfalarına Hoşgeldiniz!_

## SSS' de Ara

Aranacak olan kelimeyi giriniz

### Öne Çıkan Sorular

|     |
| --- |
| [E-imza sertifikamın geçerlilik süresi doldu/dolmak üzere, yenileme başvurusunu nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sertifikamin-gecerlilik-suresi-doldudolmak-uzere-yenileme-basvurusunu-nasil-yapabilirim) |
| [Yeni Kayıt Olan Öğrenciler](https://faq.cc.metu.edu.tr/tr/sss/yeni-kayit-olan-ogrenciler) |
| [ODTÜ'de kablosuz bilgisayar ağı var mı, nasıl faydalanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kablosuz-bilgisayar-agi-var-mi-nasil-faydalanabilirim) |
| [E-imzam yok, nasıl elde edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imzam-yok-nasil-elde-edebilirim) |
| [Bilgisayarımdaki işletim sistemini nasıl güncelleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-isletim-sistemini-nasil-guncelleyebilirim) |
| [Virüslerden korunmak için neler yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/viruslerden-korunmak-icin-neler-yapmaliyim) |
| [ODTÜ'de kullanılan lisanslı bir antivirüs programı var mı? Varsa nereden edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kullanilan-lisansli-bir-antivirus-programi-var-mi-varsa-nereden-edinebilirim) |
| [Linux tabanlı işletim sistemleri virüslerden etkilenir mi?](https://faq.cc.metu.edu.tr/tr/sss/linux-tabanli-isletim-sistemleri-viruslerden-etkilenir-mi) |
| [Casus yazılımlardan korunmak için neler yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/casus-yazilimlardan-korunmak-icin-neler-yapmaliyim) |
| [Bilgisayarımdaki virüsü temizledikten sonra ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-virusu-temizledikten-sonra-ne-yapmaliyim) |

## En Çok Sorulanlar

|     |
| --- |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Yeni client - DSClient Uygulaması\]](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client) |
| ["abc-l" listesi üyeliğinden çıkmak istiyorum, nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesi-uyeliginden-cikmak-istiyorum-nasil-yapabilirim) |
| ["abc-l" listesine üye olduğum adresi üyelikten çıkmadan değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uye-oldugum-adresi-uyelikten-cikmadan-degistirebilir-miyim) |
| ["abc-l" listesine üyeyim fakat listeden bana mesaj gelmiyor. Neden?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-fakat-listeden-bana-mesaj-gelmiyor-neden) |
| ["abc-l" listesine üyeyim. Üyelik şifremi edinmek için e-posta adresimi yazıp...](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-uyelik-sifremi-edinmek-icin-e-posta-adresimi-yazip-sifre-hatirlaticisi) |

### Ana Menü

### Ağ

### Akıllı Kart

### Kullanıcı Hesapları

### E-Posta

### Enformatik Servisleri

### Diğer

### EBYS

### [Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar "Lisanslı Yazılımlar")

### Bilgi Güvenliği