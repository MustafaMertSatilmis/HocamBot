[Jump to navigation](https://faq.cc.metu.edu.tr/tr/abbyy#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-01-2022 **Görüntüleme:** 14352


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/abbyy "ABBYY")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/abbyy "ABBYY")

# ABBYY

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ABBYY FINEREADER** **10** **—**

**_Abbyy_** **_FineReader_** _bir optik karakter tanıma (OCR) uygulamasıdır. ABBYY_ _FineReader_ _yazılımı, basılı belgelerin dijital ortama aktarılabilmesi, jpg, pdf vs. formatlı görsel dosyaların, taranmış belgelerin metin dosyaları olarak düzenlenebilmesi gibi işlemlere olanak sağlamaktadır._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/abbyy#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/abbyy#aktivasyon)

* * *

**_\[1\] Not:_** _Türkçe karakter ve sözlük desteği de mevcut olan yazılım, yapılan lisans anlaşmaları gereği ağ üzerinden eş zamanlı lisanslama ile sadece ODTÜ yerleşkesinde çalışabilmektedir ve sadece ODTÜ personelinin kullanımına açıktır._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Setup_** **_”_** dosyasını çalıştırarak kuruluma başlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/abbyy_finereader_10_step1.png)

**_ADIM-2_**

**_“OK”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/abbyy_finereader_10_step2.png)

**_ADIM-3_**

**_“Typical”_** seçeneğini işaretleyiniz ve**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/abbyy_finereader_10_step3.png)

**_ADIM-4_**

**_“Install”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/abbyy_finereader_10_step4.png)

**_ADIM-5_**

**_“Finish”_**_butonuna tıklayarak kurulum işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/abbyy_finereader_10_step5.png)

**_ADIM-6 <<<AKTİVASYON>>>_**

_Lisanslama için **“metuabbyy10”** iso_ _dosyası içerisindeki**“hosts\_batch”**klasöründeki **“** **change\_hosts\_license**_**_”_** _dosyasına sağ tıklayınız ve **“Run as** **administrator**_**_”_** _seçeneği ile yönetici olarak çalıştırınız. Bu adımdan sonra yazılımı kullanmaya başlayabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/abbyy_finereader_10_step6.png)

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *