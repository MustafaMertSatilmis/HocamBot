[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/metusis-ogrenci-bilgi-sistemi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# METUSIS - Öğrenci Bilgi Sistemi

[![Subscribe to METUSIS - Öğrenci Bilgi Sistemi](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/187/all/feed "Subscribe to METUSIS - Öğrenci Bilgi Sistemi")