[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-profil-silme-nasil-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-11-2022 **Görüntüleme:** 4091


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-profil-silme-nasil-yapilir)

# VPN Profil Silme Nasil Yapilir?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

**Aruba VIA** yazilimini açınız ve **"Ayarlar"** simgesine tıklayınız.

![01VPN](https://faq.cc.metu.edu.tr/system/files/u21699/01_vpnayarlar.png)

**VPN Profiles** sekmesini tıklayınız ve **Clear Profiles** tıklayınız.

![02VPN](https://faq.cc.metu.edu.tr/system/files/u21699/02_vpnprofiles.png)

Geçerli olan profili seçiniz **"UserController1"** ve **"-"** simgesi ile sil tıklayınız.

![03vpn](https://faq.cc.metu.edu.tr/system/files/u21699/03_clearprofiles.png)

Silme işlemini **"Continue"** diyerek onaylayınız.

![04VPN](https://faq.cc.metu.edu.tr/system/files/u21699/04_clearprofilesproceed.png)

**"Cancel"** tıklayınız ve  VPN Profil Download kısmına geçiniz.

![05VPN](https://faq.cc.metu.edu.tr/system/files/u21699/05_clearprofilescancel.png)

**"Click to download VPN Profile"** tıklayınız.

![06VPN](https://faq.cc.metu.edu.tr/system/files/u21699/06_clickdownloadprofiles.png)

**"border.metu.edu.tr"** adresini giriniz. **"Download"** tıklayınız.

![07VPN](https://faq.cc.metu.edu.tr/system/files/u21699/07_downloadprofiles.png)

**"default"** profile seçiniz.

![072VPN](https://faq.cc.metu.edu.tr/system/files/u21699/07_2defaultprofile.png)

**"Kullanıcı Adı"** ve **"Şifre"** alanlarını doldurunuz ve Proceed tıklayınız ve tekrar profili indiriniz.

![08VPN](https://faq.cc.metu.edu.tr/system/files/u21699/08_username.png)

Bilgisayarınızı **yeniden başlatınız** ve Aruba-VIA açınız. Kullanıcı adı ve Şifre girerek VPN bağlantısı kurunuz.

![09vpn](https://faq.cc.metu.edu.tr/tr/system/files/u21699/09_vpnconnect.png)