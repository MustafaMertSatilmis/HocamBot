[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/parola#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Parola

|     |
| --- |
| [Kurtarma e-posta adresi nedir, kurtarma e-postasını kullanıcı hesabımda nasıl tanımlarım?](https://faq.cc.metu.edu.tr/tr/kurtarma_eposta_adresleri) |
| [ODTÜ Kullanıcı Kodu Parola ve Kurtarma E-Postası İşlemleri](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodu-parola-ve-kurtarma-e-postasi-islemleri) |
| [ODTÜ kullanıcı koduma ait kurtarma e-posta adresim yok. Nasıl oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim) |
| [ODTÜ kullanıcı koduma ait parolamı unuttum. Nereden öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim) |
| [ODTÜ kullanıcı kodumu ve parolamı nerelerde kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumu-ve-parolami-nerelerde-kullanabilirim) |
| [Parolamı nasıl değiştirebilirim? Yeni parola seçerken nelere dikkat etmeliyim?](https://faq.cc.metu.edu.tr/tr/sss/parolami-nasil-degistirebilirim-yeni-parola-secerken-nelere-dikkat-etmeliyim) |

[![Subscribe to Parola](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/53/all/feed "Subscribe to Parola")