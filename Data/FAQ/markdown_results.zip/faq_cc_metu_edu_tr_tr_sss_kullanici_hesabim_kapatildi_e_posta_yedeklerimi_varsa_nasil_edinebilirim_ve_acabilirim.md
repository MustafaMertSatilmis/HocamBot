[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabim-kapatildi-e-posta-yedeklerimi-varsa-nasil-edinebilirim-ve-acabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-06-2022 **Görüntüleme:** 8027


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-user-account-closed-how-can-i-get-my-e-mail-backups-if-there-are-any-and-open-them "My user account is closed. How can I get my e-mail backups (if there are any) and open them?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabim-kapatildi-e-posta-yedeklerimi-varsa-nasil-edinebilirim-ve-acabilirim "Kullanıcı hesabım kapatıldı. E-posta yedeklerimi (varsa) nasıl edinebilirim ve açabilirim?")

# Kullanıcı hesabım kapatıldı. E-posta yedeklerimi (varsa) nasıl edinebilirim ve açabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

Herhangi bir nedenle öğrenciliği sonlanan veya öğrenciliğe ara vererek kayıtsız duruma geçen öğrencilerimizin kullanıcı hesapları bir (1) eğitim dönemi sonrasında kapatılmaktadır. Kullanıcı hesabı kapatılacak olan kullanıcılarımıza bu durum belirli aralıklarla eposta ile bildirilir.

Mezun öğrencilerin ODTÜ Bilgi İşlem Daire Başkanlığı merkezi sunucuları üzerinde tanımlı exxxxxxmetu.edu.tr formatındaki e-posta adresleri talep edilen başka bir e-posta adresine yönlendirilebilmektedir. Yönlendirme servisine ilişkin bilgilendirme, [https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kulla...](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim)

adresinde bulunmaktadır.

Yönlendirmeniz yoksa kullanıcı hesabınız kapatıldıktan sonra başka adreslerden gönderilen e-postalar ulaşmayacağı için kapatılma tarihinden sonra gönderilen e-postaların yedekleri bulunmamaktadır. Kapatılma tarihinden önce e-posta hesabına giriş yaparak [https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim)  adresindeki şekilde yedeklerinizi .mbox dosyası olarak bilgisayarınıza indirebilirsiniz.

Hesabınız kapatılmadan önce yedekleme işlemlerinizi yapmadıysanız, kapatılma tarihinden itibaren 30 gün içerisinde [hotline@metu.edu.tr](mailto:hotline@metu.edu.tr)  adresine  eposta gönderirseniz, yedekleriniz indirilerek size gönderilebilir. Yedekler en fazla 30 gün geriye yönelik olarak alınabilmektedir.

Size iletilen .mbox ya da tar.gz uzantılı dosyalardaki e-postalarınızı görüntüleyebilmek ve başka bir e-posta adresinize göndermek için aşağıdaki yöntemleri uygulayabilirsiniz.

Bilgisayarınıza indirdiğiniz tar.gz uzantılı dosya sıkıştırılmış bir dosya olduğu için, açmak için 7-zip programını kullanabilirsiniz [https://www.7-zip.org/](https://www.7-zip.org/)

.mbox dosyası için böyle bir açma işlemine gerek yoktur.

E-postaları görüntüleyebilmek için Thunderbird programını kurmanız gerekmektedir. Kurulum için [https://www.thunderbird.net](https://www.thunderbird.net/) adresindeki yönergeleri takip edebilirsiniz. Thunderbird programını kurup açtıktan sonra Ayarlar kısmından Add-ons bölümünden Add-ons seçeneğine tıklayıp gelen pencerede ImportExportTools NG eklentisini, arama kısmından bulup kurunuz. Kurulum yapıldıktan sonra Thunderbird istemcisinin tekrar başlatılması gerekmektedir.

Thunderbird istemcisi tekrar başladıktan sonra sol kısımdaki Local Folders kısmına sağ tıkayıp New Folder'ı seçerek yeni bir klasör oluşturun. İsmini istediğiniz şekilde verebilirsiniz. Aşağıdaki örnekte imported\_mails

isminde yerel bir klasör oluşturduk.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/01_newfolder.png)

Yeni oluşturduğunuz bu klasöre sağ tıklayıp ImportExportTools NG menüsünden:

A) .mbox dosyanız var ise Import mbox file seçerek mbox uzantılı dosyanızın yerini gösterip e-postalarınıza ulaşabilir ve isterseniz başka bir e-posta adresine yönlendirebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/02_import_mbox.png)

B) .tar.gz dosyasını 7-zip benzeri bir zip programı ile bilgisayarındaki bir klasöre açtıysanız, Import messages seçeneği ile devam edebilirsiniz. Import messages seçeneğini tıkladığınızda karşınıza gelen ekranda öncelikle

görüntülenecek dosya tipi kısmını All files (\*.\*), Tüm dosyalar (\*.\*) seçmeniz gerekmektedir. Karşınıza çıkan pencerede açmış olduğunuz tar.gz klasörünün içindeki ilgili e-posta klasörlerindeki dosyalarınızın hepsini seçenerek Thunderbird istemcisinde görünmesini sağlayabilirsiniz. Örneğin Inbox kutusunda bulunan e-postalarınız maildir > INBOX > cur klasörünün içindedir. Thunderbird istemcisinde gözüken e-postalarınızın eklerine de bu istemci üzerinden e-postanın ekler kısmından erişebilir ve ayrıca bilgisayarınıza kaydedebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/02_import_allmessages.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/03_allmessages.png)