[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pop3-ve-imap-arasinda-ne-fark-vardir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 11308


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-difference-between-pop3-and-imap-accounts "What is the difference between POP3 and IMAP accounts?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pop3-ve-imap-arasinda-ne-fark-vardir "POP3 ve IMAP arasında ne fark vardır?")

# POP3 ve IMAP arasında ne fark vardır?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

POP veya IMAP gelen e-postalarınızı bilgisayarınıza ya da diğer cihazlarınıza indirmenizi sağlayan iletişim protokolleridir.

**POP3**

Posta kutularına erişimde basit indirme ve silme gereksinimlerini karşılar. POP kullanan e-posta alıcıları genelde şu işlemleri gerçekleştirir: sunucuya bağlanır, tüm mesajları alır, bu mesajları kullanıcının bağlandığı cihazda yeni mesaj olarak saklar ve sunucudan siler, ardından da bağlantıyı keser. Dolayısıyla cihazdan da silindiği zaman, mesajlara bir daha ulaşılamaz. Ama bazı e-posta alıcıları bu mailleri yeni bir klasörde saklama seçeneği sunabilir. POP3 aynı anda sadece bir kullanıcıyı desterler. Yani bir cihazdan oturum açtıysanız ve sonrasında başka bir cihazdan oturum açtıysanız artık eski cihazdan maillerinizi göremezsiniz.

**IMAP**

IMAP protokolü, Gmail gibi hesaplardan e-postaları alırken aynı anda sisteme bağlanan cep telefonu gibi aygıtlarınız arasında sorun yaşanmasını engellemektedir. IMAP erişimi POP’a göre, e-posta aldığınız cihaz arasında iki yönlü iletişim sunuyor. Bu sayede, webden bağlanırken, cepten senkronize yaparken, bilgisayardan da e-postaları indirirken oluşabilecek hataların önüne geçilir. IMAP’ın en güzel özelliği bir e-postayı ABC isimli bir klasöre taşıdığınız zaman, aynı anda sisteme bağlı olan diğer cihazlarınızda da bu güncelleme yapılır. Yani akıllı telefonunuz ile bağlandığınızda, bu e-postanın ABC isimli klasöre taşındığını görebilirsiniz. Yapmış olduğunuz tüm değişiklikler akıllı telefonunuz ya da tabletiniz üzerinde de senkronize olur.