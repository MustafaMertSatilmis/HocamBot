[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-tasiyabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 968


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-tasiyabilirim)

# Roundcube'de iletileri farklı klasörlere nasıl taşıyabilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Gelen kutusunda ileti satırını sürükle-bırak yöntemi ile ya da iletiyi görüntülerken "Diğer" butonuna tıklayıp açılacak menüden "Şuraya taşı..." seçeneğiyle istediğiniz klasöre taşıyabilirsiniz.