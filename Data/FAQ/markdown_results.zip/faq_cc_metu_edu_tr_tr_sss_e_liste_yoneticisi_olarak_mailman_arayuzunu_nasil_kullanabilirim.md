[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-liste-yoneticisi-olarak-mailman-arayuzunu-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 13748


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-mailman-interface-list-administrator "How can I use MAILMAN Interface as a List Administrator? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-liste-yoneticisi-olarak-mailman-arayuzunu-nasil-kullanabilirim "E-Liste yöneticisi olarak Mailman Arayüzünü nasıl kullanabilirim?")

# E-Liste yöneticisi olarak Mailman Arayüzünü nasıl kullanabilirim?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

Bu sayfada liste yöneticisi olan kişilerin Mailman yazılımını kullanarak elektronik liste hizmetinden nasıl yararlanabileceği hakkında bilgiler verilmektedir. Mailman yazılımı liste hizmetlerini başta İngilizce ve Türkçe olmak üzere çeşitli dillerde hazırlanmış web arayüzlerinden sağlamaktadır. Bu sayfadaki bölüm başlığı ve bilgi mesajı gibi bilgiler liste yöneticilerinin Türkçe web arayüzlerini kullanacağı varsayılarak açıklanmıştır.

Yöneticisi olduğunuz liste ile ilgili bilgileri görmek veya işlem yapmak için:

**(1)** [http://mailman.metu.edu.tr/mailman/admin](http://mailman.metu.edu.tr/mailman/admin) adresinden yöneticisi olduğunuz bir listeyi tıklayınız.

**(2)** Ekrana gelen **[http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI** adresindeki sayfada liste yöneticisi şifresinin girilmesi gerekir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_8.gif)

Şifre doğru olarak girildikten sonra aşağıdaki gibi bir ekran görüntülenir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_9.gif)

**(3) Liste yönetimi arayüzündeki bölümler:**

> **(a) Genel seçenekler:** Liste kısa ve uzun adı, liste yöneticisi ekleme/silme/değiştirme, moderatör atama, liste açıklaması, hoşgeldin mesajı, veda mesajı gibi özelliklerde değişiklik yapmak için kullanılan arayüzdür. **[http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/general** şeklindeki adresten ulaşılır.
>
> - **Listenin kısa adını büyük veya küçük harfle görüntülemek için:**"Bu listenin genel ismi (sadece büyük-küçük harf değişikliği yapın)." alanında değişiklik yapılır:
>
>   _Ör. Bir liste kısa adı Test, TEST, Test vb. şekilde görüntülenebilir._
>
> - **Liste yöneticisinde değişiklik yapmak/yenisini eklemek/varolanı silmek için:**
>
>   "Liste yöneticisi e-posta adresleri. Birden çok yönetici adresi tanımlanabilir, her satıra tek bir adres yazın." alanında değişiklik yapılır. Her satıra bir e-posta adresi gelecek şekilde yeni yöneticiler eklenebilir; mevcut bir satır silindiğinde, o liste yöneticisi silinmiş olur.
>
> - **Listeye moderatör atamak için:**
>
>   "Liste moderatör adresleri. Birden çok moderatör adresi tanımlanabilir, her satıra tek bir adres yazın." alanında değişiklik yapılır. Her satıra bir e-posta adresi gelecek şekilde yeni moderatörler eklenebilir; mevcut bir satır silindiğinde, o moderatör silinmiş olur. Bu alan boş bırakılırsa liste için moderatör tanımlanmamış olur.
>
> - **Listenin uzun adını tanımlamak için:**
>
>   Listenin [http://mailman.metu.edu.tr/mailman/listinfo](http://mailman.metu.edu.tr/mailman/listinfo) adresinde görünecek uzun adını tanımlamak için "Bu listeyi belirleyen kısa bir ifade." alanına bilgi girişi yapılır. Bu alan boş bırakılırsa listenin uzun adı görünmez, yerine _\[no description available\]_ açıklaması görünür.
>
>   _Ör. Elektronik liste servisi TEST listesi_
>
> - **Liste açıklamasını göstermek için:** Herhangi bir listeyle ilgili **[http://mailman.metu.edu.tr/mailman/listinfo/L](http://mailman.metu.edu.tr/mailman/listinfo/L) İSTE-ADI** adresli sayfaya girildiğinde liste ile ilgili bir açıklama metni görülmesi istenirse, "Liste ile ilgili bir önsöz - birkaç paragraf -." alanına bilgi girişi yapılır.
>
>   _Ör. TEST listesi elektronik liste servisinin geliştirilmesi ve olası sorunların giderilmesi amacıyla denemelerin yapıldığı, sadece BİDB personelinin üye olduğu kapalı bir listedir._
>
> - **Liste üyelerine aylık şifre hatırlatması yapmak için:** Bunun için "Aylık şifre hatırlatıcılar gönderilsin mi?" alanında **Evet** seçilir; hatırlatma istenmiyorsa **Hayır** seçilir.
>
> - **Yeni üyelere gönderilen hoşgeldin mesajına ekleme yapmak için:**
>
>   Yeni üyelere listeye üye olduklarında normalde standart bir hoşgeldin mesajı gönderilir (istendiğinde bu özellik değiştirilebilir.) Standart hoşgeldin mesajına eklemek üzere listeye özel veya liste yöneticisinin gerekli gördüğü bilgiler için "Yeni üye olanlara giden Hoşgeldiniz mesajının önüne eklenecek listeye özgü yazı" alanına bilgi girişi yapılabilir. (Not: Standart hoşgeldin mesajında değişiklik yapılmak istenirse **[http://mailman.metu.edu.tr/mailman/edithtml/L](http://mailman.metu.edu.tr/mailman/edithtml/L) İSTE-ADI/subscribeack.txt** sayfasındaki metin üzerinde değişiklik yapılabilir.)
>
> - **Liste üyeliğinden ayrılan kullanıcılara veda mesajı göndermek için:** Liste üyeliğinden ayrılan üyelere normalde standart bir veda mesajı gönderilir (istendiğinde bu özellik değiştirilebilir.) Standart veda mesajının sonuna eklemek üzere listeye özel veya liste yöneticisinin gerekli gördüğü bilgiler için "Bu listeden çıkan kişilere gönderilecek yazı." alanına bilgi girişi yapılabilir.
>
> - **Yeni üyelerin standart üyelik ayarları için:**
>
>   Bir listeye yeni eklenen üyelerin üyelik ayarları için çeşitli seçenekler bulunmaktadır. Liste yöneticisi isteğine göre bu ayarlarda "Bu listeye yeni üye olanlar için varsayılan ayarlar." alanından değişiklik yapabilir.
>
> - **Listeye gönderilen mesajların boyunu sınırlamak için:**
>
>   Bir listeye gönderilen maksimum mesaj boyu (mesajla birlikte gönderilen ekli dosyanın boyu da dahil olmak üzere) normalde 40 KB'dir. Liste yöneticisi ihtiyaca göre bu boyu azaltabilir veya çoğaltabilir. Maksimum mesaj boyu değiştirilmek istenirse, "Mesaj gövdesinin kilobayt (KB) olarak maksimum uzunluğu." alanına istenen değer yazılır. Bu alana değer olarak 0 (sıfır) yazıldığı takdirde, maksimum mesaj boyuna sınır konmamış olur.
>
>
> **(b) Liste yöneticisi ve modearötörü için yeni şifre tanımlama:** Liste yöneticisinin veya varsa moderatörünün şifresi değiştirmek istenirse, gerekli değişiklik **[http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/passwords** adresinde bulunan arayüzden yapılır.
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_10.gif)
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_11.gif)
>
> **(c) Liste için dil seçenekleri:** Bir listenin web arayüzlerinde kullanılması istenen dil veya dillerin seçimi **[http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/language** adresinde bulunan arayüzden yapılır. Önce, "Bu listenin desteklediği diller" alanından arayüzde kullanılması istenen diller işaretlenir (İngilizce ve Türkçe dillerinin her listede seçili olması gereklidir.) Sonra, "Bu listenin varsayılan dili." alanından liste için varsayılan dilin seçimi yapılır.
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_12.gif)
>
> **(d) Üyelik yönetimi:** Bir listeye üye eklemek, listeden üye çıkarmak veya liste üyelerinin üyelik ayarlarını değiştirmek için **[http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/members** adresinde bulunan arayüz kullanılır.
>
> - **Üyelik listesi arayüzünde ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/members/list):**\- E-posta adresine göre üye araması yapılabilir.
>
>   ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_13.gif)
>
>   ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_14.gif)
>
>
>   > \- Üye tablosunda her bir üyenin ayarlarında değişiklik yapılabilir.
>   >
>   > **çıkar** ile liste üyeliği iptal edilir.
>   >
>   > **onay** ile üyeden gelen mesajların kontrol edilip edilmeyeceği belirlenir.
>   >
>   > **gizle** ile liste üyesinin adresinin üye listesinde görünmemesi sağlanır.
>   >
>   > **mesaj yok** ile çeşitli sebeplerle liste üyesine liste mesajlarının gönderilmemesi sağlanır:
>   >
>   > **K -** bu seçim üyenin kişisel isteği ile olabilir.
>   >
>   > **Y -** bu seçim liste yöneticisi tarafından yapılabilir.
>   >
>   > **G -** üyenin adresinde tekrarlayan bir problem varsa, bu seçim sistem tarafından yapılır.
>   >
>   > **? -** sebebi bilinmeyen durum
>   >
>   > **bilgi** ile üyeler kendi gönderdikleri mesaj hakkında bilgilendirilir.
>   >
>   > **mesajımı bana gönderme** ile üyenin gönderdiği mesajların bir kopyasının kendisine gelmesi engellenir.
>   >
>   > **kopya gönderme** ile bir üyeye bir mesajın birden fazla kopyasının gitmesi engellenir.
>   >
>   > **toplu** ile bir üyeye toplu mesaj gönderilmesi sağlanır. (bu seçim yapılmazsa mesajlar tek tek ulaşır)
>   >
>   > **düz yazı** ile toplu mesaj almayı tercih eden üyelerin mesajları sade metin olarak alması sağlanır. (bu seçim yapılmazsa mesajlar MIME formatında ulaşır.)
>   >
>   > **dil** ile kullanıcının tercih ettiği dil seçimi yapılır.
>
>   - **Yığı üye ekleme arayüzünde ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/members/add):**\- Bir veya birden fazla üye ekleme işlemleri doğrudan arayüzde bulunan alana her satıra bir adres gelecek şekilde bilgi girişi yapılarak veya bir dosyadan indirerek yapılabilir. Aynı zamanda üyeler hemen listeye üye yapılabildiği gibi, üyelik öncesinde kendilerine bir davet gönderilebilir.
>
>     ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_15.gif)
>     - **Yığın üye çıkarma arayüzünde ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/members/remove):**\- Bir veya birden fazla üye çıkarma işlemleri doğrudan arayüzde bulunan alana her satıra bir adres gelecek şekilde bilgi girişi yapılarak veya bir dosyadan indirerek yapılabilir.
>
>       ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_16.gif)
>
>       **(e) Listeye gönderilen mesajların toplu veya tek tek alınması ile ilgili ayarlar:**
>
>
>       - **Listeye gönderilen mesajların TEK TEK alınması istenirse gerekli ayarlar,** **[http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/nondigest** adresinde bulunan arayüzden (Toplu Olmayan Gönderim Seçenekleri) yapılır. Bu arayüzde ayrıca, listeye gönderilen her mesajın başına ve sonuna eklenebilen bilgi mesajını silme/düzenleme alanı da bulunmaktadır. Normalde her liste mesajinın sonuna standart olarak aşağıdaki gibi bir bilgi eklenir:
>
>
> > _LİSTE-ADI mailing list_
> >
> > _Lİ [STE-ADI@metu.edu.tr](mailto:STE-ADI@metu.edu.tr)_
> >
> > _[http://mailman.metu.edu.tr/mailman/listinfo/L](http://mailman.metu.edu.tr/mailman/listinfo/L) İSTE-ADI_
> >
> > İstendiği takdirde bu bilgiler silinebilir veya değiştirilebilir. Mesajın başına normalde herhangi bir bilgi konmamaktadır.
>
>       - **Listeye gönderilen mesajların TOPLU olarak alınması istenirse gerekli ayarlar, [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/digest** adresinde bulunan arayüzden (Toplu Gönderim Seçenekleri) yapılır. Bu arayüzde toplu mesajların hangi zaman aralıklarıyla gönderileceğinin belirlenmesi, her toplu mesajın başına ve sonuna eklenebilecek bilgilerin düzenlenmesi, bir toplu mesaj gönderimi için maksimum mesaj boyunun ayarlanması gibi işlemler yapılmaktadır.
>
>
> **(f) Gizlilik seçenekleri:**
>
>       - **Üyelik kuralları** **( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/privacy/subscribing):**\- Söz konusu listenin Mailman kapsamında hizmette olan listeler sorgulandığında görüntülenmesi için, "Kişiler bu sunucudaki listeleri sorguladığında bu liste ilan edilsin mi?" alanındaki **Evet** seçeneği işaretlenir.
>
>         \- Söz konusu listeye üye olması istenmeyen e-posta adreslerinin üyelik engellemesi için, istenmeyen e-posta adresleri, "Bu mesaj listesine üye olmaları yasak olan adreslerin listesi." alanına yazılır.
>
>         \- Bir listeye hangi adreslerin üye olduğunu görebilme izninin herkese mi, sadece listenin üyelerine mi, sadece liste yöneticisine mi verileceği "Üyelik listesini kim görebilir?" alanından seçilir.
>
>         \- Üye e-posta adreslerinin e-posta adresi olarak görüntülenmemesi istenirse "Üye adresleri doğrudan e-posta adresi olarak tanınmayacak şekilde gösterilsin mi?" alanında **Evet** seçeneği işaretlenir.
>
>         _Ör. [test@metu.edu.tr](mailto:test@metu.edu.tr) yerine test at metu.edu.tr gibi_
>
>       - **Gönderici filtreleri ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/privacy/sender):** Bu arayüzde, liste üyeleri ile listeye üye olmayan kişilerin listeye gönderdiği mesajların denetlenip denetlenmemesi, denetlenmesi durumunda ne tür işlemler yapılacağı, kullanıcılara ne tür mesajlar gönderileceği gibi konular için ayarlamalar yapılmaktadır.
>
>       - **Spam filtreleri ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/privacy/spam):** Bu arayüzde, listeye spam nitelikli bir mesaj geldiğinde ne tür bir işlem yapılacağı (bekletmek, reddetmek, onaylamak vb.) seçilmekte ve spam gönderen adreslerin filtrelenmesi için çeşitli formatta kural yazılabilen bir alan bulunmaktadır.
>
>         _Ör._
>
>         _**from: [list@listme.com](mailto:list@listme.com)** ( [friend@public.com](mailto:friend@public.com) adresinden gelen mesajları filtrele)_
>
>         _**from: .\*@uplinkpro.com** (uplinkpro.com uzantılı adreslerden gelen mesajları filtrele)_
>
>
> **(g) Geri Dönüş İşleme ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/bounce):**
>
>       - Adresinde sorun yaşanan üyelerin üyeliğinin kaç sorundan sonra durdurulacağı "Bir üyenin üyeliğinin devre dışı kalması için ulaşılacak en fazla geri dönüş puanı." alanına yazılan sayı ile belirlenir.
>
>       - Adresinde sorun yaşanan üyelerin sorunu düzelse bile, bu adreslerin artık sorunlu olmadığını varsaymak için kaç gün geçmesi gerektiği "Bir üyeden, geri dönüş alınmaması sonucunda geri dönüş bilgisinin gözardı edilmesi için geçmesi gereken gün sayısı." alanına yazılan sayı ile belirlenir.
>
>       - Adresinde sorun yaşanan üyelerin üyeliğinin kaç adet "üyeliğiniz Devre Dışı" mesajı alacağı "Üyenin, üyeliği silinmeden önce kaç tane _Üyeliğiniz Devre Dışı_ mesajı alacağı." alanına yazılan sayı ile belirlenir.
>
>       - "üyeliğiniz Devre Dışı" uyarı mesajlarının gün bazında gönderilme sıklığı " _Üyeliğiniz Devre Dışı_ mesajlarının gönderileceği gün sıklığı." alanına yazılan sayı ile belirlenir.
>
>
> **(h) Arşivleme Seçenekleri ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/archive):** Liste için arşiv tutulup tutulmayacağı, arşivin herkese açık olup olmayacağı ve arşivleme sıklığı ile ilgili ayarlamalar bu arayüzden yapılır.
>
> **(i) Haber Geçitleri ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/gateway):** Listeye gönderilen mesajlar ile bir habergrubu ilişkilendirilmek istendiğinde bu arayüzde ayarlar yapılmalıdır.
>
> **(j) Otomatik Yanıtlayıcı ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/autoreply):** Çeşitli durumlar için otomatik yanıtlama gerektiğinde bu arayüzde ayarlamalar yapılır.
>
> **(k) İçerik Filtreleme ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/contentfilter):** Listeye gönderilen mesajlar için eklenti dosya uzantısı veya MIME tiplerine göre filtrelenmesi istenirse bu arayüzden ayarlamalar yapılmalıdır. Filtreleme yapmak gerektiğinde ne tür işlemler (mesajı eklentili dosyayı çıkardıktan sonra gönderme, reddetme, kabul etme, bekletme gibi) yapılacağı da yine buradan seçilir. Listeler standart olarak bazı tür dosyaların dağılabileceği bazılarının filtreleneceği şekilde bir tanımla açılmaktadır. Buradaki dağıtılan ve filtrelenen dosya türleri mevcut kullanım alışkanlıkları ve internet güvenlik kriterleri dikkate alınarak oluşturulmuştur.
>
> **(l) Konular ( [http://mailman.metu.edu.tr/mailman/admin/L](http://mailman.metu.edu.tr/mailman/admin/L) İSTE-ADI/topics):** Listedeki yazışmalar için belli konu kategorilerinin oluşturulması ve liste üyelerinin mesajlarını bu kategorilere göre alması ile ilgili ayarlar bu bölümden yapılır. Bir listede konu filtresi normalde devre dışıdır.
>
> **(m) Bekleyen moderatör isteklerine bak ( [http://mailman.metu.edu.tr/mailman/admindb/L](http://mailman.metu.edu.tr/mailman/admindb/L) İSTE-ADI):** Liste moderated/denetlenen bir liste ise listeye gönderilen mesajlar onaylanmak veya reddilmek üzere moderatörün kontrolü için biriktirilir. Gelen bu mesajları liste moderatörü bu arayüzden görüp onay, red, bekletme gibi işlemleri yapabilir.
>
> **(n) Genel liste bilgi sayfasına git ( [http://mailman.metu.edu.tr/mailman/listinfo/L](http://mailman.metu.edu.tr/mailman/listinfo/L) İSTE-ADI):** Herkese açık genel bilgilendirme sayfasına liste yönetici arayüzünde bulunan bu linkle ulaşılabilir.
>
> **(o) Herkese açık web sayfalarının ve metin dosyalarının düzenlenmesi (Edit the public HTML pages and text files) ( [http://mailman.metu.edu.tr/mailman/edithtml/L](http://mailman.metu.edu.tr/mailman/edithtml/L) İSTE-ADI):** Bu arayüzden, liste ile ilgili genel bilgilendirme web sayfası, üyelik başvurusu sonucunu gösteren web sayfası, kişiye özel liste ayarlarının görüntülendiği web sayfası ile yeni üyelere gönderilen hoşgeldin mesajının içeriği kaynak kodlarına ulaşılarak düzenlenebilmektedir.
>
> **(p) Liste arşivlerine git ( [http://mailman.metu.edu.tr/mailman/private/L](http://mailman.metu.edu.tr/mailman/private/L) İSTE-ADI):** Listenin arşivi tutuluyorsa bu linkten ulaşılabilir.
>
> **(r) Çıkış:** Liste yöneticisi yönetim arayüzüne bir şifre ile ulaştığından, arayüzden çıkmak istediğinde güvenlik gereği "Çıkış" linki ile çıkış yapmalıdır.