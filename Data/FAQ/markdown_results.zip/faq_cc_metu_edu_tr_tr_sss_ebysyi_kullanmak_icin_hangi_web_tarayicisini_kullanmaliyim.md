[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysyi-kullanmak-icin-hangi-web-tarayicisini-kullanmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2024 **Görüntüleme:** 5295


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysyi-kullanmak-icin-hangi-web-tarayicisini-kullanmaliyim)

# EBYS'yi kullanmak için hangi web tarayıcısını kullanmalıyım?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Sistem teorik olarak bütün tarayıcılarda çalışacak şekilde hazırlanmıştır.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.