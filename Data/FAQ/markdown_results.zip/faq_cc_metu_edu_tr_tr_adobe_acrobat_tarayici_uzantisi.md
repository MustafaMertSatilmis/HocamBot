[Jump to navigation](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-05-2022 **Görüntüleme:** 10295


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/adobe-acrobat-browser-extension "ADOBE ACROBAT BROWSER EXTENSION")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi "ADOBE ACROBAT TARAYICI UZANTISI")

# ADOBE ACROBAT TARAYICI UZANTISI

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **ADOBE ACROBAT** **CHROME EXTENSION****—**

_Adobe Acrobat uzantısıyla PDF'leri doğrudan Google Chrome tarayıcınızda düzenleyin._

_Aşağıdaki adımları takip ederek uzantının yükleme ve etkinleştirme işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi#kurulum)

**_[ETKİNLEŞTİRME](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi#etkinlestirme)_**

* * *

_**ADIM-1 <<<UZANTIYI YÜKLEYİN>>>**_

_Aşağıdaki link üzerinden Google Chrome Mağazasına giderek uzantıyı tarayıcınıza ekleyebilirsiniz._

[https://chrome.google.com/webstore/detail/adobe-acrobat/efaidnbmnnnibpcajpcglclefindmkaj](https://chrome.google.com/webstore/detail/adobe-acrobat/efaidnbmnnnibpcajpcglclefindmkaj)

_**ADIM-2 <<<UZANTIYI ETKİNLEŞTİRİN>>>**_

_Google chrome'u açınız ve Chrome araç çubuğunun sağ üst köşesindeki Chrome menü simgesini tıklayınız. Daha sonra " **Daha Fazla** **Araçlar > Uzantılar"**'ı seçiniz._

![](https://faq.cc.metu.edu.tr/system/files/u16319/acrobat-extension-ss1.png)

_**ADIM-3**_

_Adobe Acrobat uzantısını açmak için açma düğmesine tıklayınız._

![](https://faq.cc.metu.edu.tr/system/files/u16319/acrobat-extension-ss3.png)

_**ADIM-4**_

_Yeni bir Chrome sekmesinde bir web sayfası açın veya mevcut herhangi bir sekmeyi yenileyin. Uzantı, web sayfası tamamen indirildikten sonra etkinleştirilir. Bu aşamadan sonra uzantı kullanıma hazır. Seçenekleri görmek için Adobe Acrobat simgesine tıklayınız._

![](https://faq.cc.metu.edu.tr/system/files/u16319/acrobat-extension-ss4.png)

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *