[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklara-bakarken-bir-evrak-birden-fazla-kez-listede-gorunebiliyor-neden#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 1338


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklara-bakarken-bir-evrak-birden-fazla-kez-listede-gorunebiliyor-neden)

# Geçmiş bölümünden evraklara bakarken bir evrak birden fazla kez listede görünebiliyor, neden?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Evrak her git-gel yaptığında sistemde bu git-gel kayıt edildiğinden bir kişiye bir evrak kaç kere ulaşmış ise o evrak listede o kadar sayıda görünecektir. Bu normal bir durumdur.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.