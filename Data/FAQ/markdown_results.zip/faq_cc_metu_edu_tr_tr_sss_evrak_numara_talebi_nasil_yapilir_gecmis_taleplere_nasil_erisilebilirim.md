[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/evrak-numara-talebi-nasil-yapilir-gecmis-taleplere-nasil-erisilebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 2107


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/evrak-numara-talebi-nasil-yapilir-gecmis-taleplere-nasil-erisilebilirim)

# Evrak numara talebi nasıl yapılır, geçmiş taleplere nasıl erişilebilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Evrak sistemden hazırlanmak yerine haricen hazırlanıp teslim edilecek ise Kurum İçi veya Kurum Dışı menülerinin altından Evrak Numara Talep Formu ekranına ulaşılabilmektedir.

Açılan ekranda gerekli alanlar doldurularak Gönder düğmesine basılır. Onaylayacak kişinin onaylaması sonrası evrak numarası oluşacaktır. Oluşturulan evrak numaralarına EBYS Evrak Sorgulama menüsünün altındaki Evrak Numara Talepleri ekranından ulaşılabilmektedir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.