[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartiniz-iptal-edilmistir-universitenize-basvurunuz-uyarisi-almaktayim-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-10-2021 **Görüntüleme:** 8286


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-get-warning-message-says-your-smart-card-has-been-canceledout-use-please-apply-your-university "I get a warning message says “Your smart card has been canceled/out of use. Please apply your University” What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartiniz-iptal-edilmistir-universitenize-basvurunuz-uyarisi-almaktayim-ne-yapmaliyim "\"Akıllı Kartınız Iptal Edilmiştir. Üniversitenize Başvurunuz\" uyarısı almaktayım. Ne yapmalıyım?")

# "Akıllı Kartınız Iptal Edilmiştir. Üniversitenize Başvurunuz" uyarısı almaktayım. Ne yapmalıyım?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınız mezun/emekli veya göreviniz sona erdiği için iptal edilmiş olabilir. Bu koşullardan herhangi biri sizin durumunuza uymuyor ve kartınız iptal edilmiştir uyarısı alıyoranız; öğrenci iseniz Öğrenci İşleri Daire Başkanlığı’na, personel iseniz Personel Daire Başkanlığı’na başvurmanız gerekmektedir.