[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/windows-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 24110


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-e-mail-services-windows-mail "How can I use METU E-Mail Services with Windows Mail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/windows-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim "Windows Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?")

# Windows Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

Windows Vista işletim sisteminde bulunan Windows Mail programıyla e-posta okumak ve göndermek için merkezi e-posta sunucusu ayarlarını yapmanız gereklidir.

Bunun için, menüden **Araçlar > Hesaplar** seçeneği ile "İnternet Hesapları" penceresini açın. **Ekle** düğmesine tıkladığınızda açılan pencereden **E-posta Hesabı** seçeneğini seçip **İleri** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_winmail01_tr.jpg)

Bir sonraki pencerede adınızı yazıp **İleri** düğmesine tıklayın (Bu pencere Windows Mail programını ilk kez çalıştırdığınızda otomatik olarak ekrana gelir).

Daha sonraki pencerede e-posta adresinizi yazıp **İleri** düğmesine tıklayarak sunucu ayarları ekranına gelin. Mesajlarınıza ve sunucu üzerindeki klasörlerinize birden fazla bilgisayardan ulaşmak isterseniz hesap türünü "IMAP" seçin. Gelen posta sunucu adresini **imap.metu.edu.tr** olarak yazın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_winmail02_tr.jpg)

Gelen kutunuzu tek bir bilgisayara indirip mesajlarınıza yalnızca bu bilgisayardan ulaşmak isterseniz ve sunucu üzerindeki klasörlere erişmenize gerek yoksa hesap türünü "POP3" seçin. Gelen posta sunucu adresini **pop3.metu.edu.tr** olarak yazın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_winmail03_tr.jpg)

Her iki seçenekte de giden e-posta sunucusu adını **smtp.metu.edu.tr** olarak yazın ve "Giden sunucu için kimlik doğrulaması gerekiyor" kutucuğunu işaretleyip **İleri** düğmesine tıklayın.

Sonraki pencerede kullanıcı adınızı ve parolanızı yazın. Parolanızın hatırlanmasını istiyorsanız "Parolayı anımsa" kutucuğunu işaretleyin. **İleri** düğmesine tıklayarak sonraki ekranda kurulumu tamamlayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_winmail04_tr.jpg)

Güvenli IMAP bağlantısı kullanmak için "İnternet Hesapları" penceresinde **Özellikler** düğmesine tıklayın. Ekrana gelen "Özellikler" penceresinde **Gelişmiş** sekmesini seçin. "Giden posta (SMTP)" karşısına **587**, "Gelen posta (IMAP)" karşısına **993** yazarak her iki "Bu sunucu için güvenli bağlantı (SSL) gereklidir" kutucuğunu da işaretleyin.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_winmail05_tr.jpg)

Güvenli POP3 bağlantısı kullanmak için "Giden posta (SMTP)" karşısına **587**, "Gelen posta (POP3)" karşısına **995** yazarak her iki "Bu sunucu için güvenli bağlantı (SSL) gereklidir" kutucuğunu da işaretleyin. Sunucudaki tüm mesajları o an bilgisayara indirmek istemezseniz "İletilerin bir kopyasını sunucuda bırak" kutucuğunu işaretleyin.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_winmail06_tr.jpg)

Yaptığınız ayarları daha sonra görmek ya da değiştirmek isterseniz menüden **Araçlar > Hesaplar** seçeneği ile "İnternet Hesapları" penceresini açıp **Özellikler** düğmesine tıklayın.

_**Not:** Bu doküman Windows Mail 6.0 sürümü dikkate alınarak hazırlanmıştır. Menüler ve seçenekler önceki sürümlerle farklılık gösterebilir._