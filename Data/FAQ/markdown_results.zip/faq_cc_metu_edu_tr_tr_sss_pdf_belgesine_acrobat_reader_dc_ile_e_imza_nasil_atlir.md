[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pdf-belgesine-acrobat-reader-dc-ile-e-imza-nasil-atlir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 31-10-2020 **Görüntüleme:** 19810


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-e-sign-pdf-document-acrobat-reader-dc "How to e-sign a PDF document with Acrobat Reader DC?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pdf-belgesine-acrobat-reader-dc-ile-e-imza-nasil-atlir "PDF belgesine Acrobat Reader DC ile e-imza nasıl atlır?")

# PDF belgesine Acrobat Reader DC ile e-imza nasıl atlır?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Acrobat Reader DC yazılımı ile daha önce oluşturulmuş olan bir pdf belgesine e-imza imza atmak mümkündür. Burada dikkat edilmesi gereken iki notkta bulunmaktadır.

1. TUBITAK KamuSM bir çok işletim sisteminde güvenli kök sertifika sağlayıcı olarak kabul edilmemektedir. Bu nedenle, TUBITAK KamuSM tarafından üretilen [kök sertifikaların](https://sertifikalar.kamusm.gov.tr/ "KamuSM Kök ve Alt Kök Sertifikaları") indirilmesi ve yüklenmesi gerekmektedir.
2. İşletimi sisteminize uygun "akis" sürücüsünü yüklemiş olmanız gerekmektedir. TUBİTAK KamuSM'nin sürücüler sayfasından [indirebilirsiniz](http://kamusm.bilgem.tubitak.gov.tr/islemler/surucu_yukleme_servisi/ "KamuSM Sürücü Yükleme Servisi").

Acrobat Reade DC yazılımın çalıştırdıktan sonra aşağıdaki adımları takip ediniz:

|     |     |
| --- | --- |
| Üst menüde  'Edit' ve sonra  'Preferences...'ı seçin | ![](<Base64-Image-Removed>) |
| Sol tarafta “Security (Enhanced)”ı seçin ve orta ekranda “Sandbox Protections” altında “Enbale Protected Mpode at Startup” yanındaki tiki kaldırın. “OK” diyerek sayfayı kapatın.<br>Acrobat Reader DC’yi yeniden başlatmanız gerekecek. | ![](<Base64-Image-Removed>) |
| Acrobat Reader DC yeniden başladığında “1. Maddedeki” gibi Üst menüde  'Edit' ve sonra  'Preferences...'ı seçin.<br>Sol tarafta “Signiture”ı seçin ve orta ekranda “Identities & Trusted Certificates” altında “More” düğmesine basın. | ![](<Base64-Image-Removed>) |
| Sol tarafta “Digital IDs”  seçin altında “PKCS#11 Modules and tokens”a tıklayın ve “Attach Module” düğmesine tıklayın | ![](<Base64-Image-Removed>) |
| Akis modülü “C:/Windows/System32/akisp11.dll” dosyasıdır | ![](<Base64-Image-Removed>) |
| Sol tarafta “Digital IDs”  seçin altında “PKCS#11 Modules and tokens” altında “AKIS PKCS#11 Kutuphanesi”nin altında “Akis”e gidin.<br>“+” işareti ile düğmeye basarak sertifikanızı yükleme işlemine başlayın. | ![](<Base64-Image-Removed>) |
| Açılan pencereye sertifikanıza ulaşmak için gerekli olan “PIN” numarasını yazın.<br>Ardından açılan pencerede “Cancel” diyerek çıkın | ![](<Base64-Image-Removed>) |
| Sol tarafta “Digital IDs”nin altında “PKCS#11 Modules and tokens”nin altında  “AKIS PKCS#11 Kutuphanesi”nin altında“Akis”te sertifikanızı görebilirsiniz. <br> “Kalem” işaretine basıp “Use for Signing”i seçiniz.<br>Tüm açılan pencereli kapatıp ana Acrobat Reader DC ekranına dönünüz. | ![](<Base64-Image-Removed>) |
| Acrobat Reader DC sekmelerlerinde “Tools” altında “certificates”e içinde “open” düğmesine basın. “Certificates” yoksa “Show more” altında bulunabilir. | ![](<Base64-Image-Removed>) |
| “Certificates” araç çubuğu oluştuktan sonra “Digital Sign” düğmesine basın. | ![](<Base64-Image-Removed>) |
| Belge üzerinde imzanızı atacağınız yeri belirlemenizi için uyarı çıkacaktır. | ![](<Base64-Image-Removed>) |
| İmzanızın yeri belirlediğinizde Acrobat Reader DC hangi sertifikayı kullanacağınızı sorduğu ekran ile karşılaşacaksınız (E-imzanızın takılı olması gerekli) Sertifikanızı seçin ve “Contiune” tuşuna basın | ![](<Base64-Image-Removed>) |
| “Entet the Digital ID PIN or Password…” alanına e-imza PIN'inizi girin ve "Sign" düğmesine basın. | ![](<Base64-Image-Removed>) |
| E-imzaladığınız dosyayı kayıt etmeniz için pencere açılacak. Uygun gördüğünüz alana kaydedin. |  |