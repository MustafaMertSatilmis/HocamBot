[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/odtukentyurtlarlojmanlar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# ODTÜKENT/Yurtlar/Lojmanlar

|     |
| --- |
| [Lojmanlardan İnternet'e nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/lojmanlardan-internete-nasil-baglanabilirim) |
| [ODTÜ Yurt Odaları Bilgisayar Ağı Kullanım Kuralları nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurt-odalari-bilgisayar-agi-kullanim-kurallari-nelerdir) |
| [ODTÜ Yurtlarında geçici olarak kalıyorum, kablolu bilgisayar ağından faydalanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurtlarinda-gecici-olarak-kaliyorum-kablolu-bilgisayar-agindan-faydalanabilir-miyim) |
| [Yurtlarda yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/yurtlarda-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim) |
| [Yurtlardan İnternete nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim) |

[![Subscribe to ODTÜKENT/Yurtlar/Lojmanlar](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/41/all/feed "Subscribe to ODTÜKENT/Yurtlar/Lojmanlar")