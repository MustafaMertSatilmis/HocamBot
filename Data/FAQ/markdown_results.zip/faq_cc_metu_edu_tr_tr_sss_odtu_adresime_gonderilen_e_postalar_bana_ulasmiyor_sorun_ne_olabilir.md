[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-adresime-gonderilen-e-postalar-bana-ulasmiyor-sorun-ne-olabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 6084


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-dont-receive-e-mails-sent-my-metu-e-mail-address-what-can-be-wrong "I don't receive e-mails sent to my METU e-mail address. What can be wrong?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-adresime-gonderilen-e-postalar-bana-ulasmiyor-sorun-ne-olabilir "ODTÜ adresime gönderilen e-postalar bana ulaşmıyor, sorun ne olabilir?")

# ODTÜ adresime gönderilen e-postalar bana ulaşmıyor, sorun ne olabilir?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

ODTÜ e-posta adresinize gönderilen bir e-postayı gelen kutunuzda göremiyorsanız, öncelikle aşağıdaki olası nedenleri kontrol ediniz:

- Eğer ODTÜ e-posta yönlendirme hizmetini aktif olarak kullanıyorsanız, yeniden ODTÜ öğrencisi veya personeli olmanız durumunda e-posta yönlendirme hizmeti otomatik olarak devre dışı kalmayacaktır. Bu durumda yönlendirme işlemini iptal etmeniz gerekmektedir. Ayrıntılı bilgi için [https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kulla...](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim) adresini ziyaret edebilirsiniz.
- Mümkünse size gönderilen e-posta mesajının göndericiye geri dönüp dönmediğini kontrol ettiriniz. E-posta mesajı geri dönmüşse, geri dönüş mesajında hangi nedenle teslim edilemediğine dair açıklama bulunacaktır.