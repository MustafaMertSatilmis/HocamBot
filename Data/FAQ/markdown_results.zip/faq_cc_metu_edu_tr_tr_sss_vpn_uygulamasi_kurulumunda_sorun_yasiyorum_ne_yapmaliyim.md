[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-06-2024 **Görüntüleme:** 18218


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-problems-installing-vpn-services-what-can-i-do " I have problems installing VPN services, what can I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiyorum-ne-yapmaliyim "VPN uygulaması kurulumunda sorun yaşıyorum. Ne yapmalıyım?")

# VPN uygulaması kurulumunda sorun yaşıyorum. Ne yapmalıyım?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

Eğer uygulama kurulumu yapılmış ancak bağlantı sorunu yaşıyorsanız [https://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum...](https://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-ne-yapmaliyim) adresini inceleyiniz.

**Windows işletim sisteminde** VPN uygulaması kurulumu sırasında hata alıyorsanız:

Windows 10 64 bit işletim sisteminde Symantec Endpoint Protection yazılımı kurulu iken VPN uygulamasının kurulması ve çalıştırılması sırasında bağlantı sağlanamadığı (real-time protection kapatılsa bile) tespit edilmiştir. Symantec ve ArubaVPN uygulamaları kaldırıldıktan sonra yeniden ArubaVPN uygulaması kurulduğunda VPN bağlantısı sağlanabilmiştir.

Kurulum sırasında "Virtual Intranet Acccess (VIA) setup wizard ended prematurely" hata mesajı alıyorsanız

- bilgisayanızda VIA uygulamasına dair herhangi dosya/sürücü kalmadığına emin olunuz (Aygıt yöneticisi / Ağ Adaptörleri altında VIA veya Aruba adında aygıt varsa siliniz)
- Varsa, aygıt yöneticisi / ağ adaptörleri altında _bilinmeyen aygıtl_ arı siliniz.
- Windows güncellemelerinizi tamamlayınız
- bilgisayarınızda yüklüyse Symantec, Mcafee, Avast, vb. antivirüs/güvenlik uygulamalarını kaldırınız
- bilgisayarınızı güvenli modda yeniden başlatınız
- güvenli modu başlattıktan sonra bilgisayarınızı kapatıp normal modda tekrar açınız
- güvenli modda çalıştırmak için [https://support.microsoft.com/tr-tr/windows/windows-10-da-bilgisayar%C4%...](https://support.microsoft.com/tr-tr/windows/windows-10-da-bilgisayar%C4%B1n%C4%B1z%C4%B1-g%C3%BCvenli-modda-ba%C5%9Flatma-92c27cff-db89-8644-1ce4-b3e5e56fe234) adresindeki adımları takip edebilirsiniz
- bilgisayarınızın ismini kontrol ediniz. Türkçe karakter (ı gibi) varsa değiştiriniz. ( [https://support.microsoft.com/tr-tr/windows/windows-10-bilgisayar%C4%B1n...](https://support.microsoft.com/tr-tr/windows/windows-10-bilgisayar%C4%B1n%C4%B1z%C4%B1-yeniden-adland%C4%B1r%C4%B1n-750bc75d-8ff8-e99a-b9dc-04dff566ae74))
- bilgisayarınızı yeniden başlatınız
- kurulumu tekrar deneyiniz

Sorununuz devam ederse, kurulum dosyasını, yönetici olarak çalıştırdığınız bir komut satırından **Windows\_4.0.0\_64.msi /L\*v log.txt** (Bu komutta Windows\_4.0.0\_64.msi ifadesini kurulum için kullandığınız dosya ismyle değiştiriniz) şeklinde çalıştırıp oluşan log.txt dosyasını, işletim sistemi bilginizle birlikte (winver komutu çıktısı) bize iletiniz.

**Ubuntu 20.04 işletim sisteminde** VPN uygulaması kurulumu sırasında eksik paket hatası alıyorsanız:

Aşağıdaki kurulum adımlarını takip ediniz.

1\. Zip [dosyasını](https://faq.cc.metu.edu.tr/tr/system/files/u2/via_4.0.0-2004190.Ubuntu16.04_amd64.zip) indirip açınız.

2\. root olarak komut satırı üzerinden :

# _dpkg -i <dosyanin ismi>_

komutunu çalıştırınız (Örnek "dpkg -i via\_4.0.0-2004190.Ubuntu16.04\_amd64.deb"  )