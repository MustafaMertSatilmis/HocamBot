[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/spam-olmayan-bazi-e-postalar-spambox-dizinine-geliyor-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8637


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/some-e-mails-although-not-spam-arrive-spambox-folder-what-should-i-do "Some of e-mails, although not spam, arrive at the SPAMBOX folder. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/spam-olmayan-bazi-e-postalar-spambox-dizinine-geliyor-ne-yapmaliyim "Spam olmayan bazı e-postalar SPAMBOX dizinine geliyor. Ne yapmalıyım?")

# Spam olmayan bazı e-postalar SPAMBOX dizinine geliyor. Ne yapmalıyım?

[Spam](https://faq.cc.metu.edu.tr/tr/groups/spam)

E-postayı tam başlık (full header) bilgileri ve gövde (body) kısmı ile birlikte [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresinden bize yönlendirin. E-posta başlığının tamamının nasıl görüntüleneceğiyle ilgili [buradan](http://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim) bilgi alabilirsiniz.

Horde kullanıyorsanız, spam olmadığını düşündüğünüz SPAMBOX dizinindeki e-postaları işaretleyip **Temiz Olarak Rapor Et** seçeneğiyle de spam filtresine temiz olarak tanıtabilirsiniz.