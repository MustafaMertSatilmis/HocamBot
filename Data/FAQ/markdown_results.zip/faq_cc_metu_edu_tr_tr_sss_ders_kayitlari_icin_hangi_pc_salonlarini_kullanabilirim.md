[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ders-kayitlari-icin-hangi-pc-salonlarini-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-02-2022 **Görüntüleme:** 6300


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/which-pc-rooms-are-available-course-registrations "Which PC Rooms are available for course registrations?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ders-kayitlari-icin-hangi-pc-salonlarini-kullanabilirim "Ders kayıtları için hangi PC Salonlarını kullanabilirim?")

# Ders kayıtları için hangi PC Salonlarını kullanabilirim?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

Tüm salonlar mesai saatlerinde, belirtilen ders, temizlik ve bakım saatleri dışında, genel kullanıma açıktır.

| **Salon** | **Saat** | **Gün** | **Temizlik ve Genel Bakım Saatleri** |
| --- | --- | --- | --- |
| Beşeri Bilimler PC Salonu | 09:00 - 17:00<br>Ders programları<br>PC Salonunda duyurulmaktadır. | Pazartesi - Cuma | Temizlik<br>Salı 09:00 - 10:00 |
| 1\. Yurt PC Salonu | 09:00 - 06:00 | Dersler devam ettiği sürece her gün<br>Dönem aralarında kapalı | Her gün<br>Temizlik 07:00-09:00 |
| 2\. Yurt PC Salonu - 2 | 09:00 - 06:00 | Dersler devam ettiği sürece her gün<br>Dönem aralarında 09:00 - 17:00 arası | Her gün<br>Temizlik 07:00-09:00 |
| 2\. Yurt PC Salonu - 3 | Bu salon eğitim ve seminer amacıyla kullanılmaktadır. | Planlı eğitim ve seminer süresince | Her gün<br>Temizlik 07:00-09:00 |
| Isa Demiray Yurdu PC Salonu | 09:00 - 01:00 | Dersler devam ettiği sürece her gün | Her gün<br>Temizlik 07:00-09:00 |
| Faika Demiray Yurdu PC Salonu | 09:00 - 01:00 | Dersler devam ettiği sürece her gün | Her gün<br>Temizlik 07:00-09:00 |
| Refika Aksoy Yurdu PC Salonu | 09:00 - 01:00 | Dersler devam ettiği sürece her gün | Her gün<br>Temizlik 07:00-09:00 |
|  |  |  |  |

**_Yaz döneminde sadece Yurtlar Müdürlüğü tarafından açık tutulan yurt binalarındaki PC salonları hizmet vermektedir._**