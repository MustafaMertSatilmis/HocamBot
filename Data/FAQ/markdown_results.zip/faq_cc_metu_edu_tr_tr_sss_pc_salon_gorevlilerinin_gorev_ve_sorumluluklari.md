[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salon-gorevlilerinin-gorev-ve-sorumluluklari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-01-2020 **Görüntüleme:** 9641


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/duties-pc-room-supervisors "What are the duties of PC Room Supervisors?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salon-gorevlilerinin-gorev-ve-sorumluluklari "PC Salon Görevlilerinin Görev ve Sorumlulukları Nelerdir?")

# PC Salon Görevlilerinin Görev ve Sorumlulukları Nelerdir?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

Bilgi İşlem Daire Başkanlığı'na bağlı PC salonlarının işletimi mesai saatlerinde PC Salon Operatörleri, mesai saatleri dışında Öğrenci Asistanları tarafından gerçekleştirilmekte, BİDB Kullanıcı Destek Grubu'na bağlı olarak çalışan personel aşağıda belirtilen kurallar doğrultusunda çalışmaktadır.

**PC Salon Operatörleri ve Öğrenci Asistanları:**

- BİDB tarafından belirlenen [çalışma saatlerinde](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-calisma-saatleri) (bakım, temizlik vb. çalışmalar için ayrılan süreler dışında) PC salonunu kullanıma açık tutmakla yükümlüdür.
- BİDB tarafından belirlenen [PC Salon Kuralları](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-kullanim-kurallari)'na eksiksiz uymak, kullanıcıların da bu kurallara uymasını sağlamak, uyarıları yapmak ve gerekli durumlarda cezaları uygulamakla yükümlüdür.
- Sessiz, sağlıklı bir çalışma ortamı yaratmak ve yaratılan bu ortamın devamlılığını sağlamakla yükümlüdür.
- Kullanıcılar ile ilişkilerinde seviyeli bir iletişim kurmalı ve kullanıcılara karşı nazik davranmalı, sözlü ve fiziksel tartışmalardan kesinlikle kaçınmalı, gerektiği durumlarda mesai saatleri içinde BİDB'de ilgili personeli, mesai saatleri dışında Yurt danışmasını haberdar etmelidir.
- Görevi sırasında elektrik kesintisi yaşandığında kullanıcıları kesintisiz güç kaynağının (UPS) devreden çıkabileceği konusunda uyararak tüm bilgisayarların 5 dakika içinde kapanmasını sağlamalıdır.
- Olası bir yangında salonda bulunan yangın söndürme aletlerini kullanarak ilk müdahaleyi yapmak ve Nöbetçi Amirliği(Tel:2113,2114) 'ni haberdar etmekle yükümlüdür.
- Görevi sırasında meydana gelen teknik arızaları kayıt programındaki "Arıza Bildirim Formu" nu kullanarak BİDB personeline bildirmekle yükümlüdür.
- Demirbaş listesinde kayıtlı eşyaların zarar görmesini engellemekle ve demirbaşların zarar görmesi halinde BİDB'ye durumu bildirmekle yükümlüdür.