[Jump to navigation](https://faq.cc.metu.edu.tr/tr/iso-dosyalarindan-cd-dvd-kaliplarindan-yazilim-kurulumu-nasil-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-11-2024 **Görüntüleme:** 65777


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/how-to-install-software-using-iso-cd-dvd-images-files "HOW TO INSTALL THE SOFTWARE USING ISO (CD/DVD IMAGES) FILES?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/iso-dosyalarindan-cd-dvd-kaliplarindan-yazilim-kurulumu-nasil-yapilir "ISO DOSYALARINDAN (CD/DVD KALIPLARINDAN) YAZILIM KURULUMU NASIL YAPILIR?")

# ISO DOSYALARINDAN (CD/DVD KALIPLARINDAN) YAZILIM KURULUMU NASIL YAPILIR?

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

Yerleşkemizde lisanslı yazılımların kurulum kaynaklarını indirebileceğiniz [https://yazilim.cc.metu.edu.tr/](https://yazilim.cc.metu.edu.tr/) adresinde teknik gereklilikler ve sağlayacağı kolaylıklar nedeniyle bazı yazılımlar; **CD/DVD kalıpları** halinde ((disk image), **ISO dosyası** olarak) **erişime açılmıştır**.

Bu disk kalıpları (imaj dosyaları), CD/DVD’ye yazılarak (Nero, [Imgburn](https://www.imgburn.com/) (ücretsiz) gibi yazılımlarla) doğrudan CD/DVD üzerinden de kullanılabilir.

### Önerilen Pratik Yöntem: 7-zip

Önerilen ve pratik yöntem [http://www.7-zip.org](https://www.7-zip.org/)/ adresinden **7-Zip** yazılımını indirip kurmak, ve sonra indirilen iso dosyasını sağ tıklayarak **7-zip** ile içeriğini bir klasöre (tıpkı zipli bir klasörü açmak gibi) "extract" etmektir. Oluşturulan klasör içindeki ilgili konumdan setup.exe çalıştırılarak kurulum yapılabilir.

ISO dosyasını CD/DVD'ye yazmak sadece bilgisayarı kendisi çalıştıran (bootable CD/DVD) medya isteyen işletim sistemi  kurulumları için gereklidir.

### DAEMON TOOLS:

**Daemon Tools** ise; ISO (Standard ISO), NRG (Nero Image), CUE gibi farklı dosya sistemlerindeki **CD/DVD kalıplarını** **Windows işletim sistemlerinde, sanal CD/DVD olarak çalıştırabilmek** için kullanılabilecek bir yazılımdır. Böylece iso dosyalarını CD ya da DVD ye yazmak, bir yere açmak (extract etmek) ve o şekilde saklamak zorunluluğu ortadan kalkmaktadır. Iso dosyaları ile sık işlem yapan kullanıcılarmıza bu yol önerilmektedir.

Yazılımın en güncel sürümünün [http://www.daemon-tools.cc/eng/products/dtLite](https://www.daemon-tools.cc/eng/products/dtLite)/ adresinden indirilmesi önerilmektedir (Ücretsiz olan DAEMON Tools Lite sürümüdür)

**Kurulum:** Programı kurmak için öncelikle kurulum dosyası (daemon410.exe gibi) dosyası yerel bilgisayara kaydedilip, çalıştırılır. Varsayılan ayarlarda kurulum gerçekleştirilir. (Kurulumun başlarında seçenek penceresinde “ **Daemon Tools Search Bar**”, "Ask.com Search", "Browser Toolbar" gibi ek yazılımların yanındaki işareti kaldırarak **kurulumdan çıkarınız**, yine sonraki aşamalarda gelecek anasayfayı daemon-search.com yapmakla ilgili seçim de **kaldırılabilir**)

Kurulum bilgisayarın yeniden başlatılmasını isteyebilir.

**Yapılandırma ve Kullanım:** Daemon Tools programı kurulduktan sonra, masaüstünün sağ alt köşesinde programın erişim kısayolu gözükür (Aşağıda, kırmızı şimşek işareti ile görünen simge). Kısayol üzerinden farenin sağ tuşu ile açılan menü ile yaratılacak sanal CD/DVD sürücü (drive) sayısı belirlenir.

**Şekil 1**:

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/img_sw_deamontools_howto1.jpg)

Son olarak, aynı kısayol üzerinden yaratılan sanal CD/DVD için kullanılacak imaj dosyası bağlantı işlemi ( **Mount image**) yerel diskte bulunan disk kalıbı (iso imaj dosyası) gösterilerek gerçekleştirilir. Böylece Bilgisayarım (My Computer) üzerinden yaratılan sanal CD/DVD sürücüsü tıklanarak DVD içeriğine erişilip, kurulum işlemleri gerçekleştirilebilir. **Unmount** seçeneği ile ilgili dosyanın bağlantısı sonlandırılabilir.

**Şekil 2:**

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/img_sw_deamontools_howto2.jpg)