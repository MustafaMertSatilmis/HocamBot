[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gorevim-degisti-ama-eski-gorevimle-ilgili-evraklar-gelmeye-devam-ediyor-neden#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-11-2021 **Görüntüleme:** 1206


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gorevim-degisti-ama-eski-gorevimle-ilgili-evraklar-gelmeye-devam-ediyor-neden)

# Görevim değişti, ama eski görevimle ilgili evraklar gelmeye devam ediyor, neden?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Bunun birkaç sebebi olabilir:

En sık karşılaşılan sebep:

Eski biriminizde birim gelen evrak sorumlusu iseniz, yeni biriminize geçtiğinizde bu değişikliğin [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine yazılı olarak bildirilmesi gerekmektedir. Bildirilmediği takdirde eski biriminizle ilgili evraklar gelmeye devam edebilir.

Diğer sebepler:

Onayları devam eden veya eski şablonlardan oluşturulan Kurum içi veya kurum dışı evraklar üzerinde paraf, imza, olur, uygunluk gibi onaylarınız kalmış ise bu nedenle evrak size gelebilir. Yazıyı oluşturan kişiye bu durumu bildirerek ve evrakı iade ederek sizin isminizi evraktan çıkarmasını talep etmelisiniz.

Hazır sevk grupları kullanarak evrak sevki yapılmış ise size evrakı gönderen kişiye ulaşarak sizi sevk grubundan çıkarmasını talep etmelisiniz. Evrakı bu notu ekleyerek tekrar size gönderen kişiye sevk edebilirsiniz.