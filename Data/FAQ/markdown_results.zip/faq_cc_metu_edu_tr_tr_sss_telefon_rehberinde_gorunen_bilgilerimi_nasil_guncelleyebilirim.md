[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/telefon-rehberinde-gorunen-bilgilerimi-nasil-guncelleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-06-2020 **Görüntüleme:** 5729


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-update-my-information-in-the-phonebook "How can I update my information in the Phonebook?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/telefon-rehberinde-gorunen-bilgilerimi-nasil-guncelleyebilirim "Telefon Rehberinde (Phonebook) görünen bilgilerimi nasıl güncelleyebilirim?")

# Telefon Rehberinde (Phonebook) görünen bilgilerimi nasıl güncelleyebilirim?

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

[https://phonebook.metu.edu.tr](https://phonebook.metu.edu.tr/) adresinden ulaşılan Telefon Rehberinde (Phonebook) görünen kişisel web adresinizi ve telefon numaranızı güncellemek için öncelikle kullanıcı adı ve şifrenizle sisteme giriş yapmalısınız:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/phonebook.png)

Giriş yaptıktan sonra gelen ekrandaki "Kontrol Paneli" linkine tıklayarak aşağıda görünen alanlardan kişisel web adresinizi ve telefon numaranızı girebilir ya da önceden eklenmiş bilgileriniz varsa değiştirebilirsiniz. Bilgilerin kaydedilmesi için "Güncelle" butonuna basılmalıdır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/phonebook_1.png)

Telefon Rehberinde kişisel web adresi ve telefon numarası dışındaki size ait diğer bilgiler, Personel Daire Başkanlığı yönetimindeki İnsan Kaynakları Yönetim Sisteminden (İKYS) otomatik olarak aktarılmaktadır.

Telefon Rehberi ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.