[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-ogrencisiyim-nasil-metuedutr-uzantili-kullanici-kodu-edinebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-11-2024 **Görüntüleme:** 10728


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-get-user-account-metuedutr-extension "How can I get an user account with @metu.edu.tr extension?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-ogrencisiyim-nasil-metuedutr-uzantili-kullanici-kodu-edinebilirim "ODTÜ Öğrencisiyim nasıl @metu.edu.tr uzantılı kullanıcı kodu edinebilirim?")

# ODTÜ Öğrencisiyim nasıl @metu.edu.tr uzantılı kullanıcı kodu edinebilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

ÖİDB tarafından kayıt işlemi gerçekleştirilen ve öğrenci numarası bulunan tüm öğrenciler useraccount.metu.edu.tr adresindeki Yeni Öğrenci bağlantısını kullanarak TC Kimlik veya Öğrenci numarası ile kayıtlı olduğu bölüm bilgisini seçer, beyan ettiği e-posta adresine aktivasyon linkinin bulunduğu e-posta iletilir. Linke basıldığında açılan sayfadan gerekli alanları doldurarak, kurtarma e-posta adresiniz ile ad.soyad şeklindeki e-posta adresinizi (özel öğrenciler hariç) tanımlayabilir, şifrenizi oluşturabilirsiniz.

Tüm kullanıcılar " [O](http://web.archive.org/web/20130602185425/http:/bilisim-etigi.metu.edu.tr/) [DTÜ Bilişim Kaynakları Politikalar](http://bilisim-etigi.metu.edu.tr/) [ı](http://web.archive.org/web/20130602185425/http:/bilisim-etigi.metu.edu.tr/)"na uymakla yükümlüdür.