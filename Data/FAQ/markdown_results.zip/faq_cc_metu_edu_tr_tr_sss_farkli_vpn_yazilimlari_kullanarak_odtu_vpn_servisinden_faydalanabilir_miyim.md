[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/farkli-vpn-yazilimlari-kullanarak-odtu-vpn-servisinden-faydalanabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-01-2017 **Görüntüleme:** 27513


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-use-different-vpn-softwares-use-metu-vpn-service "Can I use different VPN softwares to use METU VPN Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/farkli-vpn-yazilimlari-kullanarak-odtu-vpn-servisinden-faydalanabilir-miyim "Farklı VPN yazılımları kullanarak ODTÜ VPN servisinden faydalanabilir miyim?")

# Farklı VPN yazılımları kullanarak ODTÜ VPN servisinden faydalanabilir miyim?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

ODTÜ VPN servisinden faydalanmak için [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) adresinde yayınlanan işletim sisteminize uygun Aruba Via yazılımını kullanmanız gerekmektedir. İşletim sistemi içerisinde gömülü gelen VPN yazılımı ya da diğer üçüncü parti yazılımlar ile ODTÜ VPN bağlantısı yapılamamaktadır.