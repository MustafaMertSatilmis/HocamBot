[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/tatildeyim-mesajini-nasil-olusturabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7874


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-create-vacation-message "How can I create a vacation message?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/tatildeyim-mesajini-nasil-olusturabilirim "\"Tatildeyim\" mesajını nasıl oluşturabilirim?")

# "Tatildeyim" mesajını nasıl oluşturabilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Size gelen e-postalara cevap veremeyeceğiniz bir dönemde size e-posta gönderen kişilere otomatik olan belli bir mesajın dönmesini istiyorsanız, buna uygun bir "Tatildeyim" mesajı oluşturabilirsiniz. Bu işlem Horde arayüzü ile yapılabilir.

**Horde** e-posta arayüzünü kullanarak "Tatildeyim" mesaji hazırlamak isteyen kullanıcılarımız, Horde'un üst menüsündeki "Posta" başlığı altındaki "Süzgeçler" seçeneğinin altında "Tatil" kısmını kullanabililer. Bu sayfada hazırlamak istediğiniz mesajın konusunun ve içeriğinin ilgili alanlara girilmesi yeterlidir. Aynı menü kullanılarak bu uyarı iptal edilebilir.![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde_filter_rule_tr.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5-tatil.png)

Tatil başlangıç-bitiş tarihleri ile mesajın konusu ve içeriğini yazdıktan sonra, "Kaydet ve geçerli kıl" düğmesi ile tatil mesajınızı etkinleştirebilirsiniz.

Not: 27/07/2009 tarihinde uygulamaya geçilen e-posta sistemi ile artık sunucu sistemler üzerinde **.vacation.msg** ve **.forward** dosyaları oluşturularak tatildeyim mesajı oluşturulamamaktadır.