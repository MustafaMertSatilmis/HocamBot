[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/harcamalarimi-ve-yuklemelerimi-nasil-takip-edebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2021 **Görüntüleme:** 9251


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-see-my-cash-payments-and-loadings "How can I see my cash payments and loadings?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/harcamalarimi-ve-yuklemelerimi-nasil-takip-edebilirim "Harcamalarımı ve yüklemelerimi nasıl takip edebilirim?")

# Harcamalarımı ve yüklemelerimi nasıl takip edebilirim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

```
https://cardinfo.metu.edu.tr adresinde sisteme giriş yaptıktan sonra "Transactions/Kart Hareketleri" arayüzünde, nakit yüklemelerinizi/harcamalarınızı görebilirsiniz.
```