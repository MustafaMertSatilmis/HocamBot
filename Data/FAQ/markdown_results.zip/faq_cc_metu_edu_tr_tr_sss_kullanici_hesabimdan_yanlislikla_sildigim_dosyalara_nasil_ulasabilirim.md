[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimdan-yanlislikla-sildigim-dosyalara-nasil-ulasabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7737


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-recover-files-i-have-mistakenly-deleted-my-user-account "How can I recover the files I have mistakenly deleted from my user account?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimdan-yanlislikla-sildigim-dosyalara-nasil-ulasabilirim "Kullanıcı hesabımdan yanlışlıkla sildiğim dosyalara nasıl ulaşabilirim?")

# Kullanıcı hesabımdan yanlışlıkla sildiğim dosyalara nasıl ulaşabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

Hesabınızdan yanlışlıkla sildiğiniz dosyalara ulaşmak için [https://portal.metu.edu.tr/odtu\_bidb/yedekleme/yedekleme.xhtml](https://portal.metu.edu.tr/odtu_bidb/yedekleme/yedekleme.xhtml) adresinden karşınıza çıkan formu doldurmanız yeterli olacaktır. Sistem her gece hesabınızdaki dosyalarınızın yedeğini almaktadır. Yedekleme zamanından önce gelen ve yedekleme zamanından sonra silinmiş dosyalarınızın yedeğini alabilirsiniz.

**Not:** Yedekler en fazla 30 gün geriye yönelik olarak alınabilmektedir.