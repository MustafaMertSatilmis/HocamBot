[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/posta-kutusu-ve-dizin-goruntuleme-secenekleri-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-11-2021 **Görüntüleme:** 2883


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-are-options-displaying-mailbox "What are the options for displaying a mailbox?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/posta-kutusu-ve-dizin-goruntuleme-secenekleri-nelerdir "Posta kutusu ve dizin görüntüleme seçenekleri nelerdir?")

# Posta kutusu ve dizin görüntüleme seçenekleri nelerdir?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

Horde menüsünde bulunan seçenekler (çark işareti) altındaki Posta seçeneğiyle Posta uygulaması ayarlarına ulaşabilir, Posta Kutusu Görünümü ayarlarını değiştirebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde-secenekler.png)

_Posta Kutusu ve Dizin Görüntüleme Seçenekleri_ alt menüsü İleti sıralama, sayfa başı ileti sayısı ve iletileri sıralama kriteri gibi görüntüleme özelliklerini kişiselleştirme imkanı sunmaktadır.

Eğer e-postanıza giriş yaptığınızda yeni mesajlar yerine eski tarihli okunmamış mesajlar görüntüleniyorsa **Yeni bir posta kutusunu ilk defa açılırken, hangi sayfadan başlamak istersiniz?** kutusundan **İlk Sayfa** ayarını seçebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde-posta-secenekler.png)