[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-virusu-temizledikten-sonra-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-03-2024 **Görüntüleme:** 7277


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-after-removing-virus-my-computer "What should I do after removing the virus from my computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-virusu-temizledikten-sonra-ne-yapmaliyim "Bilgisayarımdaki virüsü temizledikten sonra ne yapmalıyım?")

# Bilgisayarımdaki virüsü temizledikten sonra ne yapmalıyım?

[Virüs](https://faq.cc.metu.edu.tr/tr/groups/virus)

IP erişiminiz BİDB tarafından kısıtlandıysa, [hotline@metu.edu.tr](mailto:hotline@metu.edu.tr) adresine e-posta atarak kısıtlanma gerekçesini öğrenebilirsiniz.

Virüsü temizledikten sonra [cc-sec@metu.edu.tr](mailto:cc-sec@metu.edu.tr) adresine e-posta atarak virüsün temizlendiğine dair bilgi verin. Böylece ağ bağlantısının açılması sağlanacaktır. Ağ bağlantısı aktif hale gelen bilgisayarın en kısa zamanda işletim sistemi güncellemelerini kontrol edin. Ayarlardan "Windows Güncelle" sekmesine giderek güncellemeleri kontrol edebilirsiniz.