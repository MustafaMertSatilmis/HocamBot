[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/virus#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Virüs

|     |
| --- |
| [Bilgisayarıma virüs bulaşması durumunda ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarima-virus-bulasmasi-durumunda-ne-yapmaliyim) |
| [Bilgisayarıma virüs bulaştığını nasıl anlayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarima-virus-bulastigini-nasil-anlayabilirim) |
| [Bilgisayarımdaki virüsü temizledikten sonra ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-virusu-temizledikten-sonra-ne-yapmaliyim) |
| [Casus yazılımlardan korunmak için neler yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/casus-yazilimlardan-korunmak-icin-neler-yapmaliyim) |
| [Linux tabanlı işletim sistemleri virüslerden etkilenir mi?](https://faq.cc.metu.edu.tr/tr/sss/linux-tabanli-isletim-sistemleri-viruslerden-etkilenir-mi) |
| [ODTÜ'de kullanılan lisanslı bir antivirüs programı var mı? Varsa nereden edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kullanilan-lisansli-bir-antivirus-programi-var-mi-varsa-nereden-edinebilirim) |
| [Spyware nedir?](https://faq.cc.metu.edu.tr/tr/sss/spyware-nedir) |
| [Virüslerden korunmak için neler yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/viruslerden-korunmak-icin-neler-yapmaliyim) |

[![Subscribe to Virüs](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/49/all/feed "Subscribe to Virüs")