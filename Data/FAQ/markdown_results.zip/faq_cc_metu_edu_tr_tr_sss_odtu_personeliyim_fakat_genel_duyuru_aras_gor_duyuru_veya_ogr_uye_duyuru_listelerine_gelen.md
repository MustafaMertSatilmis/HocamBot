[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-fakat-genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-gelen#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7662


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-metu-personnel-i-can-not-receive-messages-university-administration-sent-announcement-lists "I am a METU personnel but I can not receive the messages from university administration sent to announcement lists. What should I do? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-fakat-genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-gelen "ODTÜ personeliyim fakat \"genel-duyuru\", \"aras-gor-duyuru\" ve/ya \"ogr-uye-duyuru\" listelerine gelen mesajları göremiyorum, ne yapabilirim?")

# ODTÜ personeliyim fakat "genel-duyuru", "aras-gor-duyuru" ve/ya "ogr-uye-duyuru" listelerine gelen mesajları göremiyorum, ne yapabilirim?

[Elektronik Listeler](https://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler)

Üniversitemiz yönetimince mensuplarımız için çeşitli duyuru listeleri tanımlanmıştır. Öğrencilerin, akademik ve idari personelin kendileriyle ilgili bu listelere üyelikleri bir otomasyonla sağlanmaktadır.

Bu liste(ler)e gönderilen mesajlari daha önce görüyor ancak bir süredir göremiyorsaniz [mailman![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr](mailto:mailman<img src=) adresine ilgili listeye üyelik için kullandığınız e-posta adresinden durumu bildiren bir e-posta gönderiniz. Üyelik durumunuz incelenecek, konu hakkında size bilgi verilecektir.

Eğer ilgili listelerden şimdiye kadar hiç e-posta almadıysanız üyelik başvurusunda bulunmanız gerekmektedir. Bu konuda **" [Bir listeye üye olmak için ne yapmalıyım](https://faq.cc.metu.edu.tr/faq/what-should-i-do-subscribe-list-turkish)?"** bölümünden bilgi alabilirsiniz.