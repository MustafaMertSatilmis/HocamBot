[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kurum-ici-yazi-antetinde-bulunan-birim-iletisim-bilgilerim-hatali-gorunuyor-nasil-duzeltilebilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-01-2020 **Görüntüleme:** 6115


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kurum-ici-yazi-antetinde-bulunan-birim-iletisim-bilgilerim-hatali-gorunuyor-nasil-duzeltilebilir)

# Kurum içi yazı antetinde bulunan birim iletişim bilgilerim hatalı görünüyor, nasıl düzeltilebilir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de oluşturulan kurum içi yazılarda Grafik Tasarım Birimi tarafından hazırlanmış olan ve [http://www.metu.edu.tr/tr/gkk/antetli-kagitlar](http://www.metu.edu.tr/tr/gkk/antetli-kagitlar) adresinde listelenen antetli kağıtlar kullanılmaktadır. Örneğin Rektörlük için kullanılan antetli kağıt başlığı aşağıdaki gibidir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/icyaziantet.png)

Kurum içi yazı oluşturma sırasında Belge Önizle butonu ile görüntülediğiniz antette birim isminiz farklı görünüyorsa [http://www.metu.edu.tr/tr/gkk/antetli-kagitlar](http://www.metu.edu.tr/tr/gkk/antetli-kagitlar) adresindeki listeden biriminize ait antetli kağıt olup olmadığını kontrol ediniz. Bu adreste olmadığı halde Grafik Tasarım Birimi tarafından biriminiz için oluşturulmuş ve kullanılmakta olan antetiniz varsa, antetin EBYS'ye aktarılması için [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine bir örneğini gönderebilirsiniz.

Halihazırda biriminiz için oluşturuluş bir antet yoksa Grafik Tasarım Birimi ile iletişime geçmeniz gerekmektedir.

Kurum içi yazı antetinde birim ismi doğru görünüyor, fakat birim adres ve iletişim bilgilerinde hata varsa düzeltilmesi için [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine bildirimde bulunabilirsiniz.