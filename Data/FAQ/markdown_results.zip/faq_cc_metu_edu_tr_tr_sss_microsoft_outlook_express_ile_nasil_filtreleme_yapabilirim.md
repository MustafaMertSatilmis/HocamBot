[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-express-ile-nasil-filtreleme-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8351


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-do-i-filter-my-incoming-e-mails-microsoft-outlook-express "How do I filter my incoming e-mails with Microsoft Outlook Express?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-express-ile-nasil-filtreleme-yapabilirim "Microsoft Outlook Express ile nasıl filtreleme yapabilirim?")

# Microsoft Outlook Express ile nasıl filtreleme yapabilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Outlook Express programını kullanarak istemediğiniz e-postaların hesabınıza gelmesini engelleme olanağı sadece POP3 bağlantılarda vardır. Bu işlem için;

- **Araçlar** (Tools) \| **Mesaj Kuralları** (Message Rules) \| **Posta** (Mail) yolunu izlemelisiniz.
- Açılan pencerede hangi kısıtlara göre filtreleme yapacağınızı belirleyip **OK** düğmesine tıklamalısınız.


![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_OE_09_01.JPG)

- Daha sonra **Araçlar** (Tools) \| **Mesaj Kuralları** (Message Rules) \| **Durdurulmuş Gönderenler** (Block Senders) yolunu izlemelisiniz.
- Bu kısımda belirteceğiniz adreslerden gelen e-postalar doğrudan **Çöp Kutusu** (Trash) dizinine aktarılacaktır.


![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_OE_09_02.JPG)