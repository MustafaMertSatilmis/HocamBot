[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kullanici-adiparola-hatasi-uyarisi-alindiginda-ne-yapilmalidir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 10-05-2018 **Görüntüleme:** 7566


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kullanici-adiparola-hatasi-uyarisi-alindiginda-ne-yapilmalidir)

# EBYS’de kullanıcı adı/parola hatası uyarısı alındığında ne yapılmalıdır?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS’ye "@metu.edu.tr" uzantılı kullanıcı adı ve parolası ile giremeyen kullanıcılarımız, aynı kullanıcı kodu ve parolalarıyla başka sistemlere (METU Mail, ODTÜ Portal, METUSIS vb.) giriş yapıp yapamadığını kontrol etmelidir.

Eğer başka sistemlere giriş yapılabiliyor ancak EBYS'ye giriş yapılamıyorsa [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine durumunuzu açıklayan bir e-posta gönderebilirsiniz.

Diğer sistemlere de giriş yapılamıyorsa [http://faq.cc.metu.edu.tr/tr/sss/sifremi-nasil-degistirebilirim-yeni-sif...](http://faq.cc.metu.edu.tr/tr/sss/sifremi-nasil-degistirebilirim-yeni-sifre-secerken-nelere-dikkat-etmeliyim) adresindeki yönergeler izlenmelidir.