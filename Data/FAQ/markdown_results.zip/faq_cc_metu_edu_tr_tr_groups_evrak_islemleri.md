[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Evrak İşlemleri

|     |
| --- |
| ["Gereği Yapıldı" dediğim bir evrakı nasıl bulabilirim?](https://faq.cc.metu.edu.tr/tr/sss/geregi-yapildi-dedigim-bir-evraki-nasil-bulabilirim) |
| ["Uygundur" notlarını çıktı olarak alabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/uygundur-notlarini-cikti-olarak-alabilir-miyim) |
| [Anabilim dallarına nasıl evrak gönderirim?](https://faq.cc.metu.edu.tr/tr/sss/anabilim-dallarina-nasil-evrak-gonderirim) |
| [Bana gönderilen bir evrakı nasıl arşivleyeceğim?](https://faq.cc.metu.edu.tr/tr/sss/bana-gonderilen-bir-evraki-nasil-arsivleyecegim) |
| [Bir evrakın çıktısını nasıl alabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bir-evrakin-ciktisini-nasil-alabilirim) |
| [Bir yazı için "Cevapla" butonuna basınca yazıyı kaybettim, nereden ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bir-yazi-icin-cevapla-butonuna-basinca-yaziyi-kaybettim-nereden-ulasabilirim) |
| [Bir yazı için birden fazla ilgi seçebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/bir-yazi-icin-birden-fazla-ilgi-secebilir-miyim) |
| [Bir yazıyı İngilizce olarak hazırlamak istiyoruz, ne yapabiliriz?](https://faq.cc.metu.edu.tr/tr/sss/bir-yaziyi-ingilizce-olarak-hazirlamak-istiyoruz-ne-yapabiliriz) |
| [Birden fazla görevim/pozisyonum var, farklı görevimi/pozisyonumu kullanarak nasıl yazı oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/birden-fazla-gorevimpozisyonum-var-farkli-gorevimipozisyonumu-kullanarak-nasil-yazi) |
| [Dağıtım gruplarını nasıl tanımlayabilir ve düzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/dagitim-gruplarini-nasil-tanimlayabilir-ve-duzenleyebilirim) |
| [Dağıtım Onayı Özelliği nasıl kullanılır?](https://faq.cc.metu.edu.tr/tr/sss/dagitim-onayi-ozelligi-nasil-kullanilir) |
| [Deneme amaçlı veya yanlışlıkla oluşturduğum yazılar silinebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/deneme-amacli-veya-yanlislikla-olusturdugum-yazilar-silinebilir-mi) |
| [E-imzası olmayan bir kişiye gönderilen yazı nasıl imzalanabilir?](https://faq.cc.metu.edu.tr/tr/sss/e-imzasi-olmayan-bir-kisiye-gonderilen-yazi-nasil-imzalanabilir) |
| [EBYS'de bir evrakın son durumunu nasıl takip edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bir-evrakin-son-durumunu-nasil-takip-edebilirim) |
| [EBYS'de dilekçe yazabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-dilekce-yazabilir-miyim) |
| [EBYS'de evrak nasıl aranır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrak-nasil-aranir) |
| [EBYS'de evrakımı nasıl iptal edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrakimi-nasil-iptal-edebilirim) |
| [EBYS'de gizli evraklar nasıl hazırlanır ve gönderilir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gizli-evraklar-nasil-hazirlanir-ve-gonderilir) |
| [EBYS'de hazırladığım yazının antetinde bağlı olduğum birim ismi yanlış görünüyor, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirladigim-yazinin-antetinde-bagli-oldugum-birim-ismi-yanlis-gorunuyor-ne-yapmaliyim) |
| [EBYS'de hazırlanmış ve imzalanmış bir yazı istendiği durumda tamamen yok edilebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirlanmis-ve-imzalanmis-bir-yazi-istendigi-durumda-tamamen-yok-edilebilir-mi) |
| [EBYS'de şablon olarak kaydetmeden imzaya gönderdiğim bir yazıyı şablon olarak nasıl kaydedebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-sablon-olarak-kaydetmeden-imzaya-gonderdigim-bir-yaziyi-sablon-olarak-nasil) |
| [EBYS'de tarafıma bir evrak iletildi, ne yapmalıyım? Seçeneklerim nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarafima-bir-evrak-iletildi-ne-yapmaliyim-seceneklerim-nelerdir) |
| [EBYS'de tarama nasıl yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarama-nasil-yapilir) |
| [EBYS'de yazı şablonları nasıl oluşturulur?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sablonlari-nasil-olusturulur) |
| [EBYS'de yazı sevk edeceğim kişi/birim görünmüyor. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sevk-edecegim-kisibirim-gorunmuyor-ne-yapmaliyim) |

## Pages

- 1
- [2](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri?page=1 "Go to page 2")
- [3](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri?page=2 "Go to page 3")
- [sonraki ›](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri?page=1 "Go to next page")
- [son »](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri?page=2 "Go to last page")

[![Subscribe to Evrak İşlemleri](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/213/all/feed "Subscribe to Evrak İşlemleri")