[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-vekalet-verme-islemi-nasil-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 11407


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-vekalet-verme-islemi-nasil-yapilir)

# EBYS’de vekalet verme işlemi nasıl yapılır?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

EBYS'de vekalet vermek için:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/vekalet_0.png)

- Sağ üstte isminizin sol tarafında bulunan vekalet verme düğmesine basınız.
- Açılan bölümden "+" düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/vekalet2.png)

- Açılan bölümden vekalet türü açılır listesinden "Tam Vekalet"i seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/vekalet3_0.png)

- "Tam Vekalet"i seçmenizin ardından "Vekaleti Alan" bölümündeki "..." düğmesine basarak vekalet vermek istediğiniz kişiyi seçiniz. Ardından vekaletin başlangı ve bitiş tarihlerini giriniz.
- Yukarı kısımda bulunan "Gönder" düğmesine basarak vekalet işlemini tamamlayınız.

Not: Tam Vekalet dışındaki seçenekler henüz kullanılmamaktadır.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.