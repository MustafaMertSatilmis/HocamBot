[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesap-yonetimi-sayfasindan-neler-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8732


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-can-i-do-metu-user-account-management-page "What can I do from METU User Account Management page?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesap-yonetimi-sayfasindan-neler-yapabilirim "ODTÜ Kullanıcı Hesap Yönetimi sayfasından neler yapabilirim?")

# ODTÜ Kullanıcı Hesap Yönetimi sayfasından neler yapabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

ODTÜ Kullanıcı Hesap Yönetimi sayfasından ( [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/index.php?lang=TR)) kullanıcı hesabınızın şifresini değiştirebilir, şifrenizi unuttuğunuzda yeni şifrenizin ulaştırılacağı kurtarma e-posta adresinizi belirleyebilirsiniz.

Ayrıca ODTÜ'yü kazanmış yeni öğrencilerimizin kullanıcı kodu ve şifre gerektiren sistemlere giriş yapmadan önce, bu siteden geçici şifrelerini girerek, kalıcı şifrelerini ve kurtarma e-posta adreslerini belirlemeleri ve ODTÜ e-posta adreslerini seçmeleri gerekmektedir.