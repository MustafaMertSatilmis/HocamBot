[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmeti-kullanim-politikasi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-10-2018 **Görüntüleme:** 49539


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/metu-vpn-service-use-policy "METU VPN Service Use Policy")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmeti-kullanim-politikasi "ODTÜ VPN Hizmeti Kullanım Politikası")

# ODTÜ VPN Hizmeti Kullanım Politikası

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

**ODTÜ VPN Hizmeti Kullanım Politikası**

**ODTÜ VPN Hizmetinin Amacı**

             ODTÜ VPN hizmeti ile, mensup ve öğrencilerimizin, sahip oldukları kişisel bilgisayarlar ya da mobil cihazlar yardımıyla, yerleşke dışında bulundukları sürelerde de ODTÜ yerleşke IP bloğuna (144.122.0.0/16) izinli olan ağ servislerine erişme imkanı bulmaları amaçlanmaktadır.

**ODTÜ VPN Kullanım Kuralları**

1\. ODTÜ öğrenci ve mensupları için tahsis edilen VPN hizmeti [http://www.metu.edu.tr/tr/bilisim-etigi](http://www.metu.edu.tr/tr/bilisim-etigi) adresinde tam metni bulunan "ODTÜ Bilişim Kaynakları Kullanım Politikaları" çerçevesinde kullanılmalıdır.

2\. Üniversitenin bilgisayar ağı yatırımları, devlet tarafından belirlenen kaynaklar kullanılarak akademik, idari, eğitim ve araştırma birincil amaçlarına hizmet etmek üzere yapılmaktadır. VPN hizmeti üzerinden kişisel kullanımlar hiçbir zaman diğer kullanıcıların birincil ağ erişim gereksinimlerini (akademik, idari, eğitim, araştırma) yerine getirmelerine engel olmamalıdır.

3\. VPN kaynaklarının kullanımında uyulması gereken kurallar ve yasaklanmış faaliyetler genel olarak şöyledir:

3.1. Peer-to-peer (P2P - noktadan noktaya) dosya paylaşım programlarının (μTorrent, BitTorrent, BearShare vb.) kullanılması yasaktır. VPN kullanıcısı bu uygulamaları sisteme bağlanmadan önce kapatmalıdır. Bu tür uygulamaların otomatik açılmasına izin vermemelidir.

3.2. VPN hizmetinin şahsi kazanç ve kar amacı ile kullanılması yasaktır.

3.3. VPN hizmeti kullanılarak, kütlesel e-posta gönderilmesi (mass mailing, mail bombing, spam) ve üçüncü şahısların göndermesine olanak sağlanması yasaktır. VPN kullanıcısı sisteme bağlanmadan önce virüs taraması yapmalıdır.

3.4. Ağ güvenliğini tehdit edici faaliyetlerde bulunmak (DoS saldırısı, port-network taraması vb.) yasaktır.

3.5. VPN hizmetinden faydalanan her kullanıcı, üniversite tarafından kendisine tahsis edilen kaynakların kullanımından, güvenliğinden ve bu kaynakların bilinçli veya bilinçsiz olarak üçüncü kişilere kullandırılması durumunda ortaya çıkabilecek yasaklanmış faaliyetlerden birinci derecede sorumludur.

4\. Yukarıda belirtilen kurallara uyulmadığının tespiti durumunda aşağıdaki cezalardan bir ya da birkaçı uygulanabilir;

4.1. VPN servisine erişiminin sonlandırılması,

4.2. Sunucu sistemleri üzerindeki merkezi kullanıcı kodunun kapatılması veya şifresinin değiştirilmesi,

4.3. Üniversite bünyesindeki soruşturma mekanizmalarının harekete geçirilmesi,

4.4. Adli yargı mekanizmalarının harekete geçirilmesi.

5\. Kurallara uymadığı tespit edilen kullanıcıya yazılı olarak çevrimiçi bildirim yapılır. Kendisine bildirim ulaşmayan kullanıcı BİDB-Bilişim Destek Ekibi ( [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)) aracılığı ile bilgi alabilir

6\. Bu kurallar yayınlandığı tarihten itibaren geçerlidir. Gerekli görüldüğü durumlarda metin üzerinde değişiklik yapılabilir. Kuralların güncel sürümüne aynı web adresi üzerinden erişilebilir.

**ODTÜ VPN Hizmet Koşulları**

1\. ODTÜ VPN hizmetinden, tüm mensup ve öğrencilerimiz “ODTÜ VPN Kullanım kuralları” çerçevesinde faydalanabilecektir.

2\. ODTÜ VPN Hizmeti, arıza durumu hariç 7x24 esasında çalışacaktır.

3\. Arıza durumunda;

3.1. Mesai saatleri içerisinde oluşan arızalara, mümkün olan en kısa sürede müdahale edecektir.

3.2. Mesai saati dışında oluşan problemler acil statüsünde değerlendirilmeyecek olup, takip eden ilk iş gününde soruna müdahale edilecektir.

3.3. Donanım arızası oluşan durumlarda servisin tekrar çalışma süresi uzayabilecektir.

4\. VPN hizmetinde yaşanacak uzun süreli kesintiler web üzerinden yayınlanacaktır.

5\. VPN servisinde her kullanıcı için 8 Mbps hız kapasitesi sağlanacaktır.

6\. VPN servisi süresince kullanıcılarımızın günde bir defa tekrar oturum başlatması gerekmektedir. Yani, kullanıcı oturum açtıktan 24 saat sonra VPN bağlantısı otomatik olarak kesilecek olup, bağlantının tekrar kurulması için kullanıcının tekrar oturum açması gerekmektedir.

**YASAL SORUMLULUK REDDİ:**

1\. ODTÜ Bilgi İşlem Dairesi ODTÜ VPN hizmeti kullanımından doğacak riskler konusunda sorumluluk kabul etmez. Bütün sorumluluk kullanıcıya aittir.

2\. Teknik aksaklıklar nedeniyle VPN bağlantısının kurulamaması ya da VPN bağlantısının kopması durumunda kullanıcının yaşayacağı kayıplardan ODTÜ Bilgi İşlem Dairesi sorumlu değildir.

3\. ODTÜ Bilgi İşlem Dairesi, önceden haber vermeden bazı ağ hizmetlerine ve web sayfalarına VPN üzerinden erişimi geçici veya kalıcı olarak kısıtlar.

* * *

_**Son Güncelleme:** 28/03/2016 - 16:30_