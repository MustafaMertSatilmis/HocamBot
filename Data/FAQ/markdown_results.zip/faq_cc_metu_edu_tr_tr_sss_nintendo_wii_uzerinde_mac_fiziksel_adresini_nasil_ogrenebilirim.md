[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/nintendo-wii-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 6803


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-nintendo-wii "How can I find out the MAC (physical) address on a Nintendo Wii?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/nintendo-wii-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim "Nintendo Wii üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Nintendo Wii üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

1. Kanal menüsünden ‘Wii Ayarları’nı seçin. (Ekranın alt-sol kısmında kalan üzerinde ‘Wii’ yazan yuvarlak düğme)
2. ‘Internet’i seçin.
3. ‘Konsol Ayarları’nı seçin.
4. Wii konsoluna ait MAC adresi ilk satırda gösterilmektedir.