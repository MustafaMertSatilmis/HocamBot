[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/odtu-harita-servisi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# ODTÜ Harita Servisi

|     |
| --- |
| [ODTÜ’de yer alan bir bina ya da dersliğin yerini nasıl bulabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-yer-alan-bir-bina-ya-da-dersligin-yerini-nasil-bulabilirim) |

[![Subscribe to ODTÜ Harita Servisi](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/171/all/feed "Subscribe to ODTÜ Harita Servisi")