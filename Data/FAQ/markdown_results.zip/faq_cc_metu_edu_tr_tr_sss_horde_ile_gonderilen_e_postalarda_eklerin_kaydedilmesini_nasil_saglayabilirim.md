[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-gonderilen-e-postalarda-eklerin-kaydedilmesini-nasil-saglayabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 15-04-2020 **Görüntüleme:** 6965


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-save-e-mail-attachments-horde "How can I save e-mail attachments with Horde?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-gonderilen-e-postalarda-eklerin-kaydedilmesini-nasil-saglayabilirim "Horde ile gönderilen e-postalarda eklerin kaydedilmesini nasıl sağlayabilirim?")

# Horde ile gönderilen e-postalarda eklerin kaydedilmesini nasıl sağlayabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

Horde web e-posta uygulamasında gönderilen e-posta ekleri öntanımlı değer olarak e-posta mesajı ile birlikte kaydedilmemektedir. E-posta eklerinin kaydedilmesi için

- e-posta yazma penceresinde Dosya Ekle / Add Attachment yazısı yanındaki ok işaretine tıklayarak "Save Attachments in Sent Mailbox" seçeneğini işaretlemeniz gerekmektedir. Bu işlem sadece göndermekte olduğunuz e-posta için geçerlidir.

![](https://faq.cc.metu.edu.tr/system/files/u2/horde-compose-save-tr.png)

- Göndereceğiniz tüm e-postaların eklerinin kaydedilmesi için

Horde'ye giriş yaptıktan sonra üst menüdeki çark işaretinden Seçenekler --> Posta --> Gönderilmiş E-posta --> "Save attachments in the sent-mail message?" ayarını Save Attachments olarak seçipkaydet derseniz bundan sonra göndereceğiniz e-postaların ekleri de kaydedilecektir.

![](https://faq.cc.metu.edu.tr/system/files/u2/horde-save-pref-tr.png)

![](https://faq.cc.metu.edu.tr/system/files/u2/horde-save-tr.png)