[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-ile-ilgili-soru-veya-sorunlarimi-nereye-iletebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6596


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/where-can-i-direct-my-questions-and-problems-regarding-metu-survey-service "Where can I direct my questions and problems regarding METU Survey Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-ile-ilgili-soru-veya-sorunlarimi-nereye-iletebilirim "ODTÜ anket servisi ile ilgili soru veya sorunlarımı nereye iletebilirim?")

# ODTÜ anket servisi ile ilgili soru veya sorunlarımı nereye iletebilirim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

ODTÜ Anket Servisi ile ilgili sorularınızı, yorumlarınızı ve önerilerinizi wwwsurvymetu.edu.tr adresine e-posta ile gönderebilirsiniz.