[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-10-2020 **Görüntüleme:** 36032


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-problems-vpn-services-what-can-i-do "I have problems with VPN services, what can I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-ne-yapmaliyim "VPN Hizmeti ile ilgili sorun yaşıyorum. Ne yapmalıyım?")

# VPN Hizmeti ile ilgili sorun yaşıyorum. Ne yapmalıyım?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

Kurulum sırasında hata alıyorsanız öncelikle [https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiy...](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiyorum-ne-yapmaliyim) adresini inceleyiniz.

VPN hizmeti ile ilgili yaşadığınız sorun ile ilgili lütfen aşağıdaki ayarları kontrol ediniz.

Kurmuş olduğunuz Aruba VIA yazılımını çalıştırmak istediğinizde "... çalışmayı durdurdu" şeklinde bir Windows hata mesajı alıyorsanız, uygulama kurulumu doğru yapılmamış veya Windows işletim sistemi ile ilgili farklı bir sorun bulunuyor olabilir. Bu konuda işletim sistemi konusunda yetkin bir kişi eşliğinde [bu bağlantıdaki](https://www.google.com.tr/search?q=%22%C3%A7al%C4%B1%C5%9Fmay%C4%B1+durdurdu%22) işlemleri inceleyebilirsiniz.

Aruba VIA yazılımı penceresinde yazan sürüm ile [https://netregister.metu.edu.tr/](https://netregister.metu.edu.tr/) adresinden indirilen VPN yazılımlarının sürümünün aynı olduğundan emin olunuz. Kullanmakta olduğunuz sürüm güncellenmiş olabilir. Yeni sürümü indirdikten sonra [http://faq.cc.metu.edu.tr/groups/vpn-service](http://faq.cc.metu.edu.tr/groups/vpn-service) adresinden işletim sisteminize uygun sıkça sorulan sorulara bakarak kurulum ayarlarını yapabilirsiniz.

VPN Servisine bağlanırken her seferinde kullanıcı adı ve şifre bilgilerinin girilmesi gerekmektedir. Eğer, cihazınızla VPN Servisine bağlanırken kullanıcı adı ve şifrenizi artık sormuyorsa, cihazınızdan bağlantı profili bilgilerini kaldırmanız gerekmektedir. Bunun için ilgili VPN istemcisinden profil bilgilerini temizleyebilir ve ya uygulamayı tekrar kurabilirsiniz.

Bağlantı sağlamaya çalıştığınız kurum ya da şirket VPN uygulamasının erişmeye çalıştığı portları kısıtlamış olabilir. VPN uygulaması 443 ve 4500 portları üzerinden iletişim kurmaktadır. (MAC OS için kullanılan portlar UDP:  500, 1701, 4500 TCP: 1723, 443, IP protocol: 50 şeklindedir.) İlgili kurumun ya da şirketin bilgi işlem birimleri ile iletişime geçerek bu portların kısıtlanmadığından lütfen emin olunuz. (Ekim 2018 itibariyle Turknet, Vodafone Internet Servis Sağlayıcılardan ODTÜ VPN hizmetine erişim sıkıntıları bildirilmektedir. Turknet ile kurulan iletişimde sorununun ortak kullanılan IP adresi nedeniyle yaşandığını, ek ücret vererek statik IP adresi kullanması durumunda sorununun çözüleceği belirtilmiştir. Statik IP adresi kullanmaya başlayan bir kullanıcımız ile yapılan denemelerde VPN Hizmetini sorunsuz kullanabildiği gözlemlenmiştir.)

Bilgisayarınızda yüklü antivirüs, firewall vb bir uygulamanın VPN bağlantılarını engelleyebilir. Hem bilgisayarınızda kurulu bu gibi uygulamaları hem de VPN uygulamasını kaldırmanızı ve sistemi yeniden başlattıktan sonra VPN uygulamasını tekrar kurmanızı öneriyoruz. Bağlantı sağlamanız halinde kaldırdığınız antivirüs uygulamasını tekrar kurabilirsiniz.

Yaptığımız testler sırasında Windows 10 64 bit işletim sisteminde Symantec Endpoint Protection yazılımı kurulu iken VPN uygulamasının kurulması ve çalıştırılması sırasında bağlantı sağlanamadığı (real-time protection kapatılsa bile) tespit edilmiştir. Symantec ve ArubaVPN uygulamaları kaldırıldıktan sonra yeniden ArubaVPN uygulaması kurulduğunda VPN bağlantısı sağlanabilmiştir.

Ağ kartları arasında Aruba Via driver görünmediği durumlarda VPN uygulaması çalışmayabilir. Böyle bir durumda Lütfen Aruba Via yazılımını kaldırıp yeniden yükleyiniz.

Aygıt yöneticisinden Aruba Via Driver'ının düzgün kurulup kurulmadığını kontrol ediniz.

VPN hizmeti sadece [https://netregister.metu.edu.tr/](https://netregister.metu.edu.tr/) adresinden uyumlu işletim sistemlerini destekleyen uygulama ile çalışmaktadır. İşletim sisteminin içinde kurulu olan ya da indirilen diğer VPN uygulamaları ile protokol farklarından dolayı çalışmamaktadır. Sizin işletim sisteminize uyumlu bir Aruba VIA (VPN) programı yoksa uyumlu sürüm sunulana kadar destekleyen başka cihazlar üzerinden bağlanıp hizmeti kullanabilirsiniz.

Yukardaki adımlardan sonra hala bağlantı sağlayamıyorsanız lütfen aşağıdaki bilgileri [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletiniz.

Kullanıcı adı:

İşletim Sistemi ve Cihaz Tipi(PC, Tablet, Telefon vb.):

Diagnostics tabının ekran görüntüsü:

Diagnostics tabındaki Connection Log ekranının görüntüsü:

Connection Details Tabında Error metni çıkmışsa ekran görüntüsü:

Connection Details Tabındaki send logs butonu ile oluşan log

Bağlanmaya çalıştığınız tarih/saat bilgisi