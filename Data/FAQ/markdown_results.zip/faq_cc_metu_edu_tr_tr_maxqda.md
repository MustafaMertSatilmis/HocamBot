[Jump to navigation](https://faq.cc.metu.edu.tr/tr/maxqda#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 27-02-2024 **Görüntüleme:** 22703


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/maxqda "MAXQDA")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/maxqda "MAXQDA")

# MAXQDA

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MAXQDA** **24** **—**

_**MAXQDA** akademik ve bilimsel kurumlarda bilgisayar destekli nitel ve karma yöntemler veri, metin ve multimedya analizi için tasarlanmış bir yazılım programıdır._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/maxqda#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/maxqda#aktivasyon)

[**_HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER_**](https://faq.cc.metu.edu.tr/tr/maxqda#hata)

* * *

**_\[1\] Not:_**_Merkezi lisans sunucusu eski MAXQDA versiyonlarını desteklemediğinden yazılımın 64-bit sistem ve 2024 versiyonunun kullanılması gerekmektedir._

**_\[2\] Not:_** _Yazılımın kampüs dışından kullanılabilmesi için öncelikle VPN ile kampüs ağına bağlanılması gerekmektedir. VPN konusunda ayrıntılı bilgiye [https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) sayfasından ulaşılabilir._

**_Download link for Windows:_** _[https://www.maxqda.de/updates/24/MAXQDA24\_Setup.msi](https://www.maxqda.de/updates/24/MAXQDA24_Setup.msi)_

**_Download link for macOS:_** _[https://www.maxqda.de/updates/24/MAXQDA24.dmg](https://www.maxqda.de/updates/24/MAXQDA24.dmg)_

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step1.png)

**_ADIM-2_**

**_“Install”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step2.png)

**_ADIM-3_**

**_“Finish”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step3.png)

**_ADIM-4_**

**_“I accept the terms in the License Agreement_** **_”_** _seçeneğini işaretleyiniz ve **“** **Continue**_ **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step4.png)

**_ADIM-5_**

**_“Continue”_**_butonuna tıklayarak ilerleyiniz._

**_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step5.png)_**

**_ADIM-6 **_<<<AKTİVASYON>>>_**_**

**_“Connect to your institution's network license"_**_butonuna_ _tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step6.png)

**_ADIM-7_**

_Server address altındaki alana **“maxqda.cc.metu.edu.tr”**ve port altındaki alana **“21990”**(otomatik olarak gelmemiş ise)  yazdıktan sonra **“Search for licenses automatically”**seçeneğini işaretleyerek **“Refresh”**butonuna basınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step7.png)

**_ADIM-8_**

_Lisans adı olarak listelenen **“METUMAXQDA”**üzerine tıklayarak seçiniz ve **“Connect”**butonuna basınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step8.png)

**_ADIM-9_**

_Lisans işlemi başarılı ise aşağıdaki uyarı ekranı karşınıza çıkacaktır. Artık yazılımı kullanabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/maxqda_2024_step9.png)

**_HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER_**

|     |     |     |
| --- | --- | --- |
| **Hata Kodu** | **Açıklama** | **Önerilen Çözüm** |
| 102x3 | No license with the entered license name has been found in the MAXQDA Netlic Service. | Lisans adını kontrol ediniz, yazım hataları olabilir.<br>Olması gereken: "METUMAXQDA" |
| 102x7 | The client is currently using the license in another instance of MAXQDA. A license can only be used in one MAXQDA instance on the same device. | Daha önce açılan MAXQDA örneğini kullanın veya lisansı yeni MAXQDA örneğinde kullanmak için kapatın.<br>Uygulamayı yeniden başlatın. |
| 102x8 | The requested license is not activated or invalid. | İstenen lisansın etkinleştirilmediğini veya süresinin dolup dolmadığını kontrol edin. Gerekirse, lisansı MAXQDA Netlic Service'ten kaldırın. |
| 102x9 | The requested license does not match this version of MAXQDA. | Lütfen MAXQDA'nın bu sürümünde kullanılmak üzere hangi lisansın yapılandırıldığını kontrol edin.<br>Olması gereken: "MAXQDA 2022" |
| 102x10 | The client device is not on the whitelist or cannot be added automatically and therefore does not have permission to use the license. | Girilen adın doğru olup olmadığını kontrol edin. |
| 102x11 | The client device is listed on the blacklist and is therefore excluded from use of the license. | Kampus dışı erişim için VPN kullanın. |
| 102x12 | The maximum number of simultaneously connected clients has been reached for the requested license. | Şu anda bağlı olan bir istemci MAXQDA ile çalışmayı bıraktığında yeni bir alan kullanılabilir. |
| 104x15 | A connection to the MAXQDA Netlic Service could not be established or was disconnected. | Lütfen ağ bağlantınızı ve belirtilen sunucu adresini ve portunu kontrol edin. |

* * *

**_Bize_ _ulaşın_ _:_**[**https://bilisimdestek.metu.edu.tr/**](https://bilisimdestek.metu.edu.tr/)

* * *