[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5448


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim)

# Horde bir iletinin tam başlık bilgisini nasıl görebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Bir iletinin tam başlık bilgisini nasıl görebilirim?

İletinin başlık bilgisini görmek için iletiyi görüntülerken + işareti (Diğer seçenekler) altındaki Kaynağı Görüntüle bağlantısını kullanabilirsiniz.