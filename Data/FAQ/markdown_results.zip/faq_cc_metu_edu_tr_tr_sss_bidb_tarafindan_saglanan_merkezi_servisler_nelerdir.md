[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-saglanan-merkezi-servisler-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-04-2017 **Görüntüleme:** 6779


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-saglanan-merkezi-servisler-nelerdir)

# BİDB Tarafından Sağlanan Merkezi Servisler Nelerdir?

[BİDB hakkında](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda)

**BİDB TARAFINDAN SAĞLANAN MERKEZİ SERVİSLER NELERDİR?**

_**Yerleşke Kablolu Ağ Bağlantısı**_

Yerleşke kablolu ağ altyapısının tasarlanması, oluşturulması, işletilmesi ve geliştirilmesidir

_**Yerleşke Kablosuz Ağ Bağlantısı**_

Yerleşke kablosuz ağ altyapısının tasarlanması, oluşturulması, işletilmesi ve geliştirilmesidir.

_**Eduroam**_

Eduroam üyesi kurumların kullanıcılarının diğer eğitim kurumlarında da sorunsuzca ağ kullanımını amaçlamaktadır.

_**Kullanıcı kodları**_

ODTÜ personel ve öğrencilerine ODTÜ bilişim hizmetlerinden faydalanabilmeleri için kullanıcı kodları sağlanmaktadır.

_**Danışmanlık Servisi / Hotline**_

ODTÜ bilişim hizmetleri kullanıcılarına hizmetlere ilişkin destek hizmeti sağlanmasıdır.

**_PC Salonları_**

Üniversitede kullanıcı kodu bulunan tüm kullanıcıların ödev, ders ve akademik amaçlı araştırma yapmaları amacıyla hizmete sunulmaktadır.

_**İnsan Bilgisayar Etkileşimi (İBE) Araştırma ve Uygulama Laboratuvarı**_

Akademik çalışmalar için ortam sağlayan, verimli ara yüzlerin geliştirilmesine destek veren, erişilebilirlik ve kullanılabilirlik çalışmalarının yapıldığı servistir.

_**Bilgi Güvenliği**_

Bilişim sistemlerinin zafiyetlerinin belirlenerek, sorumlularına raporlanması.

_**Akıllı Kimlik Kartı ve RFID Teknik Altyapısı**_

ODTÜ kampüsü içerisinde para harcama ve kapı giriş-çıkış yetkilendirmesi için kullanılan kartlı sistemdir.

_**Merkezi Sunucu Sistemler**_

Kullanıcı kodları ve yardımcı hizmetlerinin merkezi sunucular üzerinde tanımlanmasıdır.

_**E-posta Servisi**_

İnternet üzerinden elektronik haberleşme hizmetidir.

_**Web Sayfaları**_

Birim, topluluk ve etkinlik organizasyonlarına yönelik web sayfası oluşturulabilmesi amacıyla, kullanıcı kodlarının açılarak alan adının tanımlanması hizmetidir.

_**Elektronik Listeler**_

Haberleşme listelerinin bakımını yürüten, liste üye ve yöneticilerine kullanım ve bilgi desteği sunan servistir.

_**Blog Servisi**_

ODTÜ kullanıcıları için web günlüğü tutma servisidir.

_**Merkezi İçerik Yönetim Sistemi (MİYS)**_

ODTÜ Kurumsal kimlik çalışmaları çerçevesinde, kurumsal kimlikle uyumlu web sayfaları oluşturulması amacıyla çok kullanıcılı Drupal altyapısında sunulan web kullanıcı servisidir.

_**Merkezi Lisanslı Yazılımlar**_

ODTÜ genelinde kullanılmak üzere lisanslı yazılımların alımları ile ilgili ön çalışmalar yapılması, kullanıma sunulması, sürekliliğinin sağlanması, destek verilmesi.

_**Dosya Paylaşım Hizmeti FTP Servisi**_

Kullanıcılarımızın açık kaynak kodlu bazı yazılımlara indirmelerini sağlayan sistemdir.

_**Web Tabanlı Sistemler (METU-SIS, ODTÜ Class, Portal, EDYS, Anket…)**_

Personel, Öğrenci ve Akademik kullanıcıların katılımcı teknikler ile belge ya da benzeri içeriklerin yaratılmasına ve düzenlenmesine yardımcı olan yazılım servisidir.