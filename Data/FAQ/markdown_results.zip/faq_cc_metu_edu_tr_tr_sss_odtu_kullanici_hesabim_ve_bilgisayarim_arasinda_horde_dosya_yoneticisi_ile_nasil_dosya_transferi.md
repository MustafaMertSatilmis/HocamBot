[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-horde-dosya-yoneticisi-ile-nasil-dosya-transferi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-11-2023 **Görüntüleme:** 9476


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-transfer-files-and-folders-between-my-metu-user-account-and-my-computer-using-horde "How can I transfer files and folders between my METU user account and my computer by using Horde File Manager?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-horde-dosya-yoneticisi-ile-nasil-dosya-transferi "ODTÜ kullanıcı hesabım ve bilgisayarım arasında Horde dosya yöneticisi ile nasıl dosya transferi yapabilirim?")

# ODTÜ kullanıcı hesabım ve bilgisayarım arasında Horde dosya yöneticisi ile nasıl dosya transferi yapabilirim?

[Dosya Transferi](https://faq.cc.metu.edu.tr/tr/groups/dosya-transferi)

Horde Dosya Yöneticisi'ni kullanarak merkezi sunucu sistemler ile kişisel bilgisayarınız arasında dosya transferi yapmak mümkündür. Bu işlem için Horde'a giriş yapıldıktan sonra, üst menüden "Diğerleri" başlığı altındaki "Dosya Yöneticisi" ve "METU" seçilmelidir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/screenshot_from_2018-04-17_10-42-39.png)

Merkezi sunucu sistemlerde duran bir dosyayı kişisel bilgisayarınıza indirmek için ![](https://faq.cc.metu.edu.tr/tr/system/files/u2/download.png) ikonuna tıklamak yeterlidir.

Kişisel bilgisayarınızdaki bir dosyayı merkezi sunucu sistemlere yüklemek için ise sayfanın altındaki bölüm kullanılarak önce "Browse" butonu kullanılarak kişisel bilgisayarınızdaki dosya seçildikten sonra, "Dosya Yükleme" butonuna basılmalıdır.