[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurt-odalari-bilgisayar-agi-kullanim-kurallari-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 13232


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-are-dormitory-rooms-network-rules-and-regulations-use "What are the Dormitory Rooms Network Rules and Regulations of Use?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurt-odalari-bilgisayar-agi-kullanim-kurallari-nelerdir "ODTÜ Yurt Odaları Bilgisayar Ağı Kullanım Kuralları nelerdir?")

# ODTÜ Yurt Odaları Bilgisayar Ağı Kullanım Kuralları nelerdir?

[ODTÜKENT/Yurtlar/Lojmanlar](https://faq.cc.metu.edu.tr/tr/groups/odtukentyurtlarlojmanlar)

1\. Yurt odalarında öğrencilerin kişisel bilgisayarları için tahsis edilen ağ kaynakları (ağ bağlantısı, kullanıcı kodu, IP-MAC adresi ikilisi, kampüs içi/dışı erişimi vb.) ["http://bilisim-etigi.metu.edu.tr"](http://bilisim-etigi.metu.edu.tr/) adresinde tam metni bulunan **"ODTÜ Bilgi İşlem ve Bilgisayar Ağı Kaynakları Kullanım Etiği"** çerçevesinde kullanılmalıdır.

2\. Üniversitenin bilgisayar ağı yatırımları, devlet tarafından belirlenen kaynaklar kullanılarak akademik, idari, eğitim ve araştırma birincil amaçlarına hizmet etmek üzere yapılmıştır. Ağ üzerindeki kişisel kullanımlar hiçbir zaman diğer kullanıcıların birincil ağ erişim gereksinimlerini (akademik, idari, eğitim, araştırma) yerine getirmelerine engel olmamalıdır. Bu doğrultuda ağ kaynaklarının kullanımında **uyulması gereken kurallar ve yasaklanmış faaliyetler** aşağıda belirtilmiştir:

- _KaZaA, iMesh, eDonkey2000, Gnutella, Napster, Aimster, Madster, FastTrack, Audiogalaxy, MFTP, eMule, Overnet, NeoModus, Direct Connect, Acquisition, BearShare, Gnucleus , GTK-Gnutella, LimeWire, Mactella, Morpheus, Phex, Qtella, Shareaza, XoLoX, OpenNap, WinMX, DC++, BitTorrent vs.._

a. "Peer-to-peer (P2P - noktadan noktaya)" dosya paylaşım programları, telif hakları ve lisansları ihlal etmenin yanı sıra, yüksek bant genişliği tüketerek birincil amaçlar için ağ kullanımına kaynak bırakmamaktadır. Bu nedenle, aşağıda sıralanan fakat bunlarla sınırlı olmayan tüm **"peer-to-peer" dosya paylaşım araçlarının kullanılması** yasaktır.

b. **Ağ kaynaklarının şahsi kazanç ve kar amacı ile kullanılması** yasaktır.

c. Ağ kaynakları kullanılarak, **kütlesel e-posta gönderilmesi** (mass mailing, mail bombing, spam) ve **üçüncü şahısların göndermesine olanak sağlanması** yasaktır.

d. Yurt odalarında, **servis veren** (web hosting servisi, e-posta servisi vb.) **sunucu nitelikli bilgisayar bulundurulması** yasaktır.

e. Üniversite ağ kaynaklarının **üniversite dışından kullanılmasına sebep olabilecek ya da üniversite dışındaki kişi ya da bilgisayarların kendilerini üniversite içindeymiş gibi tanıtmalarını sağlayacak her tür faaliyet** (proxy, relay, IP sharer, NAT vb.) yasaktır.

f. **Ağ güvenliğini tehdit edici faaliyetlerde bulunmak** (DoS saldırısı, port-network taraması vb.) yasaktır.

g. Bilgisayarın ağ arabiriminin donanım adresinin (MAC addresi) **değiştirilmesi veya değiştirilmeye çalışılması yasaktır**. Ağa bağlı bilgisayarın IP ayarları ise, MAC adreslerini kayıt edildiği sayfada verilen talimatlara uygun olmalıdır.

h. Yurt odasında, adına kayıtlı bilgisayar bulunan her öğrenci, üniversite tarafından **kendisine tahsis edilen kaynakların**(ağ bağlantısı, kullanıcı kodu, IP-MAC adresi ikilisi, kampüs içi/dışı erişimi vb.) **kullanımından, güvenliğinden** ve bu kaynakların bilinçli ya da bilinçsiz olarak üçüncü kişilere kullandırılması durumunda ortaya çıkabilecek **yasaklanmış faaliyetlerden birinci derecede sorumludur**.

3\. Yukarıda belirtilen kurallara uyulmadığının tesbiti durumunda aşağıdaki **cezalar** dan bir ya da birkaçı uygulanabilir;

- Kampus içi ve/veya kampus dışı ağ erişiminin sınırlandırılması,
- Kampus içi ve/veya kampus dışı ağ erişiminin kapatilmasi,
- Sunucu sistemler üzerindeki kullanıcı kodunun kapatılması,
- Üniversite bünyesindeki soruşturma mekanizmalarının harekete geçirilmesi,
- Adli yargı mekanizmalarının harekete geçirilmesi.

4\. Kurallara uymadığı tesbit edilen öğrencilere Yurt Müdürlüğü aracılığı ile bildirim yapılır.

5\. Bu kurallar yayınlandığı tarihten itibaren geçerlidir. Gerekli görüldüğü durumlarda metin üzerinde değişiklik yapılabilir. Kuralların güncel sürümüne bu sayfadan erişilebilir.

6. Soru ve sorunlarınız için Bilişim Destek Ekibimize ODTÜ BİDB ana sayfasındaki “Bize Ulaşın” bağlantısından ve [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresinden ulaşabilirsiniz.

Belgeyi indirmek için [tıklayınız](https://faq.cc.metu.edu.tr/tr/system/files/u2/yurt_misafirkullanici.pdf).