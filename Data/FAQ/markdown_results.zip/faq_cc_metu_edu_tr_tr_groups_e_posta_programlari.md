[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# E-posta Programları

|     |
| --- |
| [Microsoft Outlook ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-ile-odtu-e-posta-servisini-nasil-kullanabilirim) |
| [Android yüklü cihazımla ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-yuklu-cihazimla-odtu-e-posta-servisini-nasil-kullanabilirim) |
| [Apple Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/apple-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim) |
| [Gmail hesabıma ODTÜ e-posta adresimi nasıl eklerim?](https://faq.cc.metu.edu.tr/tr/sss/gmail-hesabima-odtu-e-posta-adresimi-nasil-eklerim) |
| [iPhone ya da iPad ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-e-posta-servisini-nasil-kullanabilirim) |
| [Mozilla Thunderbird ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mozilla-thunderbird-ile-odtu-e-posta-servisini-nasil-kullanabilirim) |
| [POP3 ve IMAP arasında ne fark vardır?](https://faq.cc.metu.edu.tr/tr/sss/pop3-ve-imap-arasinda-ne-fark-vardir) |
| [Windows Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim) |
| [Windows Mail’i IMAP ile ODTÜ e-posta adresime nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-maili-imap-ile-odtu-e-posta-adresime-nasil-baglanabilirim) |

[![Subscribe to E-posta Programları](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/65/all/feed "Subscribe to E-posta Programları")