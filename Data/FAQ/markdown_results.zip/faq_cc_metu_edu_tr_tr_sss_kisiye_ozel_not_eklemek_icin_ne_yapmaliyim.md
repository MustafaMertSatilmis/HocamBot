[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kisiye-ozel-not-eklemek-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4610


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kisiye-ozel-not-eklemek-icin-ne-yapmaliyim)

# Kişiye özel not eklemek için ne yapmalıyım?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

1. Evrak üzerinde bulunan "Notlar" düğmesine tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/1_1.png)

2. "Yeni Not" düğmesini tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/2_0.png)

3. "Herkes görebilir" onay kutusundan tiki kaldırınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/3.png)

4. "Kullanıcılar ve Roller" kısmındaki "..." düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/4_0.png)

5. Açılan bölümden "Tür" listesini tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/5_0.png)

6. "Tür" listesinden "Kullanıcı Rolü"nü seçiniz ve "ID" bölümündeki "..." düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/6_0.png)

7. Açılan bölümden kişiyi aratarak bulup seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/7_0.png)

8. "Ekle" düğmesine basarak önceki bölüme dönünüz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/8_0.png)

9. Notunuzu yazarak "Ekle" düğmesine basınız. Artık sadece tanımladığınız kişiler evrak kendilerine ulaştığında bu notu görebileceklerdir. Evrak kendilerine ulaşmazsa ayrıca bir bildirim gitmeyecektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/9_0.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.