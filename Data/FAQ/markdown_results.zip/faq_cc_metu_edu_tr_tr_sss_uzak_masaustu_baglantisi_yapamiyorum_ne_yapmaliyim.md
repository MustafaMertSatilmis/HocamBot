[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uzak-masaustu-baglantisi-yapamiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2020 **Görüntüleme:** 69972


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-cannot-make-remote-desktop-connection-what-should-i-do "I cannot make remote desktop connection, what should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uzak-masaustu-baglantisi-yapamiyorum-ne-yapmaliyim "Uzak masaüstü bağlantısı yapamıyorum, ne yapmalıyım?")

# Uzak masaüstü bağlantısı yapamıyorum, ne yapmalıyım?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

Uzak masaüstü bağlantısı kurmakta sorun yaşıyorsanız bunun olası iki nedeni olabilir.

a) Bağlantı için kullanılan port numaralarının değiştirilmesi gerekmesi

b) Uzak masaüstü bağlantısı ayarlarında ya da kullanıcı adında sorun olması

**a) Bağlantı için kullanılan port numaralarının değiştirilmesi gerekmesi**

Uzak masaüstü bağlantı noktası olan 3389 numaralı porta ODTÜ yerleşkesi dışından erişimle ilgili çeşitli güvenlik önlemleri alınmıştır. Bu nedenle 3389 numaralı port çift yönlü (kampüs içine ve dışına yönlü) olarak kapalı tutulmaktadır. Bu çerçevede, yerleşke dışından ODTÜ'deki bilgisayarınıza uzak masaüstü bağlantısı yapabilmek için her iki bilgisayarın uzak masaüstü port numarasını değiştirmeniz gereklidir. Bunun için aşağıdaki yöntem kullanılabilir.

- [**Başlat > Çalıştır > regedit** komutuyla "Kayıt Defteri Düzenleyicisi" açılır ve **HKEY\_LOCAL\_MACHINE \ System \ CurrentControlSet \ Control \ TerminalServer \ WinStations \ RDP-Tcp** altında "PortNumber" kısmındaki port numarası 1025-65535 arasında kullanılmayan bir port numarasıyla değiştirilir.](http://support.microsoft.com/kb/306759)
- Daha sonra Windows Güvenlik Duvarı'nda (veya kullandığınız güvenlik duvarı yazılımında) ilgili port numarasına erişim izni verilmelidir. **Windows 7** işletim sisteminde bunun için **Başlat > Denetim Masası > Sistem ve Güvenlik > Windows Güvenlik Duvarı > Gelişmiş Ayarlar** seçeneğiyle gelişmiş güvenlik ayarları penceresi açılır. **Windows 10** işletim sisteminde de **Başlat > Windows Yönetimsel Araçları > Gelişmiş Güvenlik Özellikli Windows Defender Güvenlik Duvarı** seçeneği izlenir.

Sol taraftaki menüden, bağlandığınız bilgisayarda **Giden Kuralları**, uzak masaüstü ile bağlanacağınız bilgisayarda **Gelen Kuralları** seçeneğini seçip sağ taraftaki **Yeni Kural** düğmesine tıklayın. Her iki bilgisayarı da uzaktan bağlanmak üzere kullanacaksanız ikisi üzerinde de hem gelen, hem giden kuralı oluşturmanız gereklidir.

|     |     |
| --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_01_tr.jpg) | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_01a_tr.jpg) |

Sihirbaz penceresinde kural türünü **Bağlantı Noktası** olarak seçip **İleri** düğmesine tıklayın. Sonraki ekranda protokolü **TCP** olarak seçip belirlediğiniz port numarasını yazın.

|     |     |
| --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_02_tr.jpg) | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_03_tr.jpg) |

Sonraki ekranda **Bağlantıya izin ver** seçeneğini işaretleyip **İleri** düğmesine tıklayın. En son ekranda kurala bir ad verip **Son** düğmesine tıklayarak işlemi sonlandırın.

|     |     |
| --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_04_tr.jpg) | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_05_tr.jpg) |

Windows Güvenlik Duvarı dışında farklı bir güvenlik duvarı yazılımı kullanıyorsanız ilgili port numarasına erişim izinlerini bu yazılımda vermeniz gereklidir.

Ayarların etkinleşmesi için bilgisayarları yeniden başlatın. Bu işlemlerden sonra uzak masaüstü bağlantısı yaparken bağlanacağınız bilgisayar adını **IP:port numarası** şeklinde yazmalısınız.

|     |
| --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_06_tr.jpg) |

**b) Uzak masaüstü bağlantısı ayarlarında ya da kullanıcı adında sorun olması**

Uzak masaüstü bağlantısı yapılırken girilecek olan kullanıcı adı her zaman bilgisayar açıldığında görülen kullanıcı adı ile aynı olmayabilir. Bilgisayarınıza uzak masaüstü bağlantısı yapmakta sorun yaşıyorsanız hangi kullanıcı adı ile bağlanılması gerektiğini kontrol etmek gerekmektedir. Bunun için uzak masaüstü bağlantısı yapılacak olan bilgisayardaki Görev Yöneticisi çalıştırılarak (Ctrl+Alt+Delete tuşlarına basarak gelen menüden veya görev yöneticisi çubuğuna sağ klikleyerek gelen menüden "Görev Yöneticisi'ni başlat" seçeneği seçilerek çalıştırılabilir) kullanıcılar sekmesindeki kullanıcı adına bakılabilir.

|     |     |
| --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_07_tr.png) | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_08_tr.png) |

Uzak masaüstü bağlantısı kurulurken kullanılacak kullanıcı adı burada yazan kullanıcı adıdır.

|     |
| --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_09_tr.png) |

Uzak masaüstü bağlantısı sağlanacak iki bilgisayar arasında versiyon farkı varsa (örneğin Windows XP bir bilgisayardan Windows 7 bir bilgisayara bağlanmaya çalışılıyorsa), uzak masaüstü bağlantı ayarlarında "Herhangi bir Uzak Masaüstü sürümünü çalıştıran bilgisayardan yapılan bağlantılara izin ver (az güvenli)" ayarının seçili olması gereklidir. Bu ayarlara Sistem Özellikleri penceresinin Uzak Bağlantı sekmesinden ulaşılabilir.

|     |
| --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_rdp_10_tr.png) |