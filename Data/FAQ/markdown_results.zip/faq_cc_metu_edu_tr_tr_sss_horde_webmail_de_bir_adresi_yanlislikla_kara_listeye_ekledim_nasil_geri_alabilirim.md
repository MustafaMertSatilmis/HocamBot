[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-webmail-de-bir-adresi-yanlislikla-kara-listeye-ekledim-nasil-geri-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7602


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-blacklisted-someone-accident-my-horde-webmail-how-do-i-undo "I blacklisted someone by accident in my Horde Webmail. How do I undo that?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-webmail-de-bir-adresi-yanlislikla-kara-listeye-ekledim-nasil-geri-alabilirim "Horde Webmail de bir adresi yanlışlıkla kara listeye ekledim. Nasıl geri alabilirim?")

# Horde Webmail de bir adresi yanlışlıkla kara listeye ekledim. Nasıl geri alabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

- Kullanıcı adı ve şifreniz ile Horde Webmail sayfasına giriş yapınız.
- Soldaki menüden Seçenekleri seçiniz.
- Seçenekler bölümünden Süzgeçlere tıklayınız.
- Gelen sayfada üst kısımda bulunan menüden Kara Liste'ye tıklayınız.
- Gelen ekrandaki metin kutusunda yazılı bulunan e-posta adreslerinden kara listeden çıkarmak istediğiniz e-posta adresini siliniz (her bir satırda bir e-posta adresi olmasına dikkat ediniz).
- Değişikliklerden sonra Kaydet düğmesine tıklayınız.