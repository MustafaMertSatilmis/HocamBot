[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/spam-e-postalari-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 9365


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-spam-e-mail "What should I do with spam e-mail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/spam-e-postalari-ne-yapmaliyim "Spam e-postaları ne yapmalıyım?")

# Spam e-postaları ne yapmalıyım?

[Spam](https://faq.cc.metu.edu.tr/tr/groups/spam)

E-postayı tam başlık (full header) bilgileri ve gövde (body) kısmı ile birlikte [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresinden bize ileterek ilgili e-postanın spam filtresine istenmeyen e-posta olarak tanıtılmasını sağlayabilirsiniz. E-posta başlığının tamamının nasıl görüntüleneceğiyle ilgili [buradan](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim) bilgi alabilirsiniz.

Horde kullanıyorsanız, istenmeyen e-postaları seçip **İstenmeyen İleti Olarak Rapor Et** seçeneğiyle de spam filtresine istenmeyen e-posta olarak tanıtabilirsiniz.

Spam filtresi, kullanıcılardan gelen bildirimler sayesinde istenmeyen e-postaları daha verimli biçimde ayırt edebilecektir.