[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/anabilim-dallarina-nasil-evrak-gonderirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5546


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/anabilim-dallarina-nasil-evrak-gonderirim)

# Anabilim dallarına nasıl evrak gönderirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de sadece disiplinlerarası anabilim dalı başkanlıkları tanımlıdır. Disiplinlerarası olmayan anabilim dallarının bilgisi İKYS\*'de bulunmadığından, bu tür bir anabilim dalına gönderim yapılması gerektiğinde doğrudan ilgili bölümü seçerek yazıyı gönderebilirsiniz.

Ör: İşletme anabilim dalı yerine İşletme bölümüne gönderim yapılması gibi.

\\* İKYS: İnsan Kaynakları Yönetim Sistemi (Personel Daire Başkanlığı)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.