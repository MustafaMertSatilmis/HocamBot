[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-07-2023 **Görüntüleme:** 3339


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuklerim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 1. Adım: Java'yı nasıl yüklerim?\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- [https://www.java.com/](https://www.java.com/) adresine giderek Java'yı bilgisayarınıza indiriniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_1.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_2.jpg)

2- İndirilen dosyayı açarak kurulum işlemini tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_3.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_4.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_5.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_6.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-java_7.jpg)