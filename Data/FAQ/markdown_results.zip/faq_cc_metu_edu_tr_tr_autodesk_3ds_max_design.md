[Jump to navigation](https://faq.cc.metu.edu.tr/tr/autodesk-3ds-max-design#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-01-2022 **Görüntüleme:** 16920


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/autodesk-3ds-max-design "AUTODESK 3DS MAX DESIGN")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/autodesk-3ds-max-design "AUTODESK 3DS MAX DESIGN")

# AUTODESK 3DS MAX DESIGN

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**3ds Max Kurulumu**

**1.Adım:** Yükleme dosyasını çalıştırdıktan sonra karşınıza gelen ekranda **Install Products** seçeneğini tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds1.png)

**2.Adım:** Gelen ekranda yüklenmesi gereken öğeler seçili olarak gelecektir. İleri ( **Next**) butonuna tıklayarak devam ediniz.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds2.png)

**3.Adım:** Bileşenlerin yüklenmesi işlemi başlayacaktır. Bu işlem zaman alabilir, lütfen bekleyin.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds3.png)

**4.Adım:** Bileşenler yüklendikten sonra karşınıza lisans sözleşmesinin yer aldığı ekran gelecektir. Burada sözleşmeyi kabul edip İleri ( **Next**) butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds4.png)

**5.Adım:** Gelen ekranda “ **I have my product information**” seçeneği işaretlenir. Daha sonra [https://yazilim.cc.metu.edu.tr/](https://yazilim.cc.metu.edu.tr/) adresinde yer alan **serial\_ftpcc.txt** dosyasındaki seri numarasını, gerekli alanlara giriniz ve İleri ( **Next**) butonuna tıklayarak devam ediniz.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds5.png)

**6\. Adım:** Karşınıza gelen ekranda **Configure** seçeneğine tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds6.png)

**7.Adım:** Ürünü lisanslı hale getirebilmek için “ **Network License**” seçeneğini seçiniz ve allta yer alan lisans sunucusu kısmına “ **autodesk.cc.metu.edu.tr**” adresini giriniz. Son olarak bu ekrandan çıkmak için **Configuration Complete** butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds7.png)

**8\. Adım: Install** butonuna tıklayarak yükleme işlemini tamamlayınız.

![](https://faq.cc.metu.edu.tr/system/files/u16319/3ds8.png)

**İlgili olduğunu düşündüğünüz soruları [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**