[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/bolum-koordinatorlugu#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Bölüm Koordinatörlüğü

|     |
| --- |
| [Bölüm koordinatörüne nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bolum-koordinatorune-nasil-ulasabilirim) |
| [Koordinatör olarak sorumlu olduğum bilgisayarın IP erişiminin yeniden açılması için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/koordinator-olarak-sorumlu-oldugum-bilgisayarin-ip-erisiminin-yeniden-acilmasi-icin-ne) |

[![Subscribe to Bölüm Koordinatörlüğü](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/42/all/feed "Subscribe to Bölüm Koordinatörlüğü")