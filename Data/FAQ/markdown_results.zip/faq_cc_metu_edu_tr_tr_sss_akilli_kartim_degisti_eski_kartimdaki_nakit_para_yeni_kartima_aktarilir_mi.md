[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartim-degisti-eski-kartimdaki-nakit-para-yeni-kartima-aktarilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-05-2023 **Görüntüleme:** 11941


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-smart-card-has-been-changed-would-available-cash-my-old-card-be-transferred-my-new-card "My Smart card has been changed. Would the available cash on my old card be transferred to my new card?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartim-degisti-eski-kartimdaki-nakit-para-yeni-kartima-aktarilir-mi "Akıllı kartım değişti, eski kartımdaki nakit para yeni kartıma aktarılır mı?")

# Akıllı kartım değişti, eski kartımdaki nakit para yeni kartıma aktarılır mı?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınız değiştiğinde, eski kartınızda bulunan, nakit yükleme kiosklarından veya odtucard üzerinden yüklediğiniz sanal para yeni kartınıza otomatik olarak aktarılır. Bunun için yeni kartınızı para yükleme Kiosk'larından birine okutmanız yeterli olacaktır (resim aşağıdadır).

Eğer para aktarımı ile ilgili bir sorun fark ederseniz durumu  [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) sayfasından  kullnıcı bilgilerinizle giriş yaparak bildirebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/kiosk.jpeg)