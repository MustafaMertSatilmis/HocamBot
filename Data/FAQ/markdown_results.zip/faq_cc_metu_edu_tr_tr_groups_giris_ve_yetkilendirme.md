[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Giriş ve Yetkilendirme

|     |
| --- |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Yeni client - DSClient Uygulaması\]](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client) |
| [Aynı anda birden fazla kişiye vekalet verilebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/ayni-anda-birden-fazla-kisiye-vekalet-verilebilir-mi) |
| [Bir Evrak için Gelen EBYS E-posta Bildirimindeki Bağlantıdan Diğer Evraklarıma Nasıl Ulaşırım?](https://faq.cc.metu.edu.tr/tr/sss/bir-evrak-icin-gelen-ebys-e-posta-bildirimindeki-baglantidan-diger-evraklarima-nasil-ulasirim) |
| [Bir kişi bana vekalet bıraktığında yazılarına nasıl ulaşabilirim?](https://faq.cc.metu.edu.tr/tr/sss/bir-kisi-bana-vekalet-biraktiginda-yazilarina-nasil-ulasabilirim) |
| [EBYS E-imza Uygulaması (DSClient) Lisans Dosyası Değişikliği](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi) |
| [EBYS'de E-imza Uygulaması DSClient'da Karşılaşılabilen Uyarılar](https://faq.cc.metu.edu.tr/tr/sss/dsclient-uygulamasinda-karsilasilabilen-uyarilar) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Linux\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 1. Adım: Java'yı nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 2. Adım: E-imza sürücülerini nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-2-adim-e-imza-suruculerini-nasil-yuklerim) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 3. Adım: DSClient uygulamasını nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimini-nasil-yuklerim) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 1. Adım: Java'yı nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuklerim) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 2. Adım: E-imza sürücülerini nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-2-adim-e-imza-suruculerini-nasil-yuklerim) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 3. Adım: DSClient uygulamasını nasıl yüklerim?\]](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim) |
| [EBYS'de görünen birim, görev ya da unvanınız hatalı ise ne yapmalısınız?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gorunen-birim-gorev-ya-da-unvaniniz-hatali-ise-ne-yapmalisiniz) |
| [EBYS'de oturum süresi nedir?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-oturum-suresi-nedir) |
| [EBYS'ye nasıl giriş yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebysye-nasil-giris-yapilir) |
| [EBYS'yi kullanmak için hangi web tarayıcısını kullanmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysyi-kullanmak-icin-hangi-web-tarayicisini-kullanmaliyim) |
| [EBYS'yi mobil cihazım (tablet/akıllı telefon) ile kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/ebys-yi-mobil-cihazim-ile-kullanabilirmiyim) |
| [EBYS’de kullanıcı adı/parola hatası uyarısı alındığında ne yapılmalıdır?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kullanici-adiparola-hatasi-uyarisi-alindiginda-ne-yapilmalidir) |
| [Görev Değişikliği / Atama durumlarında EBYS'de tanımlamalar nasıl yapılmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/gorev-degisikligi-atama-durumlarinda-ebysde-tanimlamalar-nasil-yapilmaktadir) |
| [Kampus dışından EBYS'ye giriş yapılabilir mi?](https://faq.cc.metu.edu.tr/tr/sss/kampus-disindan-ebysye-giris-yapilabilir-mi) |
| [Üzerinde vekalet bulunan bir kişi bir başka kişiye vekalet verirse ilk vekalet veren kişinin vekaleti üçüncü kişiye aktarılıyor mu?](https://faq.cc.metu.edu.tr/tr/sss/uzerinde-vekalet-bulunan-bir-kisi-bir-baska-kisiye-vekalet-verirse-ilk-vekalet-veren-kisinin) |
| [Vekalet verecek kişi ulaşılır olmadığında vekalet vermek/değişiklik yapmak nasıl mümkün olacak?](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verecek-kisi-ulasilir-olmadiginda-vekalet-vermekdegisiklik-yapmak-nasil-mumkun-olacak) |
| [Vekalet verilen kişi vekaleti reddetme hakkına sahip mi?](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verilen-kisi-vekaleti-reddetme-hakkina-sahip-mi) |

[![Subscribe to Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/211/all/feed "Subscribe to Giriş ve Yetkilendirme")