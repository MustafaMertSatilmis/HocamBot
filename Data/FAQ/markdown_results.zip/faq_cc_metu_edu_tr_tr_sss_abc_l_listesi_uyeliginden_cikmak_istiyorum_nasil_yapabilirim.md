[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesi-uyeliginden-cikmak-istiyorum-nasil-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-09-2022 **Görüntüleme:** 8370


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-unsubscribe-abc-l-list-turkish "How can I unsubscribe from the  \"abc-l\" list? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesi-uyeliginden-cikmak-istiyorum-nasil-yapabilirim "\"abc-l\" listesi üyeliğinden  çıkmak istiyorum, nasıl yapabilirim?")

# "abc-l" listesi üyeliğinden çıkmak istiyorum, nasıl yapabilirim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

1. Liste üyeliğinden çıkış için **[http://mailman.metu.edu.tr/mailman/listinfo/abc-l](http://mailman.metu.edu.tr/mailman/listinfo/abc-l)** adresinde sayfanın en alt kısmında yer alan "abc-l listesinden çıkmak, bir şifre hatırlatıcı istemek, veya üyelik seçeneklerinizi değiştirmek için üyelik e-posta adresinizi girin" yazılı bölüme listeye üyelik için kullandığınız e-posta adresinizi girip butona basınız.
2. Karşınıza gelen sayfada yer alan "Üyelikten Çık" butonuna basınız.
3. Belirttiğiniz e-posta adresi listeye üye bir adres ise üyelikten çıkış için bu adrese bir onay mesaji gönderilecektir (Bazen mesajların alındığı adres ile listeye üye olan adres farklı olabilmektedir. Birden fazla e-posta adresi kullanıyorsanız bu adresler arasında yönlendirme olabilir. Üyelikten çıkış işlemini listeye üyelik için kullandığınız adres üzerinden gerçeklestiriniz.)
4. E-posta adresine gelen onay mesajındaki linke tıklayarak erişeceğiniz web sayfasında üyelikten çıkış talebinizi bir kere daha onaylamalısınız.
5. Bazı listelerde üyelikten çıkış işlemlerinin liste yöneticisi tarafından onaylanması tercih edilmektedir. Eğer bu işlemleri gerçekleştirdiğiniz halde listeden mesaj almaya devam ediyorsanız **abc-l-owner![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr** adresinden liste yöneticisiyle iletişime geçiniz.
6. Yukarıdaki yöntemlerin yanı sıra [abc-l-request@metu.edu.tr](mailto:abc-l-request@metu.edu.tr) adresine "unsubscribe" konulu boş bir e-posta gondererek de üyelikten çıkış işleminizi başlatabilirsiniz.

(Yukarıda geçen "abc-l" ifadesi liste ismi için örnek olarak verilmiştir. abc-l yerine çıkmak istediğiniz listenin adını yazmalısınız.)