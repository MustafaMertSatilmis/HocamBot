[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-12-2022 **Görüntüleme:** 12797


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-internet-connection-very-slow-what-problem "My Internet connection is very slow. What is the problem?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir "İnternet bağlantım çok yavaş. Sorun ne olabilir?")

# İnternet bağlantım çok yavaş. Sorun ne olabilir?

[Kablolu Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablolu-ag)

ODTÜ yerleşke ağında tüm kullanıcılarımız aynı İnternet bağlantısını paylaşmaktadır. Bu paylaşım ne kadar artarsa, her bir paydaşın bağlantı hızı o kadar düşmektedir. Yurtlardaki ağ yönlendirici cihazlar kaynaklar dahilinde yenilenmekte ve iyileştirilmektedir.

Kendi prizinizde farklı bir internet kablosu ile sağlıklı bir bağlantı yapılabiliyorsa kablonuz arızalıdır, kablonuzu yenilemeniz gerekmektedir.

Yurt odalarında kendi kablonuz ile farklı bir prizde sağlıklı bir bağlantı kurabiliyorsanız, kendi ağ prizinizin kontrol ettirilmesi için Yurt Danışmasını bilgilendiriniz.

Yaşadığınız sorun farklı priz ve ara kablo ile de tekrarlıyorsa, inceleme yapılabilmesi için aşağıdaki bilgileri [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresinden vaka oluşturarak iletebilirsiniz.

1) start-run-cmd'ye ipconfig /all yazıp, çıkan sonucun ekran görüntüsünü iletebilir misiniz?

2) Yavaşlık hangi saatlerde oluyor? (akşam belli saatlerdeyse, saat dilimi nedir?)

3) Yavaşlık hissettiğiniz bir zamanda bağlı olduğunuz "ağ gecidine/gateway" ping çekip sonucunu bize iletebilir misiniz?

(start->run'a ping -t 144.122.xxx.1 sonucunu 20-30 sn ekran görüntüsü)

4) [http://speedtest.metu.edu.tr/](http://speedtest.metu.edu.tr/) sonucunu iletebilir misiniz?

5) [https://docs.microsoft.com/en-us/sysinternals/downloads/tcpview](https://docs.microsoft.com/en-us/sysinternals/downloads/tcpview)  adresinden indirebileceğiniz "TCPView" programini çalıştırıp, çıkan sonucun ekran görüntüsünü iletebilir misiniz?

6) "netstat -rn" çıktılarının ekran görüntüsünü iletebilir misiniz?

(command prompt'a bu komutları yazarak sonucu görebilirsiniz.)

Yerleşke İnternet bağlantı trafiğini [http://lines.metu.edu.tr](http://lines.metu.edu.tr/) adresinden takip edebilirsiniz.

**Buna ek olarak, internet yavaşlığı yaşamanız durumunda aşağıdaki maddeleri gözden geçirebilirsiniz;**

\- Bilgisayar ile duvardaki data prizi arasındaki birkaç metrelik kablonun kalite düşüklüğü (kablo hasarı, standart dışı kablo kullanımı), kaliteli ve deforme olmamış bir ethernet ara kablosu kullanılması sorunu çözecektir.

\- Tırnağı kırılmış konnektörlere sahip bir kablonun kullanılması

\- Dış koruması sıyrılmış bir ara kablonun kullanılması

\- Ara kablonun keskin açılarla bükülmesi

\- Ara kablonun düğüm haline getirmesi veya bağlanması

\- Bilgisayarın ethernet kartı sürücüsünün doğru modelde ve güncel olmaması

\- Bilgisayarın kablolu ağ girişinin temiz olmaması ( toz ve sıvılar sorun yaşanmasına sebep olur)

\- Bilgisayarın kablolu ağ girişinde deformasyon olması (zamanla yıpranıp oksidasyona uğrayabilmektedir)

\- Arka planda çalışan ve internet trafiğini etkileyebilecek uygulamaların olması  (incelenip gereksiz olanlar kapatılmalıdır)

\- Kullanıcının haberi olmadan arka planda indirme/yükleme işlemi yapan uygulamarın (Botnet vb.) çalışması (güvenlik taramalarının yapılması ve bilgisayarın güncel tutulması gerekmektedir)

\- Anlık kullanıcı yoğunluğunun fazla olması (kullanıcı sayısının artması hızı yavaşlatacaktır)