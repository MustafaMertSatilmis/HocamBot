[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebys#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2023 **Görüntüleme:** 53702


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebys)

# EBYS

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

**Elektronik Belge Yönetim Sistemi**, bir kurumun faaliyetlerini yerine getirirken oluşturulan her türlü dokümantasyonun içerisinden kurumun faaliyetlerinin delili olabilecek belgelerin ayıklanarak bunların içerik, üstveri, format ve ilişkisel özelliklerini koruyan, belgelerin ait olduğu fonksiyon veya işlem için delil teşkil eden ve aidiyet zinciri içerisindeki yönetimini elektronik ortamda sağlayan sistemdir.

[**ODTÜ Elektronik Belge Yönetim Sistemi (EBYS)**](https://ebys.metu.edu.tr/) de bu kapsamda, üniversite birimlerinin ve personelinin kendi içlerinde, birbirleriyle veya gerçek ya da tüzel kişiler ile iletişim sağlamak amacıyla fiziksel ortamda veya güvenli elektronik imza kullanarak elektronik ortamda yürüttükleri süreci gerçekleştirmeleri amacıyla kurgulanmıştır.

Gizlilik derecesi taşıyan ve fiziksel ortamda gönderilme zorunluluğu olan belgeler hariç, üniversitedeki kurum içi ve kurum dışı tüm yazışmaların 21 Mayıs 2018 tarihinden itibaren EBYS üzerinden yapılması beklenmektedir.

EBYS'nin işleyişinde ve kullanımında aşağıdaki yönergelerin dikkate alınması gerekmektedir:

- **[Orta Doğu Teknik Üniversitesi Fiziki ve Elektronik Ortamda Uygulanacak Resmi Yazışma Kuralları Yönergesi](https://genduy.metu.edu.tr/2018/EBYS/yazismayonergesi.pdf)**
- **[Orta Doğu Teknik Üniversitesi Yetki Devri ve İmza Yetki/Yetkilileri Yönergesi](https://genduy.metu.edu.tr/2018/EBYS/imzayetkileriyonergesi.pdf)**
- **[Gizlilik Dereceli Yazıların Sınıflanması-İç Genelge](https://genduy.metu.edu.tr/2018/EBYS/gizlilikdyazilar.pdf)**
- **[Dış Yazışmalar-İç Genelge](https://genduy.metu.edu.tr/2018/EBYS/disyazisma.pdf)**
- **[Elektronik Belge Yönetim Sistemi Kuralları](https://genduy.metu.edu.tr/2018/EBYS/EBYSkurallari.pdf)**
- [**Görevlendirme Yazılarının EBYS'den Gönderimine İlişkin İlkeler**](https://genduy.metu.edu.tr/2020/GorevlendirmeYazilariHaziran2020.pdf)
- [**Harcama Birimlerinin EBYS'de E-Faturalara İtiraz Yazısı Hazırlama Kılavuzu**](https://sgdb.metu.edu.tr/en/system/files/e_fatura_itiraz_kilavuzu_0_0.pdf)
- **[EBYS’de e-Yazışma Paketi (EYP) 2.0 Versiyonu ile Getirilen Yenilikler (Mayıs 2021)](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eyp2.0_yenilikler_mayis2021.pdf)**
- [**EBYS Fiziksel Postalama Formu Kullanım Kuralları**](https://eam.metu.edu.tr/tr/system/files/posta_gonderim_kurallari.pdf)

ODTÜ EBYS ile ilgili detaylı bilgilere aşağıdaki yardım bağlantılarından erişilebilir:

- **[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)**
- **[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)**
- **[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)**
- **[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)**
- **[Yardım Videoları](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari)**

_EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir._