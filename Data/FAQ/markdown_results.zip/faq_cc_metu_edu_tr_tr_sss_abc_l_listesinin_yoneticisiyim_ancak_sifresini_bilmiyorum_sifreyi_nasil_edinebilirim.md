[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesinin-yoneticisiyim-ancak-sifresini-bilmiyorum-sifreyi-nasil-edinebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8294


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-administrator-abc-l-list-i-do-not-remember-list-admin-password-how-can-i-get-it-turkish "I am the administrator of  \"abc-l\" list. I do not remember the list admin password. How can I get it? (in  Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesinin-yoneticisiyim-ancak-sifresini-bilmiyorum-sifreyi-nasil-edinebilirim "\"abc-l\" listesinin yöneticisiyim. Ancak şifresini bilmiyorum. Şifreyi nasıl edinebilirim?")

# "abc-l" listesinin yöneticisiyim. Ancak şifresini bilmiyorum. Şifreyi nasıl edinebilirim?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

Liste yönetim şifresini edinmek için listenin yöneticisi olarak kullandığınız e-posta adresinden [mailman@metu.edu.tr](mailto:mailman@metu.edu.tr) adresine yöneticisi olduğunuz listenin adı ve **telefon numarası bilginizi vererek** şifre isteğinizi bildiren bir e-posta gönderiniz. E-Liste servis yöneticisi talebiniz üzerine gerekli incelemeleri gerçekleştirecek, talebin uygun görülmesi durumunda sizinle telefon aracılığıyla iletişime geçecektir.

E-Liste yöneticiliğinde bir değişiklik söz konusu olduğunda, önceki e-liste yöneticisi yeni liste yöneticisinin e-posta adresini listenin yönetim arayüzü üzerinde yönetici olarak tanımlamalı ve yönetim şifresini yeni yöneticiye teslim etmelidir. Ancak, liste yöneticisinin yeni yöneticiyi tanımlamadan ve şifreyi aktarmadan görevden ayrılması gibi durumlarda, farklı bir kişinin liste yöneticisi olarak tanımlanmasına BİDB tarafından destek verilebilmektedir.

Böyle bir durum söz konusu ise, ilgili listenin yeni yöneticisi olacak kişinin konuyla ilgili talebini "![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr" uzantılı e-posta adresini kullanarak [mailman![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr](mailto:mailman<img src=) adresine iletmesi gerekmektedir. Söz konusu liste üniversitedeki bir birime ait ise, bu talep ilgili birimin yöneticisi tarafından iletilmelidir. Talebin BİDB'na ulaşmasının ardından, talep sahibi ile iletisime geçilerek gerekli işlemler gerçekleştirilecektir.

(Yukarıda geçen "abc-l" ifadesi liste ismi için örnek olarak verilmiştir.)