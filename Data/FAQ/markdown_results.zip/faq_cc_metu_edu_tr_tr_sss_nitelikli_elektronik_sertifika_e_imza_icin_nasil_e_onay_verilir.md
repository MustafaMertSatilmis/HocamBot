[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/nitelikli-elektronik-sertifika-e-imza-icin-nasil-e-onay-verilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-06-2021 **Görüntüleme:** 5917


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-give-e-approval-certified-electronic-signature-e-signature "How to give E-APPROVAL for Certified Electronic Signature (e-signature)?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/nitelikli-elektronik-sertifika-e-imza-icin-nasil-e-onay-verilir "Nitelikli Elektronik Sertifika (e-imza) için nasıl E-ONAY verilir?")

# Nitelikli Elektronik Sertifika (e-imza) için nasıl E-ONAY verilir?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

KamuSM Nitelikli Elektronik Sertifika işlemlerinde e-imzanızı kullanarak bir defaya mahsus **e-onay** vermeniz durumunda, bundan sonraki taleplerinizde evrak göndermeye gerek kalmadan hızlı bir şekilde Nitelikli Elektronik Sertifika (NES) temin edebilirsiniz. Bunun için aşağıdaki adımları takip etmeniz gerekmektedir:

**KamuSM'de ilgili işlemlerin yapılması için [Akis](https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu_yukleme_servisi/) ve [Java Kurulumu](https://www.java.com/en/download/) yapılmış olması gerekmektedir.**

1.  **http://kamusm.gov.tr**adresine gidiniz.

2.  "**ONLINE İŞLEMLER**" sekmesine tıklayınız.

3.  "**E-Devlet ile Giriş**" seçtikten sonra "**E-devlet Kapısına Git**" linkinden **T.C. kimlik numaranız** ya da **NES** ile giriş yapınız.

4\. "**NES İŞLEMLERİ**"ni seçiniz.

5.  "**E-ONAY İŞLEMLERİ**"ni seçiniz:

![](https://faq.cc.metu.edu.tr/system/files/u127225/screen_shot_2020-09-18_at_15.48.11.png)

6\. Açılan sayfada takip edilmesi gereken adımlar ayrıntılı bir şekilde tarif edilmektedir.  Adımları takip ederek **E-ONAY** veriniz.