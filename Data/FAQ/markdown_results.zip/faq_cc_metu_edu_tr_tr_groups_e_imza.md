[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/e-imza#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# E-imza

|     |
| --- |
| [E-imza SIM kartımın PIN (parola) kodunu nasıl oluşturabilirim? PIN kilidini nasıl çözebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sim-kartimin-pin-parola-kodunu-nasil-olusturabilirim-pin-kilidini-nasil-cozebilirim) |
| [E-imzam yok, nasıl elde edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imzam-yok-nasil-elde-edebilirim) |
| [E-imzayı nerede kullanacağım? Zorunlu muyum?](https://faq.cc.metu.edu.tr/tr/sss/e-imzayi-nerede-kullanacagim-zorunlu-muyum) |
| [Kamu SM Nitelikli Elektronik Sertifika (E-imza) Başvuru Süreci Nasıldır?](https://faq.cc.metu.edu.tr/tr/sss/kamu-sm-nitelikli-elektronik-sertifika-e-imza-basvuru-sureci-nasildir) |
| [EBYS'de E-imzayı nasıl kullanabilirim? \[Yeni client - DSClient Uygulaması\]](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client) |
| [Başka bir kurumdan e-imza alabilir miyim? E-imzam var kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/baska-bir-kurumdan-e-imza-alabilir-miyim-e-imzam-var-kullanabilir-miyim) |
| [E-imza geçerlilik süresini nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-gecerlilik-suresini-nasil-ogrenebilirim) |
| [E-imza kart okuyucumu kaybettim. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-kart-okuyucumu-kaybettim-ne-yapmaliyim) |
| [E-imza nedir?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-nedir) |
| [E-imza sertifikamın geçerlilik süresi doldu/dolmak üzere, yenileme başvurusunu nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sertifikamin-gecerlilik-suresi-doldudolmak-uzere-yenileme-basvurusunu-nasil-yapabilirim) |
| [E-imzamı kaybettim/çalındı, kimlik bilgim güncellendi; ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/e-imzami-kaybettimcalindi-kimlik-bilgim-guncellendi-ne-yapmaliyim) |
| [EBYS E-imza Uygulaması (DSClient) Lisans Dosyası Değişikliği](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi) |
| [EBYS'de "Uygulama Yüklenirken Hata Oluştu!" mesajı alıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-uygulama-yuklenirken-hata-olustu-mesaji-aliyorum-ne-yapmaliyim) |
| [Emekli oldum, artık ODTÜ'de çalışmıyorum, e-imza alabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/emekli-oldum-artik-odtude-calismiyorum-e-imza-alabilir-miyim) |
| [Islak imzalı e-imza başvuru formu nereye iletilmelidir?](https://faq.cc.metu.edu.tr/tr/sss/islak-imzali-e-imza-basvuru-formu-nereye-iletilmelidir) |
| [Kamu SM'den gelen NES başvuru erişim parolası ile erişemiyorum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nes-basvuru-erisim-parolasi-ile-erisemiyorum-ne-yapmaliyim) |
| [Kamu SM'den gelen Nitelikli Elektronik Sertifika (E-imza) Başvuru E-postasını sildim. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nitelikli-elektronik-sertifika-basvuru-e-postasini-sildim-ne-yapmaliyim) |
| [Nitelikli Elektronik Sertifika (e-imza) için nasıl E-ONAY verilir?](https://faq.cc.metu.edu.tr/tr/sss/nitelikli-elektronik-sertifika-e-imza-icin-nasil-e-onay-verilir) |
| [PDF belgesine Acrobat Reader DC ile e-imza nasıl atlır?](https://faq.cc.metu.edu.tr/tr/sss/pdf-belgesine-acrobat-reader-dc-ile-e-imza-nasil-atlir) |
| [Sertifikamı uluslararası yazışmalarda kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/sertifikami-uluslararasi-yazismalarda-kullanabilir-miyim) |
| [Soyadı değişikliği durumunda ne yapılması gerekir? E-imzamı yine de kullanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/soyadi-degisikligi-durumunda-ne-yapilmasi-gerekir-e-imzami-yine-de-kullanabilir-miyim) |
| [TÜBİTAK proje başvurularında e-imzamı nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/tubitak-proje-basvurularinda-e-imzami-nasil-kullanabilirim) |

[![Subscribe to E-imza](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/210/all/feed "Subscribe to E-imza")