[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-akilli-kart-tarihcesi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-12-2021 **Görüntüleme:** 4262


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/metu-smartcard-history "METU Smartcard History")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-akilli-kart-tarihcesi "ODTÜ Akıllı Kart Tarihçesi")

# ODTÜ Akıllı Kart Tarihçesi

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/1.jpg)

ODTÜ’de 2000’li yılların başından sonra geliştirilmeye başlanan Akıllı Kart(Smartcard) projesi çerçevesinde, ilk adım olarak tüm öğrenci ve personel kimlikleri Akıllı Kimlik Kartı haline getirilmiş ve 2002-2003 öğretim yılından itibaren öğrenci ve personel kimlikleri, Akıllı Kimlik Kartı olarak dağıtılmaya başlanmıştır.

Proje kapsamında geliştirilen e-cüzdan(Elektronik Cüzdan) ve e-kimlik(Elektronik Kimlik) uygulamaları ile birlikte 2005 yılından itibaren akıllı kart kullanılmaya başlanmıştır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/2.jpg)

E-kimlik(elektronik kimlik) uygulaması ile ilk etapta 7 bölüm binası ve 2 bilgisayar salonu erişim kontrolünde akıllı kimlik kartı kulanılmaya başlanmıştır. E-cüzdan uygulaması ilk olarak Kafeterya’da kullanıma açılmış ve sonraki yıllarda bu uygulama yerleşke genelinde çeşitli noktalarda(Kütüphane, Havuz, Spor Merkezi vb.) hizmet vermeye başlamıştır. ODTÜ Akıllı Kart Projesi ile ilgili her türlü bilgiye sayfalarımızdan ulaşabilirsiniz.