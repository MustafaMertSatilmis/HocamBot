[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimda-bulunan-parayi-hesabima-geri-aktarabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-11-2021 **Görüntüleme:** 8926


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-transfer-virtual-money-left-my-metu-id-card-back-my-account "Can I transfer the virtual money left on my METU ID card back to my account?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimda-bulunan-parayi-hesabima-geri-aktarabilir-miyim "Akıllı kimlik kartımda bulunan parayı hesabıma geri aktarabilir miyim?")

# Akıllı kimlik kartımda bulunan parayı hesabıma geri aktarabilir miyim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Evet, akıllı kimlik kartınızda bulunan sanal parayı banka hesabınıza geri aktarabilirsiniz. Bunun için kafeterya üst katta bulunan muhasebe şefliğine başvuruda bulunmanız gerekmektedir.