[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-02-2025 **Görüntüleme:** 5022


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[Linux\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- Terminal'den şu komut satırını çalıştırınız:

sudo apt install default-jre

Devam etmek istiyor musunuz diye sorulduğunda Y yazıp enter düğmesine basarak kurulumu tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.53.04.png)

2- [https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu\_yukleme\_servisi/](https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu_yukleme_servisi/) adresine giderek e-imza sürücülerini sırasıyla indirerek kurunuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.49.09.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.50.12.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.50.35.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.50.49.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.51.14.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-20_14.51.52.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/1_3.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/2_2.png)

3- **[Buradan](https://portal.synergynow.io/#/_redirect/jDiciX128Kg8uo6CmbkcRt)** Ubuntu Linux için (son versiyon: 1.5.5), **[buradan](https://portal.synergynow.io/#/_redirect/LP9Vkbfv7DgFGlelUufuHi)** Debian Linux için (son versiyon: 1.5.5) güncel DSClient yazılımını indiriniz. İndirdiğiniz paketi ayıkladıktan sonra SetupFiles klasörüne kadar giderek sağ tık ile "Open in Terminal" seçeneğine tıklayınız.

_**ÖNEMLİ NOT:** Bilgisayarında halen 1.5.5 versiyonu öncesi DSClient yazılımı bulunan kullanıcılarımızın mevcut versiyonla sorunsuz olarak e-imzalama yapabilmesi için [https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi) sayfasında tarif edilen lisans dosyası değişikliğini yapması ya da DSClient yazılımını 1.5.5 versiyonuna güncellemesi gerekmektedir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/1_4.png)

Açılan terminalde ubuntu için

bash DSClientLinux.sh

Debian için

bash DSClientDebian.sh

komutunu çalıştırınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/2_3.png)

İşlem tamamlanmıştır.

* * *

Yukarıda tarif edilen adımları uygulamanıza rağmen EBYS'de e-imza kullanımıyla ilgili problem yaşıyorsanız ya da e-imza ile ilgili farklı sorularınız olursa [https://faq.cc.metu.edu.tr/tr/groups/e-imza](http://faq.cc.metu.edu.tr/tr/groups/e-imza) adresindeki sıkça sorulan soruları inceleyebilirsiniz.

EBYS ilgili sorularınızı [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletebilirsiniz.

* * *