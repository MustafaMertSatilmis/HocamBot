[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kamu-sm-nitelikli-elektronik-sertifika-e-imza-basvuru-sureci-nasildir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 10-03-2022 **Görüntüleme:** 29353


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-kamusm-certified-electronic-signature-e-signature-application-process "How is the KamuSM Certified Electronic Signature (E-signature) Application Process?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kamu-sm-nitelikli-elektronik-sertifika-e-imza-basvuru-sureci-nasildir "Kamu SM Nitelikli Elektronik Sertifika (E-imza) Başvuru Süreci Nasıldır?")

# Kamu SM Nitelikli Elektronik Sertifika (E-imza) Başvuru Süreci Nasıldır?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

**Kamu Sertifikasyon Merkezi Nitelikli Elektronik Sertifika (NES) Başvuru Süreci**

- [http://eimza.metu.edu.tr](http://eimza.metu.edu.tr/) adresinden kullanıcı **ODTÜ kodu / parola** ile giriş yapılarak başvuru "Kurum E-imza Yetkilisi"ne iletilir.

**\*\*\*ÖNEMLİ:** İlgili adreslere kampüs dışından erişebilmek için VPN hizmetini kullanınız.

VPN hizmeti ile ilgili bilgi almak ve kurulumu için **[https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)** adresini ziyaret edebilirsiniz.

- "Kurum E-imza Yetkilisi" e-imza temin edilecek kurum personeli listesini TÜBİTAK KamuSM'ye iletir.
- TÜBİTAK KamuSM tarafından kullanıcıya başvurusu için e-posta gelir.
- TÜBİTAK KamuSM'den gelen e-posta sonrasında bağlantıda belirtilen " [**Ön Başvurusu Yapılan Kişilerin e-İmza Başvurularını Tamamlaması**](https://kamusm.bilgem.tubitak.gov.tr/basvurular/nes/?info=7 "Ön Başvurusu Yapılan Kişilerin e-İmza Başvurularını Tamamlaması")" işlemlerinin tamamlanması gerekmektedir.
- TÜBİTAK KamuSM tarafından hazırlanan Nitelikli Elektronik Sertifika (e-imza) özel kurye ile adresinde ilgili kişiye teslim edilecektir.