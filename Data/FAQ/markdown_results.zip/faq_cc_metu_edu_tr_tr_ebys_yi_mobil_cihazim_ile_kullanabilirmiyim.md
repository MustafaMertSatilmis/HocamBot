[Jump to navigation](https://faq.cc.metu.edu.tr/tr/ebys-yi-mobil-cihazim-ile-kullanabilirmiyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 8724


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/ebys-yi-mobil-cihazim-ile-kullanabilirmiyim)

# EBYS'yi mobil cihazım (tablet/akıllı telefon) ile kullanabilir miyim?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS'ye kampus içinden ya da dışından (VPN ile), modeli ya da sürümü çok eski olmayan mobil cihazlar (Android ve IOS tablet/akıllı telefonlar) ile erişimde bir problem bulunmamakta; evraklar için -e-imzalama haricindeki- ulaşma/sevk etme/iade etme/dağıtım onayı verme gibi işlemler mobil cihazlar üzerinden de yapılabilmektedir.

E-imzalama işlemi ise -EBYS'den bağımsız olarak- mobil cihazlarda teknik olarak yapılamamakta ya da oldukça uğraştırıcı bir şekilde yapılabilmekte; bu tür cihazlar için ek aparatlar ya da programlar kullanılması gerekmektedir. Bu kapsamda son aylarda sektörde gelişen bazı çözümler takip edilmekte olup; bu çözümler stabil hale geldiğinde e-imzalama işleminin mobil cihazlar üzerinden de yapılabilmesi için çalışma yapılması planlanmaktadır. Bu nedenle, kampus içinden ya da dışından e-imza ile imzalanmak istenen evraklar için, şu an için mobil cihazlar yerine masaüstü ya da dizüstü PC kullanımı önerilmektedir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.