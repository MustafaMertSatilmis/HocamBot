[Jump to navigation](https://faq.cc.metu.edu.tr/tr/adobe#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-11-2024 **Görüntüleme:** 20676


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/adobe "ACCESS TO ADOBE SOFTWARE")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/adobe "ADOBE YAZILIMLARINA ERİŞİM")

# ADOBE YAZILIMLARINA ERİŞİM

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ADOBE** **CREATIVE CLOUD** **//** **ACROBAT PRO** **—**

_Kısıtlı sayıda temin edilebilen **Adobe Creative Cloud** ve **Adobe Acrobat Pro** yazılımlarının lisanslarına erişim için, ODTÜ kurumsal e-posta adresleri ve bu adreslerle ilişkili olarak oluşturulmuş Adobe hesabı erişim parolası kullanılabilmektedir._

_Adobe yazılımlarına erişim için yetkilendirilen e-posta adresi ve Adobe hesabı erişim parolası bilgilerini edinen kullanıcılarımız aşağıdaki adımları izleyerek yazılımları kullanabilirler._

* * *

**_\[1\] Not:_****_Adobe_ _yazılımları sadece teknik birim personelinin kullanımına açıktır! (Teknik birimler tarafından kullanılmakta olan ve kısıtlı miktarda temin edilen Adobe lisansları personel veya öğrencilerin kullanımına açık bir yazılım değildir.)_**

**_\[2\] Not:_**_Kullanıma sunulan_ _Adobe_ _yazılımına erişim için tanımlanan e-posta adresi ve_ _Adobe_ _hesabı parolasının hem güvenlik hem de ortak kullanım açısından üçüncü kişilerle paylaşılmaması gerekmektedir!_

**_\[3\] Not:_** _PDF'leri görüntülemek, dönüştürmek, sıkıştırmak veya imzalamak için_ _Adobe Acrobat_ _eklentisini tarayıcınıza ekleyerek ücretsiz olarak kullanabilirsiniz. Detaylı bilgi için [tıklayınız](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi)._

* * *

**_ADIM-1_**

_**[https://www.adobe.com/](https://www.adobe.com/)** sitesine gidiniz ve sayfanın sağ üst tarafında bulunan **“Giriş”** butonuna tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step1.png)

**_ADIM-2_**

_Açılan sayfada e-posta adresiniz ve Adobe hesabı erişim parolanız ile giriş yaparak devam ediniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step2.png)

**_ADIM-3_**

_Giriş yapmak için **“ODTU Bilgi Islem”** profilini seçiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step3.png)

**_ADIM-4_**

_Sayfanın sağ üst tarafında yer alan uygulama menüsünde plan kapsamında listelenen ürünlerin içerisinden **“Creative** **Cloud**_**_”_**_simgesine tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step4.png)

**_ADIM-5_**

_Ekrana gelen pencerede Creative Cloud_ _alanı altındaki **“İndir”** butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step5.png)

**_ADIM-6_**

_Yükleyiciyi tarayıcınızın indirilenler bölümünde veya bilgisayarınızda indirilen dosyalarınızı kaydettiğiniz konumda bulup çalıştırınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step6.png)

**_ADIM-7_**

**_“Continue_** **_”_** _butonuna tıklayarak kurulumu başlatınız. Kurulum başladığında kullanıcı girişi yapmak için bir web sayfasına yönlendirilirsiniz. Bu sayfada ilgili e-posta adresiniz ve Adobe hesabı erişim parolanız ile giriş yapınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step7.png)

**_ADIM-8_**

_Kullanıcı girişi başarılı bir şekilde yapıldıysa aşağıdaki şekilde ekranda bir uyarı mesajı görünecektir. Kullanıcı girişi tamamlandıktan sonra kurulum devam eder ve tamamlanır._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step8.png)

**_ADIM-9_**

_Kurulum tamamlandıktan sonra kullanmak istediğiniz yazılımları indirip kullanmaya başlayabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step9.png)

**_ADIM-10_**

_Yazılımı aynı anda sadece tek bir kişi kullanabildiğinden yazılımın kullanımı bittikten sonra mutlaka çıkış yapılması **(** **Sign Out**_**_)_**_gerekmektedir. Aksi durumda diğer kullanıcılar yazılımlara erişemez._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adobe_cc_acrobat_pro_step10.png)

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *