[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirlanmis-ve-imzalanmis-bir-yazi-istendigi-durumda-tamamen-yok-edilebilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4538


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirlanmis-ve-imzalanmis-bir-yazi-istendigi-durumda-tamamen-yok-edilebilir-mi)

# EBYS'de hazırlanmış ve imzalanmış bir yazı istendiği durumda tamamen yok edilebilir mi?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Hayır. EBYS'lerde üretilmiş ve e-imzalanmış evraklar yok edilemez.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.