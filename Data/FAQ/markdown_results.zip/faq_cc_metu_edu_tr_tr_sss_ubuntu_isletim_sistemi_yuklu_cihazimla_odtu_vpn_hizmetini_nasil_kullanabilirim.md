[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ubuntu-isletim-sistemi-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2020 **Görüntüleme:** 16847


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-vpn-service-ubuntu-os-installed-devices "How can i use METU VPN Service on Ubuntu OS installed devices?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ubuntu-isletim-sistemi-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim "Ubuntu işletim sistemi yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?")

# Ubuntu işletim sistemi yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

**Ubuntu işletim sistemi yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?**

ODTÜ VPN hizmeti ile birlikte, mensup ve öğrencilerimiz yerleşke dışında bulundukları sürelerde kullandıkları kişisel bilgisayarlara ya da mobil cihazlara kuracakları küçük bir paket program vasıtasıyla (VPN Client), üniversitemiz yerleşke içi ağ kaynaklarına erişebileceklerdir.

Önemli Uyarı: VPN üzerinden bağlanan kullanıcılarımızın bağlantı hızları kullanıcı başına 8 Mbps olarak şekillendirilmektedir. Bu nedenle VPN bağlantısına ihtiyacınız kalmadığı durumlarda VPN bağlantınızı sonlandırmanızı öneririz.

**Via 3.1.0 Linux paketi ile birlikte Ubuntu 18.04 LTS işletim sistemi desteği gelmiş ancak 12.04 LTS işletim sistemi desteği sonlandırılmıştır.**

Via 3.1.0 Linux yazılımı kurulumundan ya da yükseltme işleminden önce aşağıdaki paketlerin kurulu olması gerekmektedir:

- libqtcore4
- libqtgui4
- libgnome-keyring0

Bu paketlere **packages.ubuntu.com** adresi üzerinden erişim sağlanabilmekte ve **sudo apt install <package name>** komutu ile kurulum yapılabilmektedir.

**netregister.metu.edu.tr** adresine giriş yapıp VPN service bağlantısında gelen işletim sisteminize uygun yazılımı indirdikten sonra kurulumu çalıştırınız.

![](<Base64-Image-Removed>)

Gelen ekranlardan Next (İleri), Install (Kur) seçeneklerine tıklayarak ve yönetici işlemleri için kullandığınız şifrenizi girerek kurulumu tamamlayınız.

![](<Base64-Image-Removed>)

Kurulum sonlandığında karşınıza gelen ekranda Remote Server kısmına **border.metu.edu.tr**, Username ve Password kısmına da ODTÜ kullanıcı adı ve şifrenizi girerek Login (Giriş)’e basınız.

![Profile Selection](https://faq.cc.metu.edu.tr/system/files/u21699/profile_page.png)

**default** profili seçiniz.

Servis ilk açıldığında Not Connected (Bağlı Değil) olarak gelecektir. Bağlantı kurmak istediğinizde Connect (Bağlan) diyerek bağlantı kurabilir, ihtiyacınız kalmadığı durumda Disconnect (Bağlantıyı Sonlandır) diyerek bağlantıyı kesebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/u21699/ubuntu_0.png)