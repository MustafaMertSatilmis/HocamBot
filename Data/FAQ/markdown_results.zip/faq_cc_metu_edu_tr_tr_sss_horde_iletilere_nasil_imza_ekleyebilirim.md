[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-iletilere-nasil-imza-ekleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7191


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-iletilere-nasil-imza-ekleyebilirim)

# Horde iletilere nasıl imza ekleyebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### İletilere nasıl imza ekleyebilirim?

Seçenekler / Posta menüsünde Kişisel Bilgiler bölümünde imzanızı ekleyebilirsiniz. İmzanızı kaydettikten sonra göndereceğiniz tüm iletilere imzanız otomatik olarak eklenecektir. İmzanızın ileti oluşturma sayfasında da görünmesi için Seçenekler / Posta menüsünde İleti Oluşturma bölümünde "İmzanız yeni ileti oluşturma penceresinde görüntülensin mi?" onay kutusunu işaretlemeniz gerekmektedir.