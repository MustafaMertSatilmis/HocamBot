[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/evrak-hazirlama-sirasinda-kontrole-gonder-dugmesi-ne-ise-yaramaktadir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4924


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/evrak-hazirlama-sirasinda-kontrole-gonder-dugmesi-ne-ise-yaramaktadir)

# Evrak hazırlama sırasında "Kontrole Gönder" düğmesi ne işe yaramaktadır?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Hazırlanan evrakın onay sürecine girmeden önce bir başka kişi tarafından kontrol edilmesi gerekiyorsa, evrak hazırlanan ekranın üzerinde bulunan "Kontrole Gönder" işlevi kullanılabilir.

**Bir evrakı kontrole gönderme**

Evrakı herhangi bir sınır olmadan istediğiniz kere istediğiniz kişiye kontrole gönderebilirsiniz. Gönderdiğiniz kişi daha önce gönderdiğiniz kişiden farklı da olabilir aynı da olabilir. Evrak aynı anda sadece bir kişiye kontrole gönderilebilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/kontrolegonder.png) "Kontrole Gönder" düğmesine basıldıkran sonra karşınıza kullanıcı seçme ekranı çıkar:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/kullanicisec.png)

Açılır listeden evrakı kontrol edecek kişiyi seçiniz. Ardından "Tamam" butona bastığınızda evrak ilgili kişiye gidecektir.

**Kontrol için gelmiş bir evrakta neler yapılabilir?**

Kontrol için evrak gönderilen kişi;

1- Evrakı tıpkı hazırlayan kişi gibi değiştirebilir ve yazıyı oluşturan kişiye gönderir. Not: Kimin hangi değişikliği yaptığı bilgisi tutulmaz. Yazıyı hazırlayan kişi olarak daima yazıyı ilk başlatan kişi görünür. Bununla birlikte akış tarihçesinde yazının kontrole gittiği kişiler tek tek tarihleri ile birlikte listelenir.

2- Belirtecek olduğu değişiklikleri uygulaması için yazıyı hazırlayan kişiye notlar bırakır ve yazıyı oluşturana gönderir. Aşağıda notların nasıl bırakılabileceği anlatılmıştır.

3- Evrakta hiçbir sorun yoksa doğrudan yazıyı oluşturan gönder ![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/yaziyiolusturanagonder.png) düğmesine basıp karşısına gelen "Neden" bölümüne "uygundur", "tamam" gibi bir ifade yazar ve yazıyı hazırlayana gönderir. Eğer bu yazı, kontrol için gönderilen kişi ile ilgili değilse kontrol için gönderilmiş olan kişi "Neden" bölümüne "benimle ilgili değil" gibi bir ifade yazarak kontrol işlemi gerçekleştirmediğini belirtebilir.

**Düzeltme notları iki farklı şekilde eklenebilir:**

1- "Neden" alanına eklenen notlar. (Evrakı gören herkes tarafından akış tarihçesinde sürekli görülür ve silinemez.)

2- "Notlar" düğmesinden eklenen notlar. (Notu ekleyen kişi tarafından istediği zaman silinebilir.)

**"Neden" alanına eklenen notlar**

"Neden" alanı ile not eklemek için yazıyı oluşturana gönder ![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/yaziyiolusturanagonder.png) düğmesine basılır. Ardından karşınıza not ekleme alanı gelir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/neden.png)

Bu alana yazdığınız ifadeler akış tarihçesinde görülür. Ve daha sonra silinemez. Evrağı daha önce veya daha sonra görebilen herkes akış tarihçesindeki bu notunuzu görebilir. Notunuzun sürekli herkes tarafından akış tarihçesinde görünür kalmasını istiyorsanız bu kısımdan not ekleyebilirsiniz.

**"Notlar" düğmesinden eklenen notlar**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/notlar.png) Evrak üzerindeki notlar düğmesine basılır. Açılan bölümden yeni not ![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/yeninot.png) düğmesine basılır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/notgiris.png)

Açılan kısımdan ilgili not girilir ve üstteki "Ekle" butonuna basılır. Buradan eklediğiniz notları daha sonra silebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.