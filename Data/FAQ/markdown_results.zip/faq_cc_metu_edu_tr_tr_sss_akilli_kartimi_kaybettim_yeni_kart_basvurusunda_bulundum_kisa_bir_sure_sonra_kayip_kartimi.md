[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-kaybettim-yeni-kart-basvurusunda-bulundum-kisa-bir-sure-sonra-kayip-kartimi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-01-2025 **Görüntüleme:** 3124


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-lost-my-smartcard-and-apply-new-one-after-short-time-i-found-my-lost-smartcard-what-can-i "I have lost my smartcard and apply for a new one, after a short time I found my lost smartcard. What can I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-kaybettim-yeni-kart-basvurusunda-bulundum-kisa-bir-sure-sonra-kayip-kartimi "Akıllı kartımı kaybettim, yeni kart başvurusunda bulundum. Kısa bir süre sonra kayıp kartımı buldum ne yapabilirim?")

# Akıllı kartımı kaybettim, yeni kart başvurusunda bulundum. Kısa bir süre sonra kayıp kartımı buldum ne yapabilirim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

```
Akıllı kartınızı kaybedip yeni kart başvurusunda bulunduğunuzda (kayıp/çalıntı kart seçeneği ile), kaybolan akıllı kartınız otomatik olarak pasif moda alınarak kimsenin kullanamaması sağlanır. Kayıp kartınızı, yeni kartınız basılmadan bulursanız Bilgi İşlem Merkezi'ne (B-14 nolu ofis) başvurabilirsiniz. Kartınız kontrol edilip çalışır durumda olduğu görüldükten sonra, eğer yeni kart başvurunuz baskı aşamasında değilse tekrar aktif moda alınabilir.

Kartınızı aktive etmek için öncelikle yeni kart başvurunuzu CardInfo üzerinden (https://cardinfo.metu.edu.tr/) iptal etmeniz gerekmektedir. Bu işlemi kart başvurunuz Öğrenci İşleri tarafından onaylanmadıysa yapabilirsiniz (yeni kart başvurunuz Öğrenci İşleri tarafından onaylandıysa, kartınız basım sürecine girmiş demektir).
```