[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imzasi-olmayan-bir-kisiye-gonderilen-yazi-nasil-imzalanabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4868


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imzasi-olmayan-bir-kisiye-gonderilen-yazi-nasil-imzalanabilir)

# E-imzası olmayan bir kişiye gönderilen yazı nasıl imzalanabilir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

E-imzası olmayan kişiler sistemde e-imzalama işlemi yapamazlar. Bu nedenle yazı iade edilerek ıslak imza yöntemi ile ilerlenebilir.

Islak imza ile ilgili daha ayrıntılı bilgiye [https://faq.cc.metu.edu.tr/tr/sss/islak-imzaya-gondermek-ile-e-imzaya-gondermek-arasindaki-farklar-nelerdir](https://faq.cc.metu.edu.tr/tr/sss/islak-imzaya-gondermek-ile-e-imzaya-gondermek-arasindaki-farklar-nelerdir) adresinden ulaşılabilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.