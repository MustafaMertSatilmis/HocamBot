[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-duyurular-ozelligi-nedir-nasil-goruntulenir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5379


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-duyurular-ozelligi-nedir-nasil-goruntulenir)

# EBYS’de duyurular özelliği nedir? Nasıl görüntülenir?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

Duyurular özellliği, EBYS üzerinden yapılan duyuruların size ulaşmasını sağlar.

Duyurulara ulaşmak için sağ üstteki duyurular simgesine tıklayabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/duyurular.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.