[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imzam-yok-nasil-elde-edebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 30-09-2024 **Görüntüleme:** 12151


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-dont-have-e-signature-how-can-i-get-it "I don't have an e-signature, how can I get it?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imzam-yok-nasil-elde-edebilirim "E-imzam yok, nasıl elde edebilirim?")

# E-imzam yok, nasıl elde edebilirim?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Bireysel ya da kurum ödemeli olarak elektronik imza edinmeniz mümkündür. Kamu kurumları, Başbakanlık genelgesi gereği elektronik sertifikalarını TÜBİTAK UEKAE'ye bağlı Kamu Sertifikasyon Merkezi'nden temin etmek durumundadırlar. Kurum ödemeli elektonik imza temin edilebilecek personel, **E-imza** talebini ODTÜ kullanıcı adı ve parolası ile giriş yapılan

[**http://e-imza.metu.edu.tr/**](http://e-imza.metu.edu.tr/)

adresindeki formu doldurarak yapabilir.

İlgili adrese **yerleşke dışından** erişebilmek için lütfen **VPN hizmetini** kullanınız. VPN hizmeti ile ilgili bilgi almak ve kurulumu için [https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) adresini ziyaret edebilirsiniz.

Bireysel olarak elektronik imza satın almak isteyenler için elektronik imza temin etmeye yetkili kurumlar

[https://www.btk.gov.tr/elektronik-sertifika-hizmet-saglayicilari](https://www.btk.gov.tr/elektronik-sertifika-hizmet-saglayicilari)

adresinden öğrenilebilir. Alternatif kurumlardan temin edilen Nitelikli Elektronik Sertfika (e-imza) ücretlerini kişiler kendileri karşılamak durumundadır.

Daha önceden temin edilmiş elektronik imza kart okuyucunuz varsa kullanabilirsiniz.