[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Kablosuz Ağ

|     |
| --- |
| [Android işletim sistemi yüklü telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-isletim-sistemi-yuklu-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim) |
| [iPhone telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim) |
| [Mac bilgisayarımdan eduroam kablosuz ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mac-bilgisayarimdan-eduroam-kablosuz-agina-nasil-baglanabilirim) |
| [meturoam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/meturoam) |
| [Windows 10 bilgisayarımdan eduroam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-10-bilgisayarimdan-eduroam-agina-nasil-baglanabilirim) |
| [Hangi cihazlar meturoam bağlantısını desteklememektedir?](https://faq.cc.metu.edu.tr/tr/sss/hangi-cihazlar-meturoam-baglantisini-desteklememektedir) |
| [İnternet bağlantım çok yavaş. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir-0) |
| [Kablosuz ağa bağlı görünüyorum ancak İnternet'e erişemiyorum. Ne Yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/kablosuz-aga-bagli-gorunuyorum-ancak-internete-erisemiyorum-ne-yapmaliyim) |
| [meturoam şifremi unuttum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/meturoam-sifremi-unuttum-ne-yapabilirim) |
| [ODTÜ Kablosuz Ağı nasıl yönetiliyor?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablosuz-agi-nasil-yonetiliyor) |
| [ODTÜ Kablosuz Bilgisayar Ağı Kullanım Kuralları nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablosuz-bilgisayar-agi-kullanim-kurallari-nelerdir) |
| [ODTÜ'de kablosuz bilgisayar ağı var mı, nasıl faydalanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtude-kablosuz-bilgisayar-agi-var-mi-nasil-faydalanabilirim) |

[![Subscribe to Kablosuz Ağ](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/39/all/feed "Subscribe to Kablosuz Ağ")