[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#main-menu)

﻿

-A+A

**Son Güncelleme:** 12-02-2024 **Görüntüleme:** 12539


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari)

# EBYS Yardım Videoları

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

1. **[EBYS'de Kurum İçi Yazışma Nasıl Yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#kurumiciyazisma)**
2. **[EBYS'de Kurum Dışı Yazışma Nasıl Yapılır?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#kurumdisiyazisma)**
3. **[EBYS'de Nasıl Şablon Oluşturulur?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#sablonolusturma)**
4. **[EBYS'de Şablondan Yazı Nasıl Oluşturulur?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#sablondanyaziolusturma)**
5. **[EBYS'de Makale Ödülü Formu Nasıl Doldurulur?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#makaleoduluformu)**
6. **[EBYS'de E-imza Nasıl Kullanılır?](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#eimzakullanimi)**
7. [**EBYS'de Nasıl Vekalet Verilir?**](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#vekaletverme)
8. [**EBYS'de Verilen Vekalet Nasıl İptal Edilir?**](https://faq.cc.metu.edu.tr/tr/sss/ebys-yardim-videolari#vekaletiptali)

EBYS ilgili sorular [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletilebilir.

* * *

**1) EBYS'de Kurum İçi Yazışma Nasıl Yapılır?**

EBYS'de Kurum İçi Yazışma - YouTube

ODTU BIDB IYG

5 subscribers

[EBYS'de Kurum İçi Yazışma](https://www.youtube.com/watch?v=WCuViWZ6VwY)

ODTU BIDB IYG

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

More videos

## More videos

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=WCuViWZ6VwY&embeds_referring_euri=https%3A%2F%2Ffaq.cc.metu.edu.tr%2F)

0:00

0:00 / 4:59•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=WCuViWZ6VwY "Watch on YouTube")

**2) EBYS'de Kurum Dışı Yazışma Nasıl Yapılır?**

EBYS'de Kurum Dışı Yazışma - YouTube

ODTU BIDB IYG

5 subscribers

[EBYS'de Kurum Dışı Yazışma](https://www.youtube.com/watch?v=c4d06WAU2LM)

ODTU BIDB IYG

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

More videos

## More videos

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=c4d06WAU2LM&embeds_referring_euri=https%3A%2F%2Ffaq.cc.metu.edu.tr%2F)

0:00

0:00 / 2:54•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=c4d06WAU2LM "Watch on YouTube")

**3) EBYS'de Nasıl Şablon Oluşturulur?**

EBYS'de Şablon Oluşturma - YouTube

ODTU BIDB IYG

5 subscribers

[EBYS'de Şablon Oluşturma](https://www.youtube.com/watch?v=KwJTAfKLnuM)

ODTU BIDB IYG

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

More videos

## More videos

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=KwJTAfKLnuM&embeds_referring_euri=https%3A%2F%2Ffaq.cc.metu.edu.tr%2F)

0:00

0:00 / 3:31•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=KwJTAfKLnuM "Watch on YouTube")

**4) EBYS'de Şablondan Yazı Nasıl Oluşturulur?**

EBYS'de Şablondan Yazı Oluşturma - YouTube

ODTU BIDB IYG

5 subscribers

[EBYS'de Şablondan Yazı Oluşturma](https://www.youtube.com/watch?v=-GwE8CC3hNA)

ODTU BIDB IYG

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

More videos

## More videos

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=-GwE8CC3hNA&embeds_referring_euri=https%3A%2F%2Ffaq.cc.metu.edu.tr%2F)

0:00

0:00 / 0:51•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=-GwE8CC3hNA "Watch on YouTube")

**5) EBYS'de Makale Ödülü Formu Nasıl Doldurulur?**

Makale ödülü başvurularının 1 Ekim 2020 tarihinden itibaren Akademik Performans Değerlendirme Süreç Yönetim Sistemi ( [https://apsis.metu.edu.tr/](https://apsis.metu.edu.tr/)) üzerinden yapılacak olması nedeniyle EBYS Makale Ödülü Başvuru Formu erişime kapatılmıştır. Konuyla ilgili sorular Akademik Programlar ve Eğitim Koordinatörlüğüne e-posta yoluyla ( [apek@metu.edu.tr](mailto:apek@metu.edu.tr)) iletebilir.

**6) EBYS'de E-imza Nasıl Kullanılır?**

Yeni e-imza altyapısı için [https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-y...](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client) adresini ziyaret edebilirsiniz.

**7) EBYS'de Nasıl Vekalet Verilir?**

EBYS'de Nasıl Vekalet Verilir? - YouTube

ODTU BIDB IYG

5 subscribers

[EBYS'de Nasıl Vekalet Verilir?](https://www.youtube.com/watch?v=fT2jrXVk0cQ)

ODTU BIDB IYG

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

More videos

## More videos

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=fT2jrXVk0cQ&embeds_referring_euri=https%3A%2F%2Ffaq.cc.metu.edu.tr%2F)

0:00

0:00 / 0:33•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=fT2jrXVk0cQ "Watch on YouTube")

**8) EBYS'de Verilen Vekalet Nasıl İptal Edilir?**

EBYS'de Verilen Vekalet Nasıl İptal Edilir? - YouTube

ODTU BIDB IYG

5 subscribers

[EBYS'de Verilen Vekalet Nasıl İptal Edilir?](https://www.youtube.com/watch?v=GkorTISGngs)

ODTU BIDB IYG

Search

Watch later

Share

Copy link

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

More videos

## More videos

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

[Watch on](https://www.youtube.com/watch?v=GkorTISGngs&embeds_referring_euri=https%3A%2F%2Ffaq.cc.metu.edu.tr%2F)

0:00

0:00 / 0:23•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=GkorTISGngs "Watch on YouTube")