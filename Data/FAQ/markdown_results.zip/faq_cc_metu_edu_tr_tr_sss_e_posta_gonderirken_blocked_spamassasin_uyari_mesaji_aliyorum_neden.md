[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-blocked-spamassasin-uyari-mesaji-aliyorum-neden#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8852


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/while-sending-e-mail-i-get-message-blocked-spamassasin-alert-message-why "While sending an e-mail I get the message \"blocked by SpamAssasin\" alert message. Why?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-blocked-spamassasin-uyari-mesaji-aliyorum-neden "E-posta gönderirken \"blocked by SpamAssasin\" uyarı mesaji alıyorum. Neden?")

# E-posta gönderirken "blocked by SpamAssasin" uyarı mesaji alıyorum. Neden?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Giden e-postalarda uygulanacak olan spam filtresi uygulamasıyla , ODTÜ'den dışarıya giden "spam" e-posta sayısının azaltılması planlanmaktadır. Bu kapsamda, bir e-posta, spam filtresine takıldığında, kullanıcının kullandığı e-posta programı aracılığıyla kendisine uyarı mesajı iletilecektir.

E-posta programlarına göre alınacak uyarı mesajları aşağıda listelenmiştir.

**Horde Uyarı Mesajı**

- İleti gönderilerken hata oluştu: Failed to send data \[SMTP: Invalid response code received from server (code: 550, response: 5.7.1 Blocked by SpamAssassin)\]

![Horde Hata Mesajı](https://faq.cc.metu.edu.tr/system/files/horde_hata.jpg)

**Squirrelmail Uyarı Mesajı**

- HATA: İstenen eylem gerçekleşmedi: posta kutusu yok

Server replied: 550 5.7.1 Blocked by SpamAssassin

![Squierrel Hata Mesajı](https://faq.cc.metu.edu.tr/system/files/squirrel_hata.jpg)

**IMAP/POP3 Client Uyarı Mesajı**

- An error occured while sending mail. The mail server responded: 5.7.1 Blocked by SpamAssassin . Please check the message and try again.

![Imap/Pop3 Client  Hata Mesajı](https://faq.cc.metu.edu.tr/system/files/imap_pop3_hata.jpg)