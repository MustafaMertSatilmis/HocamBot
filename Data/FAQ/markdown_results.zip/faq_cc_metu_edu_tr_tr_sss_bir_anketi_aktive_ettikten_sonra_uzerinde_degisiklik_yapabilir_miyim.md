[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-anketi-aktive-ettikten-sonra-uzerinde-degisiklik-yapabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6949


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-modify-survey-after-activation "Can I modify a survey after activation?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-anketi-aktive-ettikten-sonra-uzerinde-degisiklik-yapabilir-miyim "Bir anketi aktive ettikten sonra üzerinde değişiklik yapabilir miyim?")

# Bir anketi aktive ettikten sonra üzerinde değişiklik yapabilir miyim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Oluşturduğunuz bir anketi kullanıma açmak için önce aktive etmelisiniz. Aktive edilmiş bir ankette sadece soruların kodu/başlığı/içeriği, soru gruplarının ismi/açıklaması, yanıt opsiyonlarının içeriği ve anket ismi/açıklaması değiştirilebilmektedir. Soru eklemek/çıkarmak, soru grubu eklemek/çıkarmak, alt soru eklemek/çıkarmak ve bunların kodunu değiştirebilmek için anketi deaktive etmeniz gerekmektedir.