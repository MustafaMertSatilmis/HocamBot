[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/talep-etmis-oldugum-iade-hala-akilli-kimlik-kartima-yuklenmedi-sorun-ne-olabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-11-2021 **Görüntüleme:** 7491


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/refund-i-requested-has-still-not-been-loaded-my-smart-card-what-could-be-problem "The refund that I requested has still not been loaded to my smart card. What could be the problem?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/talep-etmis-oldugum-iade-hala-akilli-kimlik-kartima-yuklenmedi-sorun-ne-olabilir "Talep etmiş olduğum iade hala akıllı kimlik kartıma yüklenmedi. Sorun ne olabilir?")

# Talep etmiş olduğum iade hala akıllı kimlik kartıma yüklenmedi. Sorun ne olabilir?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

İade edilen para akıllı kartınıza değil, iade sürecinde IBAN numarasını belirtmiş olduğunuz vadesiz veya kredi kartı hesabınıza aktarılmaktadır. İade sürecinin sonuçlanması ilgili brimlerin onayı ile gerçekleştiği için süreç biraz uzayabilmektedir.