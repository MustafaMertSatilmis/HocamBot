[Jump to navigation](https://faq.cc.metu.edu.tr/tr/microsoft-visual-studio#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-05-2022 **Görüntüleme:** 16410


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/microsoft-visual-studio "MICROSOFT VISUAL STUDIO")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/microsoft-visual-studio "MICROSOFT VISUAL STUDIO")

# MICROSOFT VISUAL STUDIO

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT VISUAL STUDIO** **2022** **—**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/microsoft-visual-studio#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/microsoft-visual-studio#aktivasyon)

* * *

**_\[1\] Personel için not:_** _Microsoft_ _Visual_ _Studio_ _yazılımı sadece personelin kullanımına açıktır._

**_\[2\] Öğrenciler için not:_**_Microsoft Visual Studio yazılımını kullanabilmek için_ [_bu sayfada_](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware) _yer alan yönergeleri takip ederek **“Öğretim için Azure Geliştirici Araçlar”** hizmetine metu.edu.tr uzantılı e-posta adresinizle kaydolunuz. Bu işlemden sonra ilgili yazılıma erişip kullanabilirsiniz._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“SW\_ELECTRONIC\_VS\_Professional\_2022\_MultiLang\_MLF\_X22-95048”_** _dosyasına tıklayarak yükleyiciyi çalıştırınız. (Gerekiyor ise yükleyici dosyasının üzerine sağ tıklayıp yönetici olarak çalıştırınız.)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step1.png)

**_ADIM-2_**

**_“Continue”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step2.png)

**_ADIM-3_**

_Kurulum başlamadan önce ekranda aşağıda yer alan pencere açılacaktır. Kurulum ekranı gelene kadar bu pencereyi kapatmayınız!_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step3.png)

**_ADIM-4_**

_Yükleyiciyi çalıştırdıktan sonra gelen kurulum ekranından yüklemek istediğiniz bileşenleri seçiniz._ _Daha sonra_**_“Install while downloading”_**_seçeneğini seçiniz ve_**_“Install”_**_butonuna tıklayarak kurulumu başlatınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step4.png)

**_ADIM-5_**

**_“Continue”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step5.png)

**_ADIM-6_**

_Yükleyici seçilen ürünleri indirerek yüklemeye başlayacaktır. Seçtiğiniz bileşenler internetten indirilip kurulurken bir süre bekleyiniz. Bekleme süreniz seçtiğiniz bileşenlerin sayısı ile doğru orantılı olarak değişecektir. Yükleme devam ederken açılan ekranda_**_“Start after installation”_** _seçeneğini işaretleyiniz ve kurulumun bitmesini bekleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step6.png)

**_ADIM-7_**

_İlk açılışta eğer bir Microsoft Visual Studio hesabınız varsa_ **_"Sign in"_** _, hesap oluşturmak isterseniz_ **_"Create one!"_** _, hesap oluşturmadan devam etmek isterseniz_**_"Not now, maybe later"_** _seçeneğine basarak devam edebilirsiniz. Bu kurulum anlatımında hesap oluşturulmadan devam edilecektir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step7.png)

**_ADIM-8_**

**_“Start Visual Studio_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step8.png)

**_ADIM-9_**

**_“Launch”_**_butonuna tıklayarak yazılımı başlatınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step9.png)

**_ADIM-10_**

**_“Continue without code_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step10.png)

**_ADIM-11 <<<AKTİVASYON>>>_**

_Yazılımın aktivasyon işlemini gerçekleştirmek için_ **_“Help”_** _menüsü altında yer alan_ **_“Register Visual Studio”_** _seçeneğine tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step11.png)

**_ADIM-12_**

_Bilgisayarınızda ofis yazılımlarının aktivasyon işlemini daha önceden yapmış iseniz kurulumdan sonra Microsoft Visual Studio yazılımı arka planda aktivasyon işlemini gerçekleştirecektir. Aktivasyon işlemi sorunsuz bir şekilde tamamlandığında ekranda **"License: Product key applied"** ifadesi görülecektir._

_Aktivasyon ile ilgili sorun yaşıyorsanız eğer; açılan sayfada sağ tarafta bulunan **"Unlock with a Product Key"**seçeneğine tıklayınız ve lisanslı yazılımlar sayfasından indirdiğiniz ürün anahtarı bilgisini girerek aktivasyon işlemini tekrarlayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_visual_studio_2022_step12.png)

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *