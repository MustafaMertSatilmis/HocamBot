[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcube-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 3310


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcube-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim)

# Roundcube ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube, merkezi sunucular üzerinde verilmekte olan elektronik posta servislerine, ODTÜ içi ve ODTÜ dışından herhangi bir web tarayıcısı (Mozilla Firefox, Chrome vb.) aracılığıyla  modern bir arayüz ile erişilebilmesini sağlayan bir webmail servisidir. Bu servise [https://metumail.metu.edu.tr/](https://metumail.metu.edu.tr/ "https://metumail.metu.edu.tr/") adresindeki ilgili bağlantı tıklanarak ulaşılabileceği gibi, [https://webmail.metu.edu.tr](https://webmail.metu.edu.tr/ "https://webmail.metu.edu.tr") adresinden direkt olarak da ulaşılabilir.