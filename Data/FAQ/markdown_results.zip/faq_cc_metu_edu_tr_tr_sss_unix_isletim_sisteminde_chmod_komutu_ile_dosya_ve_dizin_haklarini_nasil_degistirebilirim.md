[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/unix-isletim-sisteminde-chmod-komutu-ile-dosya-ve-dizin-haklarini-nasil-degistirebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 10747


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-change-file-and-directory-permissions-unix-operating-system-chmod-command "How can I change the file and directory permissions in Unix operating system with the 'chmod' command?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/unix-isletim-sisteminde-chmod-komutu-ile-dosya-ve-dizin-haklarini-nasil-degistirebilirim "Unix işletim sisteminde 'chmod' komutu ile dosya ve dizin haklarını nasıl değiştirebilirim?")

# Unix işletim sisteminde 'chmod' komutu ile dosya ve dizin haklarını nasıl değiştirebilirim?

[Web Servisleri](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri)

Unix üzerindeki dizin ve dosya adları "ls" komutu ile görülebilir. Ancak dosya adlarını belli tercihlerle de görebilmek mümkündür.

|     |     |
| --- | --- |
| -a | '.' ile başlayan gizli dosyalar dahil, dizinin tüm içeriğini listeler |
| -l | Dosyalar hakkında daha ayrıntılı bilgiler vererek listeleme yapar<br>_(Son işlem tarihi, dosya ile ilgili izin hakları )_ |
| -t | Dosyaları değişime uğrama zamanlarına göre sıralar |
| -R | Alt dizinlerin içerikleri ile birlikte tüm dosyaları listeler |

Unix üzerinde her dosya veya dizin için, dosya sahibi, gruptakiler ve diğerlerine verilmiş olan okuma, yazma ve çalıştırma izinleri vardır. Belli bir dosya ile ilgili verilmiş izinler "ls -l" konutu ile görülebilmektedir.

|     |
| --- |
| bash-2.03$ ls -l<br>total 100<br>-rw------- 1 usrname usrgrp 1156 Nov 29 14:30 dead.letter<br>-rw-r--r-- 1 usrname usrgrp   11 Dec 19 17:29 document1<br>drwx------ 2 usrname usrgrp  512 Nov 29 14:44 mail<br>drwxr-xr-x 5 usrname usrgrp  512 Nov 29 11:56 wwwhome |

Yukarıdaki ifadede wwwhome ile ilgili özellikleri biraz daha detaylı incelediğimizde 7 temel sütundan oluştuğunu görürüz.

|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
| _1_ | _2_ | _3_ | _4_ | _5_ | _6_ | _7_ |
| drwxr-xr-x | 5 | username | usergroup | 512 | Nov 29 11:56 | wwwhome |

**1\. Sütun** wwwhome dizininin _okuma, yazma ve çalıştırma_ ile ilgili tanımlanan haklarını göstermektedir. 10 karakterden oluşmaktadır.

drwxr-xr-x ifadesinde ilk karakter "-","d" ya da "l" değerlerini alabilmekte ve sırasıyla "dosya", "dizin" veya "bağlantı" olduğunu göstermektedir.

Sonraki dokuz karakterden ilk üçü kullanıcıya, ortadaki üç karakterlik grup kullanıcının dahil olduğu gruba en sondaki üç karakterlik grup da diğer kullanıcılara verilen izin haklarını göstermektedir.

Her üçlü grupta yer alan karakterler soldan sağa doğru sırasıyla okuma, yazma ve çalıştırma (ilgili dizini açma) haklarını göstermektedir.

**2\. Sütun;** Dosya için geçerli bağlantı sayısını gösterir. Bir dizin için bağlantı sayısı, bu dizinin içinde bulunduğu ve kendisine bağlı bulunan dizin sayılarının toplamıdır.

**3\. ve 4. Sütunlar;** Kullanıcı adı ve kullanıcının bağlı olduğu grubu,

**5\. Sütun;** Dosyanın büyüklüğünü veya ilgili dizin için ayrılmış karakter sayısını,

**6\. Sütun;** ilgili dizinde yapılan son değişiklik tarihini,

**7\. Sütun** da dizin veya dosya adını göstermektedir.

Okuma, yazma ve çalıştırma ile ilgili tanımlanan haklar sadece dosya sahibi tarafından verilmekte ya da değiştirilebilmektedir. Bir dosya veya dizine verilen izinler "chmod" komutuyla değiştirilebilir. Komutun yazımı;

> chmod \[izinmodu\] \[dosyaadi\]

şeklindedir. İzin modu, aşağıdaki tabloda gösterildiği gibi sınıf, izin alma/verme ve izin karakterlerinden oluşur. İzin '+' işareti ile verilir, '-' işareti ile geri alınır. Dosya adı, izinleri değiştirilecek dosyanın adıdır. Örneğin:

|     |
| --- |
| bash-2.03$ chmod go-x wwwhome   1<br>bash-2.03$ ls -l wwwhome        2<br>total 102<br>drwxr--r-- 2 username usergroup 512 Nov 29 11:56 wwwhome |

Yukarıdaki örnekte 1. satırda **"wwwhome"** dizini için **"chmod go-x"** komutu uygulanmıştır.

2\. satırda ise **"ls -l"** komutu ile **"wwwhome"** dizininin izin hakları kontrol edilmiş ve **"wwwhome"** dizinine kullanıcı haricindeki herkesin yazma ve çalıştırma (dizin içine girebilme) izinlerinin alınmış olduğu görülebilmektedir.