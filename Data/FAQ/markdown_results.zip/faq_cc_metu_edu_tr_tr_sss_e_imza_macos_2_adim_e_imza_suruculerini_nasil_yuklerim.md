[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-2-adim-e-imza-suruculerini-nasil-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-07-2023 **Görüntüleme:** 3468


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-2-adim-e-imza-suruculerini-nasil-yuklerim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 2. Adım: E-imza sürücülerini nasıl yüklerim?\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- [https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu\_yukleme\_servisi/](https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu_yukleme_servisi/) adresine gidiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.43.38.png)

2- İşletim sisteminizi, versiyonunu ve tipini seçiniz. Hangilerini seçeceğinizden emin değilseniz bölümünüzün/biriminizin bilgisayar koordinatöründen bilgi alınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.43.54.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.44.08.png)

3- Kart okuyucunuzun modelini seçtikten sonra Sürücüleri Göster düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.44.19.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.44.26.png)

4- Öncelikle "Kurulum 1: Akıllı Kart Sürücüsü"nü indiriniz. İndirdikten sonra resimlerdeki gibi kurulumu tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.44.34.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.44.44.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.45.34.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.45.41.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.45.57.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.46.03.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.46.19.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.46.48.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.46.56.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.47.09.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.47.19.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.47.34.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.48.46.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.48.53.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.00.png)

5- Ardından "Kurulum 2: Kart Okuyucu Sürücüsü"nü indiriniz. İndirdikten sonra resimlerdeki gibi kurulumu tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.09.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.18.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.26.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.33.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.50.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.49.57.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.50.03.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.50.10.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.50.17.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.50.23.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.50.31.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.50.43.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.51.32.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.51.39.png)

İşlem tamamlanmıştır.