[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabima-gelen-e-postalarimi-nasil-yonlendirebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 22028


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-forward-e-mails-incoming-my-metu-mail-account "How can I forward e-mails incoming to my METU mail account?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabima-gelen-e-postalarimi-nasil-yonlendirebilirim "ODTÜ kullanıcı hesabıma gelen e-postalarımı nasıl yönlendirebilirim?")

# ODTÜ kullanıcı hesabıma gelen e-postalarımı nasıl yönlendirebilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

ODTÜ **Horde** arayüzü ile yönlendirme işlemi yapmak istiyorsanız Horde'un üst menüsündeki "Posta" seçeneğinin altındaki "Süzgeçler" kısmından "İlet" kuralına tıklayınız.. Bu özelliği kullanmak için, "İletilecek Adresler" kutucuğuna yönlendirme yapmak istediğiniz adres(ler)i (birden fazla adres yazılacak ise aralarına "," konulmalıdır) yazmanız yeterlidir. Sonrasında "Kaydet ve geçerli kıl" butonuna tıklanmalıdır.

Yönlendirmeyi iptal etmek için bir önceki sayfada bulunan Varolan Kurallar başlığındaki "İlet" bağlantsının yanındaki tik işareti tıklanmalıdır (Seçilemez Kıl İlet).

Yaptığınız işlemlerden sonra yönlendirme ayarlarınız istediğiniz şekilde çalışmıyorsa lütfen **[https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)** adresine konu ile ilgili bir vaka oluşturunuz.

27/07/2009 tarihinde uygulamaya geçilen e-posta sistemi ile artık sunucu sistemler üzerinde .forward dosyası oluşturularak yönlendirme işlemi yapılamamaktadır.

BİDB, kullanıcı hesaplarında bulunan dosyalara hicbir şekilde müdahele etmemektedir. Yönlendirme işlemi sırasında yapacağınız hatalar mesaj kaybetmenize neden olabileceğinden, yönlendirme işlemini dikkatle yapınız ve deneyerek kontrol ediniz.