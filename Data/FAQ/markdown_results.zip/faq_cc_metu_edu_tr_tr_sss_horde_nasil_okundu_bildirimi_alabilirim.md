[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-nasil-okundu-bildirimi-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5482


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-nasil-okundu-bildirimi-alabilirim)

# Horde nasıl okundu bildirimi alabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Nasıl okundu bildirimi alabilirim?

İleti oluşturma ekranında Diğer seçenekler altındaki Okundu Onayı kutusunu tıklayarak bir okundu bildirimi isteyebilirsiniz.