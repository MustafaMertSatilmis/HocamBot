[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/spam#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Spam

|     |
| --- |
| [BİDB spam/sahte e-postalar için ne yapmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/bidb-spamsahte-e-postalar-icin-ne-yapmaktadir) |
| [SPAM E-posta önleme yöntemleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir) |
| [Spam e-postaları ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/spam-e-postalari-ne-yapmaliyim) |
| [Spam olmayan bazı e-postalar SPAMBOX dizinine geliyor. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/spam-olmayan-bazi-e-postalar-spambox-dizinine-geliyor-ne-yapmaliyim) |
| [Spam ve Malware nedir?](https://faq.cc.metu.edu.tr/tr/sss/spam-ve-malware-nedir) |
| [SPAMBOX nedir?](https://faq.cc.metu.edu.tr/tr/sss/spambox-nedir) |

[![Subscribe to Spam](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/52/all/feed "Subscribe to Spam")