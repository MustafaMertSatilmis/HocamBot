[Jump to navigation](https://faq.cc.metu.edu.tr/tr/say%C4%B1#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 7866


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/say%C4%B1)

# EBYS'deki numaralar ne ifade ediyor?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de üç farklı numara kullanılmaktadır:

- Belge Takip no: Evrak türü - YIL ve AY - aylık sayı (örn: gelen evrak için 3201801-1)
- Süreç no: Sistemin işleyişi için kullanılan tekil bir numaradır. (örn: 337912)
- Sayı: Resmi yazışma usüllerine göre SDP (Standart Dosya Planı) bazlı verilen bir numaradır. (örn: 807.01 klasörüne kaydedilen bir evrak için 27566166-807.01-1)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.