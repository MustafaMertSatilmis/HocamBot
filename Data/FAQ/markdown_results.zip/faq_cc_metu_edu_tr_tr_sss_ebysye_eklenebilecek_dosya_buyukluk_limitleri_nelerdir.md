[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysye-eklenebilecek-dosya-buyukluk-limitleri-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2023 **Görüntüleme:** 1751


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysye-eklenebilecek-dosya-buyukluk-limitleri-nelerdir)

# EBYS'ye eklenebilecek dosya büyüklük limitleri nelerdir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Öncelikle [https://faq.cc.metu.edu.tr/tr/sss/ebysye-hangi-turde-dosyalar-eklenebilmektedir](https://faq.cc.metu.edu.tr/tr/sss/ebysye-hangi-turde-dosyalar-eklenebilmektedir) adresinden EBYS'ye eklenebilecek dosya türlerini görebilirsiniz.

Kurum içi yazışmalarda;

- Tek bir ek için eklenebilecek en büyük boyut 15 MB'dir.
- Toplamda bir evraka en fazla 100 MB'lik ek eklenebilir.

Kurum dışı yazışmalarda;

- Tek bir ek için eklenebilecek en büyük boyut 15 MB'dir.
- Eğer gönderilecek yerin KEP'i PTTKEP ise (hs01.kep.tr uzantılı KEP adresi) toplamda bir evraka en fazla 100 MB'lik ek eklenebilir.
- Eğer gönderilecek yerin KEP'i PTTKEP dışındaki yerler ise (hs02, hs03 vb.) toplamda bir evraka en fazla 25 MB'lik ek eklenebilir.
- Gönderilecek yerler arasında en az bir tane PTTKEP dışındaki KEP adresli yerin bulunması eklenebilecek toplam ek boyutunu 25 MB'ye düşürecektir.

EBYS ilgili sorular [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletilebilir.