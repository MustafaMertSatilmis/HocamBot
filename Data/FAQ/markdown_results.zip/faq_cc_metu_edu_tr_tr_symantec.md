[Jump to navigation](https://faq.cc.metu.edu.tr/tr/symantec#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 10-02-2022 **Görüntüleme:** 15891


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/symantec "SYMANTEC ENDPOINT PROTECTION")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/symantec "SYMANTEC ENDPOINT PROTECTION")

# SYMANTEC ENDPOINT PROTECTION

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **SYMANTEC ENDPOINT PROTECTION** **14.3 RU4** **—**

**_Symantec Endpoint Protection_** _sunucu ve masaüstü bilgisayarlar için kötü amaçlı yazılımdan koruma, izinsiz giriş önleme ve güvenlik duvarı özelliklerinden oluşan bir güvenlik yazılımı paketidir._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve lisanslama işlemini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/symantec#kurulum)

* * *

**_\[1\] Not:_** **_Uyarı!_** _Sistemin yeniden başlatılması istendiğinde kaydedilmemiş bütün çalışmalarınızı kaydedip **"Restart Now"** düğmesine basınız. Sisteminiz yeniden başlatıldığında kurulum tamamlanmış olacaktır._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Next_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sep_14_3_ru4_step1.png)

**_ADIM-2_**

**_“I accept the terms in the license agreement_** **_”_** _seçeneğini işaretleyiniz ve **“** **Next**_ **_”_** _butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sep_14_3_ru4_step2.png)_

**_ADIM-3_**

**_“Typical_** **_”_**_seçeneğini işaretleyiniz ve **“** **Next**_ **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sep_14_3_ru4_step3.png)

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sep_14_3_ru4_step4.png)

**_ADIM-5_**

**_“Install”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sep_14_3_ru4_step5.png)

**_ADIM-6_**

**_“Finish”_**_butonuna tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/sep_14_3_ru4_step6.png)

* * *

_**Bize ulaşın:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *