[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1037


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim)

# Roundcube'de bir iletinin tam başlık bilgisini nasıl görebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

İletinin başlık bilgisini görmek için iletiyi görüntülerken "Ayrıntılar" bağlantısına tıkladıktan sonra görünür hale gelecek olan "Tüm üst bilgiler..." bağlantısını kullanabilirsiniz.