[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyelerinin-gonderdikleri-mesajlarin-bir-kopyasinin-kendilerine-gelmemesini-saglamak-icin#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 6848


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyelerinin-gonderdikleri-mesajlarin-bir-kopyasinin-kendilerine-gelmemesini-saglamak-icin "E-liste üyelerinin gönderdikleri mesajların bir kopyasının kendilerine gelmemesini sağlamak için ne yapmalıyım ? ")

# E-liste üyelerinin gönderdikleri mesajların bir kopyasının kendilerine gelmemesini sağlamak için ne yapmalıyım ?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

**Liste üyelerinin gönderdikleri mesajların bir kopyasının kendilerine gelmemesini sağlamak için (noack)**:

**(a)** _Genel Seçenekler_ > _Ek ayarlar_ > _Bu listeye yeni üye olanlar için varsayılan ayarlar._ alanında _Üyeye kendi mesajının kopyasını gönderme_ seçeneği işaretlenir (aksi istenirse boş bırakılır.)