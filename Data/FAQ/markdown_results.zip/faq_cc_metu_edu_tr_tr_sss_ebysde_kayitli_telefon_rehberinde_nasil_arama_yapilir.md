[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kayitli-telefon-rehberinde-nasil-arama-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4143


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-kayitli-telefon-rehberinde-nasil-arama-yapilir)

# EBYS'de kayıtlı telefon rehberinde nasıl arama yapılır?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

1- Sisteme giriş yaptıktan sonra, ekranın sağ üst kenarında, isminizin solunda bulunan telefon simgesine tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u16319/tel1.png)

2- Açılan ekranda üç ayrı yerden arama yapabilirsiniz. Üst kısımdaki "Ara" bölümünden hem isim hem telefon aranabildiği gibi alttaki sütun aramalarından sadece isimden veya sadece numaradan arama yapabilmektedir.

![](https://faq.cc.metu.edu.tr/system/files/u16319/tel2.png)

Not: Aradığınız kişi bu ekranda bulunamıyorsa EBYS'de kişinin numarası kayıtlı değil demektir. Bulduğunuz numara doğru değil ise, bu değişikliği yine kişinin kendisi yapabilmektedir. EBYS'de numara ekleme/güncelleme: [https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.