[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-uyeyim-fakat-bu-listelerden-artik#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6797


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-do-not-want-receive-messages-university-administration-genel-duyuru-etc-what-can-i-do-turkish "I do not want to receive messages from university administration via genel-duyuru etc. What can I do? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-uyeyim-fakat-bu-listelerden-artik "\"genel-duyuru\", \"aras-gor-duyuru\" ve/ya \"ogr-uye-duyuru\" listelerine üyeyim, fakat bu listelerden artık mesaj almak istemiyorum, ne yapabilirim?")

# "genel-duyuru", "aras-gor-duyuru" ve/ya "ogr-uye-duyuru" listelerine üyeyim, fakat bu listelerden artık mesaj almak istemiyorum, ne yapabilirim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Üniversitemiz yönetimince mensuplarımız için çeşitli duyuru listeleri tanımlanmıştır. Öğrencilerin, akademik ve idari personelin bu listelere üyelikleri bir otomasyonla sağlanmaktadır. Bu sebeple üyelikten çıkış taleplerine yönetim kararı uyarınca izin verilmemektedir.