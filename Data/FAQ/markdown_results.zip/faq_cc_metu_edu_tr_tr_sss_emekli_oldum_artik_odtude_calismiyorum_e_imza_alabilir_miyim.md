[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/emekli-oldum-artik-odtude-calismiyorum-e-imza-alabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7894


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-retired-i-no-longer-work-metu-can-i-get-e-signature "I retired, I no longer work at METU, can I get an e-signature?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/emekli-oldum-artik-odtude-calismiyorum-e-imza-alabilir-miyim "Emekli oldum, artık ODTÜ'de çalışmıyorum, e-imza alabilir miyim?")

# Emekli oldum, artık ODTÜ'de çalışmıyorum, e-imza alabilir miyim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

ODTÜ, bir kamu kurumu olması nedeni ile e-imza teminini sadece TÜBİTAK KamuSM üzerinden yapabilmektedir.

Kurumumuz aracılığı ile TÜBİTAK KamuSM'den yapılan e-imza taleplerinde, kişinin tam zamanlı veya yarı zamanlı kadrolarda ODTÜ personeli olması şartı aranmaktadır.

Kişisel başvurular aşağıda sıralanan Elektronik Sertifika Hizmet sağlayıcıların birinden yapılabilmektedir;

E-Güven ( [https://www.e-guven.com](https://www.e-guven.com/))

TürkTrust ( [http://www.turktrust.com.tr](http://www.turktrust.com.tr/))

E-Tuğra ( [http://www.e-tugra.com.tr](http://www.e-tugra.com.tr/))

e-İmzaTR ( [http://www.e-imzatr.com](http://www.e-imzatr.com/))