[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/nokia-e5e7-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 6414


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-nokia-e5e7 "How can I find out the MAC (physical) address on a Nokia E5/E7?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/nokia-e5e7-uzerinde-mac-fiziksel-adresini-nasil-ogrenebilirim "Nokia E5/E7 üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Nokia E5/E7 üzerinde MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

1\. Ana ekrana gelin.

2\. **Tuş takımıyla\*#62209526# kodunu girin.**