[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-02-2025 **Görüntüleme:** 5643


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 3. Adım: DSClient uygulamasını nasıl yüklerim?\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- Aşağıdaki seçeneklerden bilgisayarınız için uygun olan güncel DSClient yazılımını indiriniz ve kurulum işlemini tamamlayınız.

- [DSClient (.NET CORE 3.1)](https://portal.synergynow.io/#/_redirect/4Oozb3aChfgoqwc9G0wKAc) (son versiyon: 1.5.5) _(Windows'da DSClient kurulumu yaparken öncelikle .NET Core 3.1 versiyonunun kurulup denenmesi önerilmektedir. Bu versiyonun kullanılamadığı durumda .NET Core 7.0 versiyonu kurulabilir.)_
- [DSClient (.NET CORE 7.0)](https://portal.synergynow.io/#/_redirect/1AFE4F7xQlgsEA3GcMHgbs) (son versiyon: 1.5.3)

_**ÖNEMLİ NOT:** Bilgisayarında halen 1.5.5 versiyonu öncesi DSClient yazılımı bulunan kullanıcılarımızın mevcut versiyonla sorunsuz olarak e-imzalama yapabilmesi için [https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi) sayfasında tarif edilen lisans dosyası değişikliğini yapması ya da DSClient yazılımını 1.5.5 versiyonuna güncellemesi gerekmektedir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_1.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_2.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_3.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_4.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_5.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_6.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_7.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_8.jpg)

Eğer kullandığınız antivirüs yazılımı bu dosyayı şüpheli olarak algılar ise dosyaya izin vermesini söyleyiniz. (Allow this file)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_alintisi.png)

Veya Microsoft Defender'da şu şekilde bir uyarı çıkabilir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/defender1.jpeg)

Bu uyarıdaki "More info" yazısına tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/defender2.jpeg)

Ardından karşınıza gelen "Run anyway" düğmesine tıklamalısınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_9.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_10.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_11.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsclient_12.jpg)

İşlem tamamlanmıştır.

* * *

Yukarıda tarif edilen adımları uygulamanıza rağmen EBYS'de e-imza kullanımıyla ilgili problem yaşıyorsanız ya da e-imza ile ilgili farklı sorularınız olursa [https://faq.cc.metu.edu.tr/tr/groups/e-imza](http://faq.cc.metu.edu.tr/tr/groups/e-imza) adresindeki sıkça sorulan soruları inceleyebilirsiniz.

EBYS ilgili sorularınızı [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletebilirsiniz.

* * *