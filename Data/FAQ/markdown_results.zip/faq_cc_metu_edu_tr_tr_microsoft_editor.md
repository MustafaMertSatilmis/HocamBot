[Jump to navigation](https://faq.cc.metu.edu.tr/tr/microsoft-editor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-04-2022 **Görüntüleme:** 5310


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/microsoft-editor "MICROSOFT EDITOR")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/microsoft-editor "MICROSOFT EDITOR")

# MICROSOFT EDITOR

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT EDITOR:****SPELLING & GRAMMAR CHECKER** **—**

**_Microsoft Editor_** _belgelerde, postada ve webde dilbilgisini ve daha fazlasını denetler. Editör bulduğu sorunların altını çizer. Öneriyi kabul etmek veya yok saymak için altı çizili kelimeyi veya ifadeyi seçin._

_Yazım ve dil bilgisi denetimi almak ve temel bilgilerin ötesinde iyileştirmeler almak için Microsoft Office 365 hesabınızla oturum açın._

* * *

**_\[1\] Personel ve öğrenciler için not:_** _Microsoft Editor'ü kullanmak için [bu sayfadaki](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware) yönergeleri takip edin ve metu.edu.tr e-posta adresinizle Office 365 hizmetine kaydolun. Bu işlemden sonra ilgili yazılıma erişebilir ve kullanabilirsiniz._

**_\[2\] Windows kullanıcıları için not:_**_Microsoft_ _Editor_ _, Windows için Microsoft Office 365 için Word'de mevcuttur._

**_\[3\] Mac kullanıcıları için not:_** _Microsoft_ _Editor_ _, Mac için Microsoft Office 365 için Word'de mevcuttur._

**_\[4\] Not:_** _Microsoft Word'deki Giriş sekmesinde Editor'ü bulabilirsiniz._

* * *

**Office 365 uygulamaları için Microsoft Editor**

_Microsoft Office 365 aboneleri, Word, Outlook.com ve Web için Outlook'ta premium düzenleyici özellikleri elde eder. Editor, açıklık, özlülük, resmiyet, kelime önerileri ve daha fazlası gibi gelişmiş dil bilgisi ve stil iyileştirmeleri sunar._

**Web için Microsoft Düzenleyicisi \[Tarayıcı Uzantısı\]**

_Microsoft Editor tarayıcı uzantısıyla dilbilgisi ve yazım denetimi yapabilirsiniz. Editor, Edge_ _veya Chrome'da_ _bir uzantı olarak çalışır._

_Tarayıcınızın uygulama mağazasından indirebilirsiniz:_

**_URL >>_** [**_Edge_**](https://microsoftedge.microsoft.com/addons/detail/hokifickgkhplphjiodbggjmoafhignh)

**_URL >>_** [**_Chrome_**](https://chrome.google.com/webstore/detail/microsoft-editor/gpaiobkfhnonedkhhfjpmhdalgeoebfa?authuser=2)

**Microsoft Editor** **Eğitimi**

_Bu adım adım eğitimde, Microsoft Editor’ü_ _nasıl kullanacağınızı öğrenebilirsiniz._

**_URL >>_** [**_Microsoft Editor_** **_Nasıl Kullanılır_**](https://www.youtube.com/watch?v=KK6ADQRQmRY)

* * *

_**Bize**_ _**ulaşın**_ _**:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *