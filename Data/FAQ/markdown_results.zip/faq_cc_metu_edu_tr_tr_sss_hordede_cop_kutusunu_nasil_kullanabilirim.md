[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/hordede-cop-kutusunu-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-02-2022 **Görüntüleme:** 1224


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/hordede-cop-kutusunu-nasil-kullanabilirim)

# Horde'de çöp kutusunu nasıl kullanabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

Horde eposta web uygulamasında "Posta için seçenekler" / "Preferences for Mail" ayarlarınızın aşağıdaki şekilde olması gerekmektedir. Bu sayfada "Çöp Kutusu temizleme sıklığı" olarak belirtilen ayara göre otomatik olarak çöp kutusu boşaltılacaktır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde-trash.png)