[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-nasil-kullanici-kodu-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 02-11-2021 **Görüntüleme:** 12148


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-metu-personnel-how-can-i-obtain-user-code "I am a METU personnel. How can I obtain a user code?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-nasil-kullanici-kodu-alabilirim "ODTÜ Personeliyim. Nasıl Kullanıcı Kodu Alabilirim?")

# ODTÜ Personeliyim. Nasıl Kullanıcı Kodu Alabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

ODTÜ personeli kullanıcı hesabı açma talebinizi “Kişisel Kullanıcı Kodu Başvuru Formu (F1) ile gerçekleştirebilirsiniz. Forma [https://bidb.metu.edu.tr/kullanici-kodu-formlari](https://bidb.metu.edu.tr/kullanici-kodu-formlari) adresinden ulaşabilirsiniz. Bu formu doldurarak; bölüm/birim yöneticinize imzalatıp, Bilgi İşlem Daire Başkanlığı Kullanıcı Hizmetleri Birimi B-14 Nolu odaya getirebilir ya da [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/%C2%A0) web adresi üzerinden Personel Kimlik Kartının  ön yüzünün  resmini ekleyerek online olarak da iletebilirsiniz.

Personel kullanıcı kodlarının açılabilmesi için, Personel Daire Başkanlığı (PDB) İnsan Kaynakları Yönetim Sistemi (İKYS)’de göreve başlama işlemlerinizin tamamlanmış olması gerekir. PDB'den durumunuzu teyit ettikten sonra kullanıcı hesabı işlemleri için başvurabilirsiniz.

Tüm kullanıcılar " [O](http://web.archive.org/web/20130602185425/http:/bilisim-etigi.metu.edu.tr/) [DTÜ Bilişim Kaynakları Politikalar](http://bilisim-etigi.metu.edu.tr/) [ı](http://web.archive.org/web/20130602185425/http:/bilisim-etigi.metu.edu.tr/)"na uymakla yükümlüdür.