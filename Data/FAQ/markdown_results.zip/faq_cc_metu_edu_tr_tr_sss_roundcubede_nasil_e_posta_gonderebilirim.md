[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-nasil-e-posta-gonderebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1625


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-nasil-e-posta-gonderebilirim)

# Roundcube'de nasıl e-posta gönderebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube'de hesabınıza giriş yaptıktan sonra menüde yer alan "İleti Gönder" butonuna tıklayarak açılacak düzenleme penceresinden göndermek istediğiniz iletinizi oluşturabilir, "Gönder" butonuyla iletinizi gönderebilirsiniz. İletinizi düzenlemeye başladıktan sonra göndermeden taslak olarak kaydetmek isterseniz, "Kaydet" butonunu kullanabilirsiniz; iletiniz "Taslak" klasörüne kaydedilecektir, daha sonra buradan iletinizi tekrar açıp düzenlemeye devam edebilir ve gönderebilirsiniz.

İleti düzenleme penceresinde, "Alındı onayı istensin", "Teslim onayı istensin" gibi seçeneklerin yanı sıra, gönderilecek iletinizin kaydedileceği klasörü de seçebilirsiniz.

"Alındı onayı istensin" seçeneğini işaretlediğinizde, e-postanızı yolladığınız alıcının uygun bir e-posta görüntüleme uygulaması kullanması durumunda e-postayı okumasından sonra size e-postanın alındığına dair bir bildirim gönderilecektir. "Teslim onayı istensin" seçeneğini işaretlediğinizde, e-postanızı yolladığınız alıcının e-posta sunucusunun uygun yapılandırılmış olması durumunda size e-postanın teslim edildiğine dair bir bildirim gelecektir; ancak e-postanın alıcıya teslim edildiğine dair bu bildirim, e-postanın alıcı tarafından okunduğu anlamına gelmez.