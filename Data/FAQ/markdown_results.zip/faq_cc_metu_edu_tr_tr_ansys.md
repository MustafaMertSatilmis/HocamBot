[Jump to navigation](https://faq.cc.metu.edu.tr/tr/ansys#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-02-2024 **Görüntüleme:** 50028


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/ansys "ANSYS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/ansys "ANSYS")

# ANSYS

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ANSYS** **2024 R1** **—**

**_ANSYS_** _özellikle mühendislik uygulamalarında kullanılabilen sonlu eleman çözümleme yazılımıdır._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/ansys#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/ansys#aktivasyon)

[**_LİSANS SUNUCU ERİŞİM AYARLARI & AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/ansys#ayarlar)

[**_HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER_**](https://faq.cc.metu.edu.tr/tr/ansys#hata)

* * *

**_\[1\] Not:_**_Öğrencilerimiz ANSYS yazılımının **öğrenci sürümüne** [https://www.ansys.com/academic/students](https://www.ansys.com/academic/students) adresinden erişebilirler._

**_\[2\] Not:_** _ANSYS yazılımları içerik ve modülleri için [https://www.ansys.com/academic/educators/academic-product-portfolio](https://www.ansys.com/academic/educators/academic-product-portfolio) adresinden faydalanabilirsiniz._

**_\[3\] Not:_ _ANSYS 2020 R1_** _öncesi sürümleri kullanan kullanıcılarımızın_ **_Electronics_** _modülünü kullanabilmek için [bu bağlantıdaki](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansyselectronics.pdf) ayarları yapmaları gerekmektedir. Kullanıcılarımızın her koşulda yazılımın en yeni sürümünü kullanması önerilmektedir._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Install Ansys Products”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step1.png)

**_ADIM-2_**

**_“I agree ..._** **_”_**_seçeneğini işaretleyiniz ve **“** **Next**_ **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step2.png)

**_ADIM-3_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step3.png)

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step4.png)

**_ADIM-5_**

**_“No. Skip configuration. I will configure later”_**_seçeneğini işaretleyiniz ve**“** **Next**_ **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step5.png)

**_ADIM-6_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step6.png)

**_ADIM-7_**

_İstendiğinde **“#2”** numaralı **“ANSYS2024R1\_WINX64\_DISK2”**iso_ _kurulum dosyasını mount_ _ediniz ve **“Browse”**_ _butonuna tıklayarak gösteriniz. Daha sonra **“OK”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step7.png)

**_ADIM-8_**

_İstendiğinde **“#3”** numaralı **“ANSYS2024R1\_WINX64\_DISK3”** iso_ _kurulum dosyasını mount_ _ediniz ve **“Browse”**_ _butonuna tıklayarak gösteriniz. Daha sonra **“OK”**_ _butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step8.png)_

**_ADIM-9_**

**_“Next_** **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step9.png)

**_ADIM-10_**

**_“Exit”_**_butonuna tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step10.png)

* * *

**_LİSANS SUNUCU ERİŞİM AYARLARI & AKTİVASYON_**

**_ADIM-11_**

**_Aktivasyon bilgilerini girmek için “Ansys Licensing Settings 2024 R1” aracını çalıştırınız ve aşağıdaki ekran görüntülerinde yer alan bilgilere göre ilgili tanımlamaları yapınız._**

**_>\> ANSYS TEACHING_**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step11.png)

**_>\> ANSYS RESEARCH_**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ansys_2024_r1_step12.png)

_Lisans sunucu erişim ayarlarını yapmak için **"C:\\Program Files\\ANSYS Inc\\Shared Files\\Licensing"**_ _dizinindeki **“ansyslmd.ini”** dosyasını aşağıdaki şekilde kaydediniz (bu dosya yazılımı kurduğunuz dizine bağlı olarak farklı bir dizinde yer alabilir) ve ANSYS yazılımını kapatıp yeniden açınız._

**_>\> ANSYS TEACHING_**

_SERVER= [1056@license.cc.metu.edu.tr](mailto:1056@license.cc.metu.edu.tr)_

_ANSYSLI\_SERVERS= [2325@license.cc.metu.edu.tr](mailto:2325@license.cc.metu.edu.tr)_

**_>\> ANSYS RESEARCH_**

_SERVER= [1055@license2.cc.metu.edu.tr](mailto:1055@license2.cc.metu.edu.tr)_

_ANSYSLI\_SERVERS= [2325@license2.cc.metu.edu.tr](mailto:2325@license2.cc.metu.edu.tr)_

* * *

_**HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER**_

|     |     |     |
| --- | --- | --- |
| **HATA KODU** | **SORUN** | **SORUN GİDERME** |
| N/A –<br>Not Applicable | Not enough ANSYS HPC licenses | Ansys HPC yani analizlerde çekirdek kullanımı ile ilgili kampüs lisansında ortak bir HPC havuzu yer almaktadır. Dolayısıyla kampüste yer alan ve Ansys CFD, Mechanical ve Electronics yazılımlarını kullanan kullanıcılar aynı ortak HPC havuzunu kullanmaktadır. Kampüs lisansında Ansys CFD ve Mechanical kullanıcıları daha fazla olabileceği için muhtemelen ortak HPC havuzundaki çekirdekleri kullanmış olabilirler. Böylece Ansys Electronics yazılımlarını kullanan kullanıcılara ortak HPC havuzundaki çekirdek sayısı diğer kullanıcıların kullanımına göre değişkenlik göstereceği için daha az sayıda çekirdek kalmış olabilir. Dolayısıyla HPC çekirdek kullanımındaki kullanıcıların sayılarında değişkenlik gösteren HPC çekirdek kullanım sayıları bu nedenden kaynaklanıyor olabilmektedir. |
| N/A –<br>Not Applicable | Connection timed out while reading data | Ansys Workbench "Connection timed out while reading data” hatasının çözümüne yönelik ağ bağdaştırıcı ayarlarınızdan domain name çözümlemesi için DNS suffix olarak "cc.metu.edu.tr" eklemeniz gerekmektedir. Aşağıdaki linkte yer alan benzer adımları takip ederek ilgili işlemi gerçekleştirebilirsiniz. URL >> [https://answers.uillinois.edu/illinois/114224](https://answers.uillinois.edu/illinois/114224) |

* * *

_**Bize**_ _**ulaşın**_ _**:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *