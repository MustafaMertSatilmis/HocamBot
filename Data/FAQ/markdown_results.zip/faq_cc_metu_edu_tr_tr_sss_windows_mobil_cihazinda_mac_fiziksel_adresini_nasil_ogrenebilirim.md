[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/windows-mobil-cihazinda-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 6781


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-windows-mobile-device "How can I find out the MAC (physical) address on a Windows Mobile Device?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/windows-mobil-cihazinda-mac-fiziksel-adresini-nasil-ogrenebilirim "Windows Mobil Cihazında MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Windows Mobil Cihazında MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

Windows Mobil Cihazınızda MAC adresi bulmak için aşağıdaki adımları izleyin.

1. Başlat üzerinde, soldaki uygulamalar listesine gelin.

2. Ayarları seçtikten sonra, hakkında’yı ve daha sonra gelişmiş/daha fazla bilgi ye gelin.

3. MAC adresinizi not edin.