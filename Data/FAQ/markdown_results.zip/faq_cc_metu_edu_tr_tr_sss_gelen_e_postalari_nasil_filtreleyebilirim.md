[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-postalari-nasil-filtreleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 12128


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-do-i-filter-my-incoming-e-mails-horde "How do I filter my incoming e-mails with Horde?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-postalari-nasil-filtreleyebilirim "Gelen e-postaları nasıl filtreleyebilirim?")

# Gelen e-postaları nasıl filtreleyebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

İstenmeyen e-postaların "Gelen Kutusu"nda yer kaplamasını engellemek ya da belli kişilerden ve/veya belli konularda gelen e-postaları belirli dizinlere otomatik olarak taşımak için Horde'un "Süzgeçler" özelliği kullanılabilir.

Horde web tabanlı e-posta okuyucusu kullanarak yapılan bu işlemler sonrasında filtrenen gelen e-postalar, başka e-posta okuyucu programlar (Outlook, Thunderbird vb.) tarafından da tanımlanmış klasörlerin içinde gözükecektir.

Bu özelliği kullanmak için Horde'a girildikten sonra önce "Posta" ikonuna, daha sonra "Süzgeçler" ikonuna tıklanmalıdır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde_filter_rule_tr.png)

Süzgeç Kuralları sayfasında yeni bir kural oluşturmak için öncelikle "Yeni Kural" düğmesine basılır.

Süzgeç Kuralı sayfasında oluşturulacak kural için bir isim verilmelidir.

_Gelen iletiler için eşleşme_ bölümünde _Kime_, _Konu_, _Gönderen_, _Kimden_, vb. ölçütler tanımlanabilir.

_Bunu yap_ bölümünde bu ölçüte uyan iletilere uygulanacak işlem belirtilmelidir. _Dizine gönder_, _İletiyi tamamen sil_, _Yönlendir_ seçenekleri sık kullanılan işlemlerdir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde_filter_tr.png)

Örnek ekran görüntüsünde Kime bölümü genel-duyuru![](https://faq.cc.metu.edu.tr/tr/system/files/u2/et_b.gif)metu.edu.tr olan iletilerin duyurular dizinine gönderilmesi için oluşturulan kural görülebilir.