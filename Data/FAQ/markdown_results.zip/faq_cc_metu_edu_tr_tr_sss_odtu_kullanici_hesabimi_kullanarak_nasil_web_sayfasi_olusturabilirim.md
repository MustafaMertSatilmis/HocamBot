[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nasil-web-sayfasi-olusturabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 20706


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-create-web-pages-using-my-metu-user-account "How can I create web pages by using my METU user account?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nasil-web-sayfasi-olusturabilirim "ODTÜ kullanıcı hesabımı kullanarak nasıl web sayfası oluşturabilirim?")

# ODTÜ kullanıcı hesabımı kullanarak nasıl web sayfası oluşturabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

[Web Servisleri](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri)

Oluşturacağınız web sayfalarının **ODTÜ'deki Bilgi İşlem ve Bilgisayar Ağı Kaynaklarını Kullanım Etiği**'ne uygun olmasına dikkat ediniz. Etikte yer alan kurallara [bu adresten](http://bilisim-etigi.metu.edu.tr/) ulaşabilirsiniz.

Üniversitemiz kişisel hesapları ile oluşturulan web sayfalarının program çalıştırma izni ve veri tabanı desteği bulunmamaktadır. Web kullanıcılarına ise php ve bazı programları çalıştırma izni verilmektedir.

ODTÜ merkezi sunucuları üzerinde web sayfası oluşturmak için aşağıdaki adımları takip etmeniz gerekmektedir.

1. Size verilmiş olan kullanıcı kodu/şifre ikilisini kullanarak PuTTY, WinSCP gibi SSH uygulamaları aracılığıyla, merkezi sunuculara ( _orca, beluga, rorqual, narwhal_) bağlantı sağlayınız.

2. Kullanıcı kodu içerisinde wwwhome dizini otomatik olarak oluşturulmuştur. **wwwhome** dizininin erişim haklarını kontrol etmek için:

ls -ald wwwhome

komutunu çalıştırınız. Bu komut sonrasında ekranınıza aşağıdakine benzer bir satır gelecektir. Bu satırdaki ilk 10 karakter (drwxr-xr-x), **wwwhome** dizinine erişim haklarını belirtmekte olup aşağıdaki değerlerle aynı olmalıdır.

drwxr-xr-x 14 uid gid 1536 Sep 20 12:10 wwwhome

    Farklı olması durumunda aşağıdaki komutları çalıştırarak **wwwhome** dizininin erişim yetkilerini tanımlayınız.

chmod og=rx wwwhome

3. Daha sonra, kullanıcı home dizininizin erişim haklarını kontrol etmek için,

ls -ald ~

    komutunu yazınız. Bu komut sonrasında ekranınıza gelecek satırın ilk 10 karakterinin aşağıdaki değerlerle aynı olup olmadığını kontrol ediniz:

drwx--x--x 14 uid gid 1536 Sep 20 12:10 kullanici-kodu

    Eğer değerler yukarıdaki gibi değilse aşağıdaki komutu çalıştırınız:

chmod a+x ~

Bu işlemler tamamlandığında, web sayfası hazırlayabilmeniz için gerekli dizin yapısı kurulmuş olur.

4. Şimdi örnek bir açılış sayfasını birlikte hazırlayalım. Bunun için aşağıdaki komutu kullanarak **wwwhome** dizini içine giriniz.

cd wwwhome

5. Sonra alışkın olduğunuz bir editör (pico, vi vb.) aracılığıyla, aşağıdaki örnek komutu kullanarak **index.html** dosyasını oluşturunuz;

pico index.html

    ve içerisine aşağıdaki örnek bilgileri giriniz.

    Örnek sayfa




### < html >   < title >Örnek sayfa< /title >   < h3 >Hoşgeldiniz. < /h3 >   < /html>

6. Bu bilgileri **index.html** dosyasında saklayıp çıkınız. İlk sayfanızda neler olduğunu görmek için, kullandığınız web tarayıcısına (Netscape, Internet Explorer vb.), web sayfanızın URL adresini aşağıdaki şekilde giriniz:

**users.metu.edu.tr/kullanıcı\_kodu** (kişisel kullanıcılar)

**www.\*\*\*\*\*.metu.edu.tr/** (web kullanıcıları)

7. Böylece açılış sayfanızı yaratmış oldunuz. Web sayfanızda görünmesini istediğiniz bilgileri **home** dizininizdeki **wwwhome** dizini altında bulundurmanız gerekmektedir. Web sayfası hazırlama veya HTML kodu yazma konularında, aşağıda adresleri belirtilen ve değişik seviyedeki kullanıcılara hitap eden web siteleri sizin için faydalı olabilir.


1. **İngilizce içerikli siteler:**

[http://www.w3.org/MarkUp/Guide/](http://www.w3.org/MarkUp/Guide/) \- Dave Raggett's Introduction to HTML

[http://htmlhelp.org/](http://htmlhelp.org/)\- HTML Help by The Web Design Group

[http://www.december.com/html/](http://www.december.com/html/) \- Information about HTML and related technologies

2. Bu bilgilere ek olarak kendi bilgisayarınızda hazırlamış olduğunuz web sayfalarını da FTP (File Transfer Protocol / Dosya Transfer Protokolü) kullanarak, sistemdeki kullanıcı hesabınıza aktarıp web sayfanızı oluşturabilir veya güncelleyebilirsiniz. Burada dikkat etmeniz gereken, aktardığınız dosyaların erişim haklarının herkes tarafından okunabilecek şekilde tanımlanmış olmasıdır. Bunun için dosyaları aktarma işleminiz bittikten sonra aşağıdaki komutu kullanarak dosyalar için erişim haklarını tanımlayabilirsiniz:

    chmod og=r dosya-adi

3. Web sayfalarınızı hazırlarken, güncellerken ve aktarırken çeşitli web editörü programlardan yararlanabilirsiniz.