[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yurt-disi-mensei-banka-kartimla-yukleme-yapabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 27-12-2021 **Görüntüleme:** 4101


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-load-money-my-smartcard-using-foreign-bank-card "Can I load money to my smartcard by using foreign bank card? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yurt-disi-mensei-banka-kartimla-yukleme-yapabilir-miyim "Akıllı kartıma yurt dışı menşei banka kartımla yükleme yapabilir miyim? ")

# Akıllı kartıma yurt dışı menşei banka kartımla yükleme yapabilir miyim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınıza yurt dışı kaynaklı banka kartınızla yükleme yaparken hata mesajı alabilirsiniz. Bankanızla görüşüp kontrolünü sağlamanız gerekmektedir.