[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/web-onbellekleme-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 9078


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-webcache "What is webcache?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/web-onbellekleme-nedir "Web önbellekleme nedir?")

# Web önbellekleme nedir?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

**Önemli Uyarı !!!**

**Kütüphane Önbellekleme Servisi 5 Ağustos 2014 tarihinde kapatılmıştır. Kütüphane Elektronik Kaynaklarına uzaktan erişim için aşağıdaki linkte anlatılan servislerden birini kullanınız:**

[http://lib.metu.edu.tr/tr/yerleske-disindan-erisim](http://lib.metu.edu.tr/tr/yerleske-disindan-erisim)

* * *

**_Web Önbellekleme Nedir?_**

Web önbellekleme, internet üzerinden istenilen objelerin (HTTP, FTP, Gopher gibi protokoller üzerinden ulaşılabilen verilerin), yerel alan ağı içerisinde bir sunucuda saklanması, ve aynı objenin aynı veya farklı bir istemci tarafından istenilmesi halinde, bu sunucu tarafından isteğin karşılanmasıdır. Aynı web önbellekleme sunucusunu kullanan tarayıcı programların, ortalamada isteklerinin karşılanması süresi düşer, ayrıca bant genişliği tasarrufu sağlanmış olur.