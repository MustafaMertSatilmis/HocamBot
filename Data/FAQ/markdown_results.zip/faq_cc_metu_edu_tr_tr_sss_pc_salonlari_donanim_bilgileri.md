[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-donanim-bilgileri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-02-2024 **Görüntüleme:** 10963


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/pc-rooms-hardware-configuration "What are the PC Rooms Hardware Configurations?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-donanim-bilgileri "PC Salonları Donanım Bilgileri Nelerdir?")

# PC Salonları Donanım Bilgileri Nelerdir?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| **YER** | **PC SAYISI** | **CPU** | **RAM** | **PROJEKSİYON**<br>**CİHAZI** |
| Beşeri Bilimler PC Salonu | 32 | AMD Phenom IIX4 3.2 GHz | 4 GB | Var |
| 1\. Yurt PC Salonu | 10 | Intel Core i5-6500 3.5 Ghz | 8 GB |  |
| 2\. Yurt PC Salonu 2 | 25 | Intel Core i7-10700 | 8 GB |  |
| 2\. Yurt PC Salonu 3 | 40 | Intel Core i5-6500 3.5 Ghz | 8 GB | Var |
| Faika Demiray Yurdu PC Salonu | 10 | Intel core i5-6500 3.5 Ghz | 8 GB |  |
| İsa Demiray Yurdu PC Salonu | 10 | Intel core i5-6500 3.5 Ghz | 8 GB |  |
| Refika Aksoy Yurdu PC Salonu | 10 | Intel core i5-6500 3.5 Ghz | 8 GB |  |