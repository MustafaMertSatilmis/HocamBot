[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sevk-edecegim-kisibirim-gorunmuyor-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-01-2020 **Görüntüleme:** 5931


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sevk-edecegim-kisibirim-gorunmuyor-ne-yapmaliyim)

# EBYS'de yazı sevk edeceğim kişi/birim görünmüyor. Ne yapmalıyım?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine durumu açıklayan bir e-posta gönderebilirsiniz.