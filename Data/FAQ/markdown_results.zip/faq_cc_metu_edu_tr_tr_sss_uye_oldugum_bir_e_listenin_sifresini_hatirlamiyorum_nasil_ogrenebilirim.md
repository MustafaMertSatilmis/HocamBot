[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-bir-e-listenin-sifresini-hatirlamiyorum-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7129


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-forgotten-password-electronic-list-i-have-subscribed-how-can-i-get-it-turkish "I have forgotten the password of an electronic list that I have subscribed, how can I get it? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-bir-e-listenin-sifresini-hatirlamiyorum-nasil-ogrenebilirim "Üye olduğum bir e-listenin şifresini hatırlamıyorum; nasıl öğrenebilirim?")

# Üye olduğum bir e-listenin şifresini hatırlamıyorum; nasıl öğrenebilirim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

E-listelerde kullanılan şifreler, merkezi kullanıcı kodları için kullanılan şifrelerden farklı olup, herhangi bir listeye üye olunduğunda Mailman yazılımı tarafından otomatik olarak tanımlanıp e-liste üyelerine gönderilen şifrelerdir. E-liste servisi kapsamında merkezi e-posta adresleri dışındaki e-posta adresleri ile de e-listelere üye olunabildiği için, e-liste arşivlerine ulaşımda merkezi kullanıcı şifreleri kullanılamamaktadır.

E-liste şifresini hatırlamayan bir kullanıcı, bir e-listeye gönderilmiş mesajın ekinde yer alan eklenti dosya bağlantısına tıkladığında veya doğrudan **[http://mailman.metu.edu.tr/mailman/private/liste\_ad](http://mailman.metu.edu.tr/mailman/private/liste_ad) ı** şeklindeki e-liste arşiv giriş ekranının adresini yazarak, arşive giriş yapacağı sayfaya ulaşabilir. E-liste şifresini öğrenmek için, bu sayfada e-listeye üyelik için kullandığı e-posta adresini yazıp Hatırlat butonuna basması yeterlidir.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_01.jpg)

Bu işlem sonrasında e-liste şifresi kullanıcının e-posta adresine aşağıdaki gibi bir mesaj ile gönderilecektir:

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_02.jpg)

Burada, **"Your <e-liste-adı> password is:"** ifadesinin karşısında "\*\*\*\*" ile belirtilmiş olan alanda yer alan bilgi, e-liste şifre bilgisidir. Kullanıcı bu şifreyi kullanarak mesaj ekinde yer alan eklenti dosyalara ulaşabilir ve e-liste arşivinde yer alan geçmiş tüm mesajları okuyabilir (E-liste yazılımı olan "Mailman", üye olunan her liste için ayrı şifre atamaktadır, ancak isteyen kullanıcılarımız üye oldukları tüm listeler için ortak bir şifre tanımlayabilirler).