[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-verdigi-servislerden-yararlanmak-icin-yapilmasi-gerekenler-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-03-2022 **Görüntüleme:** 9634


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-do-make-use-services-provided-cc "What to do, to make use of the services provided by the CC?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-verdigi-servislerden-yararlanmak-icin-yapilmasi-gerekenler-nelerdir "BİDB'nin verdiği servislerden yararlanmak için yapılması gerekenler nelerdir?")

# BİDB'nin verdiği servislerden yararlanmak için yapılması gerekenler nelerdir?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

Merkezi sistemler üzerinde çalışmak ve İnternet'e bağlanmak isteyen akademik/idari personelin [_Kullanıcı Kodu Başvuru Formu_](http://bidb.metu.edu.tr/kullanici-kodu-formlari)'nu bölüm/birim yöneticilerine onaylattıktan sonra mesai saatlerinde **BİDB B-14** no'lu odaya personel kimlikleri ile birlikte başvurarak kullanıcı kodu ve şifrelerini almaları gerekmektedir.

Forma [https://bidb.metu.edu.tr/kullanici-kodu-formlari](https://bidb.metu.edu.tr/kullanici-kodu-formlari) adresinden ulaşabilirsiniz. Bu formu doldurarak; [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) , [hotline@metu.edu.tr](mailto:hotline@metu.edu.tr) adresleri üzerinden online olarak da iletebilirsiniz. Personel kullanıcı kodlarının açılabilmesi için, Personel Daire Başkanlığı (PDB) İnsan Kaynakları Yönetim Sistemi (İKYS)’de göreve başlama işlemlerinizin tamamlanmış olması gerekir. PDB'den durumunuzu teyit ettikten sonra kullanıcı hesabı işlemleri için başvurabilirsiniz.

Bu kullanıcı kodu ile akademik/idari personel, e-posta gönderip alabilir, elektronik haberleşme listeleri ve haber gruplarına üye olabilir, merkezi sistemler üzerinde çalışan yazılımları kullanabilir ve ftp servisinden yararlanabilir, Akademik/Öğrenci Bilgi Sisteminde sunulan her türlü hizmete erişebilirsiniz.