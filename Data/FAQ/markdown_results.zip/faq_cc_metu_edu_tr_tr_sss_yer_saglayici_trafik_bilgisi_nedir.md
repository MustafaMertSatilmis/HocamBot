[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yer-saglayici-trafik-bilgisi-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 10844


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-host-trafic-log-turkish "What is Host Trafic Log? (In Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yer-saglayici-trafik-bilgisi-nedir "Yer Sağlayıcı Trafik Bilgisi Nedir?")

# Yer Sağlayıcı Trafik Bilgisi Nedir?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

24 Ekim 2007 tarih ve 26680 sayılı Resmi Gazete'de yayınlanan yönetmeliğe göre,

" _Yer sağlayıcı trafik bilgisi, İnternet ortamındaki her türlü yer sağlamaya ilişkin olarak; kaynak IP adresi, hedef IP adresi, bağlantı tarih-saat bilgisi, istenen sayfa adresi, işlem bilgisi (GET, POST komut detayları) ve sonuç bilgisi gibi bilgileri ifade etmektedir._"

Tanımlanan bu bilgiye, bir hukuksal incelemede kullanılmak üzere yer sağlayıcılık faaliyetleri kapsamındaki bir faaliyetin kim tarafından yapıldığının tespiti için ihtiyaç duyulmaktadır.

l) Örnek "http" logu:

Aşağıda yer sağlayıcı faaliyet kapsamında bir web sayfasının bulunduğu sunucunun ilgili örnek trafik logu (http logu) gösterilmiştir. Bu log, "apache" web sunucu yazılımının ürettiği bir log örneğidir. Birimlerde kullanılan farklı web sunucu yazılımları için, yazılımların belgelerine başvurulması ve uygun log tutulması için hangi işlemlerin yapılmasının gerekli olduğunun öğrenilmesi gerekmektedir.

> 144.122.222.234 - - \[21/Mar/2008:14:58:01 -0200\] "GET 'data/liste.html HTTP/1.1" 200"1 73372 "-" "Mozilla/5.0 (XII: U; Lınux i686; en-L'S; rv:1.8.1.12) Gecko/20080129 Iceweasel/2.0.0.12(Debian-2.0.0.12-Oetchl)"

Yukarıdaki örnekte yer alan bilgi alanları, kanunda belirtilen başlıklarla aşağıdaki şekilde ilişkilendirilmiştir:

> Kaynak IP adresi : 144.122.222.234
>
> Hedef ip adresi: _Bu kayıtta bulunmamaktadır"_
>
> Bağlantı tarih-saat bilgisi: \[21/Mar/2008:14:58:01 -0200\]
>
> İstenen sayfa adresi: data/liste.html
>
> İşlem bilgisi (GET komut detayı) : GET 'data/liste.htmi HTTP/1.1
>
> Sonuç bilgisi: 200

2) Örnek e-posta logu:

"sendmail" e-posta sunucu yazılımının ürettiği log dosyasının örneği aşağıda verilmiştir. Tutulan log bilgisinde, "to", "from" ve "relay" bilgilerinin bulunması gereklidir. Kullanılan e-posta yazılımının log formatı, istenen bilgileri bir veya birden fazla satır halinde verebilir.

> Mar 25 10:20:02 mailhost sendmail\[9516\]: m2Q8K2e2009516:
>
> from=<bogususer![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)bogus.com>, size=2291, class=0, nrcpts=1,
>
> msgid=<00b101c88f1a$407a7cf0$>, proto=ESMTP, daemon=MTA,
>
> relay=boguspc.bogus.com \[192.168.1.1\]
>
> Mar 25 10:20:03 mailhost sendmail\[9550\]: m2Q8K2e1009516:
>
> to=<bogus2user![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)bogus2.com>, delay=00:00:01, xdelay=00:00:00,
>
> mailer=esmtp, pri=122357, relay=mx.bogus2.com. \[192.168.1.2\], dsn=2.0.0,
>
> stat=Sent ( Queued mail for delivery)

Yukarıdaki örnekte yer alan bilgi alanları, kanunda belirtilen başlıklarla aşağıdaki şekilde ilişkilendirilmiştir:

> Bağlantı tarih-saat bilgisi: "Mar 25 10:20:03"
>
> Gönderici: bogususer![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)bogus.com
>
> Kaynak IP adresi: 192.168.1.1
>
> Hedef IP adresi: 192.168.1.2
>
> Alıcı: bogus2user![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)bogus2.com
>
> Sonuç bilgisi: sent

3) Örnek ftp logu:

"proftpd" ftp sunucu yazılımının ürettiği log dosyasının örneği aşağıda verilmiştir. Tutulan log bilgisinde, bağlantı yapan bilgisayarın adresi, hedef dosya ve kullanıcı adı bilgileri bulunmalıdır.

> Tue Mar 25 16:39:48 2008 0 bogus.com 528 /ftp/pub/IMPORTANT-WARNING.txt b \_ o r anonim ftp 1 \* c

Yukarıdaki örnekte yer alan bilgi alanları, kanunda belirtilen başlıklarla aşağıdaki şekilde ilişkilendirilmiştir:

> Bağlantı tarih-saat bilgisi: "Tue Mar 25 16:39:48 2008"
>
> Kaynak Adres: "bogus.com"
>
> İstenen dosya: "ftp/pub/IMPORTANT-WARNING.txt"
>
> Kullanıcı adı: "anonim"

Birimler, yer sağlayıcı faaliyetleri kapsamında verdikleri servislerin ürettiği logları inceleyip, sahip oldukları sistemlerde verdikleri servislerin yarattığı trafik loglarını yönetmelikte tarif edildiği şekilde ( [zaman damgası](https://faq.cc.metu.edu.tr/tr/sss/zaman-damgasi-nedir-nicin-kullanilmasi-gerekmektedir) ile birlikte) kayıt altına almak, bu logları, gizliliğini sağlayarak arşivlemekle yükümlüdür.