[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listemi-artik-kullanmiyorum-nasil-kapatabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6179


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listemi-artik-kullanmiyorum-nasil-kapatabilirim)

# Yöneticisi olduğum listemi artık kullanmıyorum, nasıl kapatabilirim?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

Listenizin kapatılması için mailman![](https://faq.cc.metu.edu.tr/tr/system/files/img_et.gif)metu.edu.tr adresine listenizin ismini belirterek kapatılma talebini belirtebilirsiniz. E-Liste kapatma talepleri ilgili e-listenin yöneticisinden gelmelidir. Talebiniz birimimize ulaştığında tarafımızca incelenecek, uygun görüldüğünde gerekli liste kapatma işlemleri gerçekleştirilecektir.

Eğer liste arşivlerinin tarafınıza iletilmesini istiyorsanız bunu da e-postanızda belirtmelisiniz.