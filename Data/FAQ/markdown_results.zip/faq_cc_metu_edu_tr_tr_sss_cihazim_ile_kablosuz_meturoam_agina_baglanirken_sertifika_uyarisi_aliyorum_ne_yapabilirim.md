[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/cihazim-ile-kablosuz-meturoam-agina-baglanirken-sertifika-uyarisi-aliyorum-ne-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-08-2023 **Görüntüleme:** 6772


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-get-certificate-warning-when-connecting-wireless-meturoam-network-my-device-what-should-i-do "I get a certificate warning when connecting to the wireless meturoam network with my device. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/cihazim-ile-kablosuz-meturoam-agina-baglanirken-sertifika-uyarisi-aliyorum-ne-yapabilirim "Cihazım ile kablosuz meturoam ağına bağlanırken sertifika uyarısı alıyorum. Ne yapabilirim?")

# Cihazım ile kablosuz meturoam ağına bağlanırken sertifika uyarısı alıyorum. Ne yapabilirim?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

meturoam kablosuz ağına bağlanırken cihazınızdaki işletim sistemine ve varsa kullandığınız antivirüs yazılımı sebebiyle sertifika uyarısı alabilirsiniz.

Uyarı ekranındaki bilgileri kontrol edebilir ve eğer bilgiler aşağıdaki "Fingerprint" (parmak izi) ile aynıysa **Bağlan**'a tıklayabilirsiniz:

Radius Sunucusu: border.metu.edu.tr

SHA-256 Fingerprint 52 FD 75 C8 9D 32 57 61 30 77 88 BA 9B 01 E0 6F F5 4C 1F 19 08 10 E5 F5 D4 F7 87 2E E4 6D A4 7A

SHA-1 Fingerprint 5A 12 B5 A2 5E 20 D1 BC 73 74 2E 0E 35 60 B5 76 3D DB 14 A7