[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/birden-fazla-gorevimpozisyonum-var-farkli-gorevimipozisyonumu-kullanarak-nasil-yazi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-11-2021 **Görüntüleme:** 1356


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/birden-fazla-gorevimpozisyonum-var-farkli-gorevimipozisyonumu-kullanarak-nasil-yazi)

# Birden fazla görevim/pozisyonum var, farklı görevimi/pozisyonumu kullanarak nasıl yazı oluşturabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Yazı hazırlama ekranında "Pozisyon Seç" düğmesini tıkladıktan sonra açılan bölümden yazı hazırlamak istediğiniz pozisyonu seçebilirsiniz. Pozisyon değişikliği yaptıktan sonra yazıyı gönderebileceğiniz birimler, yazının imzacı zorunlulukları otomatik olarak değişecektir. Eğer değişmiyor ise bu durumu [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine bildiriniz.