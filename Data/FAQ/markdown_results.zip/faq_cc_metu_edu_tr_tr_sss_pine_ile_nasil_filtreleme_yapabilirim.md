[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pine-ile-nasil-filtreleme-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7073


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-do-i-filter-my-incoming-e-mails-pine "How do I filter my incoming e-mails with Pine?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pine-ile-nasil-filtreleme-yapabilirim "Pine ile nasıl filtreleme yapabilirim?")

# Pine ile nasıl filtreleme yapabilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

27/07/2009 tarihinde uygulamaya geçilen e-posta sistemi ile artık sunucu sistemler üzerinde **.procmail** dosyası oluşturularak filtreleme işlemi yapılamamaktadır. Filtreleme işlemi için Horde web e-posta istemcileri ya da Microsoft Outlook, Mozilla Thunderbird vb. e-posta okuma programları kullanılmalıdır.