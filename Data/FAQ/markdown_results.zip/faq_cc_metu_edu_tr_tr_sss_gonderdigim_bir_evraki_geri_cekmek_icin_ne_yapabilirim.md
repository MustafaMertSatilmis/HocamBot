[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gonderdigim-bir-evraki-geri-cekmek-icin-ne-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4436


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gonderdigim-bir-evraki-geri-cekmek-icin-ne-yapabilirim)

# Gönderdiğim bir evrakı geri çekmek için ne yapabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Sevk edilen bir evrak sevk eden tarafından geri alınamamaktadır. Gönderdiğiniz kişinin size tekrar sevk etmesini istemelisiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.