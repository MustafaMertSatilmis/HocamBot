[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/basvuru-ile-ilgili-sorular#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Başvuru ile İlgili Sorular

|     |
| --- |
| [Yeni bir E-Liste başvurusunda bulunmak için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/yeni-bir-e-liste-basvurusunda-bulunmak-icin-ne-yapmaliyim) |
| [Mailman sisteminde ne tür listeler tanımlanabilir?](https://faq.cc.metu.edu.tr/tr/sss/mailman-sisteminde-ne-tur-listeler-tanimlanabilir) |

[![Subscribe to Başvuru ile İlgili Sorular](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/205/all/feed "Subscribe to Başvuru ile İlgili Sorular")