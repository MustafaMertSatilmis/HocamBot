[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gonderdigim-e-postalarimin-bicimini-html-ya-da-duz-metin-nasil-degistirebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1119


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gonderdigim-e-postalarimin-bicimini-html-ya-da-duz-metin-nasil-degistirebilirim)

# Roundcube'de gönderdiğim e-postalarımın biçimini (HTML ya da düz metin) nasıl değiştirebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube'de iletilerinizi gönderirken e-posta düzenleme penceresinde göndereceğiniz iletinin biçimini düzenleyebilirsiniz. E-posta metninizi yazacağınız alanın sol üst köşesinde yer alan butona tıklayarak oluşturduğunuz e-postanın biçimini "HTML" ya da "Düz metin" olarak değiştirebilirsiniz.

Göndereceğiniz e-postaların ön tanımlı olarak belirli bir biçimde oluşturulmasını belirlemek için "Ayarlar" menüsünden "Yeni İleti Oluşturma" sekmesini ziyaret etmelisiniz. Burada yer alan "HTML ileti kullanımı" seçeneği, yollayacağınız iletilerin hangi durumlarda HTML ya da düz metin olarak gönderileceğini önceden belirlemenize olanak sağlayacaktır. Örneğin "asla HTML kullanma" ya da "yalnız HTML biçimindeki iletiler yanıtlanırken" gibi seçeneklerden birini seçmeniz mümkündür.