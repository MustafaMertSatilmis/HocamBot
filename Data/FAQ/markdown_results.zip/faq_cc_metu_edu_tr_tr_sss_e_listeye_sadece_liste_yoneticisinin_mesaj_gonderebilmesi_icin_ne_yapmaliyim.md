[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-yoneticisinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 8807


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-list-can-be-set-only-list-administrator-be-able-send-message-list "How a list can be set  for only the list administrator to be able to send message to the list?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-yoneticisinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim "E-listeye sadece liste yöneticisinin mesaj gönderebilmesi için ne yapmalıyım ? ")

# E-listeye sadece liste yöneticisinin mesaj gönderebilmesi için ne yapmalıyım ?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

**Listeye sadece liste yöneticisinin mesaj gönderebilmesi için (send-by-owners):**

**(a)** _Üyelik Yönetimi_ > _Üyelik Listesi_ > _Ek Üye Görevleri_ > _Şu anda görüntülenmeyen üyeler de dahil olmak üzere herkesin moderatör onayı ayarını etkinleştir._ ayarı _**Açık**_ olarak seçilir.

**(b)** _Gizlilik Seçenekleri_ > _Gönderici filtreleri_ > _Üye filtreleri_ > _Varsayılan olarak yeni üyelerin mesajları moderatör onayı gerektirsin mi?_ ayarı _**Evet**_ olarak seçilir.

**ÖNEMLİ NOT:** Listeye moderatörden geliyormuş gibi görünen spam ve virüslü mesajlara karşı önlem almak için aşağıdaki ayarları yapabilirsiniz.

**i.** Listeye mesaj gönderme yetkisi olacak e-posta adres(ler)inin listeye üye ol **MAMASI** gerekir. Yetkili adres(ler) moderatör(ler)e aitse, bu durum onlar için de geçerlidir. Bu adresler listeye üye ise üyelikleri iptal edilir.

**ii.** _Gizlilik Seçenekleri_ > _Gönderici filtreleri_ > _Üye olmayan kişi filtreleri_ _\> Mesajları hemen moderatör onayı için bekletilecek üye olmayan kişi adreslerinin listesi_ alanına mesaj gönderme yetkisi olacak e-posta adres(ler)i her satıra tek bir adres gelecek şekilde yazılır.

**iii.** _Gizlilik Seçenekleri_ > _Gönderici filtreleri_ > _Üye filtreleri_ > _Moderatör onay ayarı açık bir üye listeye mesaj gönderdiğinde uygulanacak eylem_. ayarı "Reddet" ya da "Gözardı Et" olarak seçilir.

**vi.** Bu ayarlamalar sonrasında listeye mesaj gönderme yetkisi olacak e-posta adres(ler)i listeye mesaj gönderebilir. Bu adreslerden gönderilen mesaj(lar) onaylanması için elektronik ortamda liste yöneticisi ve/ya moderatörün bilgisine sunulur.

**v.** Liste yöneticisi yönetici şifresiyle, tanımlanmış ise moderatör(ler) moderatör şifresiyle, **[http://mailman.metu.edu.tr/mailman/admindb/ABC-L](http://mailman.metu.edu.tr/mailman/admindb/ABC-L)** şeklindeki sayfaya girerek onaylanması gereken mesaj(lar)ı onaylar. Sonrasında bu mesaj(lar) listeye dağılır.