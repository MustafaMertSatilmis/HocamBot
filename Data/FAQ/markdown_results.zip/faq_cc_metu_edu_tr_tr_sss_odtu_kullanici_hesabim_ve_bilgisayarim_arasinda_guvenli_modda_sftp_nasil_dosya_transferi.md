[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-guvenli-modda-sftp-nasil-dosya-transferi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 13318


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-transfer-files-and-folders-between-my-metu-user-account-and-my-computer-securely "How can I transfer files and folders between my METU user account and my computer securely?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-guvenli-modda-sftp-nasil-dosya-transferi "ODTÜ kullanıcı hesabım ve bilgisayarım arasında güvenli modda (SFTP) nasıl dosya transferi yapabilirim?")

# ODTÜ kullanıcı hesabım ve bilgisayarım arasında güvenli modda (SFTP) nasıl dosya transferi yapabilirim?

[Dosya Transferi](https://faq.cc.metu.edu.tr/tr/groups/dosya-transferi)

SecureFTP (sftp) protokolünü destekleyen uygulamalar ile ODTÜ kullanıcı hesabınıza dosya transferi gerçekleştirebilirsiniz. (Kampus dışından yapacağınız bağlantılar için VPN uygulamasının çalıştırılması ve ODTÜ VPN hizmetine bağlı olmanız gerekmektedir. VPN hizmeti için [bu bağlantıdan](http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) bilgi alabilirsiniz.) Bağlantı ayarlarında sunucu adresi olarak beluga.cc.metu.edu.tr ve kullanıcı kodunuzu yazmanız yeterli olacaktır.

Aşağıdaki uygulamalar güvenli FTP protokolünü destekleyen uygulamalardan birkaçıdır.

[https://www.bitvise.com/ssh-client-download](https://www.bitvise.com/ssh-client-download) (Windows)

[https://winscp.net/eng/download.php](https://winscp.net/eng/download.php) (Windows)

[https://cyberduck.io](https://cyberduck.io/) (MacOS)