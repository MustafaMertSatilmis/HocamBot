[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisi-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-05-2018 **Görüntüleme:** 44098


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-vpn-service "What is VPN Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisi-nedir "VPN Servisi Nedir?")

# VPN Servisi Nedir?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

ODTÜ VPN hizmeti ile birlikte, mensup ve öğrencilerimiz yerleşke dışında bulundukları sürelerde kullandıkları kişisel bilgisayarlara ya da mobil cihazlara kuracakları küçük bir paket program vasıtasıyla (VPN Client), üniversitemiz yerleşke içi ağ kaynaklarına erişebileceklerdir.

VPN hizmetinden faydalanmak için işletim sisteminize uygun olan VPN Client programını bularak bilgisayarınıza ya da mobil cihazınıza indirip kurulumunu yapabilirsiniz. [http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) adresinde farklı işletim sistemlerine göre gerekli kurulum adımları bulunmaktadır.