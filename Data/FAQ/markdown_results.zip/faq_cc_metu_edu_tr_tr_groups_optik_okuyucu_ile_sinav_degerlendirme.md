[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/optik-okuyucu-ile-sinav-degerlendirme#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Optik Okuyucu İle Sınav Değerlendirme

[![Subscribe to Optik Okuyucu İle Sınav Değerlendirme](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/391/all/feed "Subscribe to Optik Okuyucu İle Sınav Değerlendirme")