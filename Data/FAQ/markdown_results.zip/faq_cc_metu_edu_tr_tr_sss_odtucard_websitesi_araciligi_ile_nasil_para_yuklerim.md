[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtucard-websitesi-araciligi-ile-nasil-para-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-04-2022 **Görüntüleme:** 12687


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-load-money-through-odtucard-website "How can I load money through odtucard website?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtucard-websitesi-araciligi-ile-nasil-para-yuklerim "Odtucard websitesi aracılığı ile nasıl para yüklerim?")

# Odtucard websitesi aracılığı ile nasıl para yüklerim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

**1.** İnternet tarayıcınızı açıp [https://odtucard.metu.edu.tr](https://odtucard.metu.edu.tr/) adresine öğrenci numarası / personel sicil numarası ile giriş sağlayınız.

![odtucard giris](https://faq.cc.metu.edu.tr/tr/system/files/u21699/odtucard-tr-02-edt.png)

**2\.** Sisteme giriş sağladıktan sonra sağ tarafta bulunan yüklenecek tutar kısmına yüklemek istediğiniz tutarı giriniz ve “ODTÜ Kart için para yükle” butonuna basınız.

![yukleme](https://faq.cc.metu.edu.tr/tr/system/files/u21699/odtucard-tr-04.png)

**3\.** İşlem onayı için açılan pencerede “Evet” butonuna basıp onay veriniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/odtucard-tr-05-edt.png)

**4.** Açılan ekranda banka kartı bilgilerinizi girerek ödeme adımını gerçekleştiriniz. Odtucard üzerinden yapılan yüklemeler 3D Secure ile yapılmaktadır. Bu nedenle kartınızın 3D Secure ile ödemeye açık olması gerekmektedir. Bu aşamada bilgileri girmeden sayfadan çıkıldığı durumda ödeme işlemi askıda kalmaktadır. Bu durumda tekrar yükleme yapılabilmesi için bir süre beklemek gerekmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/odtucard_eng-5.png)

**5.** 3D Secure ile ödeme onayı verildikten sonra provizyon işlemi başarılı olduğuna dair mesaj görüntülenmekte, bir süre sonra OdcuCard sayfasına yönlendirilmektedir. Yüklediğiniz tutar bekleyen provizyonda gözükmektedir, bakiye güncelleme terminali veya kiosk kullanarak yüklediğiniz bakiyeyi kartınıza aktarabilirsiniz. Yemek saatleri dışında yapılan yüklemelerde kartınızı harcama terminalinde ilk okutmanız halinde bakiye güncellenecek ve işlem tutarı kartınızdan çekilecektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/odcucard-tr-provizyon-edt.png)