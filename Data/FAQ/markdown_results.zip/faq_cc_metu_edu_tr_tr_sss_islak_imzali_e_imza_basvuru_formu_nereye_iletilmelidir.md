[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/islak-imzali-e-imza-basvuru-formu-nereye-iletilmelidir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-01-2025 **Görüntüleme:** 7376


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/where-should-wet-signed-e-signature-application-form-be-submitted "Where should the wet signed e-signature application form be submitted?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/islak-imzali-e-imza-basvuru-formu-nereye-iletilmelidir "Islak imzalı e-imza başvuru formu nereye iletilmelidir?")

# Islak imzalı e-imza başvuru formu nereye iletilmelidir?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

E-imza başvurularında, KamuSM'den iletilen e-posta takip edilerek doldurulan form, ıslak imza ile imzalanarak ya da Eonay verilerek, KamuSM'ye başvuru yapan kişi tarafından iletilmelidir.

Islak imzalı formu posta yolu ile aşağıdaki adrese gönderebilirsiniz:

**Adres:**

Kamu Sertifikasyon Merkezi

TÜBİTAK Gebze Yerleşkesi (İdari Bina)

P.K. 74, Gebze 41470 KOCAELİ

Başvurunuzu eonay vererek tamamlamak için daha önceden eimza kullanıcısı olmanız ve eonay vermiş olmanız gerekmektedir.

Eonay vermek için aşağıdaki linkte anlatılan işlemleri yapabilirsiniz:

[https://faq.cc.metu.edu.tr/tr/sss/nitelikli-elektronik-sertifika-e-imza-...](https://faq.cc.metu.edu.tr/tr/sss/nitelikli-elektronik-sertifika-e-imza-icin-nasil-e-onay-verilir)

Başvuru sürecine dair detaylı bilgiye [https://faq.cc.metu.edu.tr/tr/sss/kamu-sm-nitelikli-elektronik-sertifika...](https://faq.cc.metu.edu.tr/tr/sss/kamu-sm-nitelikli-elektronik-sertifika-e-imza-basvuru-sureci-nasildir) bağlantısından ulaşılabilir.