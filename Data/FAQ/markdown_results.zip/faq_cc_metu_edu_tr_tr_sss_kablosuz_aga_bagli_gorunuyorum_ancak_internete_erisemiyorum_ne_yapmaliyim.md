[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kablosuz-aga-bagli-gorunuyorum-ancak-internete-erisemiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-11-2018 **Görüntüleme:** 7132


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/it-seems-i-have-connection-wireless-network-i-cant-connect-internet-what-should-i-do "It seems I have a connection to the wireless network but I can't connect to the Internet. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kablosuz-aga-bagli-gorunuyorum-ancak-internete-erisemiyorum-ne-yapmaliyim "Kablosuz ağa bağlı görünüyorum ancak İnternet'e erişemiyorum. Ne Yapmalıyım?")

# Kablosuz ağa bağlı görünüyorum ancak İnternet'e erişemiyorum. Ne Yapmalıyım?

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Android 6 ve önceki sürümleri kullanan bazı Android cihazlarda kablosuz ağa bağlanma ile ilgili problemler yaşandığı tespit edildi. Zaman zaman bu cihazların ekranında kablosuz ağ bağlantısı kurulmuş olarak görünmesine rağmen cihaz İnternet'e erişememektedir. Bu sorun Android yazılımı içerisindeki bir hatadan kaynaklanmakta ve bu hata nedeniyle bahsi geçen cihazlar geçerlilik süresi dolmuş olmasına rağmen daha önceden DHCP üzerinden aldıkları ip adresini kullanmaya çalışmaktadır. Bu sorun ile karşılaştığınızda lütfen cihazınızın Wi-Fi bağlantısını kapatıp tekrar aktif hale getirin.