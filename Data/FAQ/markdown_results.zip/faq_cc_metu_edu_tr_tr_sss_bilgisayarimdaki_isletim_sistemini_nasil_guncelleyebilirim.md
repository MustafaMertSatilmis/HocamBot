[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-isletim-sistemini-nasil-guncelleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-05-2024 **Görüntüleme:** 12459


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-update-operating-system-my-computer "How can I update the operating system of my computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-isletim-sistemini-nasil-guncelleyebilirim "Bilgisayarımdaki işletim sistemini nasıl güncelleyebilirim?")

# Bilgisayarımdaki işletim sistemini nasıl güncelleyebilirim?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

**Windows 11 kullanıyorsanız:**

Başlat > Ayarlar > Güncelleştirme ve Güvenlik > Windows Update'e gidip Güncelleştirmeleri Denetle'yi tıklayınız. Kontrol sonrası, cihazınız için güncelleştirme var ise yükleyiniz.

**Windows 10 kullanıyorsanız:**

Başlangıç > Ayarları > Güncelleştirme & Güvenlik > Windows Update'ı seçin ve ardından Güncelleştirmeleri denetle'yi tıklayınız. Kontrol sonrası, cihazınız için güncelleştirme var ise yükleyiniz.

**Windows 7 kullanıyorsanız:**

Başlat > Programlar > Windows Güncelleme

ya da

Denetim Masası > Sistem ve Güvenlik > Windows Güncelleme

yoluyla açılan ekrandan güncellemeleri denetleyebilirsiniz.

**Linux işletim sistemi kullanıyorsanız:**

Linux tabanlı işletim sistemleri kullanıyorsanız, kullandığınız işletim sistemine göre güncellemeleri farklı sitelerden yapabilirsiniz.

_RedHat:_ **up2date** komutunu kullanarak güncelleme sitesine bağlanabilirsiniz.

_Mandrake:_ **MandrakeUpdate** komutunu kullanarak güncelleme sitesine bağlanabilirsiniz.

 _Debian:_ Öncelikle **apt-setup** programını çalıştırın, kurulu değilse **apt-get** ile kurun. Bu program aracılığıyla önce, Debian paket arşivine erişim yöntemini (ftp ya da http) seçin. Sonraki adımda gelen listeden arşiv sitesini seçin. Bu işlemlerden sonra:

apt-get update: Paket listesini günceller.

apt-get upgrade: Kurulu paketlerin en son halini çekip kurar.