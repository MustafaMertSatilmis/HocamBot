[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/oldinbox-spambox-ve-benzeri-dizinlerdeki-e-postalari-nasil-okuyabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 08-01-2020 **Görüntüleme:** 7129


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-read-e-mails-other-folders-such-oldinbox-spambox-etc "How can I read e-mails in other folders such as OLDINBOX, SPAMBOX etc?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/oldinbox-spambox-ve-benzeri-dizinlerdeki-e-postalari-nasil-okuyabilirim "OLDINBOX, SPAMBOX ve benzeri dizinlerdeki e-postaları nasıl okuyabilirim?")

# OLDINBOX, SPAMBOX ve benzeri dizinlerdeki e-postaları nasıl okuyabilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Aşağıda örnek olarak OLDINBOX dizinlerini okuma şekli anlatılmıştır. SPAMBOX gibi diğer dizinlerdeki epostalara da aynı şekilde erişilebilir.

- _Squirrelmail_ kullanıyorsanız, hesabınıza bağlandıktan sonra, sayfanın üst kısmındaki **Klasörler** seçeneğine tıkladıktan sonra **Çıkar/Ekle** kısmının sağ kısmındaki listeden bakmak istediğiniz OLDINBOX dizinini seçip **Ekle** butonu ile görünebilir hale getirebilirsiniz.
- _Horde_ kullanıyorsanız, **Dizin Eylemleri'ne** tıkladıktan sonra **Tüm Posta Kutularını Göster'e** tıklayınız. Böylece dizin Eylemlerinin altında tüm kalsörleriniz görüntülenecektir. Bakmak istediğiniz OLDINBOX dizinine sağ tıklayarak **üye ol** tıklayınız. Üye olduktan sonra **Dizin Eylemleri'nden** üye olunmayanları gizle'ye tıklaynız. Böylece aşağıda daha az klasör görünmesini sağlayabilirsiniz.
- _Microsoft Outlook_ programını kullanarak OLDINBOX'taki e-postalarınızı okumak istiyorsanız kullandığınız servisin IMAP olması gereklidir. Hesabınızı IMAP ile yapılandırdıktan sonra OLDINBOX dizinlerini görünür hale getirmeniz gerekmektedir.
OLDINBOX dizinlerini görünür hale getirmek için;

  - **Araçlar** (Tools) \| **IMAP Klasörleri** (IMAP Folders) yolunu seçmelisiniz.
  - Açılan pencerede OLDINBOX dizinlerini bulup **Görünür** düğmesine tıklamalısınız.
  - **OK** düğmesine tıkladıktan sonra OLDINBOX.tarih dizinleri IMAP dizinleri altında gözükecektir.
- _Thunderbird_ programını kullanarak OLDINBOX'taki e-postalarınızı okumak istiyorsanız kullandığınız servisin IMAP olması gereklidir. Hesabınızı IMAP ile yapılandırdıktan sonra OLDINBOX dizinlerini görünür hale getirmeniz gerekmektedir.
OLDINBOX dizinlerini görünür hale getirmek için;

  - **File \| Subscribe** yolunu seçmelisiniz.
  - Açılan pencerede OLDINBOX dizinlerini bulup işaretlemelisiniz.
  - **OK** düğmesine tıkladıktan sonra OLDINBOX.tarih dizinleri IMAP dizinleri altında gözükecektir.