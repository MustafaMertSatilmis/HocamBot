[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-icinden-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 10883


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-central-server-systems-campus "How can I connect to the Central Server Systems from campus?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-icinden-nasil-baglanabilirim "Merkezi sunucu sistemlere yerleşke içinden nasıl bağlanabilirim?")

# Merkezi sunucu sistemlere yerleşke içinden nasıl bağlanabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

ODTÜ yerleşkesi içinden **Beluga** ve **Orca** adlı merkezi sunucu sistemlerden birine bağlanabilirsiniz.

Size yardımcı olabilecek programlar içerisinde, WinScp programı Web sitesi olan kişiler için kullanılabilir FTP programlarından biridir. WinSCP sayesinde sunucuda bulunan dosyalarınızdaki izin haklarının değiştirilmesi, dosya kopyalama/taşıma gibi işlemleri yapabilirsiniz. WinSCP (Windows Güvenli Kopyalama –Secure Copy-) için bir açık kaynak SFTP ve FTP istemcisidir. Ayrıca komut sistemi olarak, PuTTY Unix/Linux sunuculara, ağ cihazlarına kadar SSH, Telnet ve COM bağlantıları ile çalışan cihaz ve bilgisayarlara uzaktan oturum açarak işlemler yapmanızı sağlayan ücretsiz bir yazılımdır. PuTTY, genellikle Windows işletim sisteminde SSH bağlantısı desteklenmediğinden dolayı SSH bağlantıları yapmak için kullanılmaktadır. WinSCP programı ile klasör, dosya ve alt dosyalara topluca erişim hak izinlerini ayarlayabilirsiniz.

İki program için de indirme bağlantısı olarak [https://winscp.net/eng/download.php](https://winscp.net/eng/download.php) adresi kullanılabilir.

Not: Güvenlik sebebiyle 21 nolu port yasaklanmış olup, kullanıcılarımızın 22 nolu port üzerinden bağlanmaları gerekmektedir.