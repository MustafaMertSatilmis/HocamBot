[Jump to navigation](https://faq.cc.metu.edu.tr/tr/msc#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-05-2024 **Görüntüleme:** 14123


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/msc "MSC")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/msc "MSC")

# MSC

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MSC ONE—**

**— MSC NASTRAN 2024.1 —**

_**_MSCOne_**, sonlu elemanlar analizi ve modellemesinde kullanılabilen çok amaçlı çok modüllü bir yazılım ailesidir._

_**MSC**_ _**One**_ _Ürün Ailesi: Actran, Adams, Apex, Apex Jaguar, BearingAT, Digimat, Dytran, Easy5, GearAT, Marc, Nastran, Patran, Simufact Additive, Simufact Forming, Simufact Joining, Simufact Welding, SimXpert, Sinda._

_Eğitim materyallerine erişmek için önce Learning Center yazılımı çalıştırılmalı ve daha sonra üyelik sağlanmalıdır._

_**MSC NASTRAN 2024.1**sürümü için hazırlanmış aşağıdaki kurulum ve aktivasyon yönergelerini takip ederek benzer **MSC**_**One**__ _yazılımlarının kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/msc#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/msc#aktivasyon)

* * *

_**\[1\] Öğrenciler için not:** MSC Software firmasının öğrencilere özel oluşturduğu ücretsiz Student Edition platformuna aşağıdaki bağlantı adresinden başvurularak erişilebilir. Öğrenci kimliği  ile başvuru yapıldıktan ve üyelik onayı alındıktan sonra öğrenciler 2 yıl boyunca ücretsiz ve limitli olarak Adams, Apex, Marc, Nastran, Patran ve SimXpert yazılımlarını kullanabilir, webinarlara erişebilir ve kullanım dokümanlarına ulaşabilirler._

_**URL >>** [https://www.mscsoftware.com/student-editions](https://www.mscsoftware.com/student-editions)_

_**\[2\] Aktivasyon hakkında not:**_ Lisans sunucu bilgisi girdiğinizde hata mesajı alırsanız, bu mesajı dikkate almayıp kurulumu tamamlayınız. Kurulum bittikten sonra Windows ortam değişkenlerine aşağıdaki adımları izleyerek bir parametre girmeniz gerekebilir:

- Masaüstünde Bilgisayar sekmesine tıklayınız.
- Bağlam menüsünden Özellikler'i seçiniz.
- Gelişmiş sistem ayarları bağlantısına tıklayınız.
- Ortam Değişkenleri'ne tıklayınız.
- Yeni Sistem Değişkeni oluşturunuz.

Burada **_"MSC\_LICENSE\_FILE"_** isminde değişken oluşturup değer olarak **_" [1700@license.cc.metu.edu.tr](mailto:1700@license.cc.metu.edu.tr)"_** bilgisini giriniz. Bu düzenlemeyi yaptıktan sonra tekrar deneyiniz.

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Next_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step1.png)

**_ADIM-2_**

**_“Acknowledged_** **_”_**_butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step2.png)_

**_ADIM-3_**

_İlgili alanlara bilgilerinizi giriniz ve**“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step3.png)

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step4.png)

**_ADIM-5_**

**_“Next”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step5.png)

**_ADIM-6 <<<AKTİVASYON>>>_**

_Aktivasyon işlemi için **“License”** başlığı karşısındaki alana **“ [1700@license.cc.metu.edu.tr](mailto:1700@license.cc.metu.edu.tr)”**yazıp **“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step6.png)

**_ADIM-7_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step7.png)

**_ADIM-8_**

**_“Acknowledged_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step8.png)

**_ADIM-9_**

**_“Acknowledged_** **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step9.png)

**_ADIM-10_**

**_“Acknowledged_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step10.png)

**_ADIM-11_**

**_“Finish”_** _butonuna tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_nastran_2024_1_step11.png)

* * *

|     |     |
| --- | --- |
| **SOFTWARE** | **INSTALLATION AND OPERATIONS GUIDE \[PDF\]** |
| **Actran** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/actran_2023.1_install.pdf) |
| **Adams** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/adams_2023.1_doc_install.pdf) |
| **Apex** | [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/apex_2022.1_doc_install_en.pdf) \| [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/msc_apex_2023.1_english_installation_guide.pdf) |
| **Apex Generative Design** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/apex_gen_des_2023.1_doc_install_doc_en.pdf) |
| **Apex Jaguar** | [2019](https://faq.cc.metu.edu.tr/system/files/u16319/apex_jaguar_doc_install_doc_en.pdf) |
| **BearingAT** | [2019](https://faq.cc.metu.edu.tr/system/files/u16319/bearing_at_2019_doc_install.pdf) \| [2021](https://faq.cc.metu.edu.tr/tr/system/files/u16319/bearing_at_2021_doc_install.pdf) |
| **Digimat** | [2021.2](https://faq.cc.metu.edu.tr/tr/system/files/u16319/digimat_2021.2_doc_install.pdf) \| [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/digimat_2023.1_install.pdf) |
| **Dytran** | [2021.2](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dytran_2021.2_doc_user.pdf) |
| **Easy5** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/easy5_2023.1_doc_install_windows.pdf) |
| **Elements** | [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/elements_2022.1_doc_content.pdf) |
| **GearAT** | [2019](https://faq.cc.metu.edu.tr/system/files/u16319/gear_at_2019_doc_install.pdf) \| [2021](https://faq.cc.metu.edu.tr/tr/system/files/u16319/gear_at_2021_doc_install.pdf) |
| **Marc** | [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/marc_2022.1_doc_install.pdf) \| [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/marc_2023.1_doc_install.pdf) |
| **Nastran** | [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/nastran_2022.1_doc_install.pdf) \| [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/nastran_2023.1_doc_install.pdf) |
| **ODYSSEE A-Eye** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/odyssee_a-eye_-_installation_v2023.pdf) |
| **ODYSSEE CAE** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/odyssee_cae_2023.1_installation.pdf) |
| **ODYSSEE Solver** | [2023.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/odyssee_solver_2023.1_installation.pdf) |
| **Patran** | [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/patran_2022.1_doc_install.pdf) \| [2022.4](https://faq.cc.metu.edu.tr/tr/system/files/u16319/patran_2022.4_doc_install.pdf) |
| **Simufact Additive** | [2020](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_additive_2020_fp1_whats_new_en.pdf) \| [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_additive_2022.1_installation_guide.pdf) \| [2023.2](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_additive_2023.2_installation_guide.pdf) |
| **Simufact Forming** | [16.0](https://faq.cc.metu.edu.tr/system/files/u16319/simufact_forming_16.0_installation_guide.pdf) \| [2022.1](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_forming_2022.1_installation_guide.pdf) \| [2023.2](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_forming_2023.2_installation_guide.pdf) |
| **Simufact Joining** | [4.0](https://faq.cc.metu.edu.tr/system/files/u16319/simufact_joining_4.0_installation_guide.pdf) \| [2022](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_joining_optimizer_2022_installation_guide_en.pdf) |
| **Simufact Welding** | [2020](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_welding_2020_whats_new_en.pdf) \| [2022](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_welding_2022.0.1_installation_instruction_en.pdf) \| [2023.2](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simufact_welding_2023.2_installation_instructions_en.pdf) |
| **SimXpert** | [2017](https://faq.cc.metu.edu.tr/system/files/u16319/simxpert_2017_doc_install.pdf) \| [2020](https://faq.cc.metu.edu.tr/tr/system/files/u16319/simxpert_2020_doc_install.pdf) |
| **Sinda** | [2017.1](https://faq.cc.metu.edu.tr/system/files/u16319/sinda_2017.1_doc_install.pdf) |

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *