[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-nasil-filtreleyebilir-iletebilir-engelleyebilir-veya-otomatik-olarak-cevap#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 6475


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-nasil-filtreleyebilir-iletebilir-engelleyebilir-veya-otomatik-olarak-cevap)

# Horde iletileri nasıl filtreleyebilir, iletebilir, engelleyebilir veya otomatik olarak cevap verebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### İletileri nasıl filtreleyebilir, iletebilir, engelleyebilir veya otomatik olarak cevap verebilirim?

Gelecekteki iletileri, kullanmakta olduğunuz ileti ile aynı kişiden filtrelemek istiyorsanız, ileti görünümünde Kara liste bağlantısını kullanın. Bu, göndereni filtrelemek için bir kural ekleyecek ve Filtre Kuralları Seçenekleri sayfasına gidebilirsiniz.

Daha genel filtreleme için, Seçenekler menü öğesini seçin ve sonra Posta Yönetimi bölümünden Filtreler'i seçin.

Silinemeyen tüm iletileri belirtilen kurallara göre filtrelemek için Filtre Kuralları sayfasındaki "Tüm Kuralları Uygula" veya kutu görünümündeki INBOX adının yanındaki "Filtreleri Uygula" simgesini tıklatmanız gerekir. Yüklemenizde kalıcı seçenekler varsa, oturum açma ve / veya posta kutusu yenilendiğinde filtre kurallarınızı uygulamak için filtre seçeneklerini ayarlayabilirsiniz.

Filtre Kuralları sayfasından kuralların oluşturulmasını, kaldırılmasını veya düzenini de düzenleyebilirsiniz.

Seçenekler / Posta menüsünde İstenmeyen İleti Bildirimi bölümünde istenmeyen iletilerin hangi klasörde bulunacağını, "İstenmeyen İleti" veya "Temiz" olarak rapor edilen iletilerde hangi işlemlerin uygulanacağını tanımlayabilirsiniz. Ayrıca İstenmeyen İleti klasörünün hangi sıklıkta temizleneceğini de ayarlayabilirsiniz.