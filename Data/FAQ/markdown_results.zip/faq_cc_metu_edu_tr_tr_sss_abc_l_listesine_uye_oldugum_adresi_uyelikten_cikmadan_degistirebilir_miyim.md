[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uye-oldugum-adresi-uyelikten-cikmadan-degistirebilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7863


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-subscribed-abc-l-list-my-e-mail-address-namesurnamedomain-can-i-change-my-subscription "I have subscribed to \"abc-l\"  list with my e-mail address name_surname@domain. Can I change my subscription address without making any  unsubscription-resubscription operations? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uye-oldugum-adresi-uyelikten-cikmadan-degistirebilir-miyim "\"abc-l\" listesine üye olduğum adresi üyelikten çıkmadan değiştirebilir miyim?")

# "abc-l" listesine üye olduğum adresi üyelikten çıkmadan değiştirebilir miyim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Liste üyeliğinden çıkmadan sadece üyelik adresinizi değiştirmeniz mümkündür. Bunun için;

1. **[http://mailman.metu.edu.tr/mailman/listinfo/abc-l](http://mailman.metu.edu.tr/mailman/listinfo/abc-l)** adresinde sayfanın en altında yer alan "Listeden çık veya seçeneklerimi düzenle" yazılı alana listeye üyelik için kullandığınız e-posta adresi ile giriniz.
2. **[http://mailman.metu.edu.tr/mailman/options/abc-l](http://mailman.metu.edu.tr/mailman/options/abc-l)** adresinde sayfanın üst kısmına listeye üyelik şifrenizi giriniz (Eğer üyelik sifrenizi bilmiyorsanız aynı sayfada yer alan "Hatırlatıcı"yı kullanabilirsiniz)
3. Sayfanın en üst alanında "üyelik bilgilerinin değişimi" kısmından üyelik için kullandiğiniz adresinizi değiştirebilirsiniz. Üyelik adresinizi Mailman sistemi altındaki tüm listeler için değiştirmek isterseniz "Adresimi ve ismimi değiştir" butonunun altında yer alan "Global olarak değiştir" seçeneğini işaretlemelisiniz.

(Yukarıda geçen "abc-l" ve "ad\_soyad![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)domain" ifadeleri liste ismi ve e-posta adresi için örnek olarak verilmiştir)