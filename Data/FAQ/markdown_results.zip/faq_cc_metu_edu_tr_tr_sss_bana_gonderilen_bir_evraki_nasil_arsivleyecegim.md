[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bana-gonderilen-bir-evraki-nasil-arsivleyecegim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-02-2024 **Görüntüleme:** 4992


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bana-gonderilen-bir-evraki-nasil-arsivleyecegim)

# Bana gönderilen bir evrakı nasıl arşivleyeceğim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de kullanıcıların evrakları istedikleri klasörlere koyacakları bir yapı bulunmamaktadır. Bütün evraklarınıza istediğiniz zaman Geçmiş bölümünden ulaşabilirsiniz.

[http://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir](http://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir)

[http://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum...](http://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum-nasil-gorebilirim)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.