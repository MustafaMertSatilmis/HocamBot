[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gizli-evraklar-nasil-hazirlanir-ve-gonderilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 10478


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gizli-evraklar-nasil-hazirlanir-ve-gonderilir)

# EBYS'de gizli evraklar nasıl hazırlanır ve gönderilir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Yazışma kuralları gereği EBYS üzerinde herhangi bir gizlilik derecesi bulunan evrak hazırlanmayacaktır. Bu evraklar eski usüllerle hazırlanmaya ve sevk edilmeye devam edecektir.

Ancak evrakın numarası Numara Talep Formu kullanılarak EBYS üzerinden alınacaktır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/gizli.png)

Alınmış olan evrak numaraları iptal edilememektedir. Ancak alınmış olan bir numaranın kullanımından vazgeçilecekse bu durum **"EBYS -> EBYS Evrak Sorgulama -> Evrak Numara Talepleri -> İlgili evrak numara talebi seçimi"** yolu takip edilip ilgili talebe erişildikten sonra not eklenerek belirtilmelidir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.