[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarina-uygulama-kurabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 04-09-2023 **Görüntüleme:** 1346


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-install-applications-pc-rooms "Can I Install Applications in PC Rooms?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarina-uygulama-kurabilir-miyim "PC Salonlarına Uygulama Kurabilir Miyim?")

# PC Salonlarına Uygulama Kurabilir Miyim?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

İşletimi Bilgi İşlem Daire Başkanlığı tarafından sağlanan bilgisayar salonları üniversite geneline hizmet vermekte olup kampüs lisans anlaşması ile satın alınan yazılımlar bu salonlardaki bilgisayarlara yüklenmektedir. PC salonlarında [https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-yuklu-yazilimlar-nelerdir](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-yuklu-yazilimlar-nelerdir) adresindeki lisanslı yazılımlar kullanılabilmektedir.

PC salonlarındaki bilgisayarlara giriş yapan kullanıcılar kısıtlı kullanıcı profili ile giriş yapabilmekte ve program yükleyememektedir. Yönetici izni gerektirmeyen bazı programlar, kurmadan çalıştır (portable) özelliği var ise bu PC'lerde çalışabilir.

Genel kullanıma açık bilgisayar lablarında kısıtlı kullanıcılar tarafından yapılması talep edilen uygulama kurulumu güvenlik, lisans ve uyumluluk nedenleriyle mümkün değildir. Bu tür bir uygulama kurulumu, aşağıdaki riskleri içermektedir:

- **Güvenlik Riski:** PC salonları, birçok farklı kullanıcının erişim sağlayabildiği ve güvenli olması gereken ortamlardır. Herhangi bir kullanıcının bilgisayar labındaki bir uygulamayı değiştirmesi veya kötü amaçlı yazılım yüklemesi durumunda, tüm kullanıcılarımız etkilenebilir. Bu durum PC salonlarının bütünlüğünü ve güvenliğini tehlikeye atabilir.
- **Lisans ve Yasal Sorumluluklar:** Bir uygulama genel kullanıma açık bir bilgisayar salonuna kampüs lisans anlaşması ile satın alınmış ise ya da açık kaynak bir uygulama olarak yasal lisans gereksinimleri karşıladığımız durumlarda kurulmaktadır. Uygulamaların bu gereksinimleri karşılamamak, lisans ihlaline ve dolayısıyla yasal sorunlara yol açabilir.
- **Veri Kaybı Riski:** Uygulama kurulumu sırasında veri kaybı riski vardır. PC salonlarında kullanılan bilgisayarların içindeki verilerin güvenliği ve bütünlüğü her zaman önceliklidir.
- **Uyumluluk Sorunları:** Kurulan uygulama, PC içindeki diğer uygulamalarla uyumsuz olabilir ve bu durum, bilgisayarların verimliliğini etkileyebilir.