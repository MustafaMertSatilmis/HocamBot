[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-ogrenci-asistan-olarak-gorev-almak-istiyorum-nereye-basvurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-10-2021 **Görüntüleme:** 8854


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-ogrenci-asistan-olarak-gorev-almak-istiyorum-nereye-basvurabilirim)

# PC salonlarında öğrenci asistan olarak görev almak istiyorum, nereye başvurabilirim?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

BİDB tarafından işletilen PC salonlarında görev alacak öğrenci asistanlara ihtiyaç duyulduğunda BİDB web sayfasında duyuru yapılmaktadır.

Ayrıca [https://ogrenciasistani.metu.edu.tr/](https://ogrenciasistani.metu.edu.tr/) adresini de takip edebilirsiniz.