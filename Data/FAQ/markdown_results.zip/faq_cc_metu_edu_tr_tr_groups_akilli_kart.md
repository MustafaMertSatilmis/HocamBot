[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Akıllı Kart

|     |
| --- |
| ["Akıllı Kartınız Iptal Edilmiştir. Üniversitenize Başvurunuz" uyarısı almaktayım. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartiniz-iptal-edilmistir-universitenize-basvurunuz-uyarisi-almaktayim-ne-yapmaliyim) |
| [Akıllı kartım değişti, eski kartımdaki nakit para yeni kartıma aktarılır mı?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartim-degisti-eski-kartimdaki-nakit-para-yeni-kartima-aktarilir-mi) |
| [Akıllı kartıma İş Bankası aracılığı ile nasıl bakiye yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-bankasi-araciligi-ile-nasil-bakiye-yuklerim) |
| [Akıllı kartıma online bakiye yükleme sisteminden (odtucard) para yükledim, yüklediğim bakiye kartıma aktarılmadı. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-online-bakiye-yukleme-sisteminden-odtucard-para-yukledim-yukledigim-bakiye) |
| [Akıllı kartıma yükleme yaptığım banka kartı e-ticarete açık değil, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yukleme-yaptigim-banka-karti-e-ticarete-acik-degil-ne-yapabilirim) |
| [Akıllı kartıma yurt dışı menşei banka kartımla yükleme yapabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yurt-disi-mensei-banka-kartimla-yukleme-yapabilir-miyim) |
| [Akıllı kartımı harcama/yükleme noktalarında okuttuğumda “kartınız okunamadı” / “kartınız tanınmadı” hatası almaktayım. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-harcamayukleme-noktalarinda-okuttugumda-kartiniz-okunamadi-kartiniz-taninmadi) |
| [Akıllı kartımı kaybettim, yeni kart başvurusunda bulundum. Kısa bir süre sonra kayıp kartımı buldum ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-kaybettim-yeni-kart-basvurusunda-bulundum-kisa-bir-sure-sonra-kayip-kartimi) |
| [Akıllı kimlik kartım iptal edildiğinde içerisindeki sanal para banka kartıma ne zaman aktarılır?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-iptal-edildiginde-icerisindeki-sanal-para-banka-kartima-ne-zaman-aktarilir) |
| [Akıllı kimlik kartım kırıldı, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-kirildi-ne-yapmaliyim) |
| [Akıllı kimlik kartıma yüklediğim sanal para hemen veya birkaç kullanımdan sonra sıfırlandı, bu durumda ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartima-yukledigim-sanal-para-hemen-veya-birkac-kullanimdan-sonra-sifirlandi-bu) |
| [Akıllı kimlik kartımda bulunan parayı hesabıma geri aktarabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimda-bulunan-parayi-hesabima-geri-aktarabilir-miyim) |
| [Akıllı kimlik kartımı değiştirdim. Yeni kimliğimi kullanıma açmam gerekir mi?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirdim-yeni-kimligimi-kullanima-acmam-gerekir-mi) |
| [Akıllı kimlik kartımı değiştirmek istediğimde kartımda bulunan para yeni kimliğime aktarılır mı?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirmek-istedigimde-kartimda-bulunan-para-yeni-kimligime-aktarilir-mi) |
| [Akıllı kimlik kartımı kaybettim/çalındı, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-kaybettimcalindi-ne-yapmaliyim) |
| [Bölüm binası kartlı geçişinden giriş-çıkış yapamıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bolum-binasi-kartli-gecisinden-giris-cikis-yapamiyorum-ne-yapmaliyim) |
| [Bölüm-Birim kartlı geçiş yetkilendirmesinden sorumlu kişiyim. Kartı geçiş yetkilendirme arayüzüne nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bb-kartli-gecis-listesi) |
| [Harcamalarımı ve yüklemelerimi nasıl takip edebilirim?](https://faq.cc.metu.edu.tr/tr/sss/harcamalarimi-ve-yuklemelerimi-nasil-takip-edebilirim) |
| [Mezun oldum, iptal edilen kartımdaki nakit para iade edilebilir mi?](https://faq.cc.metu.edu.tr/tr/sss/mezun-oldum-iptal-edilen-kartimdaki-nakit-para-iade-edilebilir-mi) |
| [Nakit harcama/yükleme cihazlarına akıllı kimlik kartımı okuttuğumda ekranda farklı isim/soyisim görüyorum. Bunun sebebi nedir?](https://faq.cc.metu.edu.tr/tr/sss/nakit-harcamayukleme-cihazlarina-akilli-kimlik-kartimi-okuttugumda-ekranda-farkli-isimsoyisim) |
| [ODTÜ Akıllı Kart Tarihçesi](https://faq.cc.metu.edu.tr/tr/sss/odtu-akilli-kart-tarihcesi) |
| [ODTÜ personeliyim. Yakınım için kimlik kartı çıkartabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-yakinim-icin-kimlik-karti-cikartabilir-miyim) |
| [Odtucard websitesi aracılığı ile nasıl para yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/odtucard-websitesi-araciligi-ile-nasil-para-yuklerim) |
| [SoliClub uygulması ile akıllı kartıma nasıl bakiye yüklerim ve harcama yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/soliclub-uygulmasi-ile-akilli-kartima-nasil-bakiye-yuklerim-ve-harcama-yapabilirim) |
| [Talep etmiş olduğum iade hala akıllı kimlik kartıma yüklenmedi. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/talep-etmis-oldugum-iade-hala-akilli-kimlik-kartima-yuklenmedi-sorun-ne-olabilir) |

## Pages

- 1
- [2](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart?page=1 "Go to page 2")
- [sonraki ›](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart?page=1 "Go to next page")
- [son »](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart?page=1 "Go to last page")

[![Subscribe to Akıllı Kart](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/32/all/feed "Subscribe to Akıllı Kart")