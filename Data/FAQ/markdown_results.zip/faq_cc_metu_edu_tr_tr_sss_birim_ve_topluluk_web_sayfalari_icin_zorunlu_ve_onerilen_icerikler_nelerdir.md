[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 12076


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-are-required-and-suggested-content-features-web-pages-academicadministrative-units-and "What are the Required and Suggested Content Features for the Web Pages of Academic/Administrative Units and Student Clubs")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir "Birim ve Topluluk Web Sayfaları için Zorunlu ve Önerilen İçerikler Nelerdir?")

# Birim ve Topluluk Web Sayfaları için Zorunlu ve Önerilen İçerikler Nelerdir?

[Web Servisleri](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri)

1. [Bulunması zorunlu özellikler](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir#1)
2. [Bulunması önerilen özellikler](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir#2)
3. [Akademik birimler için içerik önerileri](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir#3)
4. [İdari birimler için içerik önerileri](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir#4)
5. [Öğrenci toplulukları için içerik önerileri](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir#5)

**1\. Bulunması zorunlu özellikler**

Tüm birim ve topluluk web sayfalarının aşağıdaki özellikleri içermesi gerekmektedir:

- Birimlerin/toplulukların ana ve/ya alt sayfalarından ODTÜ ana sayfasına bağlantı sağlanmalıdır ( [http://www.odtu.edu.tr](http://www.odtu.edu.tr/) veya [http://www.metu.edu.tr](http://www.metu.edu.tr/)).
- Birimlerin/toplulukların ana ve/ya alt sayfalarında, kullanıcıların yorum, öneri veya sorularını iletebilmesi için iletişim bilgisi (en azından bir e-posta adresi ve mümkünse bir telefon numarası) bulundurulmalıdır.
- Tüm sayfalar düzenli olarak kontrol edilmeli ve güncellenmelidir (örneğin, eski ve geçersiz bilgiler ile kırık bağlantılar düzeltilmeli veya sayfadan çıkarılmalıdır.) Sıkça güncellenen sayfalarda "en son güncelleme tarihi" belirtilmelidir.

**2\. Önerilen özellikler**

Birim/topluluk web sayfaları hazırlanırken aşağıdaki konular göz önünde bulundurulmalıdır:

- Birim/topluluk web sayfaları sınırlı kotaya sahip web hesapları üzerinde tutulmaktadır. Bu hesapların verimli kullanımı için, kendilerine ayrılmış alan üzerindeki gereksiz dosyaların silinmesi ve dosya boyutlarının web için uygun hale getirilmesi gerekmektedir. Web sayfalarında sunulacak imajlar, metinler, belgeler vb. diğer nesneler, erişilebilirlik kriterleri gereğince, mümkün olduğunca web ortamına adapte edilmelidir (örneğin, büyük dosyalar sıkıştırılmalı, metinler için okunaklı font büyüklüğü seçilmeli veya imajlar web için optimize edilmelidir.)
- Web dokümanları mümkünse web editörü bir programla hazırlanmalı, MS Word programının "Save as Web Page" seçeneği tercih edilmemelidir. Mutlaka tercih edilmesi gerekli ise, oluşturulacak dosya tipinin "Filtered Web Page" olmasına dikkat edilmelidir ve sonrasında oluşan kaynak kodu gereksiz etiketlerden arındırılmalıdır.
- Web sayfalarında başka kaynaklardan edinilmiş metin veya çokluortam nesneleri kullanılıyor ise bu kaynaklar belirtilmelidir.
- Web sayfalarının içerik ve tasarımı hazırlanırken **[ODTÜ Bilişim Kaynakları Kullanım Politikaları](http://bilisim-etigi.metu.edu.tr/)** gözönünde bulundurulmalıdır.
- Web sayfaları yabancı kullanıcılara yönelik bilgiler içeriyor ise Türkçe hazırlanmış içeriğin İngilizce versiyonu da hazırlanmalıdır.

**3\. Akademik birimler için içerik önerileri**

Akademik birimler web sayfalarını hazırlarken aşağıdaki bilgi yapısı önerilerinden yararlanabilirler:

- Özet bilgiler (birimi diğer üniversitelerdeki benzer birimlerden ayıran özellikler, ...)
- Genel bilgiler (birimin tarihçesi, gelecekteki planları ve çalışmaları, olanakları, ...)
- Programlar (lisans/yüksek lisans programları, ders açıklamaları, açılan dersler, ders programları, ...)
- Birim çalışanları (isim, ünvan, adres, telefon, e-posta, araştırma/ilgi alanları vb.)
- Öğrenciler (öğrenci listeleri, öğrenci grupları, ...)
- Araştırma olanakları/çalışmaları (projeler, merkezler, ...)
- Yayınlar (kitaplar, makaleler, ...)
- Duyurular (seminer ve konferans gibi etkinlikler, çalışanlara ve öğrencilere yönelik duyurular, ...)
- Referanslar ve kaynaklar (i.e. FTP Sitesi, bağlantılar, ...)

**4\. İdari birimler için içerik önerileri**

İdari birimler web sayfalarını hazırlarken aşağıdaki bilgi yapısı önerilerinden yararlanabilirler:

- Misyon, vizyon, kısa tarihçe
- Organizasyon bilgileri (alt birimler, organizasyon şeması, ..)
- Birim çalışanları (isim, ünvan, adres, telefon, e-posta vb.)
- Verilen hizmetler ve faaliyet alanları (hizmetler ve faaliyetler hakkında detaylı bilgiler, bu hizmetlerden yararlanma yöntemleri, ...)
- Duyurular (hizmetlerle ilgili duyurular, çalışanlara ve öğrencilere yönelik duyurular, ...)

**5\. Öğrenci toplulukları için içerik önerileri**

Öğrenci toplulukları web sayfalarını hazırlarken aşağıdaki bilgi yapısı önerilerinden yararlanabilirler:

- Misyon ve kısa tarihçe (topluluğun varolma sebepleri ve amaçları, kuruluş bilgileri, ...)
- Etkinlikler (topluluk tarafından veya başka kurumlar tarafından düzenlenen etkinlik bilgileri, ...)
- Topluluk üyeleri (organizasyon şeması, çalışma grupları, ...)
- Duyurular (etkinlik duyuruları, topluluk hakkındaki duyurular, ...)
- İlgili bağlantılar (diğer üniversitelerdeki benzer topluluklar, ilgili kurumlar, ...)