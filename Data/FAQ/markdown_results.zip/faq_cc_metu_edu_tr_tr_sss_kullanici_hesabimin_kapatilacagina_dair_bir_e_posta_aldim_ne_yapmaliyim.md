[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimin-kapatilacagina-dair-bir-e-posta-aldim-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 02-11-2021 **Görüntüleme:** 7512


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabimin-kapatilacagina-dair-bir-e-posta-aldim-ne-yapmaliyim)

# Kullanıcı hesabımın kapatılacağına dair bir e-posta aldım. Ne yapmalıyım?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

Kullanıcı hesapları, ODTÜ personelinin / ODTÜ öğrencilerinin üniversite'de görev yaptığı/ders kaydı bulunduğu dönemlerde üniversite bilişim kaynaklarına erişebilmesi için kullanıma sunulmaktadır.

Herhangi bir nedenle öğrenciliği sonlanan veya öğrenciliğe ara vererek kayıtsız duruma geçen öğrencilerimizin kullanıcı hesapları bir (1) eğitim dönemi sonrasında kapatılmaktadır. Yeniden öğrenciliğe dönmeleri (ders kayıtları sonrasında kayıtlı duruma geçmeleri) ardından kullanıcı hesap durumları güncellenmektedir ve kapatılma tarihi uzatılmaktadır. Her ders kayıt dönemi sonrasında bu kontroller yeniden işletilmekte ve öğrencilik durumuna göre kullanıcı hesaplarının süreleri güncellenmektedir.

Ders kaydı bulunmaması nedeniyle kullanıcı hesabı kapatılacak olan kullanıcılarımıza bu durum belirli aralıklarla eposta ile bildirilir. Bu durumdaki öğrencilerimizin ders kayıtlarının tamamlanması ardından kayıtlı duruma geçmeleri halinde kullanıcı hesap durumları güncellenecektir ve kapatılma tarihleri uzatılacaktır.