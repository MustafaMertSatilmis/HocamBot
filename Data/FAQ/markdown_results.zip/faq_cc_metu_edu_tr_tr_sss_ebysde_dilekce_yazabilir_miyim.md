[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-dilekce-yazabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 7694


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-dilekce-yazabilir-miyim)

# EBYS'de dilekçe yazabilir miyim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Hayır.

EBYS'de yalnızca biriminizle ilişkili işlerle ilgili yazı hazırlayabilirsiniz. Tabii olarak da yazdığınız her bir yazı birim yöneticiniz tarafından imzanlanmak durumundadır.

Dilekçe türü bir yazıyı başka bir ortamda yazıp, çıktı alıp, imzalayıp, Evrak Arşiv Müdürlüğüne teslim etmelisiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.