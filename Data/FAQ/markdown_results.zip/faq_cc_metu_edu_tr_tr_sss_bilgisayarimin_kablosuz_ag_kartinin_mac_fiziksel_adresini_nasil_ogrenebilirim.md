[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-kablosuz-ag-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-03-2018 **Görüntüleme:** 204252


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-wireless-adapter-my-computer "How can I find out the MAC (physical) address of the wireless adapter of my computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-kablosuz-ag-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim "Bilgisayarımın kablosuz ağ kartının MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Bilgisayarımın kablosuz ağ kartının MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

MAC (Media Access Control) adresi, bilgisayar ağında bir cihazın ağ donanımını tanımaya yarayan, 0-9 arası rakamlar ve A-F arası harflerden oluşan ifadedir. Her ağ arayüzünün (ethernet, kablosuz, bluetooth vb.) kendine özel, benzersiz birer MAC adresi vardır.

ODTÜ yerleşkesinde kurulu olan kablolu ağlarda MAC adresi tabanlı kimlik doğrulama sistemi çalışmaktadır. ODTÜ kablosuz ağına (meturoam) bağlanmak için [https://faq.cc.metu.edu.tr/tr/sss/meturoam](https://faq.cc.metu.edu.tr/tr/sss/meturoam) adresindeki yönergeleri uygulayabilirsiniz.

- **Windows işletim sistemlerinde;**

Başlat > Programlar > Donatılar > Komut İstemi

yoluyla ya da;

Başlat > Çalıştır > cmd

yazıp **Tamam** düğmesine tıklayınca açılan komut istemi ekranında **getmac /v** komutunu girerek Enter tuşuna basın. **Kablosuz Ağ Bağlantısı** satırında **Fiziksel Adres** kolonunun altında Ethernet kartınızın MAC adresini görebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac05_tr.jpg)

Komut istemi ekranında **ipconfig /all** komutuyla da **Kablosuz LAN bağdaştırıcısı Kablosuz Ağ Bağlantısı** altında yer alan **Fiziksel Adres** satırında kablosuz ağ kartınızın MAC adresini görebilirsiniz. Bu komutla IP adresi vb. diğer ağ bilgilerine de ulaşabilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac06_tr.jpg)

- **MAC OSX işletim sistemlerinde;**

Apple > System Preferences > Network

yoluyla açılan pencerede sol taraftaki bağlantı noktaları arasından **AirPort** seçeneğini seçip **Advanced** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac07.jpg)

**AirPort** sekmesi altındaki **AirPort ID** satırında kablosuz ağ kartınızın MAC adresini görebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac08.jpg)