[Jump to navigation](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-inventor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-01-2022 **Görüntüleme:** 11235


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/autodesk-autocad-inventor "AUTODESK AUTOCAD INVENTOR")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-inventor "AUTODESK AUTOCAD INVENTOR")

# AUTODESK AUTOCAD INVENTOR

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

Autodesk Inventor, ürünlerin tasarım, görselleştirme ve simulasyonunu için kullanılan 3D dijital prototip oluşturan bir bilgisayar destekli tasarım programıdır. Autodesk Inventor programı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" adresinden temin edilebilir.

[Kurulum](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-inventor#kurulum)

Kurulum:

**1\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv1.png)**

**2\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv2.png)**

**3\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv3.png)**

**4\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv4.png)**

**5\. Adım:** Kullanılacak olan seri numarası ve ürün anahtarı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" sitesinden edinilebilir.

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv5.png)**

**6\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv6.png)**

**7\. Adım:**"Configure" seçeneği seçilerek kurulum yapılandırması seçenekleri düzenlenir.

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv7.png)**

**8\. Adım:** Lisans sunucusu olarak "autodesk.cc.metu.edu.tr" girilir.

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv8.png)**

**9\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv9.png)**

**10\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv10.png)**

**11\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv11.png)**

**12\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv12.png)**

**13\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv13.png)**

**14\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv14.png)**

**15\. Adım:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/inv18.png)**

**Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**