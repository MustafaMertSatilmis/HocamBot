[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumu-ve-parolami-nerelerde-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-02-2023 **Görüntüleme:** 9559


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/which-platforms-can-i-use-my-metu-user-code-and-password "On which platforms can I use my METU user code and password?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumu-ve-parolami-nerelerde-kullanabilirim "ODTÜ kullanıcı kodumu ve parolamı nerelerde kullanabilirim?")

# ODTÜ kullanıcı kodumu ve parolamı nerelerde kullanabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

[Parola](https://faq.cc.metu.edu.tr/tr/groups/parola)

ODTÜ kullanıcı kodunuzla BİDB tarafından sunulan aşağıdaki hizmetlere erişebilirsiniz:

- E-posta okuyabilir (Horde, Squirrelmail, POP3/IMAP kullanan e-posta programları [https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari))
- Elektronik listelere erişebilir ( [http://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler](http://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler))
- Web sayfası hazırlayabilir ( [https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nas...](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nasil-web-sayfasi-olusturabilirim))
- Bilgi İşlem Daire Başkanlığı tarafından işletilen PC Salonlarını ( [http://pc-salon.bidb.odtu.edu.tr](http://pc-salon.bidb.odtu.edu.tr/)) kullanabilir
- Öğrencilerimiz, öğrenci portalı sayfasına erişerek etkileşimli kayıt yaptırmak, duyuruları ve kişisel bilgileri takip edebilir. ( [https://student.metu.edu.tr/](https://student.metu.edu.tr/)).
- Akademik personelimiz, METU-SIS sayfasına ( [https://sis.metu.edu.tr](https://sis.metu.edu.tr/)) erişerek ders işlemlerini gerçekleştirebilir.
- Öğrenme Yönetim Sistemini (ODTÜCLASS - [https://odtuclass.metu.edu.tr](https://odtuclass.metu.edu.tr/)) kullanabilir.
- ODTÜ Portal'ı kullanabilir ( [https://portal.metu.edu.tr](https://portal.metu.edu.tr/))
- ODTÜ birimlerinin sunduğu diğer hizmetlere erişebilirsiniz.