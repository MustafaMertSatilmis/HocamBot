[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimini-nasil-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-02-2025 **Görüntüleme:** 3647


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimini-nasil-yuklerim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 3. Adım: DSClient uygulamasını nasıl yüklerim?\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- [**Buradan**](https://portal.synergynow.io/#/_redirect/thTIpQTQ3TfatSsCrhVset) MacOS için güncel DSClient yazılımını (son versiyon: 1.5.5) indiriniz.

_**ÖNEMLİ NOT:**Bilgisayarında halen 1.5.5 versiyonu öncesi DSClient yazılımı bulunan kullanıcılarımızın mevcut versiyonla sorunsuz olarak e-imzalama yapabilmesi için [https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi](https://faq.cc.metu.edu.tr/tr/sss/ebys-dsclient-lisans-dosyasi-degisikligi) sayfasında tarif edilen lisans dosyası değişikliğini yapması ya da DSClient yazılımını 1.5.5 versiyonuna güncellemesi gerekmektedir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-16_15.55.08.png)

2- İndirilen sıkıştırılmış dosyaya tıklayınız ve dosyanın açılmasını sağlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-16_15.56.16.png)

3- Klasöre tıklayarak kurulum dosyalarına erişiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-16_16.04.01.png)

4- Kurulum dosyalarına eriştikten sonra Terminal'i açınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-16_16.04.34.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-16_16.04.47.png)

5- Açılan terminale "sh" yazıp boşluk bıraktıktan sonra kurulum dosyaları arasındaki "DSClientMac.sh" isimli dosyayı tutup sürükleyerek terminale bırakınız. Ardınan enter düğmesine basınız ve bilgisayardaki kullanıcınızın şifresini girerek tekrar enter düğmesine basınız. Herhangi bir uyarı vermeden aşağıdaki resimdeki gibi yeni bir satıra geçildiğinde kurulum tamamlanmış demektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-16_16.06.41.png)

**Kurulum Kaldırma İşlemi**

DSClient yazılımını bilgisayarınızdan kaldırmak isterseniz Terminal'i açtıktan sonra şu iki satırı çalıştırınız:

sudo launchctl stopcom.dsclient.bms

sudo launchctl unload /Library/LaunchDaemons/com.dsclient.bms.plist

* * *

Yukarıda tarif edilen adımları uygulamanıza rağmen EBYS'de e-imza kullanımıyla ilgili problem yaşıyorsanız ya da e-imza ile ilgili farklı sorularınız olursa [https://faq.cc.metu.edu.tr/tr/groups/e-imza](http://faq.cc.metu.edu.tr/tr/groups/e-imza) adresindeki sıkça sorulan soruları inceleyebilirsiniz.

EBYS ilgili sorularınızı [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletebilirsiniz.

* * *