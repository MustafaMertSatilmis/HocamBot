[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-adres-defterimi-nasil-olusturabilir-ve-duzenleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1473


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-adres-defterimi-nasil-olusturabilir-ve-duzenleyebilirim)

# Roundcube'de adres defterimi nasıl oluşturabilir ve düzenleyebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube'de adres defterinizi düzenlemek için ana menüde yer alan "Kişiler" butonuna tıklayınız. Açılacak olan ekranda "Ekle" butonunu kullanarak tanımlı kişiler arasına istediğiniz yeni e-posta adreslerini ve bu kişilerle ilgili diğer bilgileri (Örneğin Telefon, Adres, Notlar vs.) ekleyebilir ve "Kaydet" butonuna tıklayarak girdiğiniz bilgileri kaydedebilirsiniz.

Halihazırda bulunan bir adres defterindeki kişilerin bilgilerini "İçe Aktar" butonu yardımıyla Roundcube'e yükleyebilirsiniz. Kişi ekleme penceresi açıldığında görünecek olan "İçe Aktar" butonu,  vCard ve CSV (virgül ile ayrılmış veriler) dosya biçimleriyle kaydedilmiş adres defterlerinin Roundcube'e aktarılmasına olanak sağlar.

Roundcube'de oluşturduğunuz adres defterinizdeki kişileri dışarı aktarmak için "Dışa Aktar" butonunu kullanabilirsiniz. Bu butona tıkladığınızda, Roundcube'de kayıtlı kişileriniz ".vcf" uzantılı bir dosya olarak bilgisayarınıza indirilecektir.

ODTÜ webmail arayüzlerinden Squirrelmail arayüzünde daha önceden oluşturduğunuz adres defteriniz ve kayıtlı kişileriniz, Roundcube arayüzünde ilk kez oturum açmanızın ardından Roundcube’e kopyalanacaktır. Ancak Roundcube arayüzünde ilk kez oturum açmanızın ardından, Squirrelmail ve Roundcube arayüzlerindeki adres defterleri birbirlerinden bağımsız olarak çalışmaya devam edeceklerdir.

Horde webmail arayüzünde daha önceden oluşturduğunuz adres defteriniz ve kayıtlı kişilerinizi Roundcube’e taşımak için, Horde webmail arayüzüne giriş yapıp kişilerinizi dışarı aktarabilirsiniz. Vcard ya da CSV biçiminde dışarı aktaracağınız dosyayı Roundcube arayüzünde yukarıda anlatıldığı şekilde içeri aktarabilirsiniz.