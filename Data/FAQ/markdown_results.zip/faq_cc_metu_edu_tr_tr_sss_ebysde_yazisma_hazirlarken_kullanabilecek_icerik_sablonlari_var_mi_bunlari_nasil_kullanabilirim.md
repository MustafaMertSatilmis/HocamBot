[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazisma-hazirlarken-kullanabilecek-icerik-sablonlari-var-mi-bunlari-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5760


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazisma-hazirlarken-kullanabilecek-icerik-sablonlari-var-mi-bunlari-nasil-kullanabilirim)

# EBYS’de yazışma hazırlarken kullanabilecek içerik şablonları var mı, bunları nasıl kullanabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de kullanmak üzere yazı şablonları kaydedebilirsiniz veya daha önce oluşturulan şablonları kullanabilirsiniz.

Bu şablonları kullanarak yazı oluşturmak için:

**EBYS -> "Kurum İçi/Dışı Yazışma" -> "Kurum İçi/Dışı Yazı oluştur"** yolu ile yeni yazı oluşturma ekranına gidilir.

Üst kısımda bulunan düğmelerden "Şablon Seç"e tıklanır.

Daha önce hazırlamış olduğunuz şablonlardan bir tanesi seçilir.

Artık şablondan gelen bütün alanlar hazır bulunmaktadır.

İstediğiniz ekleme, çıkarma ve değişiklikleri yaparak yazıyı gönderebilirsiniz.

Birtakım şablonlar önceden hazırlanmış olup Üniversite geneline açıktır. Bu şablonlardan birtanesini de kullanmak mümkündür.

Bu işlemleri görebilmek için [bu videoyu izleyebilirsiniz](https://www.youtube.com/watch?v=-GwE8CC3hNA).

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.