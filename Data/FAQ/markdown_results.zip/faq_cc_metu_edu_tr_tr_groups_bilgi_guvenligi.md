[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Bilgi Güvenliği

|     |
| --- |
| [Apple MAC bilgisayarımı daha güvenli yapmak için neler yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/apple-mac-bilgisayarimi-daha-guvenli-yapmak-icin-neler-yapabilirim) |
| [Bilgisayarımdaki işletim sistemini nasıl güncelleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimdaki-isletim-sistemini-nasil-guncelleyebilirim) |
| [Fidyeci (CryptoLocker) Nedir ve Bu Zararlı Yazılımdan Korunma Yolları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/fidyeci-cryptolocker-nedir-ve-bu-zararli-yazilimdan-korunma-yollari-nelerdir) |
| [İç IP dağıtım logu nedir?](https://faq.cc.metu.edu.tr/tr/sss/ic-ip-dagitim-logu-nedir) |
| [Phishing nedir?](https://faq.cc.metu.edu.tr/tr/sss/phishing-nedir) |
| [Yer Sağlayıcı Trafik Bilgisi Nedir?](https://faq.cc.metu.edu.tr/tr/sss/yer-saglayici-trafik-bilgisi-nedir) |
| [Zaman damgası nedir, niçin kullanılması gerekmektedir?](https://faq.cc.metu.edu.tr/tr/sss/zaman-damgasi-nedir-nicin-kullanilmasi-gerekmektedir) |

[![Subscribe to Bilgi Güvenliği](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/4/all/feed "Subscribe to Bilgi Güvenliği")