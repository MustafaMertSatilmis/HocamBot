[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarindaki-bilgisayarlara-kampus-disindan-nasil-erisebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 27-10-2021 **Görüntüleme:** 14512


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-access-computers-pc-rooms-campus "How can I access the computers in the PC rooms from off campus?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarindaki-bilgisayarlara-kampus-disindan-nasil-erisebilirim "PC salonlarındaki bilgisayarlara kampüs dışından nasıl erişebilirim?")

# PC salonlarındaki bilgisayarlara kampüs dışından nasıl erişebilirim?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

Öğrencilerimiz PC salonlarındaki bilgisayarlarda kurulu lisanslı yazılımları uzaktan erişim imkanıyla kullanabilmektedir. Aşağıdaki adımları takip ederek PC salon bilgisayarlarına uzaktan bağlanabilir ve kurulu lisanslı yazılımları kullanabilirsiniz.

**Olası ağ ve elektrik problemleri / kesintileri nedeniyle erişiminizin kesilebileceğini göz önüne alarak aralıklı olarak çalışma dosyalarınızı bilgisayarın J: sürücüsüne kaydetmeniz ve kopyala-yapıştır yöntemiyle kendi bilgisayarınıza aktarmanız önemlidir.**

**Eğer 15 dakika boyunca herhangi bir işlem yapmadan oturumunuzu açık bırakırsanız, otomatik olarak oturumunuz kapatılacaktır. Bu nedenle çalışmanız sona erdiğinde dosyalarınızı kendi bilgisayarınıza aktararak oturumunuzu kapatmanız gerekmektedir.**

Bağlantı kurabilmek için

- eğer kampüs dışından bağlanıyorsanız, öncelikle VPN uygulamasının çalıştırılması gerekmektedir. [http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) adresinden detaylı bilgi alınabilir, işletim sisteminize uygun sürümü kurma talimatlarına erişebilirsiniz. Kampüs içi bağlantılarda VPN gerekli değildir.
- erişim için gerekli Uzak Masaüstü Bağlantı / Remote Desktop Client uygulaması Windows bilgisayarlarda yüklüdür. MAC OS kullanan öğrencilerimiz, [https://apps.apple.com/us/app/microsoft-remote-desktop/id1295203466?mt=12](https://apps.apple.com/us/app/microsoft-remote-desktop/id1295203466?mt=12) adresindeki Microsoft Remote Desktop uygulamasını kurmalıdır.

[https://pcrooms.cc.metu.edu.tr](https://pcrooms.cc.metu.edu.tr/) adresini ziyaret edin ve ODTÜ kullanıcı kodu – şifrenizle giriş yapın. Bağlantıya hazır PC salonları listesi görüntülenecektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms1.png)

2\. Uygun salonlardan birini seçin. Bağlantı yapılabilecek PC listesi görüntülenecektir. Ardından bir bilgisayarın Request bağlantısını tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms2.png)

Bilgisayarı seçtikten sonra **Download & run the file to connect** düğmesine basın. Bilgisayara bağlantı kurabilmek için 5 dakika süreniz olacaktır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms3.png)

Bilgisayarınıza indirilen connect.rdp dosyasının konumunu açın ve dosyaya çift tıklayıp çalıştırın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms4.png)

Ekrana gelebilecek uyarı mesajlarında CONNECT ve YES düğmelerine basın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms5.png)![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms6.png)

Bir süre sonra karşınıza gelecek Windows oturum açma ekranında ODTÜ şifrenizi yazarak PC salon bilgisayarında oturum açabilirsiniz. Eğer kullanıcı kodunuz otomatik olarak yazılmamış olursa kullanıcı kodunuzu da yazmanız gerekmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms7.png)

Bu aşamada "authentication error" hatası alırsanız connect.rdp dosyasına tekrar çift tıklayın ve giriş ekranının sağ alt bölümündeki klavye düzenini kontrol ederek şifrenizi tekrar yazın.

Eğer 5 dakikalık bağlantı süreniz sona ermişse bağlantı sürenizin dolduğu şeklinde bir mesaj alabilirsiniz. Bu durumda yeniden bir istek yapmanız gerekmektedir.

Masaüstünde bulunan Program Shortcuts klasöründen kurulu yazılımlara ulaşabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms8.png)

Çalışmanız sona erdiğinde Windows Başlat menüsündeki Log off düğmesi ile oturumunuzu kapatabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/remotelab_pc_rooms9.png)

Uygulamamıza dair görüş-öneri ve karşılaştığınız sorunları [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.