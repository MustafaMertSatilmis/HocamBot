[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/felaket-kurtarma-merkezi-ve-surekliligi-nasil-saglanmaktadir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 14-09-2017 **Görüntüleme:** 7801


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/felaket-kurtarma-merkezi-ve-surekliligi-nasil-saglanmaktadir)

# Felaket Kurtarma Merkezi ve İş Sürekliliği Nasıl Sağlanmaktadır?

[BİDB hakkında](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda)

**FELAKET KURTARMA MERKEZİ ve İŞ SÜREKLİLİĞİ NASIL SAĞLANMAKTADIR?**

Felaket Kurtarma Merkezi, ODTÜ BİDB sistem odasını etkileyebilecek, yangın, sel, deprem gibi doğal afetler sonucunda oluşabilecek kurumsal veri ve altyapı kaybının yaşanması durumunda yedek sunucu, yedek veri depolama ve yedek ağ altyapısını kullanarak güncel veri ile ODTÜ bilişim servislerinin uzak noktadan hizmet verebilmesini sağlamaktadır.

Turkcell Superonline'ın Ankara Söğütözü veri merkezinde üniversitemize tahsis edilen güvenli, paylaşımsız ve erişimi sadece üniversitemizin görevlendirdiği yetkili personele açık olan alanda Mayıs 2017 tarihinde kurulumu tamamlanan Felaket Kurtarma Merkezi, BİDB sistem odasından ODTÜ'ye hizmet veren bilişim servislerinin tamamına yakınının anlık yedeklerini tutmakta ve servisler felaket durumunda hizmet vermeye hazır halde bekletilmektedir.

ODTÜ Bilgi İşlem Daire Başkanlığı Sistem Odası ve Felaket Kurtarma Merkezi arasındaki veri eşitlemesi; paylaşımsız, güvenli ve yedekli fiber optik hatlardan anlık olarak sağlanmaktadır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fkm.png)