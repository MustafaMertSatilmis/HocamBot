[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroama-nasil-baglanilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 44553


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-connect-eduroam "How to connect to eduroam?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroama-nasil-baglanilir "eduroam'a nasıl bağlanılır? ")

# eduroam'a nasıl bağlanılır?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

**eduroam kullanmak isteyen istemciler ne yapmalılar?**

- [MS Windows işletim sistemleri](http://eduroam.metu.edu.tr/tr/eduroama_nasil_baglanilir.html#ms)
- [Linux işletim sistemleri](http://eduroam.metu.edu.tr/tr/eduroama_nasil_baglanilir.html#linux)
- [Mac OS](https://faq.cc.metu.edu.tr/tr/sss/mac-bilgisayarimdan-eduroam-kablosuz-agina-nasil-baglanabilirim)
- [IPhone](https://faq.cc.metu.edu.tr/tr/sss/iphone-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim)
- [Android işletim sistemleri](https://faq.cc.metu.edu.tr/tr/sss/android-isletim-sistemi-yuklu-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim)
- [Sertifikalar](http://eduroam.metu.edu.tr/tr/eduroama_nasil_baglanilir.html#sertifika)

**MS Windows**

Microsoft Windows işletim sistemlerinden Windows 7 ve öncesi sürümlerini kullanan kullanıcıların, IEEE 802.1x ve EAP ayarlarını girebilmeleri için SecureW2 yazılımını kullanmaları gerekmektedir. Bu sebeple, SecureW2 : Windows için Açık Kaynak Kodlu 802.1x/EAP istemcisi (32 bit) bilgisayara kurulmalıdır. Bu istemci, sadece 32 bit Windows işletim sistemlerinde (Windows XP, Windows Vista, Windows 7) çalışmaktadır. SecureW2 istemcisinin aktif olabilmesi için, kablosuz bağdaştırıcı yöneticisi olarak Windows seçilmeli, 3. parti yazılımlar devre dışı bırakılmalıdır.

_Windows 8 ve üstü sürümler icin (32 ve 64bit dahil) herhangi bir yazılım kurulumuna gerek yoktur​._

Aşağıda, farklı işletim sistemleri için ODTU ağına nasıl bağlanılacağını anlatan açıklamalar, örnek teşkil etmesi bakımından verilmiştir. Kendi kurumuzun ağına bağlanmak için kurumunuzun ağ yöneticileri ile temasa geçiniz.

**Microsoft Windows VISTA ve 7 ayarları**

[Resimli Anlatım için tıklayınız](http://eduroam.org.tr/howto-setup-cli.php#msvista200803051443)

İşletim sisteminde **START** menüsünden aşağıda belirtilen sırayla ilgili pencereler açılmalıdır:

**START > Control Panel > Network and Sharing Center >**(Sol üstte yeralan menüden) **Manage Wireless Networks**

Burada yeralan **eduroam** ssid'si sağ tuşla tıklanarak, **Properties** seçilmeli, açılan **eduroam Wireless Network Properties** ekranında yeralan **Security** başlığında aşağıdaki değişiklikler yapılmalıdır:

Security type : **WPA2 Enterprise** seçilmelidir.

Encryption Type: **AES** seçilmelidir.

Choose a network authentication method : **SecureW2 TTLS** seçilmelidir.

Secure W2 TTLS seçeneği yanında yeralan **Settings** tıklandığında ekrana gelen Secure W2 menüsünde:

- Profile : **DEFAULT** altında yeralan **Configure** tıklanmalıdır.

  - **Connection** kısmında **Use alternate outer identity** ve **Use anonymous outer identity** seçili olmalıdır.
  - **Certificates** kısmında **Verify Server Certificates** seçeneği kaldırılmalıdır.
  - **Authentication** kısmında **PAP** seçilmelidir.
  - **User Account** kısmında, kullanıcı\_adı![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr ve şifre girilmelidir.

**Microsoft Windows 10 ayarları**

İşletim sisteminde kablosuz ağ ayarları simgesinde eduroam yayını çift tıklanmalı, gelen ekranda kullanıcı kodunuz @metu.edu.tr uzantılı kullanıcı kodu ve şifresi girilerek gelen sertifika bilgisi onaylanmalıdır.

ÖNEMLİ NOT : İşletim sistemi terfi ettirilerek kuruldu ise, öncelikle kurulu olan SecureW2 veya benzeri programlar kaldırılmalı, kablosuz ağ ayarlarından eduroam yayınını unut tıklanmalı, bilgisayar yeniden başlatıldıktan sonra eduroam yayınına bağlantı tanımlanmalıdır.

**Linux**

[Ubuntu sürümü Resimli Anlatımı için tıklayınız](http://eduroam.org.tr/howto-setup-cli.php#ubuntu200803051448)

Linux işletim sistemlerinde, WPA ve üzeri güvenlik seviyesindeki kablosuz ağlara bağlanabilmek için kullanılan wpa\_supplicant uygulaması yardımı ile IEEE802.1x ağa ve dolayısıyla eduroam'a baglanılabilinir. Bunun için öncelikle wpa\_supplicant uygulamasının kurulu olması gerekmektedir.

Bu işlemi, debian tabanlı sistemlerde **apt-get install wpasupplicant** komutu ile yapabilirsiniz. Diğer Linux türevleri için paket yöneticinizi kullanarak kurulum yapabilirsiniz.

**Linux Ayarları**

**/etc/wpa\_supplicant** veya kurulumun gerçekleştiği dizine, **wpa\_supplicant.conf** isimli bir dosya oluşturarak içerisine aşağıdaki örnekte olduğu gibi yapılandırma dosyasını giriniz (Kullanıcı adı ve şifre olarak size verilen değerleri giriniz):

**network={**

**ssid="eduroam"**

**key\_mgmt=WPA-EAP**

**pairwise=AES**

**group=AES**

**eap=TTLS**

**phase2="auth=PAP"**

**anonymous\_identity="anonymous![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr"**

**identity="** kullanici\_adi **![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr"**

**password="** sifreniz **"**

**}**

Bilgisayarınızda yeralan kablosuz ağ bağdaştırıcısının ismine göre, aşağıdaki gibi veya benzeri komut girerek ağa bağlanınız:

**wpa\_supplicant -B -i eth2 -c /etc/wpa\_supplicant/wpa\_supplicant.conf -D wext**

(wpa\_supplicant kullanımı için, **man wpa\_supplicant** ve **man wpa\_supplicant.conf** komutlarına başvurunuz.)

Otomatik olarak ip adresi alabilmek icin ise, **dhclient eth2** girmeniz gerekecektir.

Ayarlarin otomatik olarak yuklenebilmesi icin, **/etc/network/interfaces** dosyasinda, kablosuz bagdastirici ile ilgili satir (ornekte eth2 alinmistir) asagidaki gibi degistirilmelidir:

**auto eth2**

**iface eth2 inet dhcp**

**wpa-conf /etc/wpa\_supplicant/wpa\_supplicant.conf**

**Sertifikalar**

Kullanıcıların kablosuz ağ cihazlarına gerekli durumda yüklemesi beklenen sertifikaların bağlantıları aşağıdadır.

- [.der formatında sertifika](http://eduroam.metu.edu.tr/assets/files/ca.der)
- [.pem formatında sertifika](http://eduroam.metu.edu.tr/assets/files/ca.pem)