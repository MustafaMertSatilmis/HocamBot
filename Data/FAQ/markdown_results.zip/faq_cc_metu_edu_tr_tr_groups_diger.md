[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/diger#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Diğer

|     |
| --- |
| [Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-alirken-yasanabilecek-sorunlar) |
| [Yeni Kayıt Olan Öğrenciler](https://faq.cc.metu.edu.tr/tr/sss/yeni-kayit-olan-ogrenciler) |
| [Gradescope'ta Çoktan Seçmeli Sınavlar](https://faq.cc.metu.edu.tr/tr/sss/gradescopeta-coktan-secmeli-sinavlar) |
| [Kayıt sayfasındaki robot resim doğrulama (ben robot değilim) hakkında nereden bilgi edinebilirim?](https://faq.cc.metu.edu.tr/tr/sss/kayit-sayfasindaki-robot-resim-dogrulama-ben-robot-degilim-hakkinda-nereden-bilgi-edinebilirim) |
| [ODTÜ Mobil Uygulaması](https://faq.cc.metu.edu.tr/tr/sss/odtu-mobil-uygulamasi) |
| [Telefon Rehberinde (Phonebook) görünen bilgilerimi nasıl güncelleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/telefon-rehberinde-gorunen-bilgilerimi-nasil-guncelleyebilirim) |
| [Yaz Okulu Servis Dersleri uygulaması](https://faq.cc.metu.edu.tr/tr/sss/yaz-okulu-servis-dersleri-uygulamasi) |

[![Subscribe to Diğer](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/17/all/feed "Subscribe to Diğer")