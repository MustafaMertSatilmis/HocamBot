[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/konu-kismina-yazdiklarim-neden-yazildigi-sekilde-gorunmuyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4504


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/konu-kismina-yazdiklarim-neden-yazildigi-sekilde-gorunmuyor)

# Konu kısmına yazdıklarım neden yazıldığı şekilde görünmüyor?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Resmi Yazışma Kurallarına göre, konu alanındaki kelimelerin ilk harlerinin büyük yazılması gerekmektedir. Konuyu Formatla kutucuğunun işareti kaldırılarak bu kural yok sayılabilir.

Örneğin TBMM, YÖK gibi bütün harfleri büyük yazılan kısaltmaların yazdığınız gibi kalması için "Konuyu Formatla" kutucuğunun işaretini kaldırmalısınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/konuyuformatla.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.