[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-uyelerinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 8935


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-list-can-be-set-only-list-members-be-able-send-message-list "How a list can be set for  only the list members to be able to send message to the list?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-listeye-sadece-liste-uyelerinin-mesaj-gonderebilmesi-icin-ne-yapmaliyim "E-listeye sadece liste üyelerinin mesaj gönderebilmesi için ne yapmalıyım ?")

# E-listeye sadece liste üyelerinin mesaj gönderebilmesi için ne yapmalıyım ?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

**Listeye sadece liste üyelerinin mesaj gönderebilmesi için (send-by-subscribers):**

**(a)** _Üyelik Yönetimi_ > _Üyelik Listesi_ > _Ek Üye Görevleri_ > _Şu anda görüntülenmeyen üyeler de dahil olmak üzere herkesin moderatör onayı ayarını etkinleştir._ ayarı _**Kapalı**_ olarak seçilir.

**(b)** _Gizlilik Seçenekleri_ > _Gönderici filtreleri_ > _Üye filtreleri_ > _Varsayılan olarak yeni üyelerin mesajları moderatör onayı gerektirsin mi?_ ayarı _**Hayır**_ olarak seçilir.

**(c)** _Gizlilik Seçenekleri_ > _Gönderici filtreleri_ > _Üye olmayan kişi filtreleri_ _>_ _Mesajları için açıkça bir eylem tanımlanmamış üye olmayan kişilerin gönderdiği mesajlar için uygulanacak eylem._ ayarı _**Beklet**_ ya da _**Onayla**_ olarak seçilir.

Eğer "Beklet" seçilirse liste üyesinin gönderdiği ileti moderatör onayına sunulur, "Onayla" seçilirse söz konusu ileti moderasyon işleminden geçmeden listeye dağılır.