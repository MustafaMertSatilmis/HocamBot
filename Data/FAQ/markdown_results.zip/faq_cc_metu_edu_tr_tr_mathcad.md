[Jump to navigation](https://faq.cc.metu.edu.tr/tr/mathcad#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-01-2022 **Görüntüleme:** 20642


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/mathcad "MATHCAD")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/mathcad "MATHCAD")

# MATHCAD

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **MATHCAD** **15** **—**

**_MATHCAD_** _temelde mühendislik hesaplamalarını geçerlemek, doğrulamak, doküman oluşturmak ve tekrar kullanmak için bir yazılımdır._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve lisanslama işlemini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/mathcad#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/mathcad#aktivasyon)

* * *

**_\[1\] Not:_** _Kurulum bilgileri Windows 7 işletim sistemi için hazırlanmıştır, Mathcad yazılımının bu sürümü daha yeni işletim sistemlerine uyum sağlamayabilir._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Next_** **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step1.png)

**_ADIM-2_**

**_“I accept_** **_”_**_seçeneğini işaretleyiniz ve **“Next”**butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step2.png)_

**_ADIM-3_**

**_“Mathcad”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step3.png)

**_ADIM-4_**

**_“Use existing FLEXnet license server_** **_”_**_seçeneğini işaretleyiniz ve **“Next”**butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step4.png)

**_ADIM-5_**

**_“Custom_** **_”_**_seçeneğini işaretleyiniz ve **“Next”**butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step5.png)

**_ADIM-6_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step6.png)

**_ADIM-7_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step7.png)

**_ADIM-8 <<<AKTİVASYON>>>_**

**_“Add”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step8.png)

**_ADIM-9_**

**_“Single license server_** **_”_**_seçeneğini işaretleyiniz. Hostname altında yer alan kutucuğa **“mathcad.cc.metu.edu.tr”**ve port altında yer alan kutucuğa **“7788”**yazınız. Daha sonra **“OK”**butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step9.png)

**_ADIM-10_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step10.png)

**_ADIM-11_**

**_“Desktop_** **_”_**_seçeneğini işaretleyiniz ve **“Next”** butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step11.png)

**_ADIM-12_**

**_“Install Windchill ProductPoint Components_** **_”_**_seçeneğini işaretleyiniz ve **“Next”**butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step12.png)

**_ADIM-13_**

**_“Install”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step13.png)

**_ADIM-14_**

**_“OK”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step14.png)

**_ADIM-15_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step15.png)

**_ADIM-16_**

**_“Exit”_**_butonuna tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathcad_15_step16.png)

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *