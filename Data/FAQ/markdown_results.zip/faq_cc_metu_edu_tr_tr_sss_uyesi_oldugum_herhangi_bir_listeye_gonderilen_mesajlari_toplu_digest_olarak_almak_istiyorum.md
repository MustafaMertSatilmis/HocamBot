[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uyesi-oldugum-herhangi-bir-listeye-gonderilen-mesajlari-toplu-digest-olarak-almak-istiyorum#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7664


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/id-receive-messages-sent-list-digest-format-how-can-i-change-my-subscription-options-turkish "I'd like to receive the messages  sent to a list in a digest format. How can I change my subscription options? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uyesi-oldugum-herhangi-bir-listeye-gonderilen-mesajlari-toplu-digest-olarak-almak-istiyorum "Üyesi olduğum herhangi bir  listeye gönderilen mesajları toplu (digest) olarak almak istiyorum. Üyelik  ayarlarımı nereden değiştirebilirim?")

# Üyesi olduğum herhangi bir listeye gönderilen mesajları toplu (digest) olarak almak istiyorum. Üyelik ayarlarımı nereden değiştirebilirim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

1. **[http://mailman.metu.edu.tr/mailman/listinfo/abc-l](http://mailman.metu.edu.tr/mailman/listinfo/abc-l)** adresinde sayfanın en altında yer alan "Listeden çık veya seçeneklerimi düzenle" yazılı alana listeye üyelik için kullandığınız e-posta adresi ile giriniz.
2. **[http://mailman.metu.edu.tr/mailman/options/abc-l](http://mailman.metu.edu.tr/mailman/options/abc-l)** adresinde sayfanin üst kısmına listeye üyelik şifrenizi giriniz (Eğer üyelik sifrenizi bilmiyorsanız aynı sayfada yer alan "Hatırlatıcı"yı kullanabilirsiniz).
3. Gelen sayfanın alt kısmında yer alan ayarlardan "Toplu Mesaj Modunu Ayarla" bölümünü "Açık" olarak işaretleyerek mesajlarınızı toplu almaya başlayabilirsiniz.

(Yukarıda geçen "abc-l" ifadesi liste ismi için örnek olarak verilmiştir)