[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/hangi-cihazlar-meturoam-baglantisini-desteklememektedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 24456


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/which-devices-are-known-not-support-meturoam "Which devices are known NOT to support meturoam?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/hangi-cihazlar-meturoam-baglantisini-desteklememektedir "Hangi cihazlar meturoam bağlantısını desteklememektedir?")

# Hangi cihazlar meturoam bağlantısını desteklememektedir?

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Bir kablosuz cihazın ODTÜ kablosuz ağına bağlanabilmesi için WPA2 Kurumsal sistemini ve PEAP/MSCHAPv2 algoritmalarını desteklemesi gerekmektedir. Aşağıda listelenen cihazların meturoam yayını ile uyumlu olmadığı bilinmektedir.

- Kindle Wi-Fi or Wi-Fi + 3G
- Xbox 360 S or Xbox kablosuz ağ adaptörü
- Sony Playstation 3 and Sony PSP
- Nintendo Wii U, Nintendo Wii, Nintendo DS, Nintendo DSi and Nintendo 3DS
- Apple TV 1st and 2nd Generation
- Nook v1.5
- Roku HD/XD/XDS Streaming Player
- TiVo Wireless Network Adapter