[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bb-kartli-gecis-listesi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-12-2021 **Görüntüleme:** 6502


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/im-person-who-responsible-authorization-people-departmentunit-e-gate-system-how-can-i-access "I'm the person who is responsible for authorization of people to department/unit e-gate system. How can I access to  related interface for e-gate authorization?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bb-kartli-gecis-listesi "Bölüm-Birim kartlı geçiş yetkilendirmesinden sorumlu kişiyim. Kartı geçiş yetkilendirme arayüzüne nasıl erişebilirim?")

# Bölüm-Birim kartlı geçiş yetkilendirmesinden sorumlu kişiyim. Kartı geçiş yetkilendirme arayüzüne nasıl erişebilirim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Bölüm veya birimlerde kartlı geçiş yetkilendirmesini yapan personelimiz, aşağıda bağlantıları verilen sistem arayüzlerine kendi birimlerinde kurulu olan sisteme göre uygun linke tıklayarak ulaşabilirler ve arayüz üzerinden bölüm/birim kapılarına kişi geçiş yetkisi verebilirler. Sayfalara IP kısıtlaması nedeniyle sadece yetkili kişiler erişebildiğinden, erişim talebinizi hotline ( [hot-line@metu.edu.tr](mailto:hot-line@metu.edu.tr)) üzerinden iletebilirsiniz.

Ayrıca bu adresleri sık kullanılanlar listenize eklemenizi öneririz.

[BOTT Kartlı Geçiş Sistemi](https://ekgs.metu.edu.tr:8443/)

[UTARIT Kartlı Geçiş Sistemi](https://persolus.cc.metu.edu.tr/)