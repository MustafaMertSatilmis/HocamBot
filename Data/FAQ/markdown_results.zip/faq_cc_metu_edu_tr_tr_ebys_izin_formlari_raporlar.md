[Jump to navigation](https://faq.cc.metu.edu.tr/tr/ebys-izin-formlari-raporlar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 3146


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/ebys-izin-formlari-raporlar)

# EBYS İzin Formları ile ilgili Yönetici ve Sekreterlere Sunulan Raporlar

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

Birimlerdeki yönetici ve sekreterlerin görmeye yetkili olduğu, izin formları ile ilgili, iki farklı rapor bulunmaktadır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor.png)

**1\. İzinli Personel Raporu**

Bu rapor belli bir tarih aralığı belirtildiğinde bu tarih aralığında herhangi bir gün izinli olan personellerin doldurduğu izin formlarını gösterir. Listede getirilen herhangi bir form satırına tıklanarak forma ulaşılabilir, akış tarihçesine tıklanarak formun geçtiği adımlar görülebilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-1-1.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-1-2.png)

**2\. Personel İzin Süreleri Raporu**

Bu rapor birimdeki tüm kişilerin;

\- devreden(bir önceki yıldan)

\- hak edilen(bu yıl)

\- toplam(devreden + hak edilen)

\- kullanılan(içinde olunan yıl)

\- kalan(toplam - kullanılan)

izin sürelerinin listesini gösterir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-2-1.png)

**Not 1:** Raporda mazaret izinleri ve yıllık izinler ayrı satırlar olarak yer almaktadir.

**Not 2:** Birden fazla görevi olan personellerin filtre düğmesinden verilerini görmek istediği pozisyonu seçmeleri gerekmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-2-2.png)

**Raporların Kullanım Özellikleri**

1- Raporlarda var olan sütunların isimlerine tıklandığında ilgili sütundaki verilere göre alfabetik veya numara sırasına göre sıralama yapılabilmektedir. Aynı sütuna ikinci kere tıklandığında tersten sıralama yapılabilmektedir. Raporda bulunan bütün sütunlara göre sıralama imkanı bulunmaktadır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-2-3.png)

2- Raporlarda bulunan sütunlara göre gruplama yapılabilmektedir. Örneğin İzinli Personel Raporu'nda kişi ismi sütunu "Gruplamak için kolonu buraya kadar sürükle" bölümüne sürüklenip bırakıldığında kişi bazlı gruplama yapılacaktır. Aynı şekilde raporda bulunan tüm sütunlara göre gruplama yapılabilmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-gruplama-1.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-gruplama-2.png)

3- Rapor listeleme ekranında üst bölümde bulunan "Excel dosyası olarak çıkart" düğmesi ile tüm rapor Excel dosyası olarak indirilebilmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys-izin-rapor-excel.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.