[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-teknik-yapisi-nasildir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8171


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-technical-structure-eduroam "What is the technical structure of eduroam?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-teknik-yapisi-nasildir "eduroam teknik yapısı nasıldır?")

# eduroam teknik yapısı nasıldır?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

Kampüs içerisinde üç farklı marka erişim cihazı kullanılmaktadır. Bunlar Aruba, Cisco ve HP Procurve markalarıdır.

![](http://eduroam.metu.edu.tr/assets/konsept.jpg)

Kavram çiziminden de anlaşılacağı üzere kurulan bu yapı WPA(2) güvenlik çözümü sunmaktadır. Bu güvenlik çözümünün yanıda kullanıcıları kolay bir şekilde yetkilendirmek için TTLS (PAP) kullanılması uygun bulunmuştur. Bu yapıda kullanıcı sadece mevcut sistemde EAPP için bir adet sunucu sertifikasına ihtiyaç duyacaktır. Kullanıcı sertifikası kullanılmayacaktır. RADIUS'a gelen istek karşılıklı bir tünelin kurulmasını sağlayacak ve bu tünelin içerisinden gelen bilgiler RADIUS tarafından çözümlenip, güvenli ağdan LDAP'a sorgulanacaktır. Eğer, LDAP kullanıcı ismini ve şifresini onaylarsa sistem kişiyi kabul edecektir.