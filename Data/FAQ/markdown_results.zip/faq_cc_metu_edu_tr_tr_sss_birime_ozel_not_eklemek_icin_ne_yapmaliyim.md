[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/birime-ozel-not-eklemek-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4479


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/birime-ozel-not-eklemek-icin-ne-yapmaliyim)

# Birime özel not eklemek için ne yapmalıyım?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

EBYS'deki Not Ekleme özelliğini aynı birimde çalıştığınız diğer personeller ile bilgi paylaşımı için de kullanabilirsiniz. Bu özellik için aşağıdaki adımlar takip edilebilir:

1. Evrak üzerinde bulunan "Notlar" düğmesine tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/1_1.png)

2. "Yeni Not" düğmesini tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/2_0.png)

3. "Herkes görebilir" onay kutusundan tiki kaldırınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/3.png)

4. "Kullanıcılar ve Roller" kısmındaki "..." düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/4_0.png)

5. Açılan bölümden "Tür" listesini tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/5_0.png)

6. "Tür" listesinden "Departman Rolü"nü seçiniz ve "ID" bölümündeki "..." düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/10_not.png)

7. Açılan bölümden biriminizi aratarak bulup seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/11_not.png)

8. "Ekle" düğmesine basarak önceki bölüme dönünüz. Notunuzu yazarak tekrar "Ekle" düğmesine basınız. Artık biriminizdeki kişiler evrak kendilerine ulaştığında bu notu görebileceklerdir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/12_not.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.