[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarama-nasil-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 6268


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarama-nasil-yapilir)

# EBYS'de tarama nasıl yapılır?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de tarama yapabilmek için [https://ebys.metu.edu.tr/eba.net/BrowserPluginSetup/eBABrowserPluginSetup.msi](https://ebys.metu.edu.tr/eba.net/BrowserPluginSetup/eBABrowserPluginSetup.msi) adresindeki eklentiyi yükleyiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.