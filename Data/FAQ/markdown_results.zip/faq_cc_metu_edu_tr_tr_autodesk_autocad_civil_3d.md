[Jump to navigation](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-civil-3d#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-01-2022 **Görüntüleme:** 11834


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/autodesk-autocad-civil-3D "AUTODESK AUTOCAD CIVIL 3D")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-civil-3d "AUTODESK AUTOCAD CIVIL 3D")

# AUTODESK AUTOCAD CIVIL 3D

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

İnşaat mühendislerinin tasarım, analiz ve simülasyonu için yapı bilgi modelleme (BIM) çözümüdür. Autodesk Civil 3D programı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" adresinden temin edilebilir.

[Kurulum](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-civil-3d#kurulum)

Kurulum:

**1\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil1.png)**

**2\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil2.png)**

**3\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil3.png)**

**4\. Adım:** Kullanılacak olan seri numarası ve ürün anahtarı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" sitesinden edinilebilir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil4.png)**

**5\. Adım:**"Configure" seçeneği seçilerek kurulum yapılandırması seçenekleri düzenlenir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil5.png)**

**6\. Adım:** Lisans sunucusu olarak "autodesk.cc.metu.edu.tr" girilir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil6.png)**

**7\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil7.png)**

**8\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil8.png)**

**9\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil9.png)**

**10\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil10.png)**

**11\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil11.png)**

**12\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil12.png)**

**13\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil13.png)**

**14\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil14.png)**

**15\. Adım:**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/civil15.png)**

**Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**