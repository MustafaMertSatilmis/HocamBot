[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# BİDB hakkında

|     |
| --- |
| [BİDB Hizmetlerinin Kapsamı Nedir?](https://faq.cc.metu.edu.tr/tr/sss/bidb-hizmetlerinin-kapsami-nedir) |
| [BİDB Tarafından Sağlanan Merkezi Servisler Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-saglanan-merkezi-servisler-nelerdir) |
| [BİDB’nin Bilişimde Öncü Çalışmaları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-bilisimde-oncu-calismalari-nelerdir) |
| [Felaket Kurtarma Merkezi ve İş Sürekliliği Nasıl Sağlanmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/felaket-kurtarma-merkezi-ve-surekliligi-nasil-saglanmaktadir) |
| [Merkezi Bilişim Hizmetlerine Destek Veren Çağrı Merkezi Yapısı Nasıldır?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-bilisim-hizmetlerine-destek-veren-cagri-merkezi-yapisi-nasildir) |
| [SOA Yaklaşımı](https://faq.cc.metu.edu.tr/tr/sss/soa-yaklasimi) |

[![Subscribe to BİDB hakkında](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/208/all/feed "Subscribe to BİDB hakkında")