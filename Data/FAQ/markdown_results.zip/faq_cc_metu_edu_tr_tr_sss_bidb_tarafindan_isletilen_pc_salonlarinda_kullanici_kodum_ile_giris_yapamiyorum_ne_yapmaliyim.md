[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-isletilen-pc-salonlarinda-kullanici-kodum-ile-giris-yapamiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-01-2020 **Görüntüleme:** 11230


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-cannot-login-computers-pc-rooms-my-user-code-what-should-i-do "I cannot login to computers in PC rooms with my user code. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-isletilen-pc-salonlarinda-kullanici-kodum-ile-giris-yapamiyorum-ne-yapmaliyim "BİDB tarafından işletilen PC salonlarında kullanıcı kodum ile giriş yapamıyorum. Ne yapmalıyım?")

# BİDB tarafından işletilen PC salonlarında kullanıcı kodum ile giriş yapamıyorum. Ne yapmalıyım?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

BİDB tarafından işletilen bilgisayar salonlarında Windows 10 kurulu bilgisayarlarda oturum açamıyorsanız:

1\. İlk olarak [https://useraccount.metu.edu.tr](https://useraccount.metu.edu.tr/) adresinden ODTÜ Kullanıcı Hesap Yönetimi sayfasında kullanıcı kodu ve şifreniz ile bağlantı sağlayıp sağlayamadığınızı kontrol ediniz. Eğer bu sayfada da oturum açamıyorsanız [http://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim](http://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim) adresindeki yönlendirmeleri takip ederek yeni şifre edinebilirsiniz.

2\. Windows oturum açma ekranında sağ alt köşede klavye dağılımını gösteren dil işaretini kontrol ediniz. Bu bölümde TUR yazması gerekmektedir. Farklı bir işaret görüyorsanız TUR seçeneği ile değiştirerek şifrenizi ilgili alana tekrar yazmayı deneyiniz.

Eğer Windows girişi yaptıktan yaklaşık 1 dakika sonra oturumunuz kapatılıyorsa:

1\. PC Salonları Kullanım Kurallarına aykırı bir durum nedeniyle ceza almış olabilirsiniz. Konuyla ilgili bilgi almak için BİDB Bilişim Destek Ekibi ile [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresi üzerinden iletişime geçebilirsiniz.

2\. Kullanmaya çalıştığınız bilgisayara ait bir arıza tanımı bulunabilir. Farklı bir bilgisayarı kullanmayı deneyebilirsiniz.