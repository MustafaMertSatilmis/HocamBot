[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/spyware-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 32129


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-spyware "What is Spyware?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/spyware-nedir "Spyware nedir?")

# Spyware nedir?

[Virüs](https://faq.cc.metu.edu.tr/tr/groups/virus)

Spyware, bilgisayar kullanıcısının kendi rızası ve/veya bilgisi dışında veri toplayan casus yazılımlardır. Daha genel veya farklı anlamları da olan "malware" ve "adware" gibi adlar da "spyware" yerine kullanılabilmektedir.

Casus yazılımlar, kişisel bilgi gizliliğinin ihlali anlamına gelen, kullanıcının klavyede bastığı tuşları kaydetmek, görüntülediği web sayfalarının kaydını tutmak, sabit diskindeki verileri taramak, İnternet'te yapılan aramaları izlemek vb. değişik türde işlemleri gerçekleştirebilir. Bunun sonucunda, kişilerin e-posta, banka vb. şifrelerini çalmak gibi kanun dışı eylemler ya da "kişiye özel reklam" amaçlı açılır pencereler ve istenmeyen e-postalar (spam) gibi rahatsız edici, bilgisayarın ağ ve sistem kaynaklarını tüketen, web sayfalarının görüntülenme hızının düşmesi veya bilgisayarın genel olarak yavaşlaması gibi sonuçlar doğurabilecek eylemler gerçekleştirebilir.

Casus yazılımlar çoğu zaman, açık şekilde kanun dışı ve kullanıcıya doğrudan zarar verecek amaçlara yönelik tasarlanmadıkları için, kullanıcının rızasıyla ya da eylemleri sonucu bilgisayara kurulduklarından dolayı virüslerden ayrılırlar. Ayrıca casus yazılımlar, virüsler gibi kendilerini herhangi bir yolla bir bilgisayardan diğerine kopyalamaz. Ancak kuruluma dair rıza veya onay, bu zararlı yazılımın bilgisayardaki etkinlikleri konusunda kullanıcı açıkça bilgilendirilmeden alınır.

Genellikle, kullanıcı bir web sayfasını açabilmek ya da düzgün görüntüleyebilmek için İnternet tarayıcısına bir eklenti (add-on, extension, plug-in) kurulması yönünde bir uyarı alır ve bu onayı verdiğinde casus yazılım bilgisayara yüklenmiş olur. Ayrıca, kullanıcıya ücretsiz olarak bir hizmet sunan bir web sitesi (yazılım, müzik, video, çevrimiçi oyun vb.) buna benzer yazılımların bilgisayara kurulmasını şart koşabilir. Benzer şekilde, birtakım bedava yazılımlar da kendi kurulumları sırasında ek olarak bazı casus yazılımları kullanıcının onayını almaya çalışarak ya da gizlice kurmaya çalışabilir. Bu gibi siteler ve yazılım geliştiriciler, kullanıcılara ait özel bilgileri veya istatistiki verileri reklam vb. amaçlarla toplayan kişi veya gruplara para karşılığı satmakta ya da yazılımı yükletmek karşılığında çıkar elde etmektedir.