[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrakimi-nasil-iptal-edebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 6206


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrakimi-nasil-iptal-edebilirim)

# EBYS'de evrakımı nasıl iptal edebilirim?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Yalnızca kendi hazırladığınız ve üzerinizde bulunan bir evrakı iptal edebilirsiniz.

Hazırladığınız evrak başka bir kullanıcı üzerinde ise ilgili kişi ile iletişime geçerek iade etmesini istemelisiniz. İade sonrası iptal edebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.