[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 01-07-2022 **Görüntüleme:** 7766


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-eduroam "What is eduroam? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-nedir "eduroam nedir? ")

# eduroam nedir?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

ODTÜ'deki eduroam kablosuz ağ yayını, [eduroam](http://www.eduroam.org/) projesinin Türkiye üniversitelerinde ilk uygulaması olarak Ekim 2007'de ODTÜ BİDB tarafından başlatılmıştır. (eduroam educational roaming'in kısaltmasıdır - Türkçe'ye eğitsel serbest dolaşım olarak çevrilebilir)

eduroam, **RADIUS** tabanlı altyapı üzerinden **802.1x** güvenlik standartlarını kullanarak, eduroam üyesi kurumların kullanıcılarının diğer eğitim kurumlarında da sorunsuzca ağ kullanımını amaçlamaktadır. eduroam üyesi kurumların kullanıcıları, kendi kurumlarında ağa bağlanmak için kullandıkları kullanıcı adı şifre ikilileri ile, eduroam üyesi olan başka bir kurumdan ağ bağlanabilirler. Kullanıcı, misafir kurumda iken aldığı eduroam yayınına bağlantı talebi gönderdiğinde, misafir kurumun yetkilendirme sunucusu, o kullanıcıyı kendi ev kurumunun yetkilendirme sunucusuna yönlendirerek, yetkili olup olmadığını belirler. Tüm bu sorgulamaların, sunucular arasında oluşturulan şifreli bir tünel içinden yapılması, kullanıcı adı şifre ikililerinin kullanıcının kendi ev sunucusu haricinde görülmesini engeller. Bu durumda kullanıcıların yapması gereken tek şey, misafir olduğu kurumda yeralan eduroam kablosuz ağını, kendi kurumunun ağına bağlanır gibi tanımlamasıdır.