[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-2-adim-e-imza-suruculerini-nasil-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-07-2023 **Görüntüleme:** 4245


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-2-adim-e-imza-suruculerini-nasil-yuklerim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[Windows - 2. Adım: E-imza sürücülerini nasıl yüklerim?\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- [https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu\_yukleme\_servisi/](https://kamusm.bilgem.tubitak.gov.tr/islemler/surucu_yukleme_servisi/) adresine gidiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_1.jpg)

2- İşletim sisteminizi, versiyonunu ve tipini seçiniz. Hangilerini seçeceğinizden emin değilseniz bölümünüzün/biriminizin bilgisayar koordinatöründen bilgi alınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_2.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_3.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_4.jpg)

3- Kart okuyucunuzun modelini seçtikten sonra Sürücüleri Göster düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_5.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_6.jpg)

4- Öncelikle "Kurulum 1: Akıllı Kart Sürücüsü"nü indiriniz. İndirdikten sonra resimlerdeki gibi kurulumu tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_7.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_8.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_9.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_10.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_11.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_12.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_13.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_14.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_15.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_16.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_17.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_18.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_19.jpg)

5- Ardından "Kurulum 2: Kart Okuyucu Sürücüsü"nü indiriniz. İndirdikten sonra resimlerdeki gibi kurulumu tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_20.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_21.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_22.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_23.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_24.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_25.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_26.jpg)![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_27.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_28.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_29.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_30.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_31.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_32.jpg)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/eimza-kart_33.jpg)

İşlem tamamlanmıştır.