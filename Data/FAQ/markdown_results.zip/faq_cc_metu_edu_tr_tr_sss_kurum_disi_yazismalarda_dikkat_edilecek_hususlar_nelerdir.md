[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kurum-disi-yazismalarda-dikkat-edilecek-hususlar-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-10-2024 **Görüntüleme:** 5766


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kurum-disi-yazismalarda-dikkat-edilecek-hususlar-nelerdir)

# Kurum dışı yazışmalarda dikkat edilecek hususlar nelerdir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS’de Kurum Dışı yazı oluşturan ve Kayıtlı Elektronik Posta (KEP) ile gönderim yapılmasını isteyen kullanıcılarımız; “Gönderilecek Yer Tanımlama” sekmesinde seçilen Kurumun/Tüzel Şahısın/Kişinin KEP adresinin sistemden otomatik olarak gelmesini beklemelidir.

Sistem tarafından bulunamayan KEP adresleri için öncelikle [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine bilgi verilmelidir; konu ile ilgili ileti sahiplerine en kısa sürede dönüş yapılacaktır.

KEP adresi bulunmama/bulunamama durumu bilgisi ile dönüş yapılan kullanıcılarımız; “Gönderim Türü” sekmesinden "Posta, Kargo, Elden Teslim" seçeneklerinden uygun olanı seçerek evrakı oluşturmalıdır. Bu tür gönderim türü belirlenmiş evrakların imzalama işleminin tamamlanması sonrası; sistemden çıktı alınarak zarflanması, zarf üzerine gerekli bilgilerin yazılması ve Evrak Kayıt numarası verilmesi/Postalama işleminin yapılması için Evrak ve Arşiv Müdürlüğüne teslim edilmesi gerekmektedir.

**ÖNEMLİ NOT:** Üniversitemiz fiziksel (zarf, paket vb.) resmi posta gönderileri [https://eam.metu.edu.tr/tr/system/files/posta\_gonderim\_kurallari.pdf](https://eam.metu.edu.tr/tr/system/files/posta_gonderim_kurallari.pdf) adresinde belirtilen kurallar dikkate alınarak hazırlanmalı ve EBYS'de yer alan [Fiziksel Posta Gönderim Formu](https://faq.cc.metu.edu.tr/tr/sss/ebysde-fiziksel-posta-gonderim-formunu-nasil-doldurabilirim) doldurularak işlem yapılmalıdır.