[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mozilla-thunderbird-ile-odtu-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-08-2023 **Görüntüleme:** 15311


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-e-mail-services-mozilla-thunderbird "How can I use METU E-Mail Services with Mozilla Thunderbird?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mozilla-thunderbird-ile-odtu-e-posta-servisini-nasil-kullanabilirim "Mozilla Thunderbird ile ODTÜ e-posta servisini nasıl kullanabilirim?")

# Mozilla Thunderbird ile ODTÜ e-posta servisini nasıl kullanabilirim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

Mozilla Thunderbird programıyla e-posta okumak ve göndermek için merkezi e-posta sunucusu ayarlarını yapmanız gereklidir.

Bunun için, menüden **Araçlar > Hesap Ayarları** seçeneği ile "Posta ve haber grubu hesap ayarları" penceresini açın. **Hesap işlemleri** düğmesine tıkladığınızda açılan listeden **Posta hesabı ekle** seçeneği ile "Posta hesabı ayarları" penceresini açın (Bu pencere Mozilla Thunderbird programını ilk kez çalıştırdığınızda otomatik olarak ekrana gelir).

Adınızı, e-posta adresinizi ve parolanızı penceredeki kutulara girin ve **İleri** düğmesine tıklayın. Parolanızın hatırlanmasını istiyorsanız "Parolayı hatırla" kutucuğunu işaretleyin.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_mt01_tr.jpg)

Mozilla Thunderbird sunucu ayarlarını otomatik olarak tanımlar. Bu ayarları kullanmak için **Hesap yarat** düğmesine tıklayarak hesap oluşturma işlemini tamamlayın.

Varsayılan ayarları değiştirmek isterseniz **Manual config** düğmesine basın. Mesajlarınıza ve sunucu üzerindeki klasörlerinize birden fazla bilgisayardan ulaşmak isterseniz hesap türünü "IMAP" seçin. Gelen kutunuzu tek bir bilgisayara indirip mesajlarınıza yalnızca bu bilgisayardan ulaşmak isterseniz ve sunucu üzerindeki klasörlere erişmenize gerek yoksa hesap türünü "POP3" seçin.

Güvenli IMAP bağlantısı kullanmak için bağlantı noktası numarası **993**, bağlantı güvenliği (SSL) **SSL/TLS** ve kimlik doğrulaması (Authentication) **Normal Password** olmalıdır.

Güvenli POP3 bağlantısı kullanmak için bağlantı noktası numarası **995**, bağlantı güvenliği (SSL) **SSL/TLS** ve kimlik doğrulaması (Authentication) **Normal Password** olmalıdır.

Her iki seçenekte de giden sunucu adresi **smtp.metu.edu.tr**, bağlantı noktası numarası **465**, bağlantı güvenliği ( **SSL/TLS**) ve kimlik doğrulaması (Authentication) **Normal Password** olmalıdır.

Yaptığınız ayarları daha sonra görmek ya da değiştirmek isterseniz menüden **Araçlar > Hesap Ayarları** seçeneği ile ekrana gelen "Posta ve haber grubu hesap ayarları" penceresinde sol çerçevedeki listeden e-posta hesabınızın altındaki "Sunucu ayarları" seçeneğine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_mt06_tr.jpg)

_**Not:** Bu doküman Mozilla Thunderbird 7.0 sürümü dikkate alınarak hazırlanmıştır. Menüler ve seçenekler önceki sürümlerle farklılık gösterebilir._