[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodu-parola-ve-kurtarma-e-postasi-islemleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 08-02-2024 **Görüntüleme:** 37660


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/password-and-recovery-e-mail-procedures-metu-user-codes "Password and Recovery E-Mail Procedures for METU User Codes")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodu-parola-ve-kurtarma-e-postasi-islemleri "ODTÜ Kullanıcı Kodu Parola ve Kurtarma E-Postası İşlemleri")

# ODTÜ Kullanıcı Kodu Parola ve Kurtarma E-Postası İşlemleri

[Parola](https://faq.cc.metu.edu.tr/tr/groups/parola)

**A-** **ODTÜ kullanıcı kodunuzun parolasını değiştirmek için:**

1. [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/) adresine giriniz,
2. Kullanmakta olduğunuz şu anki kullanıcı kodunuz ve parolanız ile giriş yapınız,
3. Gelen sayfada PAROLA DEĞİŞTİR düğmesine tıklayınız,
4. Yeni parolanızı aşağıdaki E Bölümünde yer alan kurallara uygun olarak 2 defa yazıp DEĞİŞTİR düğmesine tıklayınız.
5. Parola değişikliği başarıyla gerçekleştikten **_yaklaşık 5 dakika sonra_** yeni parolanızı kullanabilirsiniz. Bazı sistemlere erişim için belli bir süre geçmesi gerekebilmektedir. (Örneğin: E-posta hesabı için 30 dakika gibi.)

* * *

**B-** **Parolanızı unutmanız veya parolanızın sıfırlanması halinde yeni parola belirlemek için:**

Parolanızı unutmanız halinde kendinize yeni parola belirleyebilmeniz için kullanıcı hesabınızda kurtarma e-postanızın tanımlı olması gerekmektedir. Belirlemiş olduğunuz ODTÜ dışı kurtarma e-posta adresinize (gmail  vb.) talebininiz doğrultusunda yeni bir parola aktivasyon linki gönderilecek olup; linkte yer alan bağlantı üzerinden parolanızı 24 saat içinde aktive etmeniz beklenecektir. Eğer sistemde kurtarma e-postanız tanımlı değilse veya kurtarma e-postanızı unuttuysanız aşağıdaki **C veya D bölümlerindeki** adımları takip ediniz.

Kurtarma e-postanız sistemde tanımlı ise ve kurtarma e-postanızı biliyorsanız;

1. [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/) adresine giriniz,
2. Kullanıcı Girişi bölümünün altında “Parolanızı mı unuttunuz?” düğmesine tıklayınız,
3. Gelen sayfada “kullanıcı adınızı”, sistemde tanımlı olan “kurtarma e-postanızı” ve hemen altında yer alan “resim doğrulama” karakterlerini ilgili yerlere girdikten sonra “E-POSTA GÖNDER” düğmesine tıklayınız.
4. Kurtarma e-posta adresinize giriniz. Adresinize yeni bir parola aktivasyon linki gönderilmiş olacaktır. Gelen sayfadaki mavi renkli aktivasyon linkine tıklayınız.
5. Aktivasyon linkine tıkladığınızda yeni parola oluşturabileceğiniz sayfaya yönlendirileceksiniz. E bölümünde belirtilen kriterlere uygun şekilde yeni bir parola oluşturduğunuzda parolanızın başarılı şekilde değiştirildiği mesajını göreceksiniz.
6. Parola değişikliği başarıyla gerçekleştikten _**yaklaşık 5 dakika sonra**_ yeni parolanızı kullanabilirsiniz. Bazı sistemlere erişim için belli bir süre geçmesi gerekebilmektedir. (Örneğin: E-posta hesabı için 30 dakika gibi.)
7. [**Yazdığınız kurtarma e-posta adresiniz sistemde kayıtlı e-posta adresi ile aynı değil ise** _“Kurtarma E-Posta adresi uyumsuz. Lütfen kayıtlı kurtarma e-posta adresinizi girdiğinize emin olunuz.”_ uyarısı ile karşılaşacaksınız. Eğer kurtarma e-postanızı hatırlamıyorsanız parolanızı da unutmuş olduğunuz için kurtarma e-postanızı kendiniz belirleyemezsiniz. Bu durumda](https://useraccount.metu.edu.tr/) [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) [adresindeki formu doldurarak sistemde kayıtlı olan kurtarma e-postanızı sorunuz. Size dönülen yanıtta sistemde kayıtlı olan kurtarma e-posta adresiniz bildirilecektir. Öğrendiğiniz e-posta kurtarma adresinizle yukarıdaki adımları izleyerek kendinize yeni parola belirleyebilirsiniz.](https://useraccount.metu.edu.tr/)

* * *

**C-** **Kurtarma e-postası tanımlamak için:**

1. [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/) adresine giriniz,
2. Kullanmakta olduğunuz şu anki kullanıcı kodu ve parola ile giriş yapınız,
3. Gelen sayfada KURTARMA EPOSTASI BELİRLE düğmesine tıklayınız,
4. Kurtarma e-postanızı yazıp GÜNCELLE düğmesine tıklayınız.

* * *

**D-   Parolanızı** **unuttuğunuz için kendiniz kurtarma e-postası tanımlayamıyorsanız:**

1. Öncelikle ODTÜ kimliğinizi ve T.C. nüfus cüzdanınızın ön yüzünü (ikisi birlikte) tarayıcıda taratın veya cep telefonunuz uygun ise, cep telefonunuzdan fotoğrafını çekiniz.  (dosya yüklemek için fotoğrafın pdf, png, jpeg, gif dosya türlerinden biri olması ve maksimum 2mb boyutunda olması gerekmektedir),
2. [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresine giriniz.
3. Gelen sayfada “Bilişim Destek Formu Doldur” düğmesine tıklayınız.
4. Gelen ekranda istenilen bilgileri doldurunuz.
5. Aynı ekranın altında “Dosya Yükle” düğmesine tıklayınız. Eğer düğme “Off” konumunda ise Off yazısının üzerine tıklayarak “On” konumuna getiriniz. Ve kimlik görselinizi yükleyiniz.
6. Sayfanın en altındaki doğrulama kodunu da girdikten sonra “Gönder” düğmesine tıklayınız.
7. Talebiniz bize ulaştıktan sonra kurtarma e-posta adresiniz bizim tarafımızdan tanımlanacaktır. (e-posta gönderdiğiniz adres ya da belirtmişseniz özellikle talep ettiğiniz bir adres)

* * *

**E-** **Kullanıcılarımız parolalarını aşağıdaki sayfada bulunan kurallara** **göre oluşturmalıdır:**

[Parolamı nasıl değiştirebilirim? Yeni parola seçerken nelere dikkat etmeliyim?](https://faq.cc.metu.edu.tr/tr/sss/parolami-nasil-degistirebilirim-yeni-parola-secerken-nelere-dikkat-etmeliyim)