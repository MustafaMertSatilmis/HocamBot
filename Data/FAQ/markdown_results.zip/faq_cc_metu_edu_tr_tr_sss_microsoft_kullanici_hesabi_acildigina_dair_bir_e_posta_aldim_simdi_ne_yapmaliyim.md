[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/microsoft-kullanici-hesabi-acildigina-dair-bir-e-posta-aldim-simdi-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-02-2024 **Görüntüleme:** 3632


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/microsoft-kullanici-hesabi-acildigina-dair-bir-e-posta-aldim-simdi-ne-yapmaliyim)

# Microsoft kullanıcı hesabı açıldığına dair bir e-posta aldım. Şimdi ne yapmalıyım?

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

Kurum yöneticisi tarafından ODTÜ e-posta adresiniz Microsoft hesabı olarak eklendiğinde tarafınıza aşağıdaki içerikte bir eposta gönderilmektedir. Bu e-postada belirtilen "Sign in to Office 365" bağlantısı ve e-postadaki geçici şifreniz ile Office 365 uygulamasına giriş yapabilir, yeni şifrenizi oluşturabilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/teams1.png)

Giriş yaptıktan sonra yeni şifrenizi oluşturmanız gerekecektir.

![](https://faq.cc.metu.edu.tr/system/files/u2/teams2.png)

Şifrenizi oluşturduktan sonra şifre kurtarma için kullanılabilecek alternatif bir e-posta adresi ve/veya telefon numarası doğrulaması gerekmektedir. ![](https://faq.cc.metu.edu.tr/system/files/u2/teams4.png)

Doğrulama işleminden sonra Office 365 ana sayfasındaki uygulamaları web tarayıcınız ile kullanabilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/teams5.png)

Teams uygulamasının Windows sürümünü [bu bağlantıdan](https://statics.teams.cdn.office.net/production-windows-x64/1.3.00.8663/Teams_windows_x64.exe) indirerek bilgisayarınıza kurabilirsiniz. Diğer işletim sistemleri için Office 365 sayfasından Teams uygulamasını açabilir, uygulama içindeki indirmeler bölümünden gerekli kurulum dosyalarına ulaşabilirsiniz.