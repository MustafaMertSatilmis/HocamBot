[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 10723


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir)

# SPAM E-posta önleme yöntemleri nelerdir?

[Spam](https://faq.cc.metu.edu.tr/tr/groups/spam)

**İçindekiler**

[Giriş](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#Giris)

Spam E-postalar ile Mücadele Yöntemleri:

- [İstemci Kısıtlamaları](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#istemcikisitlamalari)
- [Gönderici Bağlantı İsteği Kısıtlamaları](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#baglantiistegi)
- [Gönderici Kısıtlamaları](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#gondericikisitlamalari)
- [Alıcı Kısıtlamaları](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#alicikisitlamalari)
- [Geçici Bekleme Listelesi (GrayList)](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#graylist)
- [Spam ve Virüs Engelleme Uygulamaları (SMTP Milters)](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#smtpmilters)
- [Veri (DATA) Kısıtlamaları](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#veri)
- [ETRN Kısıtlamaları](https://faq.cc.metu.edu.tr/tr/sss/spam-e-posta-onleme-yontemleri-nelerdir#etrn)

**Giriş**

ODTÜ Bilgi İşlem Daire Başkanlığı istenmeyen e-postaları engellemek için merkezi e-posta sunucularında çeşitli yöntemler uygulamaktadır. E-posta sunucularına gelen günlük 200 bin'den fazla e-postanın yaklaşık olarak 50 bin'den fazlası çeşitli yöntemler kullanılarak spam olarak işaretlenmektedir. Spam e-postalar alıcıdan habersiz kendilerine gönderilen çoğunluk ile reklam içerikli olan ve çok sayıda alıcıya birden iletilen e-postalardır. Temel özellikleri; çok sayıda kişiye aynı anda yollanması, izinsiz bir şekilde yollanması, genellikle ticari bir amaç gütmesi, oltalama saldırıları ve çeşitli yöntemler ile kullanıcı bilgilerini çalmaya yönelik faaliyetlerde bulunmasıdır.

Spam e-postalar çeşitli yöntemler ile analiz edilmekte ve tanımlanması, engellenmesi veya geçici bekletilmesi gibi işlemler yapılabilmektedir. Aşağıdaki grafikte de gösterildiği gibi merkezi e-posta sunucularındaki sistemler tarafından spam olarak tespit edilebilen/yakalanan e-postaların %30,73'ü çevrimiçi karalisteler aracılığı ile engellenmekte, %27,37'si tanımsız alan adı gerekçesi ile kullanıcılarımıza ulaşması önlenmektedir. Spam içeriğe sahip olduğu tespit edilen e-postalardan ODTÜ alan adından geliyormuş gibi gösterilmeye çalışanların oranı %18,35'dir. Geçici Bekleme Listesi'ne (Graylist) takılan spam e-postalar ise toplam spam e-postaların %11,66'sını oluşturmaktadır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/spam_grafik.png)

Grafik 1. ODTÜ Merkezi E-posta Sunucularına Gelen E-postalardan Spam Olarak Tespit Edilenlerin Kategori Bazında Dağılımı

Spam e-postaların bir bölümü merkezi sunucularımız üzerinde otomatik olarak filtrelenmekte ve hiçbir zaman kullanıcılarımıza ulaştırılmamaktadır. Ancak, spam filtrelerine takılmaması için gönderici bilgileri ve içerikleri "Phishing" (Yemleme, yasa dışı yollarla bir kişinin şifresini veya kredi kartı ayrıntılarını öğrenme) faaliyeti içinde olan kişilerce sürekli olarak değiştirilmekte olan bu tür e-postaların dağılımının tümüyle engellenmesi, bu çeşitlilik nedeniyle teknik olarak mümkün olamamaktadır. Tüm bu zorluklara rağmen spam e-postaların tanımlanması, engellenmesi ve tekrar etmemesi için Bilgi İşlem Daire başkanlığı aşağıda listelenen yöntemleri yürütmektedir:

- **İstemci Kısıtlamaları**

  - Erişim yapan istemcinin IP adresi, IP bloğu ve alan adı ile e-posta gönderimi için belirtilen gönderici adresi ilgili listelerde taranır. Eşleşme olursa uygun uyarı metni ile engelleme yapılır.

- **Gönderici Bağlantı İsteği Kısıtlamaları**

  - İlgili listelerde bulunan IP adreslerinden gelen gönderici bağlantı istekleri taranır, tanımlı ise erişime izin verilir. Gönderilen alan adı geçersiz bir formatta ise gönderici engellenir.

- **Gönderici Kısıtlamaları**

  - Varolmayan alan adlarından geliyormuş gibi kurgulanan e-postalar, gönderici adresinin tam alan adı tanımlamasına (FQDN) uygun formatta olmadığı e-postalar engellenir. Ayrıca mail.metu.edu.tr adresini kullanmadan gönderilmeye çalışılan <kullaniciadi>@metu.edu.tr formatındaki e-postalar ilgili hata mesajları verilerek engellenir.

- **Alıcı Kısıtlamaları**

  - Alıcı ve gönderici adreslerinin tam alan adı tanımlamasına (FQDN) uygun olmayan, varolmayan alan adlarından geliyormuş gibi ya da varolmayan alan adlarına gönderiliyormuş gibi kurgulanan e-postalar, gerçek zamanlı engelleme listelerinde tanımlı olan adres ve alan adlarına gönderilmeye çalışılan e-postalar engellenir. Dünya'da yaygın olan kara liste sağlayıcı listeleri (realtime blackhole list, RBL) taranarak SPAM yayıcı olarak bildirilen adresler engellenir. Bu listeler anlık güncellenmektedir

- **Geçici Bekleme Listelesi (GrayList)**

  - Geçici beklemelistesi yöntemi de sunucularımızda kullanılan spam e-posta yöntemlerinden biridir. Bu yöntemde gönderici alan adının IP adresi (1), gönderici adresi (2) ve alıcı adresi (3) ile bir üçleme (triplet) oluşturulur. Bu üçleme sunucularımıza ilk kez ulaştıktan sonra gri listeye alınır ve gönderen e-posta sunucusundan aynı şekilde bir gönderim daha yapması istenir. İlgili karşı e-posta sunucusu bu işlemi bir kez daha yaptığı zaman e-posta alıcının dizinine yazılır. Böylece farklı e-posta adreslerinden çoklu spam gönderen e-posta sunucularından gelen mesajlar engellenmeye çalışılır. Bu yöntemin kısıtlarından birisi düzgün yapılandırılmamış e-posta sunucularından gelen e-postalar bekleme listesine alındığı için alıcılar e-postaları gönderildiği zamandan daha uzun bir süre sonra alabilmektedirler (bazen 15 dakika bazen 3 saat gibi). Göndericinin e-posta dağıtıcısı kaynaklı böyle bir durumda beklediğiniz e-posta bu üçlü kontrol dolayısı ile gelen kutunuza anında değil de gerekli kontroller sağlandıktan sonra düşmektedir.

- **Spam ve Virüs Engelleme Uygulamaları (SMTP Milters)**

  - ClamAV: Unix ve benzeri sistemler için açık kaynak bir virüs tarayıcısıdır. Yerel dosyalarda ve e-posta sunucularına iletilen mesajlarda imza tabanlı virüs araması yapar. Virüs tespit edilmesi durumunda e-posta reddedilir. Tarama başarısız olursa e-posta ertelenir.
  - SpamAssassin: Açık kaynak kodlu anti-spam platformudur. Bir çok farklı kritere göre gerçekleştirdiği değerlendirme sonucunda iletilen mesajlara spam puanı verir. Değerlendirme kriterleri arasında ön tanımlı kurallar, RBL liste sorguları, manuel girilmiş kurallar ve bayesian mesaj gövde taramaları vardır. Yazılımın kendi güncellemeleri haricinde USOM (Ulusal Siber Olaylara Müdahale Merkezi) listesi düzenli olarak spamassassin'e otomatik olarak tanıtılmaktadır. Spam puanı 25 puandan yüksek olan postalar engellenmektedir. Ayrıca spamassassin veritabanı e-posta örnekleri ile eğitilebilmektedir.
  - Spam filtresi yazılımı, kullanıcılardan gelen temiz ve spam mesajların yazılım tarafından zaman içinde öğrenilmesiyle başarı seviyesini artırabilmektedir. Öğrenme amaçlı olarak sisteme işlenen temiz ve spam olarak tanıtılan e-postalarda kullanılan kelime sayısı sıklığı vb. bilgiler sayesinde, spam filtre yazılımı sunucuya gelen e-postanın spam olma olasılığını belirlemekte, belirli bir eşik değerin üzerinde spam olasılığı olan e-postaları spam olarak işaretlemektedir. Bu e-postalar SPAMBOX'lara taşınmaktadır. Bu filtrenin mesajları doğru tespit edebilmesi teorik olarak %99.9 mümkündür. Filtre yazılımı, doğru ve yanlış/spam mesajlar tanıtılarak beslendiğinde başarı yüzdesi artmaktadır.

- **Veri (DATA) Kısıtlamaları**

  - Basit Posta Aktarım Protokolü (SMTP) komutlarının zamanlamasını tutturamayan istemciler engellenmektedir.
  - İçerik kısmında Ulusal Siber Olaylara Müdahale Merkezi (USOM) tarafından bildirilen adresler kontrol edilmektedir.
  - En önemli anti-spam filtrelerinden olan ve zamanla kara listeye alınan tüm tehditlere karşı iletileri taramayı öğrenen bayes filtresi uygulanmaktadır.
  - Yaygın tespit edilen problemler için manuel kurallar işletilmektedir.

- **ETRN Kısıtlamaları**

  - ETRN e-posta alıcısı sistemlerin kendilerine iletilen e-postaları istedikleri zaman çekmelerini sağlayan bir yapıdır ancak e-posta sistemleriyle çok uyumlu çalışmamaktadır. Internet bağlantılarının kararlı olmadığı ya da zaman limitli kaynaklar olduğu dönemden kalma eski bir uygulamadır. Sunucularımızda bu yöntem ile e-posta alınması engellenmiştir.

Uygulanan filtreleme sistemleri ile istenmeyen bu içeriklerin kullanıcılarımıza tekrar gönderilmesi veya şifrelerini çaldırmış kullanıcılarımızın hesaplarını kullanarak başka adreslere e-posta göndermeye çalışan zararlı uygulamalar engellenmeye çalışılmaktadır. ODTÜ Bilgi İşlem Daire Başkanlığı, kullanıcılarından şifre vb. tür bilgileri web ya da e-posta aracılığıyla göndermesini kesinlikle istememektedir. Kullanıcı kodunuza ait şifrenizi hiçbir durumda sözlü yada yazılı olarak bir başkasına vermemeniz gerekmektedir.

Yukarıda listelenen ve açıklanan yöntemler, sunucularımıza ve dolayısıyla kullanıcılarımızın e-posta kutularına daha az spam e-posta düşmesi için uygulanan yöntemlerdir. Spam göndericiler sürekli gelişen yöntemler ile bu engelleri aşabilmekte ve istenmeyen e-postalar gönderebilmektedirler. Bu mesajları sistemlerimize tanıtabilmek ve engelleyebilmek için ilgili mesajları [http://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tama...](http://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim) adresindekine benzer adımlar uygulayarak kullandığınız e-posta istemcisi üzerinden mesaj başlık bilgileri ile [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresi üzerinden gönderebilirsiniz.

**Spam konusundaki diğer sıkça sorulan sorular için lütfen [http://faq.cc.metu.edu.tr/tr/groups/spam](http://faq.cc.metu.edu.tr/tr/groups/spam) adresini ziyaret ediniz.**