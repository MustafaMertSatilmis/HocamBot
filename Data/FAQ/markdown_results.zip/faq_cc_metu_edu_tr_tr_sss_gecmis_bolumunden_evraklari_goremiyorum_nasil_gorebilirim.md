[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum-nasil-gorebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5229


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum-nasil-gorebilirim)

# Geçmiş bölümünden evrakları göremiyorum, nasıl görebilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Geçmiş bölümünde daha önce size ulaşmış ve sizin ürettiğiniz bütün evrakları görebilirsiniz.

**Listelenecek evraklar için başlangıç ve bitiş tarihlerini genişletmelisiniz.**

EBYS ilgili sorular [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletilebilir.