[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sablonlari-nasil-olusturulur#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 10149


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yazi-sablonlari-nasil-olusturulur)

# EBYS'de yazı şablonları nasıl oluşturulur?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de daha sonra istenildiği zaman kullanmak üzere İç/Dış yazışma şablonları kaydedebilirsiniz. Bu şablonları oluşturabilmek için:

EBYS -> Şablon Yönetimi -> "Kurum İçi/Dışı Şablonlar" -> "Şablon oluştur" yolu ile yeni şablon oluşturma ekranına gidilir.

Ekranda daha sonra hazır gelmesi istenen bütün alanlar doldurulur.

Bütün istenen alanlar doldurulduktan sonra yukarıdaki düğmelerden "Şablon Kaydet" düğmesi ile şablon kaydedilir.

Daha sonra bu şablonlar yazı oluştururken kullanılabilecektir.

Mevcut yapıda kaydedilen şablonların isimlerinde bir değişiklik yapılması fonksiyonu bulunmamaktadır. Yeni bir yazı oluştururken değişiklik yapmak istediğiniz şablonu getirdikten sonra, farklı kaydederken istediğiniz ismi verebilir ve daha sonra eskisini silebilirsiniz.

Nasıl yapıldığını görebilmek için [bu videoyu izleyebilirsiniz](https://www.youtube.com/watch?v=KwJTAfKLnuM).

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.