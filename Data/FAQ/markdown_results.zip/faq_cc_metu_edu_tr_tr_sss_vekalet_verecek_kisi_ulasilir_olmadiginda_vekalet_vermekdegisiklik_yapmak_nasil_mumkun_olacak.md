[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verecek-kisi-ulasilir-olmadiginda-vekalet-vermekdegisiklik-yapmak-nasil-mumkun-olacak#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-01-2020 **Görüntüleme:** 4161


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verecek-kisi-ulasilir-olmadiginda-vekalet-vermekdegisiklik-yapmak-nasil-mumkun-olacak)

# Vekalet verecek kişi ulaşılır olmadığında vekalet vermek/değişiklik yapmak nasıl mümkün olacak?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine kimin hangi süre ile kime vekalet vereceği bilgisi e-posta ile gönderilmelidir. Gerekli tanımlama yapılacaktır.