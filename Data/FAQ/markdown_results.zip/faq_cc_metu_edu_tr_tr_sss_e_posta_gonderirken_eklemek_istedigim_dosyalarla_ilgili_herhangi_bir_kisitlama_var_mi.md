[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-eklemek-istedigim-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8835


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/are-there-any-limitations-attachments-outgoing-e-mail "Are there any limitations for the attachments of outgoing E-mail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-eklemek-istedigim-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi "E-posta gönderirken eklemek istediğim dosyalarla ilgili herhangi bir kısıtlama var mı?")

# E-posta gönderirken eklemek istediğim dosyalarla ilgili herhangi bir kısıtlama var mı?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

ODTÜ merkezi e-posta sunucusu üzerinde e-posta gönderirken eklemek istediğiniz dosyalar 25 MB'ı aşmamalıdır. Aşan dosyalar sıkıştırılarak ya da parçalayarak (multiple file zip) gönderilebilir.