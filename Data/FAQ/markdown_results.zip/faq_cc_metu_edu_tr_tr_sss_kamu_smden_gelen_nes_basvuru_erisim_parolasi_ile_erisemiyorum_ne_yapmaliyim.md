[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nes-basvuru-erisim-parolasi-ile-erisemiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-09-2020 **Görüntüleme:** 6830


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-cannot-access-it-nes-application-access-password-come-kamu-sm-what-should-i-do "I cannot access it with the NES application access password come from Kamu SM, what should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nes-basvuru-erisim-parolasi-ile-erisemiyorum-ne-yapmaliyim "Kamu SM'den gelen NES başvuru erişim parolası ile erişemiyorum, ne yapmalıyım?")

# Kamu SM'den gelen NES başvuru erişim parolası ile erişemiyorum, ne yapmalıyım?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Nitelikli Elektronik Sertifika (NES) başvuru erişim parolası **geçerlilik süresi 6 ay** dır.

6 ay sonrasında kurum e-imza yetkilisi tarafından başvurunun **yenilenmesi** gerekir.

Bunun için **[http://eimza.metu.edu.tr](http://eimza.metu.edu.tr/)** adresini ziyaret ederek ODTÜ kullanıcı kodu ve parolanız ile giriş yaparak başvurunuzu ODTÜ Kurum e-imza yetkilisine iletiniz.