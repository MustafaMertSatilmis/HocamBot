[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-erisebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6834


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-access-metu-survey-service "How can I access METU Survey Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-erisebilirim "ODTÜ anket servisine nasıl erişebilirim?")

# ODTÜ anket servisine nasıl erişebilirim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

ODTÜ merkezi sunucularında kullandığınız kullanıcı adı ve şifrenizi kullanarak [https://anket.metu.edu.tr/admin](https://anket.metu.edu.tr/admin) adresine giriş yapabilirsiniz. Anket oluşturma ve yayınlama, katılımcı bilgilerini düzenleme, anket yanıtlarını görüntüleme gibi tüm işlemler bu adresten yapılmaktadır.