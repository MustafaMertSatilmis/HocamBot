[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yeni-bir-kurum-ici-yazi-nasil-olusturulur#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 9067


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-yeni-bir-kurum-ici-yazi-nasil-olusturulur)

# EBYS'de yeni bir kurum içi yazı nasıl oluşturulur?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

- EBYS'de oturum açınız.
- Sol menüden "EBYS" seçeneğini tıklayınız.
- Açılan bölümden "Kurum içi yazı oluştur" seçeneğini tıklayınız.
- Açılan bölümden "Konu girmek için tıklayınız" seçeneğini tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-01.png)

- Açılan bölümden "Konu" yazınız ve "Standart Dosya Planı"nı seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-02.png)

- Güvenlik sekmesine geçiniz. Gerekliyse doldurunuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-03.png)

- İlgiler sekmesine geçiniz. Bir ilgi varsa ekleyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-04.png)

- Sistemde bulunan hazır bir yazıyı eklemek istiyorsanız "Sistemden kayıtlı ilgi seç" seçeneğini kullanabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-05.png)

- Ekler sekmesine geçiniz. Ek varsa ekleyebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-06.png)

- Ekin türünü seçiniz ve gerekli alanları doldurduktan sonra tamam düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-07.png)

- Dağıtımlar sekmesine geçiniz. "Gönderilecek yer ekle" düğmesine basınız. İlgili birimi ekleyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-08.png)

- Gövde sekmesine geçiniz. Evrak gövdesini yazınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-09.png)

- Onaylayacaklar sekmesine geçiniz. Ekle düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-10.png)

- Onaycıları tek tek ve sırasıyla ekleyiniz ve tamam düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-11.png)

- Bütün alanları doldurduktan sonra tamam butonu ile evraka dönebilirsiniz. E-imzaya gönder butonuna basarak evrakın imza için ilgili kişilere gitme işlemini başlatabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/yazi-12.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.