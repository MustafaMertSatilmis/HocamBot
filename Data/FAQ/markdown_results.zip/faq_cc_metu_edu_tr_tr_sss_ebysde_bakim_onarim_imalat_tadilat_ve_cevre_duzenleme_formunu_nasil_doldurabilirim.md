[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bakim-onarim-imalat-tadilat-ve-cevre-duzenleme-formunu-nasil-doldurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-11-2023 **Görüntüleme:** 6409


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bakim-onarim-imalat-tadilat-ve-cevre-duzenleme-formunu-nasil-doldurabilirim)

# EBYS'de bakım, onarım, imalat, tadilat ve çevre düzenleme formunu nasıl doldurabilirim?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

- EBYS'de oturum açınız.
- Soldaki menüden "E-Formlar" seçeneğini seçiniz.
- Açılan bölümden "Bakım Onarım Formu" seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/bakimonarim1.png)

- Form üzerinde gerekli bütün açıklamalar bulunmaktadır. Formu dolurup "Gönder" düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/bakimonarim2.png)

- Doldurduğunuz formun hangi aşamada olduğunu, geçmiş ekranınızdan ilgili forma girdikten sonra form üzerindeki "akış tarihçesi" düğmesine tıklayarak takip edebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/bakimonarim3.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/bakimonarim4.png)

**ÖNEMLİ NOTLAR:**

- EBYS üzerinden bakım, onarım, imalat, tadilat ve çevre düzenleme istek formu aşağıdaki kurallara uygun olarak doldurulmalıdır:

\- Standart demirbaş eşya isteklerinde kod numaralarını mutlaka belirtiniz.

\- Bir formda tek tür talep yapınız. Standart ürünü, özel imalatı, onarımı aynı formda yazmayınız.

\- Standart demirbaş eşya taleplerinizi her yıl Şubat ayı sonuna kadar yapınız. Bu taleplerde bir forma birden fazla malzeme yazılabilir.

\- Demirbaş eşya onarım istek formlarında belirtilen istekler Genel Atelyeler Müdürlüğü Onarım Ekibi tarafından gerekirse yerinde incelenecek, onarımı uygun görülen malzemenin onarıma alınacağı yaklaşık tarih yazılı olarak istek sahibine bildirilecektir.

Özel imalat talepleri için:

\- Özel imalat isteklerinde detay alanındaki istek kapsamı kutusuna malzemeden yararlanacak kişi sayısını (Akademik, İdari Personel ve Öğrenci sayıları) ve kullanım amacını belirtiniz.

\- Özel imalat isteklerinde teknik resim ekleyiniz.

\- Özel imalat isteklerinde her malzeme için ayrı bir form doldurunuz. Örneğin, standart dışı 200x120x75 cm'lik masa ile 240x60x90 cm'lik masayı aynı formda istemeyiniz.

\- Özel imalat istek formlarında belirtilen talepler, malzeme imkanları ve iş programı göz önünde bulundurularak Genel Sekreterlik'e bilgi verilerek görüş almak kaydıyla Genel Atelyeler Müdürlüğü tarafından değerlendirilecek ve imalata alınıp alınmayacağı, alınacaksa tahminen ne zaman bitirileceği konularında istek sahibine bilgi verilecektir.

Ayrıntılı bilgi ve tüm sorularınız için [https://yitdb.metu.edu.tr/tr/iletisim](https://yitdb.metu.edu.tr/tr/iletisim) sayfasındaki bilgileri kullanarak ilgili Yapı İşleri ve Teknik Daire Başkanlığı birimine ulaşabilirsiniz.

- Birim ve bölümlerdeki bakım, onarım, imalat, tadilat ve çevre düzenleme talepleri doğrudan birim/bölümler tarafından doldurulacak form ile gönderilebilmektedir.
- Lojmanlarla ilgili taleplerin öncelikle Sosyal Tesisler Müdürlüğüne ( [https://stm.metu.edu.tr/tr/personelimiz](https://stm.metu.edu.tr/tr/personelimiz)) bildirilmesi gerekmektedir. Lojmanlardaki bakım onarım ihtiyaçları Sosyal Tesisler Müdürlüğü aracılığıyla iletilmektedir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.