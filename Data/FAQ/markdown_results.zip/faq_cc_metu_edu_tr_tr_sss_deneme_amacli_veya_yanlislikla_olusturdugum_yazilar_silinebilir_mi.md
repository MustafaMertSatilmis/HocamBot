[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/deneme-amacli-veya-yanlislikla-olusturdugum-yazilar-silinebilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 1437


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/deneme-amacli-veya-yanlislikla-olusturdugum-yazilar-silinebilir-mi)

# Deneme amaçlı veya yanlışlıkla oluşturduğum yazılar silinebilir mi?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Onaya gönderilmemiş yazılar içerikleri silindikten sonra "İptal" düğmesine basılmak suretiyle iptal edilmiş evrak statüsünde arşivinizde durur.

Bir evrak ilk onaya gönderildiği anda numara alarak kayıtlara girer, daha sonra silinemez.

Bir evrak bütün elektronik onayları ve imzaları tamamlanarak hedef birime gitmiş ise yine silinmesi mümkün değildir. Evrak numara alarak resmileşmiştir. Ancak yazıda bir yanlışlık varsa yeni bir yazı hazırlanarak bu numaralı evrakta hata olduğu bilgisi de resmileştirilebilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.