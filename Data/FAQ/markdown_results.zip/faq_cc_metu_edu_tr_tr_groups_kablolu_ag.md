[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/kablolu-ag#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Kablolu Ağ

|     |
| --- |
| [IP adresime uygulanmış bir kısıtlama olup olmadığını nereden öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/ip-adresime-uygulanmis-bir-kisitlama-olup-olmadigini-nereden-ogrenebilirim) |
| [Bölümde yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/bolumde-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim) |
| [İnternet bağlantım çok yavaş. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir) |
| [Kablolu Ağa Nasıl Bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/kablolu-aga-nasil-baglanabilirim) |
| [ODTÜ Kablolu Ağı nasıl yönetiliyor?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablolu-agi-nasil-yonetiliyor) |

[![Subscribe to Kablolu Ağ](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/40/all/feed "Subscribe to Kablolu Ağ")