[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/baska-bir-kurumdan-e-imza-alabilir-miyim-e-imzam-var-kullanabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-09-2020 **Görüntüleme:** 10969


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-get-e-signature-another-institution-i-have-e-signature-can-i-use-it "Can I get an e-signature from another institution? I have an e-signature, can I use it?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/baska-bir-kurumdan-e-imza-alabilir-miyim-e-imzam-var-kullanabilir-miyim "Başka bir kurumdan e-imza alabilir miyim? E-imzam var kullanabilir miyim?")

# Başka bir kurumdan e-imza alabilir miyim? E-imzam var kullanabilir miyim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Bireysel olarak elektronik imza satın almanız mümkündür. Elektronik imza temin etmeye yetkili kurumlar [https://www.btk.gov.tr/elektronik-sertifika-hizmet-saglayicilari](https://www.btk.gov.tr/elektronik-sertifika-hizmet-saglayicilari) adresinden öğrenilebilir.

Kamu kurumları, Başbakanlık genelgesi gereği elektronik sertifikalarını TÜBİTAK UEKAE'ye bağlı Kamu Sertifikasyon Merkezi'nden temin etmek durumundadırlar.

Daha önceden temin edilmiş elektronik imza kitiniz varsa kullanabilirsiniz.

Alternatif kurumlardan temin edilen Nitelikli Elektronik Sertfika (e-imza) ücretlerini kişiler kendileri karşılamak durumundadır.

Bireysel olarak KamuSM dışındaki mercilerden temin edilen e-imza sertifikalarının EBYS'de kullanımında sorun yaşanması durumunda [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine bildirimde bulunulabilir.