[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketlerin-yanitlarini-nasil-gorebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6524


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-see-responses-my-surveys "How can I see the responses to my surveys?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketlerin-yanitlarini-nasil-gorebilirim "Oluşturduğum anketlerin yanıtlarını nasıl görebilirim?")

# Oluşturduğum anketlerin yanıtlarını nasıl görebilirim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Tamamlanmış veya yarıda bırakılmış tüm anket yanıtlarını "Anket" menüsünde bulunan "Yanıtlar" seçeneği ile görebilirsiniz. Anketinizin süresi bittiğinde veya kullanımdan kaldırmak istediğinizde mutlaka sona erdirmelisiniz.