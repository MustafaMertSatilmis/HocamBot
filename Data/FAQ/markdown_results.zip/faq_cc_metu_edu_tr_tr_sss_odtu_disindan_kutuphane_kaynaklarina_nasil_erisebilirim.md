[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-disindan-kutuphane-kaynaklarina-nasil-erisebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-03-2015 **Görüntüleme:** 7866


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-access-resources-metu-library-outside-metu "How can I access to The Resources of METU Library from outside of METU?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-disindan-kutuphane-kaynaklarina-nasil-erisebilirim "ODTÜ dışından Kütüphane kaynaklarına nasıl erişebilirim? ")

# ODTÜ dışından Kütüphane kaynaklarına nasıl erişebilirim?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

**Önemli Uyarı !!!**

**Kütüphane Önbellekleme Servisi 5 Ağustos 2014 tarihinde kapatılmıştır. Kütüphane Elektronik Kaynaklarına uzaktan erişim için aşağıdaki linkte anlatılan servislerden birini kullanınız:**

[http://lib.metu.edu.tr/tr/yerleske-disindan-erisim](http://lib.metu.edu.tr/tr/yerleske-disindan-erisim)

* * *