[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/fidyeci-cryptolocker-nedir-ve-bu-zararli-yazilimdan-korunma-yollari-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 9675


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/fidyeci-cryptolocker-nedir-ve-bu-zararli-yazilimdan-korunma-yollari-nelerdir)

# Fidyeci (CryptoLocker) Nedir ve Bu Zararlı Yazılımdan Korunma Yolları Nelerdir?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

Fidyeci (CryptoLocker) kullanıcılardan dosyaları şifrelemek yoluyla para talep etmeye dayalı zararlı bir yazılımdır. Bu zararlı yazılım etkin hale e-posta adresinize güven oluşturan kurumların kimliğine bürünerek gelen e-postanın eklentisi olan pdf dosyasının açılması ile gelir. Bu sahte PDF dosyalarını açtıktan sonra  %AppData%, %Temp% ya da %WinDir% klasörleri içinde kötücül yazılım dosyalarını yükler. Bulaşan virüs sizin bilgisayarınızı tarar ve desteklenen veri dosyalarını tespit edip şifrelemeye başlar.  Şifrelenen dosyalar . **encrypted** uzantısıyla görülür. Şifrelenen veri dosyalar aşağıdaki dosya uzantısı adlarını içerebilir,

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fidyeci1.png)

Bu virüse maruz kalan kullanıcılardan alınan bilgilerin doğrultusunda istenilen ödeme sonrası verilerini geri alan kullanıcılar olduğu gibi, alamayan kullanıcıların olduğu da bilinmektedir, yani bu yöntem ile şifrelenen dosyaların kurtarılma garantisi yoktur. Siber suçlular güvenilmez insanlardır ve ödeme yöntemi kesinlikle tavsiye edilmez. Bu nedenle Fidyeci zararlı yazılımı konusunda bilgi sahibi olup dikkatli davranmak gerekmektedir.

**Korunma Yolları**

Cryptolocker’dan kaçınmak için kullanıcıların alabileceği bazı önlemler;

**•** Orijinal işletim sistemi kullanın ve güvenlik programınızı düzenli olarak güncelleyin.

**•** Yasal gibi görünen bilinmeyen kaynaklardan gelen e-posta ya da kaynakları açmayın

**•** Önemli verilerinizi düzenli olarak yedekleyin ve internete bağlı olmayan harici bir depolama alanında tutun.

**•** Microsoft, Google ya da diğer bulut sağlayıcılarını verilerinizi tutmak için kullanmayı göz önünde bulundurun.

**•**. **exe, .zip** gibi zararlı yazılım içerebilecek dosyaları e-posta üzerinden engelleyin. Bu genellikle anti-spam sistem kullanılarak yapılabilir.

**•** İşletim sisteminize yönetici haklarınız olmadan giriş yapın. Bu virüs geri yükleme ‘’Volume Shadow Copy’’ dosyalarını silebilir, ancak sisteme giriş yaptığınızda yönetici haklarınız yoksa zararlı yazılım, dosyalarınızı şifrelemesine rağmen, geri yükleme noktasını silemeyeceği için, yönetici hesabından şifrelenmiş dosyalarınız kurtarabilirsiniz.

**•** Eğer virüs bulaşmışsa yazılım kısıtlama ilkesi (Software Restriction Policy) ile zararlı yazılımları engelleyebilirsiniz. Bu servisin kullanılması için Pro seviyesinde bir işletim sistemi kullanıyor olmalısınız. Kullanımı hakkında [http://www.cozumpark.com/blogs/windows\_server/archive/2008/04/28/software-restriction-policy.aspx](http://www.cozumpark.com/blogs/windows_server/archive/2008/04/28/software-restriction-policy.aspx) adresindeki makaleden gerekli bilgiye ulaşabilirsiniz. Sonrasında, %AppData%, %Temp% ya da %WinDir%  içinde olan virüs dosyaları üzerinde kısıtlama ilkesini uygulayabilirsiniz.

**Bulaşma Şekli**

**1)**     CryptoLocker yazılımı fatura yazılımı şeklinde kullanıcılara e-posta göndermektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fidyeci2.png)

**2)** Fatura hakkında bilgi almak isteyen kullanıcılar aşağıdaki şekilde gösterilen web sayfasına yönlendirilmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fidyeci3.png)

**3)**     İstenilen kodu girip indir butonuna tıklanıldığında ‘’.zip’’ uzantılı bir dosya inmektedir. Bu dosyanın içinde ise ‘’.exe’’ uzantılı fatura dosyası bulunmaktadır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fidyeci4.png)

**4)** Bulaşan virüs sizin bilgisayarınızı taramaya başlar ve desteklenen veri dosyalarını tespit edip şifrelemeye başlar. Şifrelenen dosyaların yeni uzantıları  **.encrypted** olur.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fidyeci5.png)

**5)**     Virüs bilgisayardaki şifreleme işlemini bitirdikten sonra aşağıdaki şekilde görüldüğü gibi şifre çözme yazılımı altında bir yazılımın satın alınmasını istemektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/fidyeci6.png)

**Not:** TTNet'in fatura görüntüleme adresi " **[https://efatura.ttnet.com.tr](https://efatura.ttnet.com.tr/)**" iken zararlı yazılımın kullandığı ise " **efatura.ttnet-fatura.info**" veya “ **efatura.ttnet-fatura.biz**" adresleridir **.**