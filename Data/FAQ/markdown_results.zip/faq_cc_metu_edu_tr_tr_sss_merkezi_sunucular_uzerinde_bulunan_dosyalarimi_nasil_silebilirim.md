[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucular-uzerinde-bulunan-dosyalarimi-nasil-silebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 9201


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-could-i-delete-files-central-servers "How could i delete the files on the Central Servers?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucular-uzerinde-bulunan-dosyalarimi-nasil-silebilirim "Merkezi sunucular üzerinde bulunan dosyalarımı nasıl silebilirim?")

# Merkezi sunucular üzerinde bulunan dosyalarımı nasıl silebilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

rm -\[seçenekler\] <dosya\_adı> komutunu kullanarak, dilediğiniz dosyaları silebilirsiniz.

Örnek seçenekler;

**-e** : Dosyanın silinmesinden sonra, ekranda bilgi verir.

**-f** : Sorma işlemini yapmadan, korumalı (write-protected) olan dosyaları siler. **(Bu seçenek yanlışlıkla kullanıldığında geri dönüşü olmayıp, çok gerekmedikçe tercih edilmemelidir.)****-i** : Dosyayı silmeden önce, silmek isteyip istemediğinizi sorar.

**-r** : Tekrarlamalı olarak alt dizinlerin silinip silinmeyeceğini **sormadan**, işlemi gerçekleştirir.

Örneğin;

$ **rm Bilgi-Islem\***

komutuyla, bulunduğunuz dizinin içerisinde, isimleri "Bilgi-Islem" ile başlayan bütün dosyaları silebilirsiniz.

$ **rm -rf deneme**

komutu ile deneme dizinini ve bu dizine ait alt dizinleri, bir uyarıda bulunmaksızın silebilirsiniz.