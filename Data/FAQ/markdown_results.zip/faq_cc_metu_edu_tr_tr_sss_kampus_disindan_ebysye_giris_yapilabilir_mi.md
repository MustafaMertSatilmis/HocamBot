[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kampus-disindan-ebysye-giris-yapilabilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 7368


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kampus-disindan-ebysye-giris-yapilabilir-mi)

# Kampus dışından EBYS'ye giriş yapılabilir mi?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Güvenlik önlemi olması açısından ve Üniversite yönetiminin de onayı doğrultusunda EBYS uygulamasına kampüs dışından erişim sadece VPN üzerinden sağlanabilmektedir. Kullanıcılarımız kampüs içinden doğrudan, kampus dışından ise VPN üzerinden her zaman EBYS'ye erişebilirler.

VPN hizmeti ile ilgili olarak [http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) adresinden detaylı bilgi alabilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.