[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/metucloud#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 01-06-2023 **Görüntüleme:** 2030


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/metucloud)

# METUCloud

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

METUCloud servisi kullanıcılarımıza bulut depolama ve dosya paylaşımı hizmeti sunmaktadır.

METUCloud servisini idari/akademik personelimiz sadece faaliyet alanları ile ilgili konularda kullanabilirler.

METUCloud depolama alanında kişisel dosyalar barındırılamaz.

METUCloud servisinde kullanıcılara ön tanımlı olarak 10GB depolama alanı tahsis edilir.

Servise " [https://metucloud.cc.metu.edu.tr](https://metucloud.cc.metu.edu.tr/)" adresinden ya da mobil uygulama( " [https://owncloud.com/mobile-apps/](https://owncloud.com/mobile-apps/)") üzerinden erişim sağlanır.