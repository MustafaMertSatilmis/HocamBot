[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-farkli-ortamlarda-calisir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 08-01-2018 **Görüntüleme:** 7891


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/does-eduroam-work-different-environments "Does eduroam work in different environments?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-farkli-ortamlarda-calisir-mi "eduroam farklı ortamlarda  çalışır mı?")

# eduroam farklı ortamlarda çalışır mı?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

eduroam Windows XP, Windows Vista, Windows 7, Windows 10, Linux, Windows CE, iphone, ipod gibi değişik cihaz ve platformlarda çalışabilmektedir.