[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablosuz-bilgisayar-agi-kullanim-kurallari-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 13254


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-are-metu-wireless-network-rules-and-regulations-use "What are the METU Wireless Network Rules and Regulations for Use?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kablosuz-bilgisayar-agi-kullanim-kurallari-nelerdir "ODTÜ Kablosuz Bilgisayar Ağı Kullanım Kuralları nelerdir?")

# ODTÜ Kablosuz Bilgisayar Ağı Kullanım Kuralları nelerdir?

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

1\. ODTÜ öğrenci ve mensupları için tahsis edilen ağ kablosuz ağ kaynakları (ağ bağlantısı, kablosuz ağ bağlantı kartı, kampus içi/dışı erişimi vb.) [http://bilisim-etigi.metu.edu.tr/](http://bilisim-etigi.metu.edu.tr/) adresinde tam metni bulunan **"ODTÜ Bilgi İşlem ve Bilgisayar Ağı Kaynakları Kullanım Etiği"** çerçevesinde kullanılmalıdır.

2\. Üniversitenin bilgisayar ağı yatırımları, devlet tarafından belirlenen kaynaklar kullanılarak **akademik, idari, eğitim ve araştırma birincil amaçlarına hizmet etmek üzere** yapılmıştır. Kablosuz ağ üzerindeki kişisel kullanımlar hiçbir zaman diğer kullanıcıların birincil ağ erişim gereksinimlerini (akademik, idari, eğitim, araştırma) yerine getirmelerine engel olmamalıdır. Bu doğrultuda ağ kaynaklarının kullanımında **uyulması gereken kurallar ve yasaklanmış faaliyetler** aşağıda belirtilmiştir:

a. **Peer-to-peer (P2P - noktadan noktaya)** dosya paylaşım programları, telif hakları ve lisansları ihlal etmenin yanı sıra, yüksek bant genişliği tüketerek birincil amaçlar için ağ kullanımına kaynak bırakmamaktadır. Bu nedenle, aşağıda sıralanan fakat bunlarla sınırlı olmayan **tüm "peer-to-peer" dosya paylaşım araçlarının kullanılması** \- trafık kampüs içinde yaratılıyor olsa bile - yasaktır.

_KaZaA, iMesh, eDonkey2000, Gnutella, Napster, Aimster, Madster, FastTrack, Audiogalaxy, MFTP, eMule, Overnet, NeoModus, Direct Connect, Acquisition, BearShare, Gnucleus, GTK-Gnutella, LimeWire, Mactella, Morpheus, Phex, Qtella, Shareaza, XoLoX, OpenNap, WinMX, DC++, BitTorrent, DC++ vs.._

b. **Kablosuz ağ kaynaklarının şahsi kazanç ve kar amacı ile kullanılması** yasaktır.

c. Kablosuz ağ kaynakları kullanılarak, **kütlesel e-posta gönderilmesi** (mass mailing, mail bombing, spam) ve **üçüncü şahısların göndermesine olanak sağlanması** yasaktır.

d. Kablosuz ağ baglantısı kullanılarak **servis veren** (web hosting servisi, e-posta servisi vb.) **sunucu nitelikli bilgisayar bulundurulması** yasaktır.

e. Üniversite ağ kaynaklarının **üniversite dışından kullanılmasına sebep olabilecek ya da üniversite dışındaki kişi ya da bilgisayarların kendilerini üniversite içindeymis gibi tanıtmalarını sağlayacak her tür faaliyet (proxy, relay, IP sharer, NAT vb.)** yasaktır.

f. **Ağ güvenliğini tehdit edici faaliyetlerde bulunmak** (DoS saldırısı, port-network taraması vb.) yasaktır.

g. Kablosuz ağ arabiriminin **donanım adresinin (MAC address)** değistirilmesi yasaktır. Bu adres ODTÜ BIDB'de kurulu bulunan kimlik doğrulama sistemine BIDB Network Grubu elemanları tarafından tanıtılmalıdır. Değişikliğin zorunlu olduğu durumlarda (kablosuz ağ erişim kartının arızalanması, değiştirilmesi vb.) Bilgi İşlem Daire Başkanlığı'na bildirilmesi gerekmektedir. (Yeni adres kimlik doğrulama sistemine tanıtılmadan sistem kablosuz ağ erişimine izin vermemektedir.)

h. Kablosuz ağ hizmetinden faydalanan her kullanıcı, üniversite tarafından kendisine tahsis edilen kaynakların (ağ bağlantısı, kullanıcı kodu, kampüs içi/dışı erişimi vb.) kullanımından, güvenliğinden ve bu kaynakların bilinçli ya da bilinçsiz olarak **üçüncü kişilere kullandırılması durumunda ortaya çıkabilecek yasaklanmış faaliyetlerden** birinci derecede sorumludur.

3\. Yukarıda belirtilen kurallara uyulmadığının tesbiti durumunda aşağıdaki cezalardan bir ya da birkaçı uygulanabilir ;

- Kampus içi ve/veya kampus dışı ağ erişiminin sınırlandırılması,
- Kampus içi ve/veya kampus dışı ağ erişiminin kapatılması,
- Sunucu sistemler üzerindeki kullanıcı kodunun kapatılması,
- Üniversite bünyesindeki soruşturma mekanizmalarinin harekete geçirilmesi,
- Adli yargı mekanizmalarının harekete geçirilmesi.

4\. Kurallara uymadığı tesbit edilen öğrenci ve mensuplara ilgili idari birim aracılığı ile bildirim yapılır.

5\. Bu kurallar yayınlandığı tarihten itibaren geçerlidir. Gerekli görüldüğü durumlarda **metin üzerinde değişiklik yapılabilir**. Kuralların **güncel sürümüne** bu web adresinden erişilebilir.

**YASAL SORUMLULUK REDDİ:**

ODTÜ Bilgi Islem Dairesi ODTÜ kablosuz ag kullanimindan dogacak riskler konusunda sorumluluk kabul etmez. Bütün sorumluluk kullaniciya aittir.