[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/sertifikami-uluslararasi-yazismalarda-kullanabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-10-2020 **Görüntüleme:** 6504


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-use-my-certificate-international-correspondence "Can I use my certificate in international correspondence?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/sertifikami-uluslararasi-yazismalarda-kullanabilir-miyim "Sertifikamı uluslararası yazışmalarda kullanabilir miyim?")

# Sertifikamı uluslararası yazışmalarda kullanabilir miyim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Elektronik imzalarla yapılan işlemler için bir takım doğrulamalar vardır. Bunlardan sadece biri olan; sertifikayı veren makamın doğrulanması ve bu makamın sertifikasının (kök sertifika) doğruluğunun sağlanmasıdır.

Bu konuda "Elektronik İmza Kanununun Uygulanmasına İlişkin Usul ve Esaslar Hakkında Yönetmelik'"te Yabancı Elektronik Hizmet Sağlayıcıları (ESHS) ile ilgili şu bilgiler yer almaktadır:

\- Yabancı elektronik sertifikaların hukuki sonuçlarına ve kabul edilmesine ilişkin şartlar milletlerarası anlaşmalarla belirlenir.

\- Farklı ülkelerde kullanılacak olan son kullanıcı sertifikaları için iki ülkenin ortak karar vererek bir anlaşmaya imza atması ve sonrasında ise ülkelere ait kök sertifikaların birbirine güvenmelerinin sağlanması için birtakım yöntemlerle teknik olarak çalışma yapılması gerekmektedir.

\- İki ülkenin de uyması gereken uluslararası standartlar (ETSI TS 101 733, ETSI TS 101 903, CWA 14710 vs. gibi) çerçevesinde çalışıyor olması gerekmektedir.

\- Bu sebeple alınan sertifikaların AB üyesi ülkesi ülkeler ve diğer ülkeler de hemen kullanılabilmesi mümkün olmamaktadır. Bu iş için iki ülkenin bir araya gelerek gerekli incelemeleri ve çalışmaları yaparak anlaşma yapması gerekmektedir.