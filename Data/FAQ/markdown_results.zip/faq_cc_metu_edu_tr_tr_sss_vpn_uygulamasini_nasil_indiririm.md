[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasini-nasil-indiririm#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 07-05-2020 **Görüntüleme:** 31904


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-download-vpn-application "How to Download the VPN Application?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasini-nasil-indiririm "VPN uygulamasını nasıl indiririm?")

# VPN uygulamasını nasıl indiririm?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

Cihazınıza uygun VPN uygulamasını indirmek için, [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/ "Netregister") sayfasına giriş yaparak **"VPN Service** **"** simgesine tıklayınız.

![Vpn Menu](https://faq.cc.metu.edu.tr/system/files/u21699/vpn_netregister_1.png)

Gelen sayfadaki listeden İşletim Sisteminize uygun olan VPN uygulamasını " **Download**" veya " **View**" linklerine tıklayarak indirebilirsiniz.

![Vpn Menu](https://faq.cc.metu.edu.tr/system/files/u21699/vpn_netregister_2.png)