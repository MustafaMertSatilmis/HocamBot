[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-vpn-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2020 **Görüntüleme:** 35857


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-vpn-service-my-iphone-or-ipad "How can i use METU VPN Service on my iPhone or Ipad?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-vpn-servisini-nasil-kullanabilirim "iPhone ya da iPad ile ODTÜ VPN servisini nasıl kullanabilirim?")

# iPhone ya da iPad ile ODTÜ VPN servisini nasıl kullanabilirim?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/1.png)

"App Store" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/2.png)

Arama alanına "Aruba Via" yazınız. "Free" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/3.png)

"Install" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/4.png)

"Password" giriniz. "Ok" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/5.png)

"Open" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/6.png)

Gelen giriş ekranına "border.metu.edu.tr" yazınız. Metu "kullanıcı kodu" ve "şifre" giriniz. "Login" dokununuz.

![Profile Selection](https://faq.cc.metu.edu.tr/system/files/u21699/profile_page.png)

**default** profili seçiniz.

![](https://faq.cc.metu.edu.tr/system/files/u21699/iphone1_0.png)

"VPN" bağlantısını sağa kaydırarak açınız.

![](https://faq.cc.metu.edu.tr/system/files/u21699/iphone2_0.png)

"VPN" bağlantısı hazırdır.