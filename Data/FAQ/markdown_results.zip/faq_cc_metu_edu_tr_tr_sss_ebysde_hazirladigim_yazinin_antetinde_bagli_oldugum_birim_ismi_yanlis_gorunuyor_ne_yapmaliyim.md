[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirladigim-yazinin-antetinde-bagli-oldugum-birim-ismi-yanlis-gorunuyor-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 10-05-2018 **Görüntüleme:** 6097


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-hazirladigim-yazinin-antetinde-bagli-oldugum-birim-ismi-yanlis-gorunuyor-ne-yapmaliyim)

# EBYS'de hazırladığım yazının antetinde bağlı olduğum birim ismi yanlış görünüyor, ne yapmalıyım?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS, üniversitemiz Personel Daire Başkanlığı'nın yönetimindeki ODTÜ İnsan Kaynakları Yönetim Sistemi (İKYS) ile entegre çalışmakta, yazı antetleri üzerinde görüntülenen birim isimleri ve bağlı olduğunuz birim bilgisi İKYS'den alınmaktadır.

Yazı antetleri üzerinde görüntülenen birim ismi ile çalıştığınız birim bilgisi farklı ise, bu durumu isim ve iletişim bilgilerinizi de belirterek [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine gönderebilirsiniz. Bir tanımlama eksikliği/hatası varsa Personel Daire Başkanlığı tarafından incelenerek, uygun görülmesi durumunda düzeltilmesi sağlanacaktır.

Söz konusu değişiklikler İKYS'de yapıldıktan sonra EBYS sistemine de yansıtılmaktadır.