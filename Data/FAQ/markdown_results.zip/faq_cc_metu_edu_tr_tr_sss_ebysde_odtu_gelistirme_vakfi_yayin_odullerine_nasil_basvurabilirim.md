[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-odtu-gelistirme-vakfi-yayin-odullerine-nasil-basvurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 7128


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-odtu-gelistirme-vakfi-yayin-odullerine-nasil-basvurabilirim)

# EBYS'de ODTÜ Geliştirme Vakfı yayın ödüllerine nasıl başvurabilirim?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

- EBYS'de oturum açınız.
- Sol menüden "Elektronik Formlar" seçeneğini seçiniz.
- Açılan bölümden "Kitap Ödülü Formu" seçeneğini seçiniz.
- Form üzerinde gerekli bütün açıklamalar bulunmaktadır. Formu dolurup "Gönder" düğmesine basınız.
- Doldurduğunuz formun hangi aşamada olduğunu geçmiş ekranınızdan ilgili evrakın akış tarihçesine ulaşarak takip edebilirsiniz.
- EBYS'ye sadece üniversitemiz personeli erişebildiği ve öğrenciler giriş yapamadığı için, ODTÜ Geliştirme Vakfı Yayın Ödüllerine başvurmak isteyen öğrencilerin kitap ödülü formlarını ilgili bölüm sekreterleri aracılığı ile doldurmaları gerekmektedir.

Not: Makale ödülü başvurularının 1 Ekim 2020 tarihinden itibaren Akademik Performans Değerlendirme Süreç Yönetim Sistemi ( [https://apsis.metu.edu.tr/](https://apsis.metu.edu.tr/)) üzerinden yapılacak olması nedeniyle EBYS Makale Ödülü Başvuru Formu erişime kapatılmıştır. Konuyla ilgili sorular Akademik Programlar ve Eğitim Koordinatörlüğüne e-posta yoluyla ( [apek@metu.edu.tr](mailto:apek@metu.edu.tr)) iletebilir.

Ayrıca, ODTÜ Geliştirme Vakfı Yayın Ödülleri Öğrenci, İdari Personel, Emekli Öğretim Elemanı, Konuk Araştırmacı (ÖYP, DOSAP vb) başvuruları için [https://apek.metu.edu.tr/tr/odtu-gelistirme-vakfi-yayin-odulleri-ogrenci...](https://apek.metu.edu.tr/tr/odtu-gelistirme-vakfi-yayin-odulleri-ogrenci-idari-personel-emekli-ogretim-elemani-basvurulari) adresinden bilgi alınabilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.