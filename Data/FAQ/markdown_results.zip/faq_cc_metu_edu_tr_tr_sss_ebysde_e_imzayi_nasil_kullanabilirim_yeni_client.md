[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-07-2023 **Görüntüleme:** 6304


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-e-signature-electronic-document-management-system-new-client "How can I use E-signature in EBYS (Electronic Document Management System) [DSClient Application]? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client " EBYS'de E-imzayı nasıl kullanabilirim? [Yeni client - DSClient Uygulaması]")

# EBYS'de E-imzayı nasıl kullanabilirim? \[Yeni client - DSClient Uygulaması\]

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS uygulamasında e-imza kullanılabilmesi için Java, e-imza kart okuyucu sürücüleri ve DSClient uygulamasının bilgisayarınızda yüklü olması gerekmektedir. Bu kurulumlar için aşağıdaki adımları takip edebilirsiniz:

Windows bilgisayarlar için;

[1\. Adım: Java'yı nasıl yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-1-adim-javayi-nasil-yuklerim)

[2\. Adım: E-imza sürücülerini nasıl yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-2-adim-e-imza-suruculerini-nasil-yuklerim)

[3\. Adım: DSClient yazılımını nasıl yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim)

MacOS bilgisayarlar için,

[1\. Adım: Java'yı nasıl yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim)

[2\. Adım: E-imza sürücülerini nasıl yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-2-adim-e-imza-suruculerini-nasil-yuklerim)

[3\. Adım: DSClient yazılımını nasıl yüklerim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-3-adim-dsclient-yazilimini-nasil-yuklerim)

Linux bilgisayarlar için,

[EBYS'de e-imzamı nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-imza-linux-ebysde-e-imzami-nasil-kullanabilirim)

Kurulumlar tamamlandıktan sonra [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) adresinden "Elektronik İmza ile Giriş" bağlantısını kullanarak EBYS sistemine e-imza ile giriş yapabilirsiniz. İlk olarak içinde e-imza SIM kartınızın bulunduğu USB okuyucuyu bilgisayarınıza takınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ebys-ark1.png)

"Elektronik İmza ile Giriş" bağlantısına tıkladığınızda kart okuyucu, sertifika bilgileri (sahibi, kimlik no, seri no vs.) görüntülenecektedir. PIN numaranızı girdikten sonra YEŞİL düğme ile EBYS uygulamasına giriş yapabilirsiniz.

![](<Base64-Image-Removed>)

* * *

**[DSClient Uygulamasında Karşılaşılabilen Uyarılar](https://faq.cc.metu.edu.tr/tr/sss/dsclient-uygulamasinda-karsilasilabilen-uyarilar)**

* * *

Yukarıda tarif edilen adımları uygulamanıza rağmen e-imza kullanımıyla ilgili problem yaşıyorsanız ya da e-imza ile ilgili farklı sorularınız varsa, lütfen [https://faq.cc.metu.edu.tr/tr/groups/e-imza](http://faq.cc.metu.edu.tr/tr/groups/e-imza) adresindeki sıkça sorulan soruları inceleyiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.