[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/hatali-yazilar-nasil-iade-edilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 11576


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/hatali-yazilar-nasil-iade-edilir)

# Hatalı yazılar nasıl iade edilir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Üniversitemizde yürürlükte bulunan [Resmi Yazışma Kuralları Yönergesi](https://genduy.odtu.edu.tr/2018/EBYS/yazismayonergesi.pdf) gereği, sadece muhatabı olunmayan bir belge ulaştığında iade edilebilmekte (Madde 34); usullere uygun yazılmayan belgelere ise cevabi yazı oluşturulması gerekmektedir (Madde 37).

Birimlere, ilgili onaylardan ve imzalardan geçerek gelen fakat hata içerdiği tespit edilen bir yazı ulaştığı durumda, yukarıdaki kurallar gereği **"İade Et"** seçeneği EBYS'de görüntülenmemektedir. Hatalı yazılar **"Cevap Oluştur"** özelliği kullanılarak **"Kurum içi Yazı Oluştur"** bölümünden hazırlanacak cevap yazısı ile gönderici birime bildirilebilir ve gönderici birimin hataları düzelttiği yeni bir yazıyı baştan oluşturarak göndermesi gereği iletilir.

**"Cevap Oluştur"** seçeneğini kullanarak yönergenin belirttiği şekilde cevabi yazı yazmayı istemeyen birimlerimiz, hatalı yazıyı **"Sevt Et"** seçeneği ile gönderici birime tekrar havale etmeyi tercih edebilir. Bu işlemi yapmadan önce **"Notlar"** alanına, yazının gönderici birime tekrar havale edilme sebebi belirtilebilir. Bu şekilde gönderici birimlere geri havale edilen hatalı yazılar, gönderici birim tarafından baştan hazırlanarak tekrar muhatap birime gönderilmelidir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.