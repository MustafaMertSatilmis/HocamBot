[Jump to navigation](https://faq.cc.metu.edu.tr/tr/mathematica#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-02-2024 **Görüntüleme:** 28331


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/mathematica "MATHEMATICA")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/mathematica "MATHEMATICA")

# MATHEMATICA

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **MATHEMATICA** **14** **—**

**_MATHEMATICA_** _kontür ve yoğunluk çizimlerinin yanı sıra iki ve üç boyutlu grafikler oluşturabilen numerik ve sembolik hesaplamalar yazılımıdır._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemini gerçekleştirebilirsiniz._

_[**KURULUM**](https://faq.cc.metu.edu.tr/tr/mathematica#kurulum)_

_[**AKTİVASYON**](https://faq.cc.metu.edu.tr/tr/mathematica#aktivasyon)_

_[**ZAFİYET HAKKINDA ÖNEMLİ NOT**](https://faq.cc.metu.edu.tr/tr/mathematica#not)_

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“Next_** **_”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step1.png)

**_ADIM-2_**

**_“Next_** **_”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step2.png)

**_ADIM-3_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step3.png)

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step4.png)

**_ADIM-5_**

**_“Install”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step5.png)

**_ADIM-6_**

**_“Finish”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step6.png)

**_ADIM-7 <<<AKTİVASYON>>>_**

**_“ **_Activate through a Wolfram network license server_**”_**_yöntemini seçerek ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step7.png)

**_ADIM-8_**

_Aktivasyon işlemi için server name başlığı karşısındaki alana **“mathematica.cc.metu.edu.tr”**yazıp **“Activate”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step8.png)

**_ADIM-9_**

**_“I accept the terms of this agreement”_** _seçeneğini işaretleyiniz ve **“OK”** butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step9.png)

**_ADIM-10_**

_Aşağıdaki ekran geldiğinde kurulumunuz sorunsuz bir şekilde tamamlanmış demektir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/mathematica_14_0_step10.png)

* * *

_**ZAFİYET HAKKINDA ÖNEMLİ NOT**_

Yakın bir zamanda Mathematica 11.1, 11.2 ve 11.3 Linux versiyonlarında bir açık tespit edilmiştir. Bu açık nedeniyle bazı durumlarda sistem kullanıcıları Wolfram kodlarını yönetici hakkıyla çalıştırabilmektedir. VernierLink içeren son kurulum kaynaklarında bu açık bulunmaktadır.

**Çözüm:**

VernierLink fonksiyonunun kullanılmayacaksa zafiyet içeren dosyayı silin:

```
sudo rm /etc/udev/rules.d/wolfram-vernierlink-libusb.rules
```

Bu işlemi yapabilmek için yönetici hakkına sahip olmanız istenebilir.

Eğer Mathematica'yı VernierLink kullanan Vernier-Marka harici cihazlara bağlıyorsanız, aşağıdaki şekilde dosya iznini düzeltiniz.

```
sudo chmod 644 /etc/udev/rules.d/wolfram-vernierlink-libusb.rules
```

Bu işlemi yapabilmek için yönetici hakkına sahip olmanız istenebilir.

* * *

**_Bize ulaşın:_ _[https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)_**

* * *