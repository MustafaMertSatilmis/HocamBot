[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidb-spamsahte-e-postalar-icin-ne-yapmaktadir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8205


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-measures-does-cc-take-regarding-spambogus-e-mail "What measures does the CC take regarding spam/bogus e-mail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidb-spamsahte-e-postalar-icin-ne-yapmaktadir "BİDB spam/sahte e-postalar için ne yapmaktadır?")

# BİDB spam/sahte e-postalar için ne yapmaktadır?

[Spam](https://faq.cc.metu.edu.tr/tr/groups/spam)

BİDB e-posta sunucusuna gelen mesajlardan bir kısmı spam olarak SPAMBOX dizinlerine yazılmakta, bir kısmı virüslü mesaj olduğundan elenmektedir. Spam ya da virüs olmayan gerçek mesajlarsa INBOX dizinlerine yazılmaktadır.

Spam mesajlar BİDB tarafından merkezi e-posta sunucusu üzerinde çalişan spam filtresi ile elenmektedir. Bu filtre tarafından spam olarak işaretlenen e-postalar alıcısının mail dizini altında SPAMBOX adındaki özel bir e-posta kutusuna yönlendirilmektedir.

Spam mesajların silinmeden SPAMBOX posta kutusuna yönlendirilmesinin nedeni kullanıcılarımızın spam olmadığı halde SPAMBOX'a yazılan mesajları kaybetmesini engellemektir.

Spam filtresi yazılımı, kullanıcılardan gelen temiz ve spam mesajların yazılım tarafından zaman içinde öğrenilmesiyle başarı seviyesini arttırabilmektedir. Öğrenme amaçlı olarak sisteme işlenen temiz ve spam olarak tanıtılan e-postalarda kullanılan kelime sayısı sıklığı, gönderici adresleri vb. bilgiler sayesinde, spam filtre yazılımı sunucuya gelen e-postanın spam olma olasılığını belirlemekte, belirli bir eşik değerin üzerinde spam olasılığı olan e-postaları spam olarak işaretlemektedir. Bu e-postalar SPAMBOX'lara taşınmaktadır. Bu filtrenin mesajları doğru tespit edebilmesi teorik olarak %99.9 mümkündür. Filtre yazılımı, doğru ve yanlış/spam mesajlar tanıtılarak beslendiğinde başarı yüzdesi artmaktadır.

BİDB teknik personeli, yaptıkları araştırma sonucunda ODTÜ kullanıcıları için en uygun çözümün bu filtre yazılımı olduğuna karar vermiş ve ilk öğrenme (temiz ve spam e-postaların tanıtılması) sürecinden sonra yazılımı hizmete sunmuştur. Yazılım, teknolojisi gereği sürekli öğrenme halindedir ve kullanıcı profiline uygun olarak kendisini geliştirmektedir.