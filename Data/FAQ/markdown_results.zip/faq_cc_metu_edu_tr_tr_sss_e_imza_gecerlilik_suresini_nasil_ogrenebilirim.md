[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-gecerlilik-suresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 31-03-2022 **Görüntüleme:** 55877


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-e-signature-validity-period "How can I find out the e-signature validity period?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-gecerlilik-suresini-nasil-ogrenebilirim "E-imza geçerlilik süresini nasıl öğrenebilirim?")

# E-imza geçerlilik süresini nasıl öğrenebilirim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Elektronik imza sertifikaları **Türk vatandaşları** için **3 yıl,** **yabancı uyruklular** için **1 yıl** süre ile geçerlidir.

Elektronik imzanızın geçerlilik süresini **5 farklı** şekilde öğrenebilirsiniz.

Aşağıda **en pratik iki tanesi** tarif edilmektedir:

1\. [http://eimza.metu.edu.tr](http://eimza.metu.edu.tr/) sayfasına kullanıcı kodu / parola ikiliniz ile bağlanın. İlgili sayfada şimdiye kadar üretilmiş tüm sertifikalarınızın geçerlilik tarihleri gösterilmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u127225/screen_shot_2020-09-17_at_16.48.38.png)

Not: **Yerleşke dışından** e-imza sayfasına bağlanmak için [**VPN**](http://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti) servisini kullanmanız gerekmektedir.

2\. EBYS uygulamasında elektronik imza ile giriş veya e-imzala ekranlarında PIN giriş penceresi açıldığında kullanıcı bilgilerinizin altında "Geçerlilik süresi:" bölümünde "Geçerli" veya "Süresi dolmuş" bilgileri görüntülenmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ebys-ark2_0.png)