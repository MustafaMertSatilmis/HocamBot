[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-aginin-guvenlik-derecesi-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7321


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-security-level-eduroam "What is security level of eduroam?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-aginin-guvenlik-derecesi-nedir "eduroam ağının güvenlik derecesi nedir?")

# eduroam ağının güvenlik derecesi nedir?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

Günümüzde kablosuz ağlarda en yaygın güvenlik teknolojileri WEP, WPA, WPA2 olarak bilinen teknolojilerdir. WEP ve WPA gibi teknolojilerin artık güvenliği oldukça düşüktür. O yüzden kurulum dosyalarımızda WPA2 ön tanımlı olarak gelmektedir. Fakat WPA - TKIP geçici olarak kullanıma açıktır.