[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyesi-olarak-e-liste-servisi-arayuzunu-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 9369


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-mailman-interface-list-member "How can I use MAILMAN Interface as a List Member? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyesi-olarak-e-liste-servisi-arayuzunu-nasil-kullanabilirim "E-liste üyesi olarak E-Liste Servisi arayüzünü nasıl kullanabilirim?")

# E-liste üyesi olarak E-Liste Servisi arayüzünü nasıl kullanabilirim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Bu sayfada listelere üye olan kişilerin Mailman yazılımını kullanarak elektronik liste hizmetinden nasıl yararlanabileceği hakkında bilgiler verilmektedir. Mailman yazılımı liste hizmetlerini başta İngilizce ve Türkçe olmak üzere çeşitli dillerde hazırlanmış web arayüzlerinden sağlamaktadır. Bu sayfadaki bölüm başlığı ve bilgi mesajı gibi bilgiler liste üyelerinin Türkçe web arayüzlerini kullanacağı varsayılarak açıklanmıştır.

Üye olduğunuz liste ile ilgili bilgileri görmek için:

**(1)** [http://mailman.metu.edu.tr/mailman/listinfo](http://mailman.metu.edu.tr/mailman/listinfo) adresinden üye olduğunuz bir listeyi tıklayınız.

**(2)** Ekrana gelen **[http://mailman.metu.edu.tr/mailman/listinfo/L](http://mailman.metu.edu.tr/mailman/listinfo/L) İSTE-ADI** şeklindeki adresten liste ile ilgili şu bilgilere ulaşabilir veya şu işlemleri yapabilirsiniz:

> **(a) Liste açıklaması:** Liste yöneticisi tarafından liste hakkında detaylı bir açıklama yapılmışsa, bu bilgiler **LİSTE-ADI Hakkında** bölümünde görülebilir.
>
> **(b) Dil seçeneği:** Liste için birden fazla dil kullanımı seçeneği işaretlenmişse sayfanın sağ üst köşesinden arayüz için istenen dil seçilebilir. Liste ayarlarında birden fazla dil kullanımına izin verilmediyse, arayüzde kullanılan standart dil Türkçedir.
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_1.gif)
>
> **(c) Liste arşivi:** Listeye gönderilmiş mesajların listesini görmek için, **"Bu listeye önceden gönderilen mesajları görmek için LİSTE-ADI Arşivlerini ziyaret edin."** olarak belirtilen cümledeki linke tıklayınız. Listeye daha önce hiç mesaj gönderilmediyse **"No messages have been posted to this list yet, so the archives are currently empty"** şeklinde bir uyarı görüntülenir. Daha önce gönderilmiş mesajlar varsa ve arşiv herkese açıksa çeşitli opsiyonlarda (konusuna, tarihine, gönderen kullanıcıya vb.) sorgulamak üzere görüntülenir.
>
> **(d) Liste adresi:** Listeye mesaj göndermek için **LİSTE-ADI![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr** şeklindeki adres kullanılmalıdır.
>
> **(e) Listeye üyelik başvurusu:** Henüz üyesi olmadığınız bir listeye **LİSTE-ADI Listesine Üyelik** bölümü altındaki **e-posta adresi** ve **isminiz** bilgilerini doldurup göndererek üyelik başvurusunda bulunabilirsiniz:
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_2.gif)
>
> E-posta adresinizi ve isminizi girdikten sonra, liste işlemleri için ihtiyaç duyacağınız bir şifre de belirtmeniz gerekir. Eğer herhangi bir şifre belirtmezseniz otomatik şifre ataması yapılır ve size gelecek üyelik onay mesajında bu şifre yazılı olarak gönderilir.
>
> Ayrıca mesajlarınızı okurken kullanmak istediğiniz dil seçimini de bu alanda yapabilirsiniz.
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_3.gif)
>
> Listeye gönderilen mesajları tek tek değil de günlük toplu olarak almak isterseniz, aşağıdaki seçeneği **Evet** olarak işaretlemelisiniz.
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_4.gif)
>
> Tüm bilgileri girdikten sonra,
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_5.gif)
>
> butonuna tıklayarak üyelik başvurunuzu sonlandırabilirsiniz.
>
> **(f) Listenin üyelerini görmek, listeden çıkmak veya liste üyelik ayarlarını değiştirmek:** Eğer liste ayarları liste üyelerinin listesini görüntülemeye izin verecek şekilde yapılmışsa, listeye üye olduğunuz e-posta adresinizi ve liste şifrenizi girerek, liste üyelerini görebilirsiniz:
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_6.gif)
>
> Listeden çıkmak veya liste üyelik ayarlarınızı değiştirmek için e-posta adresinizi girmeniz gerekir:
>
> ![](https://faq.cc.metu.edu.tr/tr/system/files/u36580/img_mailman_7.gif)
>
> Daha fazla bilgi için [buraya](http://faq.cc.metu.edu.tr/tr/sss/e-liste-servisi-hakkinda-genel-bilgilere-nasil-ulasirim) tıklayınız.