[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysye-hangi-turde-dosyalar-eklenebilmektedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 2221


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysye-hangi-turde-dosyalar-eklenebilmektedir)

# EBYS'ye hangi türde dosyalar eklenebilmektedir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'ye sadece aşağıdaki türlerde dosyalar eklenebilmektedir.

PDF, TIFF, TIF, JPEG, JPG, PNG, DOC, DOCX, XLS, XLSX, TXT

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.