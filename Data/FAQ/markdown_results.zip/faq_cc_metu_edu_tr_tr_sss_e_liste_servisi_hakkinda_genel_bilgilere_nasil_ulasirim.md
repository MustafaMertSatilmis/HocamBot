[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-liste-servisi-hakkinda-genel-bilgilere-nasil-ulasirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-02-2020 **Görüntüleme:** 9824


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-reach-general-information-about-mailman "How can I reach to the general information about MAILMAN ?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-liste-servisi-hakkinda-genel-bilgilere-nasil-ulasirim "E-liste Servisi hakkında genel bilgilere nasıl ulaşırım?")

# E-liste Servisi hakkında genel bilgilere nasıl ulaşırım?

[Elektronik Listeler](https://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler)

Bu sayfada ve bağlantılı diğer sayfalarda, mevcut listelerin üyelerine ve yöneticilerine destek verilmesi amacıyla E-Liste yazılımı **Mailman** hakkında çeşitli bilgiler sunulmaktadır.

- **Liste Kullanım Arayüzü:**

[http://mailman.metu.edu.tr/mailman/listinfo](http://mailman.metu.edu.tr/mailman/listinfo)
- **Liste Yönetim Arayüzü:**

[http://mailman.metu.edu.tr/mailman/admin](http://mailman.metu.edu.tr/mailman/admin)
- **Liste Üyeleri için Yardım Belgesi:**

[mailman-member.pdf](http://file.cc.metu.edu.tr/ccweb/bidb_ccig/mailman-member.pdf) _\[PDF dosyası, 83 KB, İngilizce içerik\]_
- **Liste Yöneticileri için Yardım Belgesi:**

[mailman-admin.pdf](http://file.cc.metu.edu.tr/ccweb/bidb_ccig/mailman-admin.pdf) _\[PDF dosyası, 92 KB, İngilizce içerik\]_
- **Mailman Hakkında Bilgi Almak için:**

[http://www.gnu.org/software/mailman/index.html](http://www.gnu.org/software/mailman/index.html) _\[İngilizce içerik\]_
- **Mailman Sıkça Sorulan Sorular (FAQ) Sayfası:**

[http://wiki.list.org/display/DOC/Frequently+Asked+Questions](http://wiki.list.org/display/DOC/Frequently+Asked+Questions) _\[İngilizce içerik\]_
- **Soru ve Sorunlar için İletişim Adresi:**

**mailman**![](http://file.cc.metu.edu.tr/ccweb/bidb_ccig/img_et.gif) **metu.edu.tr**