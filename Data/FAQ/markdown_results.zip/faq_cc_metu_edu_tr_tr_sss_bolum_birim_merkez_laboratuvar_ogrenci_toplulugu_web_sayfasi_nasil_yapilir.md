[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bolum-birim-merkez-laboratuvar-ogrenci-toplulugu-web-sayfasi-nasil-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 11816


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/bolum-birim-merkez-laboratuvar-ogrenci-toplulugu-web-sayfasi-nasil-yapilir "Bölüm, Birim, Merkez, Laboratuvar, Öğrenci Topluluğu web sayfası nasıl yapılır?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bolum-birim-merkez-laboratuvar-ogrenci-toplulugu-web-sayfasi-nasil-yapilir "Bölüm, Birim, Merkez, Laboratuvar, Öğrenci Topluluğu web sayfası nasıl yapılır?")

# Bölüm, Birim, Merkez, Laboratuvar, Öğrenci Topluluğu web sayfası nasıl yapılır?

[Web Servisleri](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri)

Sayfanız için bir web hesabı ve alan adı gerekecektir. Bunun için [https://cc-form.metu.edu.tr/web](https://cc-form.metu.edu.tr/web/) adresinde yer alan " _**Yeni Web Kullanıcı Kodu ve Alan Adı Başvuru Formu**_"nu doldurmanız gerekmektedir. Başvurunuz üzerine sizinle iletişime geçilecektir. Web sitenizi aşağıdaki yöntemlerden biri ile oluşturabilirsiniz.

1. Kendiniz Dreamweaver ya da benzeri bir programla web sayfalarınızı hazırlayabilirsiniz.
2. Merkezi İçerik Yönetim Sistemi'ni (MİYS) kullanabilirsiniz.

MİYS açık kaynaklı bir içerik yönetim sistemi olan Drupal alt yapısını kullanmaktadır. Üniversitemizdeki akademik bölüm, idari birim, merkez, enstitü, fakülte/yüksekokul, lisansüstü program, laboratuvar, proje/araştırma grubu, öğrenci topluluğu vb. yapılara ait web sayfaları bu sistem üzerinde oluşturulabilmektedir. MİYS ile ilgili ayrıntılı bilgiye ve başvuru formuna [http://miys.metu.edu.tr](http://miys.metu.edu.tr/) adresinden erişebilirsiniz. Bu sistemi kullanırsanız MİYS kapsamında geçerli görsel kimlik standartlarına ( [http://www.metu.edu.tr/tr/gkk/gorsel-kimlik-standartlari](http://www.metu.edu.tr/tr/gkk/gorsel-kimlik-standartlari "Görsel Kimlik Standartları")) uymanız beklenmektedir.
3. ODTÜ Blog Servisi'ni kullanabilirsiniz.

ODTÜ Blog Servisi, özgür bir yazılım olan WordPress altyapısını kullanmaktadır. Bu servis ile üniversitemizdeki akademik bölüm, idari birim, merkez, enstitü, fakülte/yüksekokul, lisansüstü program, laboratuvar, proje/araştırma grubu, öğrenci topluluğu vb. yapılara ait web siteleri kapsamlı bir şekilde hazırlanabilir, bu sitelerde çeşitli yazılar ve sayfalar oluşturulabilir. Tasarım için biraz daha esnek olsa da serviste yer alan şablonlar dışında kalan harici bir şablona onay verilmemektedir. Servise giriş yapmak ve servis hakkında ayrıntılı bilgi almak için [http://blog.metu.edu.tr](http://blog.metu.edu.tr/) adresi kullanılmalıdır.