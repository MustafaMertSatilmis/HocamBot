[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-hangi-durumlarda-kapatilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 02-10-2024 **Görüntüleme:** 26545


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/under-which-circumstances-would-user-account-be-terminated "Under which circumstances would a user account be terminated?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-hangi-durumlarda-kapatilir "Kullanıcı hesabı hangi durumlarda kapatılır?")

# Kullanıcı hesabı hangi durumlarda kapatılır?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

**Öğrenci** kullanıcı hesapları mezun olduktan bir eğitim dönemi sonunda kapatılır. Özel Öğrenci veya Erasmus kapsamında gelen değişim öğrencilerinin kullanıcı kodları ise dönemlik olarak açılır ve dönem bitiminde otomatik olarak kapatılır.  Kapatılma işlemi için verilerin işlenmesinin hemen ardından ve kapatılış tarihinden önce belirli aralıklarla kendilerine kullanıcı hesaplarının kapatılacağına ilişkin bilgilendirme e-postası gönderilir. Mezun öğrencilerin ODTÜ Bilgi İşlem Daire Başkanlığı merkezi sunucuları üzerinde tanımlı [exxxxxxmetu.edu.tr](mailto:exxxxxx%3Cimg%20src=) formatındaki e-posta adresleri talep edilen başka bir e-posta adresine yönlendirilebilmektedir. Yönlendirme servisine ilişkin bilgilendirme, [https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim) adresinde bulunmaktadır.

İstifa, işten ayırma veya görev süresi bitimi nedeniyle **ayrılan personel** in kullanıcı kodu 3 ay sonra kapatılmaktadır. Kapatılma işlemi gerçekleşmeden önce belirli aralıklarla, hesabın kapatılacağına ilişkin bilgilendirme e-postaları gönderilir.

Ayrılan personelin ODTÜ Bilgi İşlem Daire Başkanlığı merkezi sunucuları üzerinde tanımlı kullanicimetu.edu.tr formatındaki e-posta adresleri talep edilen başka bir e-posta adresine yönlendirilebilmektedir. Yönlendirme servisine ilişkin bilgilendirme, [https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim) adresinde bulunmaktadır.  Akademik ve İdari ODTÜ personeli statüsünde iken görevinden ayrılanlara yönlendirme hakkı 19.03.2019 tarihli senato kararı ile verilmiştir ve uygulama tarihi olarak 20.03.2019 belirlenmiştir. Bu tarihten önce kapanan hesaplar için yönlendirme hizmeti uygulaması bulunmamaktadır. İlgili karar BIDB ana sayfasında e-kimlik işleyiş kuralları olarak yayınlanmıştır. Ayrılan personel kullanıcı kodları, kullanıcının bağlı olduğu idari birim amirliğince talep edildiği takdirde belirtilen tarihten (3 ay) önce kapatılabilecektir. Yarı zamanlı, sözleşmeli personel, proje personeli, diğer kamu personeli gibi kadrolu ODTÜ personeli kullanıcı tipinde açılmamış hesaplar için ayrılma sonrası yönlendirme işlemi yapılamamaktadır.

Kullanıcı hesabı kapatıldıktan sonra, hesapların yedeklerine ulaşılabilmesi için 15 gün içinde talep yapılmalıdır. Kullanıcılarımızın yedeklerini alabilmesi için, öncesinde yedeğini istedikleri tarihi belirtmeleri ve kimlikleri ile ODTÜ BİDB Bilişim Destek servisine ( [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)) başvurmaları gerekmektedir.

Geçerli nedenler belirtildiği takdirde, Personel Kullanıcı Koduna 3 ay ek uzatma verilebilmektedir. 3 aylık ek uzatma için ODTÜ BİDB Bilişim Destek servisi ( [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)) adresinden talepte bulunulabilir.

Araştırma Görevliliği sonlanan, ancak öğrencilik durumu (yüksek lisans veya doktora eğitimi) devam edenlerin, talep etmeleri halinde eğitim süreleri bitimine kadar Personel Kullanıcı Kodlarına ( 6 ay,1 yıl, 1’er yıllık sürelerle) ek uzatma verilebilir. Bu taleplerinizi , [F3 formu](http://bidb.metu.edu.tr/kullanici-kodu-formlari) nu doldurup, Bölüm/Birim yöneticisinden onay alındıktan sonra, Bilgi İşlem Daire Başkanlığı B-14 No'lu ofise getirerek ya da ( [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)) adresinden online olarak ileterek yapabilirsiniz.

Görevlendirmesi biten **Yarı-zamanlı öğretim elemanlarının** kullanıcı hesapları, görevlendirme bitimini takip eden 2 eğitim öğretim döneminin sonunda kapatılmaktadır. Yarı zamanlı öğretim elemanlarımızın kapatılan kullanıcı hesapları için e-posta yönlendirme hizmeti verilememektedir.

**Emekli** olan personelin kullanıcı kodu kapatılmamaktadır. Ancak Bölüm/Birim adına açılmış  kullanıcı hesapları (seminer,kongre,proje) için sorumlu personel olarak atanılmışsa, bu hesaplar emeklilik halinde kapatılmaktadır. Bölüm/Birim tarafından kapatılmaması talep edilen kullanıcı hesaplarına yeni Sorumlu Personel ataması yapılması gerekmektedir.

Emekli olan fakat Yarı zamanlı öğretim görevlisi olarak (ek görevli)  görevine devam eden personelin üzerine tanımlı olan bölüm/birim  hesaplarına ait kullanıcı kodları kapatılmamaktadır.

BİDB tarafından belirlenen koşullar doğrultusunda açılan **geçici kullanıcı hesapları**, kullanım süreleri bittiğinde kapatılmaktadır.

Kullanıcı kodu sahibinin **vefat** etmesi durumunda kullanıcı kodu kapatılmaktadır.

**EİS Projesi kapsamındaki birimler ve öğrenci toplulukları hesapları**, ilgili birim ya da topluluklardan resmi yazı ile talep gelmesi üzerine kapatılmakta, aksi durumda korunmaktadır.

**Kötü amaçlı kullanım sonucunda kullanıcı hesabının kapatılması:**

Kullanıcı hesapları, 24 Mart 2004 tarihinde duyurulan Bilişim Kaynakları Kullanım Politikaları metni uyarınca;

- ODTÜ BİDB tarafından belirlenen kullanım politikalarının gerektirdiği durumlarda
- T.C. yasalarının belirlediği yasadışı kullanımlarda,
- Geçici kullanıcı hesapları için belirlenen sınırların aşıldığı durumlarda,
- ODTÜ bilişim kaynaklarının akademik amaçlı çalışmaları engelleyici biçimde akademik amaçlı olmayan, ticari ve yasadışı amaçlı kullanıldığı durumlarda,
- Kişilere ait kullanıcı hesaplarının farklı kişiler tarafından kullanımının belirlendiği durumlarda,
- Sunucu Sistemler üzerinde tanımlı diğer kullanıcıların şifrelerini bulmaya çalışmak, dosyalarına müdahale etmek, değiştirmek vb. girişimlerin tespit edildiği durumlarda,
-  Lisanssız, korsan yazılımların kullanıcı hesabı disk alanında bulunduğu tespit edildiği durumlarda,
- Sistem bütünlüğünün, güvenliliğinin ve servis devamlılığının engellendiği durumlarda

_kullanıcıya haber verilmeksizin BİDB tarafından geçici olarak kapatılabilir. Kullanıcı hesabının kalıcı olarak kapatılacağı durumlarda kullanıcılar önceden bilgilendirilmektedir.Kötü amaçlı kullanım sonucunda BİDB tarafından kapatılan kullanıcı hesabı, disiplin soruşturması ve diğer yasal işlemlerin devam ettiği süre boyunca kapalı tutulabilecek, soruşturmanın bittiği ve savunmanın BİDB tarafından kabul edildiği durumlarda yeniden açılacaktır._

Kullanıcı kodları (e-kimlik) sonlandırmaya ilişkin Üniversite Yönetim Kurulu kararına BİDB web sayfasından erişilebilir.