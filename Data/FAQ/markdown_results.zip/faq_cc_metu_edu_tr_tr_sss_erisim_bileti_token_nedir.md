[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/erisim-bileti-token-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 7688


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-access-token "What is an access token?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/erisim-bileti-token-nedir "Erişim bileti (token) nedir?")

# Erişim bileti (token) nedir?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Dışarıya erişimi kapalı anketlere davet edilen kişilerin söz konusu anketlere erişmeleri için ihtiyaç duydukları, elle veya sistem tarafından otomatik oluşturabileceğiniz belli sayıda karakterden oluşan spesifik şifrelerdir. Anket erişimi kapalı olarak ayarlandıktan sonra oluşturulan erişim biletleri davet edilen kişilerin e-posta adreslerine gönderilir. Sadece davet edilen kişiler kendilerine ulaşan bu bilgiyi kullanarak ankete erişebilir ve yanıtlayabilirler.