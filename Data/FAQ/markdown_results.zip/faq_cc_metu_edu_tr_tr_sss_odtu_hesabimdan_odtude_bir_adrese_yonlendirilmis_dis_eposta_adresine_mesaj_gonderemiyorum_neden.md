[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-hesabimdan-odtude-bir-adrese-yonlendirilmis-dis-eposta-adresine-mesaj-gonderemiyorum-neden#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 8222


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-cannot-send-message-my-metu-account-external-e-mail-address-which-has-been-directed-address "I cannot send a message from my METU account to an external e-mail address which has been directed to an address in METU. Why?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-hesabimdan-odtude-bir-adrese-yonlendirilmis-dis-eposta-adresine-mesaj-gonderemiyorum-neden "ODTÜ hesabımdan, ODTÜ'de bir adrese yönlendirilmiş dış eposta adresine mesaj gönderemiyorum. Neden?")

# ODTÜ hesabımdan, ODTÜ'de bir adrese yönlendirilmiş dış eposta adresine mesaj gönderemiyorum. Neden?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

_kullanıcı![](http://faq.cc.metu.edu.tr/img/img_et.gif)metu.edu.tr_ yapısındaki bir eposta adresinden, aynı yapıdaki başka bir eposta hesabına gönderilen epostalar; diğer bir anlatımla hem kaynak, hem de hedef adreslerinde ("To" ve "From")  " _kullanici![](http://faq.cc.metu.edu.tr/img/img_et.gif)metu.edu.tr_" yapısı bulunan epostalar, "mail.metu.edu.tr"  sunucusu aracılığı ile gönderilmemişse durdurulmaktadır.

Bu engelleme, yerleşke dışından gönderilen sahte ve/veya spam içerikli istenmeyen mesajların yayılmasını durdurmak için uygulanmaktadır.

Bu nedenle, ODTÜ dışındaki bir eposta servis sağlayıcısından aldığınız eposta hesabınızı, ODTÜ merkezi kullanıcı kodunuza ait eposta adresinize yönlendirdiğinizde, bu hesabınıza ODTÜ alan adı içindeki bir hesaptan gönderilen epostalar, yerleşke dışı bir sunucu üzerinden dolaşacağından sahte/fake eposta olarak sınıflandırılarak sunucularımız tarafından

engellenecektir.

Önemli: Kampus içerisindeki bölüm eposta hesaplarından yapılacak yönlendirmeler (örn. _xxx![](http://faq.cc.metu.edu.tr/img/img_et.gif)xx.metu.edu.tr_) bu kapsamın dışında kalmakta ve engellenmemektedir.