[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-5-surumunde-yenilikler#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 15650


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-5-surumunde-yenilikler)

# Horde 5 sürümünde yenilikler

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

Horde, ODTÜ merkezi kullanıcı hesabınıza bağlanarak e-postalarınızı görüntüleyebileceğiniz, takvim, görevler, notlar gibi uygulamalarla işlerinizi organize edebileceğiniz, şifre değişikliği yapma, dosya yükleme gibi ODTÜ Merkezi kullanıcı hesabınızla ilgili işlemleri kolaylıkla yapabileceğiniz bir servistir. Bu servise [http://metumail.metu.edu.tr/](http://metumail.metu.edu.tr/) adresindeki ilgili bağlantı tıklanarak ulaşılabilir.

![metumail main screen](https://faq.cc.metu.edu.tr/tr/system/files/u2/metumail_main.png)

Gelişen teknolojiler ve üniversitemiz mensuplarının ihtiyaçları gözönüne alınarak Horde 5 sürümüne geçiş yapılmıştır. Bu sürümün sağladığı yenilikler aşağıda belirtilmektedir.

- Dinamik görüntüleme
- Mobil cihazlarla uyumlu görüntüleme
- Sadece metin görüntüleme
- Zenginleştirilmiş HTML destekli mesaj oluşturma editörü
- Eklentilerin editöre sürüklenip bırakılarak eklenebilmesi
- HTML destekli imzalar
- IMAP özelliklerinin arttırılması
- Esnek mesaj arama özellikleri
- Otomatik e-posta adresi tamamlama
- Aynı başlık altında gönderilen e-postaların mesaj dizisi olarak görüntülenmesi (thread view)
- Birden fazla e-postanın bir alıcıya ek olarak gönderilmesi
- Eklentilerin zip arşivi olarak indirilmesi vb. bir çok özellik ve performans ile ilgili geliştirmeler yapılmıştır.

![Horde 5 main screen](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5main.png)

### Yardım sayfasına nasıl ulaşabilirim?

Posta uygulamasında menü satırında bulunan çark işareti altından Yardım sayfasına ulaşabilirsiniz.

### Eposta mesajlarını nasıl silebilirim?

Seçenekler / Posta altında bulunan "İletilerin Silinmesi ve Taşınması" başlığı ile Gelen kutusunda SİL seçeneğinin işlevini tanımlayabilirsiniz. Eposta mesajlarınızı doğrudan silerek Trash / Çöp kutusuna gönderebilir veya silinmesi için işaretleyebilirsiniz. Silmek için işaretlenen mesajlarınızı Gelen Kutusunda bulunan Diğer / Silinecekleri Temizle seçeneği ile silebilirsiniz. Çöp kutusuna gönderilen mesajları daha sonra çöp kutusundan geri alabilirsiniz ancak Silinecekleri Temizle düğmesine basarak silinen mesajların geri alınması mümkün değildir.

Önceki horde sürümünün aksine yeni horde sürümünde mesaj kutusundaki tüm iletiler tek bir sayfada görüntülenmektedir. TÜMÜNÜ SEÇ işlevi görüntülenen mesaj kutusundaki tüm iletileri seçmektedir. Tüm iletileri seçerek silme işlemi yapmamanız tavsiye edilmektedir.

### Oluşturduğum bir iletiye nasıl dosya ekleyebilirim?

Yeni ileti düğmesine basarak yeni ileti yazma işlemini başlatınız. Dosya ekle düğmesine basarak iletinize eklemek istediğiniz dosyayı seçiniz. Başka bir dosya eklemek isterseniz aynı işlemi tekrarlayınız. Eklediğiniz bir dosyayı yanındaki OK işaretine basarak silebilirsiniz. İletinizin alıcısı, konusu ve içeriğini yazarak Gönder düğmesine basmanız yeterlidir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5_dosyaekleme.png)

### Bir iletinin tam başlık bilgisini nasıl görebilirim?

İletinin başlık bilgisini görmek için iletiyi görüntülerken + işareti (Diğer seçenekler) altındaki Kaynağı Görüntüle bağlantısını kullanabilirsiniz.

### İletileri nasıl filtreleyebilir, iletebilir, engelleyebilir veya otomatik olarak cevap verebilirim?

Gelen iletileri filtrelemek için sağ üstteki Süzgeç butonuna tıklayın. Açılır menüden istediğiniz filtreleme seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5_filtre.png)

Daha genel filtreleme için, Seçenekler menü öğesini seçin ve sonra Posta Yönetimi bölümünden Filtreler'i seçin.

Silinemeyen tüm iletileri belirtilen kurallara göre filtrelemek için Filtre Kuralları sayfasındaki "Tüm Kuralları Uygula" veya kutu görünümündeki INBOX adının yanındaki "Filtreleri Uygula" simgesini tıklatmanız gerekir. Yüklemenizde kalıcı seçenekler varsa, oturum açma ve / veya posta kutusu yenilendiğinde filtre kurallarınızı uygulamak için filtre seçeneklerini ayarlayabilirsiniz.

Filtre Kuralları sayfasından kuralların oluşturulmasını, kaldırılmasını veya düzenini de düzenleyebilirsiniz.

Seçenekler / Posta menüsünde İstenmeyen İleti Bildirimi bölümünde istenmeyen iletilerin hangi klasörde bulunacağını, "İstenmeyen İleti" veya "Temiz" olarak rapor edilen iletilerde hangi işlemlerin uygulanacağını tanımlayabilirsiniz. Ayrıca İstenmeyen İleti klasörünün hangi sıklıkta temizleneceğini de ayarlayabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5_filtre2.png)

### Nasıl okundu bildirimi alabilirim?

İleti oluşturma ekranında Diğer seçenekler altındaki Okundu Onayı kutusunu tıklayarak bir okundu bildirimi isteyebilirsiniz.

### İletileri farklı klasörlere nasıl taşıyabilirim?

Gelen kutusunda ileti satırını sürükle-bırak yöntemi ile istediğiniz klasöre taşıyabilirsiniz.

### İletileri farklı klasörlere nasıl kopyalayabilirim?

Gelen kutusunda ileti satırını sürükle-bırak yöntemi ile taşırken klavyedeki CTRL tuşunu basılı tutmanız gerekmektedir.

### Göndericileri karaliste veya beyaz listeye nasıl ekleyebilirim?

Gelen kutusunda Tarih sütununun üzerinde bulunan Diğer menüsü ile seçtiğiniz ileti göndericisini kara liste veya beyaz listeye ekleyebilirsiniz.

### İletilere nasıl imza ekleyebilirim?

Seçenekler / Posta menüsünde Kişisel Bilgiler bölümünde imzanızı ekleyebilirsiniz. İmzanızı kaydettikten sonra göndereceğiniz tüm iletilere imzanız otomatik olarak eklenecektir. İmzanızın ileti oluşturma sayfasında da görünmesi için Seçenekler / Posta menüsünde İleti Oluşturma bölümünde "İmzanız yeni ileti oluşturma penceresinde görüntülensin mi?" onay kutusunu işaretlemeniz gerekmektedir.

### Dizin listesinde görünmeyen posta kutularını nasıl görüntüleyebilirim?

Uygulamanın yeni sürümünde sadece üye olduğunuz posta kutuları listelenmektedir. Dizin listesinin üst kısmında yer alan Dizin Eylemleri menüsünde bulunan "Tüm Posta Kutularını Göster" seçeneği ile üye olmadığınız posta kutularının da görüntülenmesini sağlayabilirsiniz. Tüm posta kutularını görüntülediğinizde üyeliğiniz bulunmayan posta kutuları _italik_ olarak görüntülenecektir. Üye olmak istediğiniz posta kutusuna sağ tıklayarak "Üye Ol" seçeneği ile üyeliğinizi gerçekleştirebilirsiniz. Aynı zamanda üye olduğunuz herhangi bir posta kutusuna sağ tıklayarak "Üyelikten Çık" seçeneği ile üyeliğinizi iptal edebilirsiniz.

Dizin Eylemleri menüsünde "Üye Olunmayanları Gizle" seçeneği ile sadece üye olduğunuz posta kutularını görüntüleyebilirsiniz.