[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sertifikamin-gecerlilik-suresi-doldudolmak-uzere-yenileme-basvurusunu-nasil-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-01-2025 **Görüntüleme:** 37172


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-apply-renewal-if-my-e-signature-certificate-has-expired-about-expire "How can I apply for renewal if my e-signature certificate has expired / is about to expire?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sertifikamin-gecerlilik-suresi-doldudolmak-uzere-yenileme-basvurusunu-nasil-yapabilirim "E-imza sertifikamın geçerlilik süresi doldu/dolmak üzere, yenileme başvurusunu nasıl yapabilirim?")

# E-imza sertifikamın geçerlilik süresi doldu/dolmak üzere, yenileme başvurusunu nasıl yapabilirim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

1\. Kullanım süresi dolmuş ya da dolacak olan elektronik imzanızın yenilenmesi için öncelikle **[https://e-imza.metu.edu.tr](https://e-imza.metu.edu.tr/)** adresine giriş yaparak **YENİLEME** başvurusu yapmanız gerekmektedir.

**\*\*\*ÖNEMLİ:** İlgili adreslere kampüs dışından erişebilmek için VPN hizmetini kullanınız.

VPN hizmeti ile ilgili bilgi almak ve kurulumu için **[https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)** adresini ziyaret edebilirsiniz.

2\. Başvurunuz kurum yetkilisi tarafından onaylandıktan sonra kurumsal e-posta adresinize TÜBİTAK KamuSM tarafından bilgilendirme epostası gelecektir. Bu epostada belirtilen işlemleri tamamlayıp bahsedilen form KamuSM'ye başvuru yapan kişi tarafından iletilir.

[https://faq.cc.metu.edu.tr/tr/sss/islak-imzali-e-imza-basvuru-formu-nere...](https://faq.cc.metu.edu.tr/tr/sss/islak-imzali-e-imza-basvuru-formu-nereye-iletilmelidir)

3\. TÜBİTAK KamuSM'den gelen eposta sonrasında bağlantıda belirtilen " [**Ön Başvurusu Yapılan Kişilerin e-İmza Başvurularını Tamamlaması**](https://kamusm.bilgem.tubitak.gov.tr/basvurular/nes/?info=7 "Ön Başvurusu Yapılan Kişilerin e-İmza Başvurularını Tamamlaması")" işlemlerinin tamamlanması gerekmektedir.