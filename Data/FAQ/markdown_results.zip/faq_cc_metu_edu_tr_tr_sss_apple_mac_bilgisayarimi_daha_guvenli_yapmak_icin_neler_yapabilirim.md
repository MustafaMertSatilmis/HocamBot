[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/apple-mac-bilgisayarimi-daha-guvenli-yapmak-icin-neler-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 17140


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-can-i-do-make-my-apple-mac-computer-more-secure "What can I do to make my Apple MAC computer more secure?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/apple-mac-bilgisayarimi-daha-guvenli-yapmak-icin-neler-yapabilirim "Apple MAC bilgisayarımı daha güvenli yapmak için neler yapabilirim?")

# Apple MAC bilgisayarımı daha güvenli yapmak için neler yapabilirim?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

**APPLE MAC GÜVENLİK ÖNLEMLERİ**

Apple MAC bilgisayarınıza olası güvenlik tehditleri iki yerden gelebilir:

1\. Internet'ten

2\. Direkt erişim/fiziksel erişim aracılığı ile yani bilgisayarınızı başıboş ve yeterli güvenlik önlemleri almadan bırakırsanız.

Peki bilgisayarınızın güvenliğini artırmak için ne gibi güvenlik önlemleri alabilirsiniz?

Temel olarak yapacağımız bütün ayarları Sol üst köşedeki Elma ikonuna tıklayıp System Preferences’i seçerek yapacaksınız:

![Apple MAC security 1](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_01.png)

1\. **Standart kullanıcı kullanmak**: Apple bilgisayar üzerine işletim sistemi kurulurken ilk tanımlanan kullanıcı bir admin kullanıcıdır. Admin kullanıcı bilgisayar üzerinde her türlü değişikliği yapmaya yetkili kullanıcıdır. Bilgisayarınızı kullanırken admin kullanıcısı yerine standard bir kullanıcı ile kullanmak daha güvenlidir.

(Elma--> System Preferences--> User and Groups ile parolanızı değiştirebilirsiniz, standard kullanıcı tanımlayabilirsiniz.)

![Apple MAC security 2](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_02.png)

2\. **Güvenli Parola Politikası**:

Parolanızı kolay tahmin edilebilir ve sözlük saldırısı ya da sosyal mühendislik testleri (doğum tarihiniz vs) ile kolay tahmin edilebilir parolalardan seçmeyin. Güvenli parola politikasını en basit hali şu şekilde özetleyebiliriz: En az 8 karakter olmak koşulu ile içinde büyük harf, küçük harf, özel karakter (!, #, $, +, & gibi) ve rakam olmasına özen gösterin.

3\. **Autologin Seçeneğini Kaldırın**:

Bilgisayarınıza şifre sormadan giriş yapma, yani "automatic login" olma seçeneğini kaldırın. 1 numaralı şıkta açtığınız pencerede auto login olma seçeceğini kapatabilirsiniz. (Login Options altında)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_03.png)

4\. **Flash Player’ı Kaldırın**

Flash Player çok fazla kritik güvenlik açığı çıkabilen bir yazılımdır. Eğer programı kullanmıyorsanız bütünüyle kaldırın. Kullanıyorsanız da güvenlik güncellemelerini düzenli olarak takip edin. (Elma --> System Preferences altından kaldırılabiliyor)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_04.png)

5\. **Parola Yöneticisi Kullanın:**

Günümüz dünyasında pek çok parola kullanmamız ve bu parolaları hatırlamamız gerekebiliyor. Tekrar size madde 2’deki güvenli parola politikasını hatırlatmak isteriz. Ayrıca bütün parolaları aklınızda tutmak yerine, sadece tek bir parola (o da parola yöneticisinin parolası) hatırlamanıza olanak tanıyan parola yönetici (password manager) programlarından birini kurmanızı önerebiliriz. (App Store’dan indirebileceginiz Key Chain, 1 Password, Keeper gibi programlar)

**6\. File Vault ile Diskinizdeki Verileri Şifreleyin:**

MAC bilgisayarınızda değerli veriler olması durumunda şifreleme yaparak istenmeyen erişimlere karşı önlem alabilirsiniz. (Elma--> System Preferences--> Security&Privacy--> FileVault sekmesi ve aktif edilmesi)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_05.png)

**7\. Spotlight İzinlerini Gözden Geçirin:**

Spotlight arama bilgileri Apple'a iletilmekte, Apple da 3. taraflar ile bu bilgileri paylaşabilmektedir. Eğer arama bilgilerinizin mahrem kalmasını istiyorsanız Spotlight seçeneklerini gözden geçirebilirsiniz (Elma--> System Preferences--> Spotlight--> Privacy sekmesinden bilgi iletilmemesi için istisnalar tanımlayabilirsiniz)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_06.png)

**8\. Konum Servisleri (Location Services)**

Konum bilgilerinizi paylaştığınız uygulamaları denetleyin. Gerekli olmayanları kaldırın (Elma--> System Preferences--> Security&Privacy--> Privacy sekmesi) Unutmayın ki Apple bilgisayarınızı kaybettiğinizde ya da çaldırdığınızda bulmanıza yardımcı olacak uygulama "find my MAC" konum servisleri ile çalışmaktadır, o yüzden uygulamayı bütünüyle devre dışı bırakmak değil, uygun izinlerle kullanmak daha uygundur.

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_07.png)

**9\. Yazılım Güncellemeleri**

Yazılım güncellemelerini sık takip edin, hatta otomatik hale getirin. (Elma--> System Preferences--> App Store başlığı altında güncellemeleri otomatik indirmek için ayar bulunmaktadır)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_08.png)

**10\. Ekran Koruyucunuzu Etkin Kullanın**

Bilgisayarınızı sahipsiz bırakmayın. Verilerinizin güvenliğini sağlamak için başında olmadığınız zaman kısa süre içinde devreye girecek ve ancak şifre ile devre dışı bırakılacak ekran koruyucu tanımlayın. (Elma-->System Preferences--> Desktop & Screen Saver)

**11\. Güvenlik Duvarınızı (Firewall) Etkin Hale Getirin**

Firewall'u açın ve durum denetimli (stateful) yapıda çalıştırın. Güvenlik duvarını bu şekilde çalıştırdığınızda siz bir bağlantı başlatmadıkça bilgisayarınıza dışarıdan erişim mümkün olmayacaktır.

(Elma--> System Preferences--> Security&Privacy--> Firewall sekmesi; Firewall on; Firewall options--> Block all incoming connections. Böylece durum denetimli güvenlik duvarı tanımlamış olursunuz.)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_09.png)

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_10.png)

**12\. Paylaşımlar**

Paylaşımlarınızı (Sharing) kontrol edin. Gereksiz paylaşımlardan kaçının ve kaldırın (Elma--> System Preferences --> Sharing). Bu sekme her bir servisi kontrol etmek ve gereksiz olanları devre dışı bırakmak tavsiye edilir.

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_11.png)

**13\. Firmware parolası tanımlama:**

Fire Vault ile diskinizde verilerinizi şifreliyorsunuz ama bu yine de bilgisayarınızın çalınması durumunda kötü niyetli bir kişinin USB disk ile bilgisayarı açıp tüm dosyaları silmesine ya da işletim sistemini baştan kurmasına engel olamazsınız. Firmware parolası tanımladığınızda, PC’lerdekinin aksine sadece olağan dışı bir yöntemle bilgisayarı açmaya çalıştığınızda parolayı soracaktır. Bilgisayar açılırken Apple logosu belirdiğinde Cmd+R tuşuna basarak, açılan ekranda Utilities --> Firmware Password Utility seçerek tanımlayabilirsiniz. Yanlız bunu tanımlarken çok dikkat edin, eğer parolayı unutursanız Apple Yetkili Servisini ziyaret etmeniz gerekebilir.

**14\. İki Adımlı Kimlik Doğrulama**

İki adımlı kimlik doğrulama tanımlanırsa ilave güvenlik katmanı sağlanmış olur. (İkinci adımdaki kimlik doğrulama bilgisi telefonunuza gelen bir kod olacaktır.) Apple’ın sayfasında iki adımlı kimik doğrulama ile ilgili bilgileri bulabilirsiniz.

**15\. Misafir Kullanıcı**

Guest (misafir) kullanıcı tanımlama: Eğer FileVault tanımlı ise, guest kullanıcı bilgisayarı şifre olmaksızın girebilir ve sadece Safari kullanabilir, çıkışta tüm verileri silinir. Misafir kullanıcının etkin olması çalıntı ya da kayıp durumunda bilgisayarınız açıldığında yerini tespit etmenize olanak verir (Elma--> System Preferences --> Users & Groups seçeneğinden).

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_12.png)

**16\. MAC’imi bul!**

Çalındığında ya da kaybettiğinizde bilgisayarınızın yerini tespit edebilmek için “Find My MAC” etkin hale getirin. (Elma--> System Preferences--> ICloud--> Find My MAC seçili olmalı)

**17\. Üçüncü Taraf Zararlı Yazılım Programı**

Zararlı yazılımları tespit edebilmek icin Anti Virus yazılımı kullanabilirsiniz. Örneğin BitDefender programının ücretsiz versiyonunu kurulabilirsiniz. (App Store’dan indirilebilirsiniz)

**18\. VPN Kullanın**

Eğer çok fazla halka açık ağlardan (kütüphane, kafeler, havaalanları, stüdyolar vs) bağlantı sağlıyorsanız, Internet üzerinden akan verilerin güvenliğini sağlamanız için özel sanal ağ (VPN / Virtual Private Network) kullanmanızı öneririz. (Elma --> System Preferences --> Network'ten sol kutucukta “+” işaretine basarak VPN kurulumu yapabilirsiniz) ODTÜ'nün VPN servisi bulunmaktadır ama bu servis üzerinden sadece yerel ağdaki servislere ulaşabiliriniz. [https://faq.cc.metu.edu.tr/tr/sss/mac-os-x-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim](https://faq.cc.metu.edu.tr/tr/sss/mac-os-x-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim) linkinden ODTÜ için kurulumu öğrenebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_13.png)

**19\. Yasal Yazılım Kullanın**

Yasadışı uygulama kurulumuna izin vermeyin. Warez kullanmayın. Warez kullanırsanız bilgisayarınıza istenmeyen kodların da kurulması da olanaklı hale gelir. Bilgisayarınıza kuracağınız dosyaları güvenliğinizi artırmak için App Store'dan ya da "tanımlı geliştiriciler“den indirip kurun. (Elma--> System Preferences--> Security&Privacy--> General sekmesinde “Allow apps downloaded” seçeneğini güvenli şekilde ayarlayın)

**20\. Verilerinizi Yedekleyin**

Bilgisayarınızdaki değerli verilerin olası istenmeyen bir durumda (çalınma, diskin fiziksel olarak bozulması vs) back up alabilirsiniz. (Elma --> System Preferences--> Time Machine).

![](https://faq.cc.metu.edu.tr/system/files/u2/apple_mac_14.png)

**21\. eduroam Kullanın**

ODTÜ yerleşkesinde kablosuz ağ bağlantısı için iki adet SSID yayını yapılmaktadır: ng2k ve eduroam. ng2k yayını MAC adresi tabanlı kimlik doğrulama ile çalışmaktadır ve açık bir ağdır. Hâlbuki eduroam ağı RADIUS tabanlı altyapı üzerinden 802.1x güvenlik standardını kullanır. Üstelik eduroam ağı ile ağa üye olan bütün üniversitelerde kablosuz ağ altyapısını kullanabilirsiniz. Ayrıntılar için [http://eduroam.metu.edu.tr](http://eduroam.metu.edu.tr/)

**Kaynaklar:**

**1.** [http://www.macworld.co.uk/feature/mac/22-ultimate-tricks-improve-mac-security-best-tips-3643100/](http://www.macworld.co.uk/feature/mac/22-ultimate-tricks-improve-mac-security-best-tips-3643100/)

**2.** [https://www.intego.com/mac-security-blog/15-mac-hardening-security-tips-to-protect-your-privacy/](https://www.intego.com/mac-security-blog/15-mac-hardening-security-tips-to-protect-your-privacy/)