[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kopyala-yapistir-ile-ekledigim-metin-uzerinde-duzeltme-yaptigim-halde-yazi-gorunumunu-istedigim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4886


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kopyala-yapistir-ile-ekledigim-metin-uzerinde-duzeltme-yaptigim-halde-yazi-gorunumunu-istedigim)

# Kopyala-yapıştır ile eklediğim metin üzerinde düzeltme yaptığım halde yazı görünümünü istediğim hale getiremiyorum, ne yapabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Yazının gövde kısmına ekleyeceğiniz bilgileri Notepad gibi şekilsel özellikleri ortadan kaldıran bir uygulamaya yapıştırıp oradan kopyalamak yolunu izleyebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.