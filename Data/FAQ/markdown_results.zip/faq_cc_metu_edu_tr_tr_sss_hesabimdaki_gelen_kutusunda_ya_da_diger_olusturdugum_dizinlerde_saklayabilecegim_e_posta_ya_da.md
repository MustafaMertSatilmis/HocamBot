[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/hesabimdaki-gelen-kutusunda-ya-da-diger-olusturdugum-dizinlerde-saklayabilecegim-e-posta-ya-da#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 6902


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/there-limit-my-account-inbox-directory-or-other-directories-i-have-created-e-mail-messages-or "Is there a limit of my account for the Inbox directory or the other directories I have created for the e-mail messages or the other files I would like to keep?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/hesabimdaki-gelen-kutusunda-ya-da-diger-olusturdugum-dizinlerde-saklayabilecegim-e-posta-ya-da "Hesabımdaki gelen kutusunda ya da diğer oluşturduğum dizinlerde saklayabileceğim e-posta ya da dosyaların bir sınırı var mı?")

# Hesabımdaki gelen kutusunda ya da diğer oluşturduğum dizinlerde saklayabileceğim e-posta ya da dosyaların bir sınırı var mı?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Kullanıcı hesabı sahiplerine merkezi sunucular üzerinde ayrılan disk alanına kota denir. ODTÜ kullanıcılarına dosya ve e-postaları için iki ayrı kota tanımlanmıştır. Hesabınızdaki gelen kutusunda ya da oluşturduğunuz diğer e-posta dizinlerde saklayabileceğiniz e-postalar [e-posta kotası](https://faq.cc.metu.edu.tr/tr/sss/kullanici-kotasi-ne-kadardir) ile; sunucu sistemler üzerindeki diğer dizinlerde oluşturulacak dosyalar ise [dosya kotası](https://faq.cc.metu.edu.tr/tr/sss/kullanici-kotasi-ne-kadardir) ile sınırlıdır.