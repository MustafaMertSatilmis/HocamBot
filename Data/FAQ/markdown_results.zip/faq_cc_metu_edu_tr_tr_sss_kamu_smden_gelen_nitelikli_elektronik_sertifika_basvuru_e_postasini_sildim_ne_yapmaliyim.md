[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nitelikli-elektronik-sertifika-basvuru-e-postasini-sildim-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-10-2020 **Görüntüleme:** 11188


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-deleted-certified-electronic-signature-e-signature-application-e-mail-kamu-sm-what-should-i-do "I deleted the Certified Electronic  Signature (E-signature) Application E-mail from Kamu SM. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kamu-smden-gelen-nitelikli-elektronik-sertifika-basvuru-e-postasini-sildim-ne-yapmaliyim "Kamu SM'den gelen Nitelikli Elektronik Sertifika (E-imza) Başvuru E-postasını sildim. Ne yapmalıyım?")

# Kamu SM'den gelen Nitelikli Elektronik Sertifika (E-imza) Başvuru E-postasını sildim. Ne yapmalıyım?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Kamu SM'den gelen Nitelikli Elektronik Sertifika başvuru e-postası yanlışlıkla silindiyse kurumumuzdan Kamu SM'ye bildirilen e-posta adresine sistem tarafından haftada 1 tane olmak üzere otomatik parola e-postası gönderilir. Bu süreyi beklemek yerine, kişiler kendilerine aşağıdaki adımları izleyerek tekrar e-posta gönderebilirler.

1. [www.kamusm.gov.tr](http://www.kamusm.gov.tr/) web aresinde ana sayfa ekranından **BAŞVURU** bölümünden, **NES Başvuru Erişim Parolası Gönder** tıklanır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u127225/screen_shot_2020-09-18_at_15.37.05.png)

2\. Açılan yeni sayfada kullanıcıya ait **T.C. Kimlik No bilgisi**ve **ODTÜ e-posta adresi** girilerek  yeni bir başvuru erişim parolası gönderimi sağlanabilir **.**