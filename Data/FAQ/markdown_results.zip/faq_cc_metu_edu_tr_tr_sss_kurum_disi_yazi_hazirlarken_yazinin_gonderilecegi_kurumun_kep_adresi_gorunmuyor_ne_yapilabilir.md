[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kurum-disi-yazi-hazirlarken-yazinin-gonderilecegi-kurumun-kep-adresi-gorunmuyor-ne-yapilabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-01-2020 **Görüntüleme:** 4292


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kurum-disi-yazi-hazirlarken-yazinin-gonderilecegi-kurumun-kep-adresi-gorunmuyor-ne-yapilabilir)

# Kurum dışı yazı hazırlarken yazının gönderileceği kurumun KEP adresi görünmüyor, ne yapılabilir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine bu bilgiyi iletmelisiniz. Gerekli işlem yapılacaktır.