[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeleri-nasil-goruntulerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6942


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeleri-nasil-goruntulerim)

# Üye olduğum tüm e-listeleri nasıl görüntülerim?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Bir kullanıcı öncelikle üye olduğu herhangi bir liste için o e-listenin ayarları ile ilgili değişikliklerin yapılabildiği sayfaya ( **[http://mailman.metu.edu.tr/mailman/listinfo/liste\_adi](http://mailman.metu.edu.tr/mailman/listinfo/liste_adi)**) girmelidir _(Bu web adresi liste kapsamında gönderilmiş her mesajın sonunda yer alır)._

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_03.jpg)

Bu sayfanın en alt bölümünde yer alan e-posta adresi bölümüne, bu e-listeye üye olmak için kullandığı e-posta adresini yazarak, Listeden çık veya seçeneklerimi düzenle isimli butona tıklamalıdır.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_04.jpg)

Eğer e-liste şifresi daha önceden girilmiş ise, aşağıdaki şekilde olduğu gibi e-liste üyelik ayarlarının değiştirilebildiği ekran görünecektir. Aksi durumda, e-liste şifresi kullanılarak giriş yapılmalıdır:

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_elist_05.jpg)

Üye olduğu tüm e-listeleri görüntülemek için ilgili sayfada orta kısımda yer alan " **Diğer metu.edu.tr üyelikleriniz**"  isimli bölümde yer alan "listele" butonunu tıklamaları gerekmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/mailman_faq_other_subscriptions.gif)