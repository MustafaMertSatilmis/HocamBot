[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-yazi-icin-cevapla-butonuna-basinca-yaziyi-kaybettim-nereden-ulasabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4948


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-yazi-icin-cevapla-butonuna-basinca-yaziyi-kaybettim-nereden-ulasabilirim)

# Bir yazı için "Cevapla" butonuna basınca yazıyı kaybettim, nereden ulaşabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Cevap oluşturma işleminden sonra oluşturacağınız yeni yazı onaylarınıza iş olarak düşmektedir. Onaylarınızdan ilgili sürece ulaşabilirsiniz.

Eski yazıyı görmek için geçmiş ekranını kullanabilirsiniz.

Bu işlemi yanlışlıkla yaptıysanız [Evrak Geri Al](https://faq.cc.metu.edu.tr/tr/sss/sonlandirdigim-evraki-nasil-geri-alabilirim) menüsünden sonlanan yazıyı tekrar onaylarınıza düşürebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.