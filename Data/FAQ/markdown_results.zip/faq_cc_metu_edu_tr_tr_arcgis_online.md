[Jump to navigation](https://faq.cc.metu.edu.tr/tr/arcgis-online#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-01-2022 **Görüntüleme:** 7424


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/arcgis-online "ARCGIS ONLINE")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/arcgis-online "ARCGIS ONLINE")

# ARCGIS ONLINE

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ARCGIS** **ONLINE** **—**

**_ARCGIS_** **_ONLINE_** _bir haritalama ve analiz çözümüdür._ _ArcGIS Online, haritaları, sahneleri, uygulamaları, katmanları, analitiği ve verileri kullanmanıza, oluşturmanıza ve paylaşmanıza olanak tanıyan işbirliğine dayalı bir web CBS'dir. ArcGIS Living Atlas of the World, ArcGIS uygulamaları ve öğe ekleyebileceğiniz bulut altyapısındaki içeriğe erişim elde edersiniz. Bu kapsamda web katmanları yayınlayabilir veya haritalar, uygulamalar ve sahneler oluşturabilirsiniz. ArcGIS Online, ArcGIS sisteminin bir parçası olarak kullanılabilir ve ArcGIS Pro’nun yeteneklerini genişletir._

**_ArcGIS Online ile yapabilecekleriniz:_**

- _Haritalar oluşturmak_
- _Haritaları ve uygulamaları paylaşmak_
- _İşbirliği yapmak_
- _Veri analizi yapmak_
- _Verilerinizle çalışmak_

* * *

**Hesap – Nasıl üye olurum?**

ArcGIS Online mevcut ArcGIS lisanslı yazılımı kapsamında sunulduğu için kullanıcıların hesap açma yetkisi bulunmamaktadır. Fakat ArcGIS Online kullanım talebi olan kullanıcılar aşağıda yer alan Bilişim Destek web sayfası aracılığıyla taleplerini iletebilirler. Hesabınız oluşturulduktan sonra tarafınıza gelecek maildeki linke 14 gün içerisinde tıklayıp hesap şifrenizi oluşturunuz. Daha sonra ArcGIS Online’da oturum açıp sağlanılan kaynaklara erişim sağlayabilirsiniz.

**Bilişim Destek:** [_https://bilisimdestek.metu.edu.tr/_](https://bilisimdestek.metu.edu.tr/)

**Hesap – Nasıl erişirim?**

ArcGIS Online’a erişmek için aşağıdaki linke tıklayınız ve açılan sayfada kullanıcı adı ve şifrenizi girerek oturum açınız.

**ArcGIS Online:** [_https://www.arcgis.com/home/signin.html_](https://www.arcgis.com/home/signin.html)

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *