[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 77233


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-e-mail-services-iphone-or-ipad "How can I use METU E-Mail Services with iPhone or iPad?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-e-posta-servisini-nasil-kullanabilirim "iPhone ya da iPad ile ODTÜ e-posta servisini nasıl kullanabilirim?")

# iPhone ya da iPad ile ODTÜ e-posta servisini nasıl kullanabilirim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

Phone ya da iPad ile e-posta okumak ve göndermek için merkezi e-posta sunucusu ayarlarını yapmanız gereklidir.

Bunun için, **Ayarlar > Mail, Kişiler, Takvimler** seçeneği ile açılan ekranda **Hesap Ekle** düğmesine dokunun.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone01_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone02_tr.jpg) |

"Hesap Ekle" ekranında **Diğer** seçeneğini seçip sonraki ekranda **Mail Hesabı Ekle** düğmesine dokunun.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone03_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone04_tr.jpg) |

"Yeni Hesap" ekranında adınızı, e-posta adresinizi ve parolanızı yazıp **Sonraki** düğmesine dokunun. E-posta adresiniz ve parolanız doğrulanana kadar bekleyin.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone05_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone06_tr.jpg) |

Mesajlarınıza ve sunucu üzerindeki klasörlerinize bilgisayar, telefon vb. birden fazla cihazdan ulaşmak isterseniz sunucu türünü "IMAP" seçin. Gelen posta sunucusu adını **imap.metu.edu.tr** olarak yazın. Gelen kutunuzu telefonunuza indirip mesajlarınıza yalnızca bu cihazdan ulaşmak isterseniz ve sunucu üzerindeki klasörlere erişmenize gerek yoksa sunucu türünü "POP" seçin. Gelen posta sunucusu adını **pop3.metu.edu.tr** olarak yazın.

Her iki seçenekte de giden posta sunucusu adını **smtp.metu.edu.tr** olarak yazın. Kullanıcı adı ve parolanızı her iki sunucu için de yazıp **Sonraki** düğmesine dokunun.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone07_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone08_tr.jpg) |

Kullanıcı adı ve parolanız doğrulanırken ekrana gelen uyarıyı **Sürdür** düğmesine dokunarak geçin. Sunucu türünü "IMAP" seçtiyseniz sonraki ekranda e-posta alıp gönderebilmek için "E-postalar" seçeneğinin açık konumda olduğundan emin olup **Kaydet** düğmesine dokunarak ayarlarınızı kaydedin.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone09_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone10_tr.jpg) |

Yaptığınız ayarları daha sonra görmek ya da değiştirmek isterseniz **Ayarlar > Mail, Kişiler, Takvimler** seçeneği ile açılan ekranda "Hesaplar" altında ilgili hesabı seçin. Sonraki ekranda e-posta adresinizin üzerine dokunun.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone11_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone12_tr.jpg) |

Giden posta sunucusu ayarlarını görmek için "Hesap" ekranında "Giden Posta Sunucusu" altındaki "SMTP" düğmesine dokunun. Sonraki ekranda "smtp.metu.edu.tr" adresi üzerine dokunduğunuzda sunucu ayarlarını görebilirsiniz. "SSL Kullan" seçeneği açık konumda, "Kimlik Doğrulama" türü **Parola** ve bağlantı noktası numarası **465** olmalıdır.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone13_tr.jpg) |  |  |

Gelen posta sunucusu ayarlarını görmek için "Hesap" ekranında "İleri Düzey" düğmesine dokunun. Gelen posta sunucusu bağlantı noktası numaraları IMAP için **993**, POP için **995** olmalıdır. Her iki seçenek için de "SSL Kullan" seçeneği açık konumda, "Kimlik Doğrulama" türü **Parola** olmalıdır.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone15_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_iphone16_tr.jpg) |