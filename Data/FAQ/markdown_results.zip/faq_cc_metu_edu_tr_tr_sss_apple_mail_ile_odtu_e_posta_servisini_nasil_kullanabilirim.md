[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/apple-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 04-06-2021 **Görüntüleme:** 9408


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-e-mail-services-apple-mail "How can I use METU E-Mail Services with Apple Mail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/apple-mail-ile-odtu-e-posta-servisini-nasil-kullanabilirim "Apple Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?")

# Apple Mail ile ODTÜ e-posta servisini nasıl kullanabilirim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

MAC bilgisayarınızda Apple Mail ile ODTÜ e-postalarınızı okuyabilmek ve e-posta gönderebilmek için aşağıdaki ayarları yapmanız gerekmektedir.

Öncelikle Apple Mail uygulamasını başlatınız.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail1.png)

_Eğer daha önce tanımlanmış bir e-posta hesabınız bulunmuyorsa,_ Apple Mail, Bir Mail hesabı sağlayıcısı seçmenizi isteyecektir. " **Başka bir Mail Hesabı**" seçeneği ile ilerleyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/macmail3.png)

Adınızı, eposta adresinizi ve parolanızı girerek **Sign In** / **Giriş Yap** düğmesine basınız.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail4.png)

Incoming / gelen ve outgoing / giden posta sunucu adreslerini aşağıdaki resimde görüldüğü şekilde giriniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail5.png)

Parolanız doğruysa Apple Mail bu hesabı Mail ve Notlar için kullanmak isteyip istemediğinizi soracaktır. Seçerek ilerleyiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail6.png)

Bitti / Done düğmesine bastıktan sonra e-posta mesajlarınız görüntülenecektir.

_Eğer Apple Mail'de önceden başka bir e-posta hesabı daha tanımlıysa,_ Posta / Mail menüsünden Hesaplar / Accounts seçeneğini seçtiğinizde gelen pencerede + işareti ile ODTÜ e-posta bilgilerinizi girebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail11.png)

**Eğer ODTÜ kullanıcı parolanızı değiştirdiyseniz,** parolanızı Apple Mail uygulamasında da güncellemeniz gerekmektedir. Bunun için aşağıdaki iki aşamayı takip edebilirsiniz.

1\. Posta / Mail menüsünden Tercihler / Preferences seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail7.png)

Hesaplar / Accounts sekmesine gidiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail8.png)

Sunucu ayarları / server settings bölümünde her iki parola kutusuna yeni parolanızı giriniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail9.png)

2\. Posta / Mail menüsünden Hesaplar / Accounts seçeneğini seçiniz ve açılan pencerede parolayı güncelleyiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/applemail11.png)