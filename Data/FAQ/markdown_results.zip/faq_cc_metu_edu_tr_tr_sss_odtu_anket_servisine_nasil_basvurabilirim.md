[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-basvurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6891


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-apply-metu-survey-service "How can I apply to the METU Survey Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisine-nasil-basvurabilirim "ODTÜ anket servisine nasıl başvurabilirim?")

# ODTÜ anket servisine nasıl başvurabilirim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

ODTÜ personeli iseniz merkezi sunucularda kullandığınız kullanıcı kodunuzu ve şifrenizi kullanarak [https://anket.metu.edu.tr/admin](https://anket.metu.edu.tr/admin) adresinden, _başvuru gerekmeksizin_ giriş yapıp, kullanabilirsiniz.