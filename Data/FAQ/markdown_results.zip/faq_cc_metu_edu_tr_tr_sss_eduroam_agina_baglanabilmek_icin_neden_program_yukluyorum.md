[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglanabilmek-icin-neden-program-yukluyorum#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7859


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/why-do-i-have-install-program-connecting-eduroam "Why do I have to install a program for connecting eduroam?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglanabilmek-icin-neden-program-yukluyorum "eduroam ağına bağlanabilmek için neden program yüklüyorum?")

# eduroam ağına bağlanabilmek için neden program yüklüyorum?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

Yeni kurulan eduroam kablosuz ağ sisteminde, güvenlik ön plandadır. Klasik kablosuz sistemlerinde ağ üzerinden iletişim yaparken bunun başkaları tarafından izlenmesi mümkün olabilmektedir. Bunun yapılamaması için kullanılabilen tek yöntem kullanılan şifreleme yönteminin karmaşıklığını artırmaktır. Eduroam kablosuz ağ sisteminde kullanıcı adı ve parolanızı ilk göndermeye başladığınız andan itibaren şifreli iletişim sağlanmaktadır. Bu şifreli iletişimin başlatılması için gerekli olan TTLS algoritması Windows içinde mevcut olmadığından, farklı bir program kullanmak zorundayız.

Eğer Windows 10 işletim sistemi kullanıyorsanız, bu şifreleme algoritması işletim sisteminde bulunduğu için ek bir uygulama kurmanıza gerek bulunmamaktadır.