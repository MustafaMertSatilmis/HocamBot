[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2022 **Görüntüleme:** 3403


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-forgot-my-metu-alumni-user-code-password-where-can-i-apply "I forgot my METU alumni user code password. Where can I apply?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim "ODTÜ Mezun E-posta kullanıcı koduma ait şifremi unuttum. Nereden öğrenebilirim?")

# ODTÜ Mezun E-posta kullanıcı koduma ait şifremi unuttum. Nereden öğrenebilirim?

[Mezun E-posta](https://faq.cc.metu.edu.tr/tr/groups/mezun-e-posta)

ODTÜ Mezun Kullanıcı Hesap Yönetimi [https://alumniaccount.metu.edu.tr/](https://alumniaccount.metu.edu.tr/ "alumniaccount.metu.edu.tr") sayfasından, kayıtlı şifre sıfırlama e-posta adresiniz (kurtarma e-posta adresi) varsa yeni şifre alabilirsiniz. Bunun için kayıtlı bir kurtarma e-posta adresiniz bulunmalıdır.

Kayıtlı bir kurtarma e-posta adresiniz varsa "Şifrenizi mi unuttunuz?" bağlantısına tıklayınız.

İlgili alanları doldurduktan sonra “e-posta gönder” e tıklayınız. Kurtarma adresinize gelen e-postadaki yeni şifre etkinleştirme bağlantısına tıklamanız gerekmektedir.

Şifrenizi hatırlıyor fakat kayıtlı bir kurtarma e-posta adresini henüz belirlemediyseniz, ODTÜ Kullanıcı Hesap Yönetimi sayfasına giriş yaptıktan sonra "Kurtarma E-postası belirle" linki ile kurtarma e-posta adresinizi kaydedebilirsiniz.

Bu işlemler sonrası kurtarma e-posta adresinizi ve şifrenizi dileğiniz zaman bu sistem üzerinden değiştirebilir veya sıfırlayabilirsiniz.