[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-iptal-edildiginde-icerisindeki-sanal-para-banka-kartima-ne-zaman-aktarilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-11-2021 **Görüntüleme:** 10443


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/when-money-smart-id-card-transferred-back-my-bank-card-if-smart-id-card-cancelled "When is the money in smart ID card transferred back to my bank card if the smart ID card is cancelled?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartim-iptal-edildiginde-icerisindeki-sanal-para-banka-kartima-ne-zaman-aktarilir "Akıllı kimlik kartım iptal edildiğinde içerisindeki sanal para banka kartıma ne zaman aktarılır?")

# Akıllı kimlik kartım iptal edildiğinde içerisindeki sanal para banka kartıma ne zaman aktarılır?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınız iptal edildiğinde sanal paranızın banka hesabınıza aktarılması için Kafeterya binasında bulunan muhasebe şefliğine giderek iade sürecini başlatmanız gerekmektedir. İade işleminiz ilgili birimlerin onayı ile gerçekleşmekte olup yaklaşık 15 iş günü içerisinde sonuçlanmaktadır.