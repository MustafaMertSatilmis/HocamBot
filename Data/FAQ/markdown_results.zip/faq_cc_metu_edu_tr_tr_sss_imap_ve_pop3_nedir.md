[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/imap-ve-pop3-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 12807


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-imap-and-pop3 "What is IMAP and POP3?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/imap-ve-pop3-nedir "IMAP ve POP3 nedir?")

# IMAP ve POP3 nedir?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

IMAP (Internet Message Access Protocol) ve POP3 (Post Office Protocol - Version 3) aralarında ufak farklar bulunan e-posta okuma servisleridir. Outlook Express ya da Netscape Messenger gibi e-posta istemcileri kullanıldığı zaman e-postalara kolaylıkla ulaşılmasını sağlamaktadır.

**POP3 Özellikleri:**

- E-postalar sabit diskte tutulur. Eğer isteniyorsa e-postaların bir kopyası sunucuda tutulabilir.


  - **Outlook Express**

    Araçlar (Tools) menüsünden Hesaplar (Accounts) seçeneği seçilir. İstenen hesabın özelliklerinden Gelişmiş (Advanced) sekmesi seçilir ve "Mesajın bir kopyasını sunucuda sakla (Leave a copy of messages on the server)" seçeneği işaretlenir.

  - **Mozilla Thunderbird**

    Araçlar (Tools) menüsünden Hesaplar (Accounts) seçilir. Seçenekeler (Settings) kısmındaki Sunucu Seçenekleri (Server Settings), "Mesajları sunucuda bırak (Leave messages on server)" şeklinde değiştirilir.

  - **Netscape Messenger**

     Araçlar (Tools) menüsünden "Posta ve Habergrubu Ayarları (Mail & Newsgroups Account Settings)" seçilir. Seçenekler (Settings) kısmındaki Sunucu Seçenekleri (Server Settings), "Mesajları sunucuda bırak (Leave messages on server)" seçeneği işaretlenir.
- Kullanıcı, e-postalarını hard diskine indirirken onları sunucudan silmek ya da silmemek konusunda seçim yapabilir.
- E-postalarınızı sunucuda tutmayı seçebilirsiniz, ancak e-postalarıınızı hard diskinizden silerken aynı zamanda sunucudan da silmek için gerekli ayarlar yapılmalıdır.
- Eğer sunucuda farklı dizinler yaratılırsa ve bu dizinlerde farklı e-postalar tutulursa bu dizinler hard diskte görüntülenemez.
**IMAP özellikleri:**

- E-postalar sunucuda tutulur.
- Sunucu üzerinde oluşturulan ya da sistemin yarattığı dizinlere ulaşılabilir


![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_2_1.jpg)