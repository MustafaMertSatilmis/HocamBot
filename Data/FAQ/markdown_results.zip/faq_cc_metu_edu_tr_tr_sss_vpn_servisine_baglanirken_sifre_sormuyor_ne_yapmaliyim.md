[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-baglanirken-sifre-sormuyor-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 11440


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-password-not-asked-when-i-try-connect-vpn-service-what-should-i-do "My password is not asked when I try to connect VPN Service. What Should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-baglanirken-sifre-sormuyor-ne-yapmaliyim "VPN Servisine bağlanırken şifre sormuyor. Ne yapmalıyım?")

# VPN Servisine bağlanırken şifre sormuyor. Ne yapmalıyım?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

VPN Servisine bağlanırken her seferinde kullanıcı adı ve şifre bilgilerinin girilmesi gerekmektedir. Eğer, cihazınızla VPN Servisine bağlanırken kullanıcı adı ve şifrenizi artık sormuyorsa, cihazınızdan bağlantı profili bilgilerini kaldırmanız gerekmektedir. Bunun için ilgili VPN istemcisinden profil bilgilerini temizleyebilir ve ya uygulamayı tekrar kurabilirsiniz.