[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-disindan-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 12333


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-central-server-systems-campus-0 "How can I connect to the Central Server Systems from off-campus?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucu-sistemlere-yerleske-disindan-nasil-baglanabilirim "Merkezi sunucu sistemlere yerleşke dışından nasıl bağlanabilirim?")

# Merkezi sunucu sistemlere yerleşke dışından nasıl bağlanabilirim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

ODTÜ yerleşkesi dışından **SSH Secure Shell Client** yazılımını kullanarak merkezi sunucu sistemlerden birine bağlanırken önce **External** (external.cc.metu.edu.tr) sunucusuna bağlanmanız gereklidir. External sunucusuna bağlandıktan sonra **ssh** komutuyla **Beluga** ya da **Orca** sunucularına bağlanabilirsiniz. Örneğin;

ssh beluga.cc.metu.edu.tr