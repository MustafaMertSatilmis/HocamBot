[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/uzerinde-vekalet-bulunan-bir-kisi-bir-baska-kisiye-vekalet-verirse-ilk-vekalet-veren-kisinin#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 19542


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/uzerinde-vekalet-bulunan-bir-kisi-bir-baska-kisiye-vekalet-verirse-ilk-vekalet-veren-kisinin)

# Üzerinde vekalet bulunan bir kişi bir başka kişiye vekalet verirse ilk vekalet veren kişinin vekaleti üçüncü kişiye aktarılıyor mu?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Aktarılmıyor.

Örnekle anlatmak gerekirse;

A kişisi B kişisine vekalet vermişti.

B kişisi de C kişisine vekalet verirse, A kişisinin vekaleti C kişisine aktarılmıyor. A kişisinin C kişisine ayrıca vekalet vermesi gereklidir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.