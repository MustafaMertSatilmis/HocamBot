[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/kota#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Kota

|     |
| --- |
| [Kotam doldu, ne yapmam gerekir?](https://faq.cc.metu.edu.tr/tr/sss/kotam-doldu-ne-yapmam-gerekir) |
| [Kullandığım disk alanını ve kotamın son durumunu nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/kullandigim-disk-alanini-ve-kotamin-son-durumunu-nasil-ogrenebilirim) |
| [Kullanıcı kotası ne kadardır?](https://faq.cc.metu.edu.tr/tr/sss/kullanici-kotasi-ne-kadardir) |

[![Subscribe to Kota](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/55/all/feed "Subscribe to Kota")