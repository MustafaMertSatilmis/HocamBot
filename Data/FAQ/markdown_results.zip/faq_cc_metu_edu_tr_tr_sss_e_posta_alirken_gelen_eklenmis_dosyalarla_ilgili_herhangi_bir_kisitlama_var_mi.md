[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-posta-alirken-gelen-eklenmis-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8960


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/are-there-any-limitations-attachments-incoming-e-mail "Are there any limitations for the attachments of incoming E-mail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-posta-alirken-gelen-eklenmis-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi "E-posta alırken gelen eklenmiş dosyalarla ilgili herhangi bir kısıtlama var mı?")

# E-posta alırken gelen eklenmiş dosyalarla ilgili herhangi bir kısıtlama var mı?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Merkezi e-posta sunucusu üzerinde tanımlı adresinize gelen e-postalarda eklenmiş dosyalar 25 MB'ı aşmamalıdır. Kullanıcı 25 MB'tan büyük bir mektubu yollamaya çalıştığı zaman, e-posta sunucusu bu mektubu reddeder. Kullanıcının kullandığı mektup gönderme programı bu konuda bir hata mesajı gösterir.