[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-devlet-uzerinden-evrak-dogrulama#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-09-2023 **Görüntüleme:** 5804


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-devlet-uzerinden-evrak-dogrulama)

# E-Devlet Üzerinden Evrak Doğrulama

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

EBYS'de hazırlanarak kurum dışına gönderilen evrakların geçerliliğinin E-Devlet üzerinden doğrulanabilmesi için gerekli entegrasyon çalışması tamamlanmış ve "Orta Doğu Teknik Üniversitesi Elektronik Belge Yönetim Sistemi Evrak Doğrulama" sayfası E-Devlet üzerinde [https://www.turkiye.gov.tr/odtu-ebys](https://www.turkiye.gov.tr/odtu-ebys) adresinden kullanıma açılmıştır.

Kurum dışı evrakları E-Devlet üzerinden doğrulamak için evrakların alt bölümünde bulunan doğrulama kodu ya da kare kod bilgilerinden birinin kullanılması yeterlidir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys_footer.png)

**1) "Evrak Doğrulama Kodu" ile doğrulama:** Bu yöntem ile evrak doğrulamak için öncelikle " [Orta Doğu Teknik Üniversitesi Elektronik Belge Yönetim Sistemi Evrak Doğrulama](https://www.turkiye.gov.tr/odtu-ebys)" sayfası açılır ve ilgili evrakın alt bölümünün orta kısmında yer alan evrak doğrulama kodu ve sayfada görünen "Güvenlik Resmi" bilgileri ilgili alanlara girilir. Bilgiler girilip "Sorgula" düğmesine tıklandıktan sonra, eğer geçerli bir evrak ise detaylı bilgileri (konu, tarih, sayı, imzacılar) aşağıdaki gibi ekranda görüntülecektir. Bu ekrandan ayrıca evrakın dosyasını ve EYP paketini indirmek de mümkündür.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys_edevlet.png)![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys_edevlet2.png)

**2) "Kare Kod" ile doğrulama:** Evrakın alt bölümünün sol kısmında yer alan kare kod, bir kare kod okuyucu cihaz ya da akıllı telefonlara yüklenebilecek kare kod okuyucu (QR code reader) uygulama ile okutulduktan sonra doğrulama sayfasına yönlendirme yapılır. Bu sayfa üzerinde istenen bilgiler girildikten sonra evrakla ilgili bilgilere ulaşılabilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys_karekod.png)![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys_karekod2.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.