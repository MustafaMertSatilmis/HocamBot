[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/koordinator-olarak-sorumlu-oldugum-bilgisayarin-ip-erisiminin-yeniden-acilmasi-icin-ne#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7360


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-reactivate-ip-access-computer-i-am-responsible-coordinator "What should I do to reactivate the IP access of a computer that I am responsible of as a coordinator?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/koordinator-olarak-sorumlu-oldugum-bilgisayarin-ip-erisiminin-yeniden-acilmasi-icin-ne "Koordinatör olarak sorumlu olduğum bilgisayarın IP erişiminin yeniden açılması için ne yapmalıyım?")

# Koordinatör olarak sorumlu olduğum bilgisayarın IP erişiminin yeniden açılması için ne yapmalıyım?

[Bölüm Koordinatörlüğü](https://faq.cc.metu.edu.tr/tr/groups/bolum-koordinatorlugu)

Bölüm/birim koordinatörü olarak sorumlu olduğunuz bilgisayardan birinin IP erişimi kısıtlandıysa IP erişimini açmak için [www.netregister.metu.edu.tr](http://www.netregister.metu.edu.tr/) adresine koordinatör yetkiniz olan ODTÜ kullanıcı adı ve şifrenizle giriş yapın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/1-affected_login.png)

Eğer sorumlu olduğunuz bir IP kısıtlanmışsa anasayfada **Restriction** isminde menü çıkmaktadır. Eğer herhangi bir IP kısıtlaması bulunmuyorsa bu menü görünmemektedir. Kısıtlamaları görmek için **Restriction** menüsüne tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/2-affected_menu.png)

Sonraki sayfada kısıtlanan IP ve MAC adresi listesini görebilirsiniz. Detayları görmek için **Details** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/3-affected_list.png)

Kısıtlanma sebebini ortadan kaldırdıysanız **Remove Restriction** düğmesine tıklayarak IP erişimini açabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/4-affected_remove.png)

Eğer **Remove** düğmesini göremiyorsanız BİDB ile görüşmeniz gereken ciddi bir durum olabilir. Bu durumda **[https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)** adresine ilgili kayıta ait IP ve MAC adreslerini de içeren bir vaka oluşturunuz.

Kısıtlamanın kaldırıldığına dair bilgilendirme mesajını aldıktan sonra IP erişimi açılacaktır. Bazı durumlarda ilgili cihazın ethernet kablosunu çıkarıp 5dk bekledikten sonra takmak gerekebilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/5-affected_removed.png)