[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-bankasi-araciligi-ile-nasil-bakiye-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-10-2022 **Görüntüleme:** 8671


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-bankasi-araciligi-ile-nasil-bakiye-yuklerim)

# Akıllı kartıma İş Bankası aracılığı ile nasıl bakiye yüklerim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

İş Bankası üzerinden akıllı kartınıza bakiye yüklemesi için İşcep, İnternet Şube veya ATM kullanabilirsiniz. İşcep ve İnternet şubesinden kredi kartı ve vadesiz hesap kullanarak yükleme yapabilirken, ATM üzerinden bunlara ek olarak nakit para ile bakiye yükleyebilirsiniz.

İşcep ve İnternet Şubesi için yükleme adımları;

**1.** Hesabınıza giriş yapınız ve ana menüye ulaşınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/iscep1.png)

**2.** Ana menüden Ödeme Yap bağlantısını seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/iscep2.png)

**3.** Eğitim Ödemeleri bağlantısını seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/iscep3.png)

**4.** Kurum Adı menüsünden "ODTÜ / SoliClub Akıllı Kart Bakiye Yükleme" seçeneğini seçiniz ve Devam butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/iscep5_1.png)

**5.** Gelen Ekranda tutar bilgisini giriniz ve ödeme kanalını seçiniz (vadesi hesap, kredi kartı) daha sonra devam butonuna basarak yüklemeyi tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/iscep5.png)