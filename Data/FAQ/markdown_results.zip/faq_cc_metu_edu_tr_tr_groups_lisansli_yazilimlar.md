[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Lisanslı Yazılımlar

Lisanslı yazılımlar web sayfasına [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/) adresinden erişilebilir.

|     |
| --- |
| [ABBYY](https://faq.cc.metu.edu.tr/tr/abbyy) |
| [ADOBE ACROBAT TARAYICI UZANTISI](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi) |
| [ADOBE YAZILIMLARINA ERİŞİM](https://faq.cc.metu.edu.tr/tr/adobe) |
| [ANSYS](https://faq.cc.metu.edu.tr/tr/ansys) |
| [ARCGIS DESKTOP](https://faq.cc.metu.edu.tr/tr/arcgis-desktop) |
| [ARCGIS ONLINE](https://faq.cc.metu.edu.tr/tr/arcgis-online) |
| [ARCGIS PRO](https://faq.cc.metu.edu.tr/tr/arcgis-pro) |
| [AUTODESK 3DS MAX DESIGN](https://faq.cc.metu.edu.tr/tr/autodesk-3ds-max-design) |
| [AUTODESK AUTOCAD](https://faq.cc.metu.edu.tr/tr/autodesk-autocad) |
| [AUTODESK AUTOCAD CIVIL 3D](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-civil-3d) |
| [AUTODESK AUTOCAD INVENTOR](https://faq.cc.metu.edu.tr/tr/autodesk-autocad-inventor) |
| [AUTODESK ECOTECT ANALYSIS](https://faq.cc.metu.edu.tr/tr/autodesk-ecotect-analysis) |
| [AUTODESK REVIT ARCHITECTURE](https://faq.cc.metu.edu.tr/tr/autodesk-revit-architecture) |
| [ÇEVRİMİÇİ DİLBİLGİSİ VE YAZIM DENETİMİ ARAÇLARI](https://faq.cc.metu.edu.tr/tr/spell-checking-tools) |
| [COMSOL](https://faq.cc.metu.edu.tr/tr/comsol) |
| [DEMOCREATOR](https://faq.cc.metu.edu.tr/tr/democreator) |
| [GAUSSIAN](https://faq.cc.metu.edu.tr/tr/gaussian) |
| [GRADESCOPE](https://faq.cc.metu.edu.tr/tr/gradescope) |
| [ISO DOSYALARINDAN (CD/DVD KALIPLARINDAN) YAZILIM KURULUMU NASIL YAPILIR?](https://faq.cc.metu.edu.tr/tr/iso-dosyalarindan-cd-dvd-kaliplarindan-yazilim-kurulumu-nasil-yapilir) |
| [MATHCAD](https://faq.cc.metu.edu.tr/tr/mathcad) |
| [MATHEMATICA](https://faq.cc.metu.edu.tr/tr/mathematica) |
| [MATLAB](https://faq.cc.metu.edu.tr/tr/matlab) |
| [MAXQDA](https://faq.cc.metu.edu.tr/tr/maxqda) |
| [MERKEZI LISANSLI YAZILIMLARDAN KIMLER, NASIL FAYDALANABILIR?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-lisansli-yazilimlardan-kimler-nasil-faydalanabilir) |
| [MICROSOFT 365](https://faq.cc.metu.edu.tr/tr/microsoft365) |

## Pages

- 1
- [2](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar?page=1 "Go to page 2")
- [sonraki ›](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar?page=1 "Go to next page")
- [son »](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar?page=1 "Go to last page")

[![Subscribe to Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/12/all/feed "Subscribe to Lisanslı Yazılımlar")