[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebys-uzerinden-tasit-istem-formunu-nasil-doldurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5606


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebys-uzerinden-tasit-istem-formunu-nasil-doldurabilirim)

# EBYS üzerinden taşıt istem formunu nasıl doldurabilirim?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

- EBYS'de oturum açınız.
- Sol menüden "Elektronik Formlar" seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/form.png)

- Açılan bölümden "Taşıt İstem Formu" seçeneğini seçiniz.
- Form üzerinde gerekli bütün açıklamalar bulunmaktadır. Formu dolurup "Gönder" düğmesine basınız.
- Doldurduğunuz formun hangi aşamada olduğunu geçmiş ekranınızdan ilgili evrakın akış tarihçesine ulaşarak takip edebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.