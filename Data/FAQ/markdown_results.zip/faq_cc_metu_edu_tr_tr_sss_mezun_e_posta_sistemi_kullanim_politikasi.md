[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mezun-e-posta-sistemi-kullanim-politikasi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2022 **Görüntüleme:** 7631


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mezun-e-posta-sistemi-kullanim-politikasi)

# Mezun E-posta Sistemi Kullanım Politikası

[Mezun E-posta](https://faq.cc.metu.edu.tr/tr/groups/mezun-e-posta)

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

ODTÜ Mezunlar Ofisi aracılığı ile Mezun Kart alan bir ODTÜ mezunu isteği doğrultusunda @alumni.metu.edu.tr uzantılı bir e-posta hesabı alabilir.

Mezun E-posta Hesabı alabilecek/alan kullanıcıların bilgileri ODTÜ Mezunlar Ofisi tarafından yönetilir.

Mezun E-posta Hesabı, ODTÜ Mezun Kart kullanımının aktif olduğu süresince kullanılabilecektir. ODTÜ Mezun Kartı herhangi bir sebeple kapatılan ya da askıya alınan kullanıcıların Mezun E-posta Hesapları da kapatılır ya da askıya alınır. ODTÜ Mezun Kartı geçerli olmayan kullanıcı @alumni.metu.edu.tr uzantılı e-posta hesabını kullanamaz.

Mezun E-posta Hesabı almak isteyen bir kullanıcı [https://mezun.metu.edu.tr/odtu-mezun-karti/](https://mezun.metu.edu.tr/odtu-mezun-karti/) sayfasında belirtilen şekilde @alumni.metu.edu.tr uzantılı e-posta adresi alabilir.

Mezun E-posta Hesabı oluştururken sistem kullanıcıya ad/soyad ile türetilen kullanıcı kodu seçimi sunar. Bunlar dışında kullanıcı kodu seçilemez. Bir kullanıcıya tahsis edilen kullanıcı kodu başka bir kullanıcıya verilmez.

Mezun E-posta Hesabı ile ODTÜ kullanıcı kodu farklı kavramlardır. ODTÜ kullanıcı kodu ile faydalanılan diğer hizmetler Mezun E-posta Hesabından bağımsızdır.

Mezun e-posta hesabı, kullanıcı başına 100 MB e-posta kapasitesi ile açılır. Kullanıcıların kotalarının dolması durumunda Mezun E-posta Hesaplarına gelecek olan e-postalar sistem tarafından reddedilecektir.

Ekler dahil her bir ileti en fazla 25 MB boyutunda olabilir.

Mezun E-posta Kullanıcı hesaplarına bir yedekleme hizmeti verilmemektedir. Silinen bir e-posta kullanıcının hesabına tekrar yüklenemez.

SPAM ya da zararlı içerik gönderği tespit edilen bir kullanıcının hesabı geçici olarak durdurulur. Parolası sıfırlanır. Bu konu ile ilgili kullanıcıya alternatif e-posta hesabı üzerinden bilgilendirme yapılır ve parolasını tekrar oluşturması istenir.

@alumni.metu.edu.tr uzantılı Mezun E-posta Hesabı [https://alumnimail.metu.edu.tr/](https://alumnimail.metu.edu.tr/) arayüzünden kullanılır. Bu arayüz dışında başka bir POP/IMAP servisi ile sisteme erişim yoktur.

Kullanıcılarla ilk iletişimi ODTÜ Mezunlar Ofisi yönetir. Mezunlar, kendilerine sağlanan mezun e-posta hizmetiyle ilgili soru ve sorunlarını [mezunkart@metu.edu.tr](mailto:mezunkart@metu.edu.tr) adresine iletir.

ODTÜ Mezun Eposta Sistemi, Bilişim Kaynakları Kullanım Politikaları belgesinde ( [http://bilisim-etigi.metu.edu.tr/](http://bilisim-etigi.metu.edu.tr/ "bilisim etigi")) belirtilen ilkelere göre işletilir.