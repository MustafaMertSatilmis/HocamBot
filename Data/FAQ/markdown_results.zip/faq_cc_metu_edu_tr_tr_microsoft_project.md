[Jump to navigation](https://faq.cc.metu.edu.tr/tr/microsoft-project#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 08-04-2022 **Görüntüleme:** 14784


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/microsoft-project "MICROSOFT PROJECT")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/microsoft-project "MICROSOFT PROJECT")

# MICROSOFT PROJECT

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT PROJECT** **2021** **—**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/microsoft-project#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/microsoft-project#aktivasyon)

* * *

**_\[1\] Personel için not:_**_Microsoft Project yazılımı sadece personelin kullanımına açıktır._

**_\[2\] Öğrenciler için not:_** _Microsoft Project yazılımını kullanabilmek için_ [_bu sayfada_](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware) _yer alan yönergeleri takip ederek Office 365 hizmetine metu.edu.tr uzantılı e-posta adresinizle kaydolunuz. Bu işlemden sonra ilgili yazılıma erişip kullanabilirsiniz._

**_\[3\] Windows kullanıcıları için not:_** _Kullanıcılarımız **“Project 2021”**_ _windows_ _sürümü aktivasyon işlemi için **“kms\_office2021\_client.bat”**_ _volume license_ _dosyasını lisanslı yazılımlar web sayfasından indirmeli ve dosyaya sağ tıklayarak **“Run as**_ **_administrator_** **_”_** _seçeneği ile çalıştırmalıdırlar. Bu işlemden sonra Microsoft Project Windows sürümü etkinleştirilmiş olmalıdır._

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“install_** **_”_**_butonuna tıklayarak kurulumu başlatınız. (Gerekiyor ise install_ _dosyasının üzerine sağ tıklayıp yönetici olarak çalıştırınız.)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_project_2021_step1.png)

**_ADIM-2_**

_Kurulum başladıktan sonra ekranda aşağıda yer alan iki pencere açılacaktır. Kurulum tamamlanana kadar bu pencereleri kapatmayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_project_2021_step2.1.png)

**_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_project_2021_step2.2.png)_**

**_ADIM-3_**

**_“Close”_**_butonuna tıklayarak kurulum işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_project_2021_step3.png)

**_ADIM-4 <<<AKTİVASYON>>>_**

_Bilgisayarınızda ofis yazılımlarının aktivasyon işlemini daha önceden yapmış iseniz kurulumdan sonra Project yazılımı arka planda aktivasyon işlemini gerçekleştirecektir._

_Aktivasyon ile ilgili sorun yaşıyorsanız Office yazılımı aktivasyon işlemini tekrarlayınız._

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *