[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yeni-bir-e-liste-basvurusunda-bulunmak-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 10693


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-apply-new-e-list "How can I apply for a new e-list?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yeni-bir-e-liste-basvurusunda-bulunmak-icin-ne-yapmaliyim "Yeni bir E-Liste başvurusunda bulunmak için ne yapmalıyım?")

# Yeni bir E-Liste başvurusunda bulunmak için ne yapmalıyım?

[Başvuru ile İlgili Sorular](https://faq.cc.metu.edu.tr/tr/groups/basvuru-ile-ilgili-sorular)

ODTÜ'de veya KKK'daki; tüm akademik/idari birimler ile öğrenci topluluk ve takımları çeşitli duyurularını yapmak ya da iç iletişim gereksinimleri için ODTU E-Liste servisi kapsamında Mailman altyapısında e-liste tanımlayabilirler.

ODTÜ'nün liste sunucusunda yeni bir liste yaratmak için  için [http://cc-form.metu.edu.tr/list/](http://cc-form.metu.edu.tr/list/) adresinde yer alan "Başvuru Formu" nu doldurarak başvurunuzu yapabilirsiniz.  Başvuru formuna ulaşabilmek için merkezi sunucular üzerinde tanımlı bir kullanıcı kodu ve şifresi gereklidir.  Sadece akademik ve idari personel merkezi sistemler üzerinde tanımlanmış kullanıcı kodları ve şifreleri ile bu forma ulaşabilir. Öğrenci Toplulukları/takımları adına ilgili topluluk/takımın danışmanı ya da yöneticisi başvuru yapabilir.

Bu formda bilgi alabilmek amacıyla açmak istediğiniz listenin adı, açıklaması, amacı ve liste teknik nitelikleri ile ilgili bazı bilgiler istenecektir.

Başvuru formunda belirtilen listenin adı; amacı ve konusu ile ilgili olmalıdır. Liste isim standartları uyarınca talep edilen listenin adı, başvuru sahibinin bağlı bulunduğu bölüm/birim EİS kodu (bölüm/birim için belirlenen ve bilişim sistemlerinde tanımlı kısa adı) ile başlamak durumundadır. İçeriği ya da yapısı gereği belli bir bölüm ya da birimden bağımsız e-liste başvuru talepleri Rektörlük onayıyla gerçekleştirilmektedir.

ODTÜ Elektronik Liste Sunucusu üzerinde liste açma işlemleri BİDB Enformatik Grubu tarafından yürütülmektedir. Listenin açılması Bilgi İşlem Daire Başkanlığı tarafından uygun görülürse liste yöneticisi bu konuda bilgilendirilecektir.

Genel veya bir kullanıcı kodu olarak kullanılması olasılığı olan isimler liste adı olarak belirtilmemelidir. Bu tarzda bir liste adı talep edildiği durumda, BİDB Enformatik Grubu duruma uygun olarak, talep edilen liste adının sonuna "-l" veya duruma göre başa ya da sona bazı eklemelerin yapılmasını önerebilir.

**Örnek:**

" _sinema_" isimli bir liste adı talep edildiği takdirde, bu isim yerine "sinema-l" veya "odtu-sinema" şeklinde bir liste adı kullanılması önerilir.

Liste tanımlamaları ile ilgili detaylı bilgiye [http://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler](http://faq.cc.metu.edu.tr/tr/groups/elektronik-listeler) adresinden ulaşabilirsiniz.