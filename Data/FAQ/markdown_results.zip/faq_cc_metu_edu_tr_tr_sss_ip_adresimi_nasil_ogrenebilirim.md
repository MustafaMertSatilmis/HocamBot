[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 8128


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-my-ip-address "How can I find out my IP address?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim "IP adresimi nasıl öğrenebilirim?")

# IP adresimi nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

IP adresinizi, [http://whatismyip.metu.edu.tr/](http://whatismyip.metu.edu.tr/) adresine giderek öğrenebilirsiniz.