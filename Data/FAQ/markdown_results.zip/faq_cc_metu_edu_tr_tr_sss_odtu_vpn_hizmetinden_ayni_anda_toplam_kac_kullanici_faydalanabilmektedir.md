[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmetinden-ayni-anda-toplam-kac-kullanici-faydalanabilmektedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 11416


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-many-total-users-can-use-metu-vpn-service-same-time "How many total users can use METU VPN Service at the same time?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmetinden-ayni-anda-toplam-kac-kullanici-faydalanabilmektedir "ODTÜ VPN Hizmetinden aynı anda toplam kaç kullanıcı faydalanabilmektedir?")

# ODTÜ VPN Hizmetinden aynı anda toplam kaç kullanıcı faydalanabilmektedir?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

ODTÜ VPN Hizmetinden aynı anda toplam 1000 kişi faydalanabilmektedir.