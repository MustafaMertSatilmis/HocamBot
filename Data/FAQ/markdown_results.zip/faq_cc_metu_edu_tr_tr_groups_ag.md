[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/ag#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Ağ

|     |
| --- |
| [meturoam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/meturoam) |
| [Uzak masaüstü bağlantısı yapamıyorum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/uzak-masaustu-baglantisi-yapamiyorum-ne-yapmaliyim) |
| [Windows 10 bilgisayarımdan eduroam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-10-bilgisayarimdan-eduroam-agina-nasil-baglanabilirim) |
| [Benim için oluşturulan misafir kullanıcı bilgisi ile meturoam ağına nasıl bağlanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/benim-icin-olusturulan-misafir-kullanici-bilgisi-ile-meturoam-agina-nasil-baglanabilirim) |
| [Cihazım ile kablosuz meturoam ağına bağlanırken sertifika uyarısı alıyorum. Ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/cihazim-ile-kablosuz-meturoam-agina-baglanirken-sertifika-uyarisi-aliyorum-ne-yapabilirim) |
| [eduroam şifremi unuttum, ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/eduroam-sifremi-unuttum-ne-yapmaliyim) |
| [meturoam şifremi unuttum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/meturoam-sifremi-unuttum-ne-yapabilirim) |
| [ODTÜ BİDB FTP Servisi var mıdır?](https://faq.cc.metu.edu.tr/tr/sss/odtu-bidb-ftp-servisi-var-midir) |
| [ODTÜ Bölüm/Birim Kablolu Ağ Bağlantı yönetimi nasıl yapılmaktadır?](https://faq.cc.metu.edu.tr/tr/sss/odtu-bolumbirim-kablolu-ag-baglanti-yonetimi-nasil-yapilmaktadir) |
| [ODTÜ dışından Kütüphane kaynaklarına nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-disindan-kutuphane-kaynaklarina-nasil-erisebilirim) |
| [ODTÜ yerleşke dışı bağlantı istatistikleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yerleske-disi-baglanti-istatistikleri-nelerdir) |
| [ODTÜ Yerleşke Omurgası (METU-NET) istatistikleri nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-yerleske-omurgasi-metu-net-istatistikleri-nelerdir) |
| [ODTÜ' de VOIP Hizmeti var mıdır?](https://faq.cc.metu.edu.tr/tr/sss/odtu-de-voip-hizmeti-var-midir) |
| [ODTÜ'de Alan Adı Servisi verilmekte midir?](https://faq.cc.metu.edu.tr/tr/sss/odtude-alan-adi-servisi-verilmekte-midir) |
| [Web önbellekleme nedir?](https://faq.cc.metu.edu.tr/tr/sss/web-onbellekleme-nedir) |

[![Subscribe to Ağ](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/2/all/feed "Subscribe to Ağ")