[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-listeye-uye-olmak-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8118


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-subscribe-list-turkish "What should I do to subscribe to a list? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-listeye-uye-olmak-icin-ne-yapmaliyim "Bir listeye üye olmak için  ne yapmalıyım?")

# Bir listeye üye olmak için ne yapmalıyım?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Üyelik basvurusu için **`http://mailman.metu.edu.tr/mailman/listinfo/abc-l/`** adresinde yer alan "abc-l Listesine Üyelik" bölümündeki formu doldurunuz. Başvurduğunuz listenin üyelik tercihlerine bagli olarak üyeliginiz gerçekleşir, onay sürecine girer ya da reddedilir.

Liste üyelik islemleri listelerin yöneticileri tarafından yürütülmektedir. Üyelik tercihleri de liste yöneticileri tarafından belirlenmektedir. Gerekli durumlarda **`abc-l-ownermetu.edu.tr`** adresinden söz konusu listenin yöneticisi ile iletisime geçebilirsiniz.

(Yukarıdaki URL ve e-posta adreslerinde geçen "abc-l" ifadesi yerine üye olmak istediğiniz listenin adını yazmalısınız.)