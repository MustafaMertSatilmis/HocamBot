[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-yuklu-yazilimlar-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-10-2024 **Görüntüleme:** 12061


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-list-software-available-pc-rooms "What is the list of Software Available in PC Rooms?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-yuklu-yazilimlar-nelerdir "PC Salonlarında Yüklü Yazılımlar Nelerdir?")

# PC Salonlarında Yüklü Yazılımlar Nelerdir?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

İşletimi Bilgi İşlem Daire Başkanlığı tarafından sağlanan bilgisayar salonları üniversite geneline hizmet vermekte olup kampüs lisans anlaşması ile satın alınan tüm yazılımlar bu salonlardaki bilgisayarlara yüklenmektedir. PC salonlarında Windows 10 işletim sistemi yüklü olup aşağıdaki lisanslı yazılımlar da kullanılabilmektedir:

- 7-Zip File Manager
- ABBYY FineReader 10 Corporate Edition
- Adobe CC
- Acrobat Reader DC
- ANSYS AIM 17.2
- ArcGlobe 10
- ArcMap 10
- ArcScene 10
- AutoCAD 2011 - English
- AutoCAD Civil 3D 2011 Imperial
- Autodesk 3ds Max Design 2011 64-bit
- Autodesk Design Review
- Autodesk Inventor Prof 2011
- Autodesk Revit Architecture 2011 x64
- Autodesk Vault 2011
- Bitvise SSH Client
- COMSOL Multiphysics 5.6
- Dev-C++
- DWG TrueView 2011
- Dytran 2018.0
- Ecotect Analysis 2011
- EQS 6.3 for Windows
- FileZilla Client
- Force 2.0
- GIMP 2
- Google Chrome
- IBM SPSS Statistics 28
- ImgBurn
- Jamovi 1.0.7.0
- JMP 12
- KompoZer
- LibreOffice 6.0
- Marc Mentat 2017.1.0
- Mathcad 15
- MATLAB R2021b
- Microsoft Office 2016
- Mozilla Firefox
- MPC-HC x64
- MSC Apex Fossa
- MSC Nastran 2018.1
- MSC Sinda 2017.1
- Nvu
- NX 11.0
- Patran 2018 (Classic)
- Picasa 3
- PuTTy
- RStudio
- R x64 3.5.0
- Safe Exam Browser
- Simufact Forming 15.0
- Wolfram Mathematica 12.3
- Workbench 19.2

Bu yazılımlar dışında kurulması istenen diğer yazılım talepleri bölümler tarafından (kurulum dosyaları ve lisans bilgileri ile birlikte) Bilgi İşlem Daire Başkanlığına yapılmalıdır. Dönem aralarında, bir sonraki dönem kullanılacak işletim sistemi ve yazılımlar PC salonlarına kurulmaktadır.