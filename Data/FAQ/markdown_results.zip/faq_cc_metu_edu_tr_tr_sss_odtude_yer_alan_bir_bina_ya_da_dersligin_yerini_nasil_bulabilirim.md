[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtude-yer-alan-bir-bina-ya-da-dersligin-yerini-nasil-bulabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8179


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-could-i-find-location-building-or-classroom-located-odtu "How could I find the location of a building or classroom located on ODTÜ?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtude-yer-alan-bir-bina-ya-da-dersligin-yerini-nasil-bulabilirim "ODTÜ’de yer alan bir bina ya da dersliğin yerini nasıl bulabilirim?")

# ODTÜ’de yer alan bir bina ya da dersliğin yerini nasıl bulabilirim?

[ODTÜ Harita Servisi](https://faq.cc.metu.edu.tr/tr/groups/odtu-harita-servisi)

ODTÜ Harita Servisi’ni kullanarak ODTÜ’de yer alan bir bina ya da dersliğin yerini harita üzerinde görüntüleyebilirsiniz.

Harita servisine [https://harita.odtu.edu.tr/](http://harita.odtu.edu.tr/) adresinden erişebilirsiniz.