[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrak-nasil-aranir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 6169


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-evrak-nasil-aranir)

# EBYS'de evrak nasıl aranır?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

İş Akış Yönetimi altında bulunan alanlardan durumuna göre evraklar bulunabilir.

Ayrıca **İş Akış Yönetimi -> Geçmiş** bölümünden üzerinde herhangi bir işlem yaptığınız tüm evrakları bulabilirsiniz. Bu bölümde aradığınız evrakı göremediyseniz [bu sayfadan](http://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum-nasil-gorebilirim) bilgi alabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/isakis.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.