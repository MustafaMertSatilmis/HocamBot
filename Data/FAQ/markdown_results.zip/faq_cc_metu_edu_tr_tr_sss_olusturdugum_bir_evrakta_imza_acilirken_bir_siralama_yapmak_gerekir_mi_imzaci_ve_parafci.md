[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-bir-evrakta-imza-acilirken-bir-siralama-yapmak-gerekir-mi-imzaci-ve-parafci#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 2491


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-bir-evrakta-imza-acilirken-bir-siralama-yapmak-gerekir-mi-imzaci-ve-parafci)

# Oluşturduğum bir evrakta imza açılırken bir sıralama yapmak gerekir mi? İmzacı ve parafçı eklerken belli bir sırada mı yazmak gerekiyor?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Yazılarda öncelikle paraflar tamamlanır. Paraflar tamamlandıktan sonra imzalar tamamlanır.

Paraflar ve imzalar kendi içlerinde eklendikleri sıraya göre onaycılara ulaşır. Bu nedenle birden fazla paraf veya imza olduğu durumlarda yetki olarak alttan üste doğru paraf ve imza eklenmesi yerinde olacaktır.

Örneğin 3 imzalı bir yazı olacak ve imzacılar bölüm başkanı, dekan ve rektör olacak ise imzacı olarak eklenme sırası:

1\. Bölüm Başkanı

2\. Dekan

3\. Rektör

şeklinde olmalıdır. Bu sayede evrak imzalanmak üzere ilk olarak bölüm başkanına, sonrasında dekana ve son olarak rektöre gidecektir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.