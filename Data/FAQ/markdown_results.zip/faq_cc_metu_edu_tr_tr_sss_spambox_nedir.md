[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/spambox-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 10241


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-spambox "What is SPAMBOX?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/spambox-nedir "SPAMBOX nedir?")

# SPAMBOX nedir?

[Spam](https://faq.cc.metu.edu.tr/tr/groups/spam)

Kullanıcı hesabınıza gelen e-postalar, merkezi e-posta sunucusu üzerinde çalışan bir filtreden geçirilmektedir. Bu filtre tarafından istenmeyen e-posta (spam) olarak işaretlenen e-postalar, otomatik olarak oluşturulan SPAMBOX adlı posta kutusuna yönlendirilir. E-posta dizinlerinizin altında bulunan SPAMBOX posta kutularınıza Horde, SquirrelMail ve pine e-posta istemcileriyle ya da IMAP üzerinden e-posta okuma programlarıyla ulaşabilirsiniz.

IMAP, Internet Message Access Protocol'un (İnternet Mesaj Erişim Protokolü) kısaltmasıdır. IMAP size e-posta iletilerinizi doğrudan e-posta sunucusu üzerinde yönetme olanağı sunar.

Kimi zaman normal bir e-posta da filtre tarafından istenmeyen e-posta olarak işaretlenebilmektedir, bu nedenle belli aralıklarla SPAMBOX posta kutunuzu kontrol etmeniz önerilir.

Boyut olarak belli bir büyüklüğü aşan SPAMBOX posta kutuları, otomatik olarak aynı dizin altına SPAMBOX.tarih biçiminde kaydedilir ve bu durum size e-postayla bildirilir. Taşınan SPAMBOX posta kutuları belli bir süre sonra otomatik olarak silinir.