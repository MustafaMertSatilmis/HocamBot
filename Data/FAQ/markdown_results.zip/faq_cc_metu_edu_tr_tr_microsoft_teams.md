[Jump to navigation](https://faq.cc.metu.edu.tr/tr/microsoft-teams#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-11-2023 **Görüntüleme:** 19703


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/microsoft-teams "MICROSOFT TEAMS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/microsoft-teams "MICROSOFT TEAMS")

# MICROSOFT TEAMS

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT** **TEAMS** **—**

**_Microsoft Teams_** _uygulamasını kullanabilmek için bir Microsoft hesabına ve üniversite personeli/öğrencisi olduğunuzu doğrulatmak için "metu.edu.tr" uzantılı ODTÜ hesabına ihtiyacınız vardır._

_Aşağıdaki adımları takip ederek yazılımın kayıt işlemlerini gerçekleştirebilirsiniz ve eğitim/yardım dokümanlarına erişebilirsiniz._

[**_KAYIT OLMA_**](https://faq.cc.metu.edu.tr/tr/microsoft-teams#kayit)

[**_EĞİTİM / YARDIM_**](https://faq.cc.metu.edu.tr/tr/microsoft-teams#egitim)

* * *

**_\[1\] Not:_**_Microsoft Teams_ _konusunda doğrudan_ _[Microsoft FastTrack Center](https://www.microsoft.com/tr-tr/fasttrack/microsoft-365/collaboration)_ _hizmeti yoluyla destek talep edilebilmektedir._

* * *

**_KAYIT OLMA_**

_Üniversite personeli/öğrencisi olduğunuzu doğrulatmak ve_ _Microsoft Teams_ _ile diğer yazılımlara ve hizmetlere erişebilmek için aşağıdaki adımları takip ediniz._

1. _[https://www.microsoft.com/en-us/education/products/office](https://www.microsoft.com/en-us/education/products/office) adresine gidiniz ve_**_"Enter your school email address"_** _yazısı altındaki alana **metu.edu.tr** uzantılı e-posta adresinizi giriniz._


2. _ODTÜ e-posta adresinize gelecek mesajdaki doğrulama kodu ile üyelik işlemlerini tamamlayınız._

3. _Açılan sayfadaki talimatları takip ediniz. Alternatif e-posta ve/veya telefon numarası doğrulama işlemi tamamlandıktan sonra üyeliğiniz tamamlanacaktır._

_ODTÜ e-posta adresiniz ile Microsoft Office 365 hesabınızı oluşturduktan sonra_ _[**Microsoft Teams**](https://teams.microsoft.com/)_ _uygulaması da erişilebilir olacaktır._

_**İndir >>** [Teams for work or school](https://www.microsoft.com/en-ca/microsoft-teams/download-app)_

**_EĞİTİM / YARDIM_**

_Microsoft_ _Teams_ _uygulamasının kullanımı konusunda aşağıdaki dokümanlar incelenebilir._

1. [Microsoft Teams'e giriş](https://faq.cc.metu.edu.tr/system/files/u16319/ek3_-_microsoft_teams_kilavuzu.pdf)
2. [Microsoft Teams içerisinde sınıf oluşturma ve kullanma](https://faq.cc.metu.edu.tr/system/files/u16319/ek4_-_microsoft_teams_edu_quick_start.pdf)

_Microsoft Teams_ _ile ilgili oluşturulmuş aşağıdaki yardım videolarından da faydalanılabilir._

**A. Microsoft** **Teams** **Kullanarak Sınıf ve Ödev Kurulumu**

1. [Microsoft Teams kullanılarak yeni bir sınıf nasıl oluşturulur?](https://youtu.be/pNWhR61eU9Y)
2. [Microsoft Teams kullanarak öğrencilere nasıl ödev atanır?](https://youtu.be/YmmswrQSKgU)

**B. Çevrimiçi Olarak Bir Sınıf Oluşturmak İçin Microsoft** **Teams** **Kullanımı**

1. [Eğitim içeriğini göndermek için Share seçeneği nasıl kullanılır?](https://support.office.com/tr-tr/article/share-content-in-a-meeting-in-teams-fcc2bf59-aecd-4481-8f99-ce55dd836ce8)
2. [Eğitimi interaktif yapmak için Whiteboard nasıl kullanılır?](https://support.office.com/tr-tr/article/whiteboard-in-a-teams-meeting-d9210aa2-876a-40f0-8ca0-5deb2fc11ca6)
3. [Yeniden oynatmak için ve kendi bilgi tabanınız için toplantı nasıl kaydedilir?](https://support.office.com/tr-tr/article/record-a-meeting-in-teams-34dfbe7f-b07d-4a27-b4c6-de62f1348c24)
4. [Kaydedilen toplantıların katılımcı listesi nasıl alınır?](https://docs.microsoft.com/en-us/microsoftteams/teams-analytics-and-reports/meeting-attendance-report)

**C. Geniş Katılımlı Seminerler İçin Microsoft** **Teams** **Live** **Events** **Kurulumu**

1. [Bir canlı etkinlik nasıl planlanır ve programlanır?](https://support.office.com/tr-tr/article/video-plan-and-schedule-a-live-event-f92363a0-6d98-46d2-bdd9-f2248075e502?ui=en-US&rs=en-US&ad=US)
2. [Bir canlı etkinliğe nasıl katılınır?](https://support.office.com/tr-tr/article/video-attend-a-live-event-d837ad8d-ce34-44d0-9744-9beb50e943ac)
3. [Soru-Cevap kısmı nasıl yönetilir?](https://support.office.com/tr-tr/article/video-moderating-a-q-a-4984e582-8c66-4ea3-aaaf-d93cf62e1b76)

**Faydalı Linkler;**

[Microsoft Teams video eğitimi](https://support.microsoft.com/tr-tr/office/microsoft-teams-video-e%C4%9Fitimi-4f108e54-240b-4351-8084-b1089f0d21d7)

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *