[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gmail-hesabima-odtu-e-posta-adresimi-nasil-eklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-10-2021 **Görüntüleme:** 113724


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-add-my-metu-e-mail-address-gmail "How can I add my METU e-mail address to Gmail?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gmail-hesabima-odtu-e-posta-adresimi-nasil-eklerim "Gmail hesabıma ODTÜ e-posta adresimi nasıl eklerim?")

# Gmail hesabıma ODTÜ e-posta adresimi nasıl eklerim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

- mail.google.com adresine giriniz ve kullanıcı adınızla şifrenizi girerek oturum açınız.
- Sağ üstteki dişli çark simgesine tıklayınız. Altta açılan menüden Ayarlar’a tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr1.png)

- Açılan sayfada üstteki menü sekmesinden Hesaplar ve İçe Aktarma İşlemi sekmesine tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr2.png)

- Açılan sayfada Diğer hesaplardaki postaları kontrol et bölümünün sağındaki Posta hesabı ekle butonuna tıkayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr3.png)

- Yeni bir sekme açılacaktır. Açılan sekmede ilgili yere odtü mail adresinizi yazınız. Yazdıktan sonra Sonraki butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr4.png)

- Sonraki sayfada, Diğer hesabımdaki e-postaları içe aktar(POP3) seçeneğini tıklatıp Sonraki butonuna basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr5.png)

- Sonraki ekranda gerekli bilgileri doldurunuz.

1. **Kullanıcı adı: e\*\*\*\*\*\* şeklinde doldurunuz.** Eposta adresiniz olarak kullanılan ad.soyad kombinasyonu şeklinde yazmayınız ve @metu.edu.tr uzantısını eklemeyiniz.
2. Şifre: Metumail şifrenizi giriniz.
3. POP Sunucusu: pop3.metu.edu.tr
4. Bağlantı noktası: 995
5. Postaları alırken her zaman güvenli bağlnatı (SSL) kullan seçeneğini işaretleyiniz.
6. Alınan iletinin bir kopyasını sunucuda bırak seçeneğini işaretlemeniz önerilir. (İşaretlemediğiniz takdirde metu mail adresinize gelen e-postaların hepsi Gmail’e taşınabilir.)
7. Diğer seçenekleri kendi tercihlerinize göre işaretleyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr6.png)

- Posta hesabınız eklenmiştir. Artık ODTÜ e-posta adresinize gelen mailleri Gmail’den görebilirsiniz. Eğer Gmail üzerinden ODTÜ e-posta adresini kullaranak e-posta göndermek istemiyorsanız, Hayır şeçeneğine tıklayıp Bitir butonuna basınız. Eğer Gmail üzerinden ODTÜ e-posta adresini kullaranak mail göndermek istiyorsanız, Evet, mail adresimden posta gönderebilmek istiyorum butonuna tıklayın. Devam etmek için Sonraki>> butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr7.png)

- Sonraki sayfada ilgili yere adınızı yazınız. Eğer takma ad kullanmak istiyorsanız Takma ad olarak kullan seçeneğine tıklayınız. Sonraki adım>> butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr8.png)

- Sonraki sayfada ilgili boşlukları doldurunuz.

1. SMTP Sunucusu: smtp.metu.edu.tr
2. Bağlantı noktası: 587
3. Kullanıcı adı: Metumail kullanıcı adınızı yazın. (e\*\*\*\*\*\*)
4. 4\. Şifre: Metumail şirenizi yazın.
5. 5\. TLS ile güvenli bağlantı seçeneğini tıklayınız.

Bilgileri doğru bir şekilde girdiğinizden emin olduğunuzda, Hesap Ekle>> butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr9.png)

- Bir sonraki adımda onay işlemini yapmanız gerekmektedir. Bunun için bağlamak istediğiniz ODTÜ e-posta adresininize bir e-posta gelmiş olması gerekmektedir. Dilerseniz o e-postadaki bağlantıya tıklayarak onayı gerçekleştirebilirsiniz veya o e-postada size gönderilen onay kodunu açılan sayfada giriniz. Ardından Doğrula butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gmail_tr10.png)

- İşleminiz tamamlanmıştır.