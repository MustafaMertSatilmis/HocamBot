[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/android-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2020 **Görüntüleme:** 63152


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-vpn-service-my-android-device "How can i use METU VPN Service on my Android device?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/android-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim "Android yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?")

# Android yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

ODTÜ VPN hizmeti ile birlikte, mensup ve öğrencilerimiz yerleşke dışında bulundukları sürelerde kullandıkları kişisel bilgisayarlara ya da mobil cihazlara kuracakları küçük bir paket program vasıtasıyla (VPN Client), üniversitemiz yerleşke içi ağ kaynaklarına erişebileceklerdir.

Önemli Uyarı: VPN üzerinden bağlanan kullanıcılarımızın bağlantı hızları kullanıcı başına 8 Mbps olarak şekillendirilmektedir. Bu nedenle VPN bağlantısına ihtiyacınız kalmadığı durumlarda VPN bağlantınızı sonlandırmanızı öneririz.

Android işletim sistemi yüklü cihazınızla VPN hizmetini kullanabilmeniz için:

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/1_0.png)

"Play Store" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/2_0.png)

Arama alanına "Aruba Via" yazınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/3_0.png)

"Install" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/4_0.png)

"Accept" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/5_0.png)

"Open" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/6_0.png)

"Aruba Via" dokununuz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/7_0.png)

Gelen giriş ekranında "Server URL" alanına "border.metu.edu.tr" yazınız. Metu "kullanıcı kodu" ve "şifre" giriniz. "Login" dokununuz.

![Profile Selection](https://faq.cc.metu.edu.tr/system/files/u21699/profile_page.png)

**default** profili seçiniz.

![](https://faq.cc.metu.edu.tr/system/files/u21699/android1_0.png)

"VPN" bağlantısını sağa kaydırarak açınız.

![](https://faq.cc.metu.edu.tr/system/files/u21699/android2_0.png)

"VPN" bağlantısı hazırdır.