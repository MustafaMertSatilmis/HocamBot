[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirdim-yeni-kimligimi-kullanima-acmam-gerekir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2021 **Görüntüleme:** 9358


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-changed-my-smart-id-card-do-i-have-reactivate-my-new-id-card "I have changed my Smart ID card. Do I have to reactivate my new ID card?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirdim-yeni-kimligimi-kullanima-acmam-gerekir-mi "Akıllı kimlik kartımı değiştirdim. Yeni kimliğimi kullanıma açmam gerekir mi?")

# Akıllı kimlik kartımı değiştirdim. Yeni kimliğimi kullanıma açmam gerekir mi?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Hayır. Yeni kimliğiniz sisteme tanımlı şekilde teslim edilmektedir. Kartınızı alır almaz kullanmaya başlayabilirsiniz.