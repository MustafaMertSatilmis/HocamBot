[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 19837


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-download-all-my-e-mails-horde "How can I download all of my e-mails with Horde?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim "Horde ile tüm e-postalarımı nasıl indirebilirim?")

# Horde ile tüm e-postalarımı nasıl indirebilirim?

[Dosya Transferi](https://faq.cc.metu.edu.tr/tr/groups/dosya-transferi)

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

Horde kullanarak bir posta kutusundaki tüm epostaları tek bir dosya ile bilgisayarınıza indirebilirsiniz. Bunun için horde web uygulamasına DİNAMİK modda giriş yaptıktan sonra sol tarafta listelenen posta kutularından indirmek istediğinize sağ tıklayarak Export / Dışa aktar seçeneğini işaretleyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/disaaktar1.png)

Ekrana gelecek pencerede "Download into a MBOX file" seçeneğini seçerek OK tuşuna basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/disaaktar3.png)

Horde web uygulamasını TEMEL modda kullanıyorsanız, YENİ İLETİ düğmesinin altındaki Dizinler bağlantısı ile posta kutularınızı listeleyiniz, indirmek istediğiniz posta kutusunu işaretledikten sonra "İşlem Seç" menüsündeki İndir seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/indir.png)

Ayrıca Thunderbird, Outlook gibi eposta okuma programları veya gmail, hotmail, vb. web servislerine de ODTÜ eposta adresinizi ekleyebilir, eposta mesajlarınızı kopyalayabilirsiniz. Ayrıntılı bilgi için [http://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari](http://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari) adresindeki bağlantıları inceleyebilirsiniz.