[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisiminin-yeniden-acilmasi-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 12474


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-reactivate-ip-access-my-computer "What should I do to reactivate the IP access of my computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisiminin-yeniden-acilmasi-icin-ne-yapmaliyim "Bilgisayarımın IP erişiminin yeniden açılması için ne yapmalıyım?")

# Bilgisayarımın IP erişiminin yeniden açılması için ne yapmalıyım?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

Bilgisayarınızın IP erişimi kısıtlandıysa öncelikle [www.netregister.metu.edu.tr](http://www.netregister.metu.edu.tr/)-\> Restiriction menüsünde görebileceğiniz kapatılma sebebini ortadan kaldırmalısınız.

Ağ bağlantısında IP-MAC eşleşmesi kullanılan bazı bölümler, yurtlar bölgesi ve ODTÜ kablosuz ağında IP erişiminizi açmak için [www.netregister.metu.edu.tr](http://www.netregister.metu.edu.tr/) adresine ODTÜ kullanıcı adı ve şifrenizle giriş yapın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/screenshot_from_2014-04-08_11_44_01.png)

Eğer kullanıcı adınıza kayıtlı bir IP kısıtlanmışsa ekranda görüntülenen **Restriction(s)** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/screenshot_from_2014-04-08_12_10_56.png)

Sonraki sayfada kısıtlanan MAC adresini görebilirsiniz. Detayları görmek için **Details** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/screenshot_from_2014-04-08_12_11_18.png)

Kısıtlanma sebebini ortadan kaldırdıysanız **Remove Restriction** düğmesine tıklayarak IP erişimini açabilirsiniz. Bu işlemi aynı gün içinde sadece bir kez yapabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/screenshot_from_2014-04-08_12_11_26.png)

Eğer **Remove Restriction** düğmesini göremiyorsanız BİDB ile görüşmeniz gereken ciddi bir durum olabilir. Bu durumda **[https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)** adresine kısıtlama yapılan MAC adresinizi de içeren bir vaka oluşturunuz.

Kısıtlamanın kaldırıldığına dair bilgilendirme mesajını aldıktan sonra IP erişiminiz açılmıştır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/screenshot_from_2014-04-08_12_11_34.png)