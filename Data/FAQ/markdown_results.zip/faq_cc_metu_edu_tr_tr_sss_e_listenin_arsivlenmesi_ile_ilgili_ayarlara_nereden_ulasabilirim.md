[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-listenin-arsivlenmesi-ile-ilgili-ayarlara-nereden-ulasabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 8694


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-are-settings-keep-archive-list "What are the settings to keep an archive of the list?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-listenin-arsivlenmesi-ile-ilgili-ayarlara-nereden-ulasabilirim "E-listenin arşivlenmesi ile ilgili ayarlara nereden ulaşabilirim ? ")

# E-listenin arşivlenmesi ile ilgili ayarlara nereden ulaşabilirim ?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

**(a)** Listenin arşivinin olması istenmiyorsa: _Arşivleme Seçenekleri_ > _Mesajlar arşivlensin mi?_ ayarı _**Hayır**_ olarak seçilir.

**(b)** Arşivi olsun ama sadece liste üyeleri tarafından görünsün isteniyorsa:

**(b1)** _Arşivleme Seçenekleri_ > _Mesajlar arşivlensin mi?_ ayarı _**Evet**_ olarak seçilir.

**(b2)** _Arşivleme Seçenekleri_ > _Arşiv dosyası genel kullanım için mi yoksa özel kullanım için mi arşivlenecek?_ ayarı _**Evet**_ olarak seçilir.