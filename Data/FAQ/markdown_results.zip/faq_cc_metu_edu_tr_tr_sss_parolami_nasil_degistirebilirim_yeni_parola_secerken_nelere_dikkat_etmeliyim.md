[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/parolami-nasil-degistirebilirim-yeni-parola-secerken-nelere-dikkat-etmeliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-02-2023 **Görüntüleme:** 55483


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-change-my-password-what-should-i-beware-picking-new-password "How can I change my password? What should I beware of in picking a new password?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/parolami-nasil-degistirebilirim-yeni-parola-secerken-nelere-dikkat-etmeliyim "Parolamı nasıl değiştirebilirim? Yeni parola seçerken nelere dikkat etmeliyim?")

# Parolamı nasıl değiştirebilirim? Yeni parola seçerken nelere dikkat etmeliyim?

[Parola](https://faq.cc.metu.edu.tr/tr/groups/parola)

Merkezi Sunucular üzerinde bulunan kullanıcı kodunuzun parolasını değiştirmek için:

**Kullanıcı Hesap Yönetimi Sayfasından:**

Kullanıcı Hesap Yönetimi sayfasına; [https://useraccount.metu.edu.tr](https://useraccount.metu.edu.tr/) adresinden mevcut parolanızla giriş yaptıktan sonra "Parola Değiştir" düğmesine tıklayarak kullanıcı kodu parolanızı değiştirebilirsiniz.

**Kullanıcılarımız parolalarını aşağıdaki kurallara göre oluşturmalıdır:**

**Parolada bulunması gereken unsurlar:**

- Parola en az 10, en çok 25 karakter olmalıdır.
- Parola en az bir büyük harf (ABCD….Z) içermelidir.
- Parola en az bir küçük harf (abcd…z) içermelidir.
- Parola en az bir rakam (1234567890) içermelidir.
- Parola Q klavyedeki tüm özel karakterlerden (?\*!^...%) en az bir tanesini içermelidir.

**Parolada bulunmaması gereken unsurlar:**

- Parola boşluk karakteri içeremez.
- Parola 1900’lü veya 2000’li yılları içeremez. (1978, 1999, 2001 vb.)
- Parola 4 ya da daha fazla karakterli ardışık sayı içeremez. (1234, 2345, 5678 vb.)
- Parola Türkçeye özgü karakterleri içeremez. (ç, ğ, İ, ö, ş, ü…)
- Parola ASCII karakteri olmayan karakter içeremez. (ä, é, Ý, Ð, Π vb.)
- Parola tamamı büyük ya da tamamı küçük harf olan kolay tahmin edilebilir sözcük veya sözlük sözcüğü içeremez.
- Yeni parola, son 5 parola ile aynı olamaz.

Örnek Parolalar:

- Polutk836\*
- Dem70:ka2b
- A2K/mReD48cZ!4
- 2F,646(wtgRdN4#kL
- EO\*A(/5ybh;pTq3uRw
- g1>4YjT5r3jlmZjJGU4
- o)5aDA-9e2xNWYz?8cyMzV1Zr