[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/anket-servisi-ile-anonim-yanitlarin-kime-ait-oldugu-bilinmeyen-veya-anonim-olmayan-yanitlarin#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 9492


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-form-anonymous-whose-attendants-are-not-known-and-non-anonymous-whose-attendants-are-known "Can I form anonymous (whose attendants are not known) and non-anonymous (whose attendants are known), or open to all/specific category surveys by using the METU Survey Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/anket-servisi-ile-anonim-yanitlarin-kime-ait-oldugu-bilinmeyen-veya-anonim-olmayan-yanitlarin "Anket servisi ile anonim (yanıtların kime ait olduğu bilinmeyen) veya anonim olmayan (yanıtların kime ait olduğu bilinen) ya da herkese açık/sadece belli kişilere açık anketler oluşturabilir miyim?")

# Anket servisi ile anonim (yanıtların kime ait olduğu bilinmeyen) veya anonim olmayan (yanıtların kime ait olduğu bilinen) ya da herkese açık/sadece belli kişilere açık anketler oluşturabilir miyim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Anketi oluştururken amacınıza uygun olarak çeşitli erişim seçeneklerini seçebilirsiniz. ODTÜ Anket Servisi anonim, anonim olmayan, herkese açık veya dışa erişimi kapalı anketler oluşturmanıza olanak vermektedir. Bu seçeneklere "Anket Ayarları" menüsünde yer alan "Katılımcı Ayarları" seçeneğini kullanarak erişebilirsiniz.