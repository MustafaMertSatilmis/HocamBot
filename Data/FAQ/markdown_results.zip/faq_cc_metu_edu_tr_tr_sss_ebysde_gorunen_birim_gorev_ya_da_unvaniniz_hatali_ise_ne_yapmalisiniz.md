[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gorunen-birim-gorev-ya-da-unvaniniz-hatali-ise-ne-yapmalisiniz#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5769


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gorunen-birim-gorev-ya-da-unvaniniz-hatali-ise-ne-yapmalisiniz)

# EBYS'de görünen birim, görev ya da unvanınız hatalı ise ne yapmalısınız?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS'de görünen ve hatalı oluğunu düşündüğünüz bilgilerinizin düzeltilmesi için, [Personel Daire Başkanlığındaki ilgili Özlük Müdürlüğüne](http://pdb.metu.edu.tr/tr/iletisim) başvurmanız gerekmektedir. Orada yapılan değişiklikler EBYS'ye otomatik olarak yansımaktadır.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.