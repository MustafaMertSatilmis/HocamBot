[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-bilgilerimi-dogru-girmeme-ragmen-baglanamiyorum-sorun-ne-olabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 28602


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-cannot-connect-vpn-service-even-if-i-entered-my-user-code-and-password-correctly-what-could-be "I cannot connect VPN Service even if I entered my user code and password correctly. What could be the problem?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-bilgilerimi-dogru-girmeme-ragmen-baglanamiyorum-sorun-ne-olabilir "VPN Servisine bilgilerimi doğru girmeme rağmen bağlanamıyorum. Sorun ne olabilir? ")

# VPN Servisine bilgilerimi doğru girmeme rağmen bağlanamıyorum. Sorun ne olabilir?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

Öncelikle kullanıcı adı ve şifrenizi doğru girdiğinizden emin olmak için [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/) adresinden bilgilerinizin doğruluğu kontrol ediniz. İsterseniz bu sayfadan hesabınız için kurtarma e-postası tanımlayabilirsiniz. Kullanıcı adı ve şifreniz ile ilgili bir problem görünmüyorsa, VPN istemcisinin profil ayarı güncellenmiş olabilir. Böyle bir durumda, cihazınızdaki kayıtlı profili kaldırıp veya VPN programını tekrar kurup deneyebilirsiniz. Problemin devam etmesi durumunda [http://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-...](http://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-ne-yapmaliyim) adresini kontrol edebilirsiniz.