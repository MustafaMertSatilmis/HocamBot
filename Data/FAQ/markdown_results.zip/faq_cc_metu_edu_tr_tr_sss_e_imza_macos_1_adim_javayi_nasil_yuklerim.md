[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-07-2023 **Görüntüleme:** 2211


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-macos-1-adim-javayi-nasil-yuklerim)

# EBYS'de E-imzayı nasıl kullanabilirim? \[MacOS - 1. Adım: Java'yı nasıl yüklerim?\]

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

1- [https://www.java.com/](https://www.java.com/) adresine giderek Java'yı bilgisayarınıza indiriniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.31.30.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.32.02.png)

2- İndirilen dosyayı açarak kurulum işlemini tamamlayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.32.47.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.32.55.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.33.04.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.33.16.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.33.42.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.33.58.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2023-03-15_16.34.21.png)

İşlem tamamlanmıştır.