[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/toplu-yemek-nasil-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-11-2022 **Görüntüleme:** 1389


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/toplu-yemek-nasil-alabilirim)

# Toplu Yemek nasıl alabilirim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Toplu yemek hakkı personel ek göstergesi 0, 0-2200 arası ve 2200-3000 arası olanlar için geçerlidir. Bu grupta olan personelimiz toplu yemek alımını sadece Kiosk kullanarak yapabilirler. Kiosk'a akıllı kart yerleştirildikten sonra ana menü üzerinde "Aylık yemek alımı" butonuna basarak 15 günlük (10 iş günü) veya aylık (20 iş günü) tek öğün yemek alınabilmektedir. Toplu yemek ücreti, yükleme yapılırken kullanılan banka kartından tahsil edilmektedir. Ücretlendirme ilgili ek gösterge grubunun tek öğün toplu yemek birim ücretinin 10 veya 20 ile çarpılması ile hesaplanır. Yüklenen bakiye karta aktarılmaz. Bunun yerine kişiye 10 günlük veya 20 günlük yemek hakkı sunulur. Turnike üzerinden geçerken ücretlendirme yapılmaz, 0 'sıfır' TL ile geçiş yapıldığı görüntülenir, ikinci kez geçişlerde misafir ücreti yansımaktadır.  Kişiler en fazla bir sonraki aylık veya 15 günlük periyod için toplu yemek satın alabilirler. Mevcut toplu yemek hakkının bitmesine 2-3 gün kala bir sonraki periyod için satın alma işlemi yapılabilir. Toplu yemek hakkının ne zaman biteceği bilgisi ise yine Kiosk üzerinden "Aylık yemek alımı" menüsünden görüntülenebilir. Raporlu veya idari izinli olunması durumunda, belgesi ile birlikte Kafeterya Müdürlüğü Muhasebe Şefliğine müracaat edildiğinde, kullanılmayan günlerin ücreti bir sonraki toplu yemek alımında otomatik olarak düşülecektir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/kiosk-toplu-yemek-alimi.jpeg)