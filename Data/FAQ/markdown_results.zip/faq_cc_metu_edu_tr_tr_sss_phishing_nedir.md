[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/phishing-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 07-04-2020 **Görüntüleme:** 8131


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-phishing "What is phishing?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/phishing-nedir "Phishing nedir?")

# Phishing nedir?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

İngilizce "password fishing" (şifre avlama) ifadesinden türetilen "Phishing", yanıltıcı nitelikte e-posta göndererek kişinin şifre, banka, kredi kartı vb. kişisel bilgilerinin yasadışı yollarla elde edilmesidir.

ODTÜ Bilgi İşlem Daire Başkanlığı, güvenlik nedeniyle hiçbir şekilde kullanıcı hesabı adı, şifre vb. kullanıcı bilgilerinin güncellenmesine dair e-posta göndermemektedir.

**Phishing nasıl fark edilir?**

E-postaların "Kimden" (From) satırlarının kullanıcıları aldatıcı nitelikte düzenlenmesi teknik olarak mümkündür. Bu nedenle bu tür kişisel bilgi güncellemesi vb. konulara dair bilgi isteyen e-postalarda yer alan bağlantı adreslerini kesinlikle açmamanız gereklidir.

Kullanıcı bilgilerinin güncellenmesi gerektiğine dair e-postalarda, mesaj içinde verilen web adresi bağlantılarına tıklayarak kredi kartı, şifre vb. kişisel bilgileri asla girmeyin. İnternet üzerinden servis veren bankalar, aracı kurumlar, İnternet servis sağlayıcıları vb. firmalar güvenlik nedeniyle kullanıcı bilgilerinin güncellenmesi taleplerini e-posta yolu ile iletmezler. Bu tür bir e-posta geldiği durumda doğrudan ilgili kuruluşu arayarak e-postanın doğru içerik taşıyıp taşımadığı konusunda bilgi alın.

Son zamanlarda e-posta yoluyla kullanıcıları yanıltıcı nitelikte, kişisel bilgilerin elde edilmesi amacıyla gönderilen e-postaların sayısında artış gözlenmektedir. Gönderilen bu e-postaların sahte oldukları gün geçtikçe daha güç fark edilmektedir. Bu nedenle sahte olduğundan şüphelendiğiniz mesajın doğrudan ve sadece kendi e-posta adresinize gelip gelmediğinden emin olun. Bunun için, gönderilen e-postanın "Kime" (To) kısmında sadece sizin adresinizin mi olduğuna, yoksa mesajın genel bir kullanıcı başlığı altında toplu olarak mı gönderildiğine bakın. Eğer e-posta sadece size gelmemişse ve içeriği şüpheliyse, sahte ya da istenmeyen (spam) e-posta olarak değerlendirebilirsiniz. Şüpheli içerik şöyle olabilir:

- Yüksek maaşla çalışacak eleman arıyoruz.
- Afrika'nın zengin bir kabile reisinin oğluyum, bana miras kaldı, çok param var, yardım eder misiniz?
- Büyük ödülü kazandınız, tebrikler, onaylamak için tıklayınız.

Sahte e-postalarda verilen sahte web sayfalarının çeşitli ortak özellikleri bulunmaktadır:

- Sayfadaki resimler genellikle kalitesiz olur.
- Adres satırına baktığınızda e-postada yazan adrese değil, başka bir adrese ya da doğrudan bir IP numarasına bağlandığını görebilirsiniz.
- E-posta adresi toplamak için sahte e-postalar da gönderilmektedir. Bu tür e-postaların "... için ekteki dosyayı tıklayınız" içerikli olanlarına özellikle dikkat etmelisiniz.
- Sahte e-postaların sonunda yazan "bu tür e-postaları almak istemiyorsanız liste üyeliğinden çıkmak için tıklayınız" bağlantılarına tıklamamanız gerekir, tersi durumda alacağınız istenmeyen (spam) e-posta sayısında artış olacaktır.
- Sosyal içeriğiyle dikkat çeken, gerçek olabileceği gibi sahte olma olasılığı yüksek e-postalar da bulunmaktadır. Bu tür e-postalar zaman ve kaynak israfına neden olurlar. İçeriğinde hasta bir çocuk ya da tekerlekli sandalye temini için yardım toplandığı, yardım yapmak için e-postanın mümkün olan en fazla sayıda kişiye yayılması gerektiği yazılı e-postalar bunlara örnektir.

**Phishing e-posta örnekleri**


\-\-\-\-\-\-\-\- Özgün İleti --------

Kimden: XXXX Bankası

Kime: metuuser![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr

Tarih: 16 Ocak 2011 Pazar 07:21:55 +0200

Konu: E-Posta/GSM Numaranız

Değerli XXXX Bankası Müşterisi,

Dilediğiniz bilgiye ulaşmanın yolu artık E-Posta / SMS servislerimizden geçiyor.

XXXX Bankası İnternet Şubesi kullanıcılarımızın, E-Posta / SMS uyarıları için müşteri bilgileri arasında E-Posta / GSM numaralarını belirtmeleri gerekmektedir. Bu uyarı sistemi sayesinde hesaplarınızda yapılan bütün işlemler size isterseniz günlük, isterseniz anlık olarak bildirilecektir. Bununla birlikte isterseniz ekonomi, güncel bilgiler, hatırlatmalar ve daha birçok bilginin cebinize ya da e-posta adresinize gönderilmesini ücretsiz olarak sağlayabilirsiniz.

Lütfen buraya tıklayarak e-posta / GSM numaranızı tanımlayınız.

İnternet Şubesi'ne giriş yaptıktan sonra, E-Posta / SMS Servisleri başlığına tıklayıp, almak istediğiniz bilgileri seçerek servislerimizden yararlanmaya başlayabilirsiniz.

İNTERAKTIF BANKACILIK İÇİN TIKLAYIN > [http://www.XXXXbank\_net.com](http://www.xxxxbank_net.com/)

Saygılarımızla,

XXXX Bankası

\-\-\-\-\-\-\-\- Özgün İleti --------

Kimden: XXXXbank![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)XXXXbank.com.tr (eychenne![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)bigfoot.com)

Kime: metuuser![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr

Tarih: Salı, 18 Ocak 2011 10:40:53 -0400

Konu: Sayın XXXX Bankası Müşterimiz

Sayın Müşterimiz,

Farklı IP adreslerden banka hesabınıza girmeye çalışıldığını tespit ettik. Seyahatteyken hesabınıza girmeye çalıştıysanız bunun gibi hesap açma teşebbüsleri buna bağlı olabilir. Ancak hesabınızı açmak girişiminde bulunmadıysanız hesabınızla ilgili bilgilerin kontrol edilmesi için en acil şekilde bankanıza başvurmanızı tavsiye ederiz.

[http://www.XXXXbank\_net.com](http://www.xxxxbank_net.com/)

Sabrınız için teşekkür ederiz.

Saygılarımızla,

XXXX Bankası

\-\-\-\-\-\-\-\- Özgün İleti --------

Kimden: security![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr

Kime: metuuser![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr

Tarih: Salı, 7 Şubat 2011 17:18:12 +0900

Konu: Güvenlik Uyarısı

Sayın Kullanıcımız,

Bilişim kaynakları kullanım politikamıza göre aşağıdaki bağlantıya tıklayarak e-posta adresinizi onaylamanız gerekmektedir. Onay işlemini 24 saat içinde gerçekleştirmezseniz güvenlik gerekçesiyle kullanıcı hesabınız dondurulacaktır.

[http://www.metuuser](http://www.metuuser/) ![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr/confirm.php?account=metu.edu.tr

Bağlantıdaki adımları takip edip işlemi tamamlarsanız hesabınızda herhangi bir kesinti olmayacaktır.

Talebimize olan ilginiz için teşekkür ederiz. Herhangi bir rahatsızlık verdiysek özür dileriz.

Saygılarımızla,

ODTÜ Güvenlik Birimi