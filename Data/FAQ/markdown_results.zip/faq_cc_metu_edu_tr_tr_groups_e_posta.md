[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/e-posta#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# E-Posta

|     |
| --- |
| ["Tatildeyim" mesajını nasıl oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/tatildeyim-mesajini-nasil-olusturabilirim) |
| [E-posta alırken gelen eklenmiş dosyalarla ilgili herhangi bir kısıtlama var mı?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-alirken-gelen-eklenmis-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi) |
| [E-posta gönderirken "blocked by SpamAssasin" uyarı mesaji alıyorum. Neden?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-blocked-spamassasin-uyari-mesaji-aliyorum-neden) |
| [E-posta gönderirken eklemek istediğim dosyalarla ilgili herhangi bir kısıtlama var mı?](https://faq.cc.metu.edu.tr/tr/sss/e-posta-gonderirken-eklemek-istedigim-dosyalarla-ilgili-herhangi-bir-kisitlama-var-mi) |
| [Gelen e-posta mesajının başlığının tamamını (full header) görmek için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim) |
| [Hesabımdaki gelen kutusunda ya da diğer oluşturduğum dizinlerde saklayabileceğim e-posta ya da dosyaların bir sınırı var mı?](https://faq.cc.metu.edu.tr/tr/sss/hesabimdaki-gelen-kutusunda-ya-da-diger-olusturdugum-dizinlerde-saklayabilecegim-e-posta-ya-da) |
| [Horde ile tüm e-postalarımı nasıl indirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim) |
| [IMAP ve POP3 nedir?](https://faq.cc.metu.edu.tr/tr/sss/imap-ve-pop3-nedir) |
| [Merkezi e-posta sunucusu üzerindeki e-postalarıma nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/merkezi-e-posta-sunucusu-uzerindeki-e-postalarima-nasil-erisebilirim) |
| [Mezun E-posta Sistemi Kullanım Politikası](https://faq.cc.metu.edu.tr/tr/sss/mezun-e-posta-sistemi-kullanim-politikasi) |
| [Mezun Eposta Hesabı şifremi nasıl değiştirebilirim? Yeni şifre seçerken nelere dikkat etmeliyim?](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-hesabi-sifremi-nasil-degistirebilirim-yeni-sifre-secerken-nelere-dikkat-etmeliyim) |
| [Mezun olduktan sonra ODTÜ kullanıcı hesabıma gelen e-postalarımı yönlendirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/mezun-olduktan-sonra-odtu-kullanici-hesabima-gelen-e-postalarimi-yonlendirebilir-miyim) |
| [Microsoft Outlook Express ile nasıl filtreleme yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-express-ile-nasil-filtreleme-yapabilirim) |
| [ODTÜ adresime gönderilen e-postalar bana ulaşmıyor, sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-adresime-gonderilen-e-postalar-bana-ulasmiyor-sorun-ne-olabilir) |
| [ODTÜ e-posta yönlendirmeyi nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim) |
| [ODTÜ epostalarımı ve adres defterimi farklı bir eposta sistemine nasıl aktarabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-epostalarimi-ve-adres-defterimi-farkli-bir-eposta-sistemine-nasil-aktarabilirim) |
| [ODTÜ hesabımdan, ODTÜ'de bir adrese yönlendirilmiş dış eposta adresine mesaj gönderemiyorum. Neden?](https://faq.cc.metu.edu.tr/tr/sss/odtu-hesabimdan-odtude-bir-adrese-yonlendirilmis-dis-eposta-adresine-mesaj-gonderemiyorum-neden) |
| [ODTÜ kullanıcı hesabıma gelen e-postalarımı nasıl yönlendirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabima-gelen-e-postalarimi-nasil-yonlendirebilirim) |
| [ODTÜ Mezun E-posta Kullanıcı Kodu Şifre ve Kurtarma E-Postası İşlemleri](https://faq.cc.metu.edu.tr/tr/sss/odtu-mezun-e-posta-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri) |
| [OLDINBOX ve benzeri dizinler nasıl silinir?](https://faq.cc.metu.edu.tr/tr/sss/oldinbox-ve-benzeri-dizinler-nasil-silinir) |
| [OLDINBOX, SPAMBOX ve benzeri dizinlerdeki e-postaları nasıl okuyabilirim?](https://faq.cc.metu.edu.tr/tr/sss/oldinbox-spambox-ve-benzeri-dizinlerdeki-e-postalari-nasil-okuyabilirim) |
| [Pine ile nasıl filtreleme yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/pine-ile-nasil-filtreleme-yapabilirim) |
| [Yanlışlıkla sildiğim e-postalara nasıl ulaşabilirim? Yedekten dönmek mümkün müdür?](https://faq.cc.metu.edu.tr/tr/sss/yanlislikla-sildigim-e-postalara-nasil-ulasabilirim-yedekten-donmek-mumkun-mudur) |

[![Subscribe to E-Posta](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/9/all/feed "Subscribe to E-Posta")