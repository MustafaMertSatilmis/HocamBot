[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-onayda-bekleyen-akislar-nasil-goruntulenir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5599


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-onayda-bekleyen-akislar-nasil-goruntulenir)

# EBYS’de onayda bekleyen akışlar nasıl görüntülenir?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

- Öncelikle EBYS'de oturum açınız.
- Sağ üst tarafta onayınızda kaç tane evrak beklediğini gösteren işarete tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/bekleyen-onaylar2.png)

- Açılan sayfanın sol tarafında üzerinizde bekleyen evrak türlerine tıklayarak ilgili evrakları listeleyebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/bekleyen-onaylar-yazisma-turu.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.