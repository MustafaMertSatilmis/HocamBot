[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-02-2023 **Görüntüleme:** 24839


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-forgot-my-password-where-can-i-apply "I forgot my METU user code password. Where can I apply?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim "ODTÜ kullanıcı koduma ait parolamı unuttum. Nereden öğrenebilirim?")

# ODTÜ kullanıcı koduma ait parolamı unuttum. Nereden öğrenebilirim?

[Parola](https://faq.cc.metu.edu.tr/tr/groups/parola)

ODTÜ Kullanıcı Hesap Yönetimi [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/) sayfasından, kayıtlı parola sıfırlama e-posta adresiniz (kurtarma e-posta adresi) varsa yeni parola alabilirsiniz. Bunun için kayıtlı bir kurtarma e-posta adresiniz bulunmalıdır.

Kayıtlı bir kurtarma e-posta adresiniz varsa "Şifrenizi mi unuttunuz?" bağlantısına tıklayınız. Kayıtlı bir kurtarma adresiniz yoksa lütfen [buraya](https://faq.cc.metu.edu.tr/tr/sss/sifremi-unuttum-nereden-ogrenebilirim#yoksa) tıklayınız ya da bu sayfanın en alt kısmındaki açıklamaları okuyarak gerekli işlemleri yapınız.

![](<Base64-Image-Removed>)

İlgili alanları doldurduktan sonra “e-posta gönder” e tıklayınız. Gelen e-postadaki yeni parola etkinleştirme bağlantısına tıklamanız gerekmektedir.

Parolanızı hatırlıyor fakat kayıtlı bir kurtarma e-posta adresini henüz belirlemediyseniz, ODTÜ Kullanıcı Hesap Yönetimi sayfasına giriş yaptıktan sonra "Kurtarma E-postası belirle" linki ile 2. e-posta adresinizi kaydedebilirsiniz.

![](<Base64-Image-Removed>)

Henüz tanımlanmış bir kurtarma e-posta adresiniz yoksa ODTÜ kimliğinizi ve T.C. nüfus cüzdanınızın ön yüzünü (ikisi birlikte) tarayıcı ile tarayabilirsiniz. Cep telefonunuz uygun ise, Cep telefonunuzdan ODTÜ kimliğinizin ve Nüfus cüzdanınızın ön yüzünü (ikisi birlikte) fotoğrafını çekip (dosya yüklemek için fotoğrafın pdf, png, jpeg, gif dosya türlerinden biri olması ve maksimum 2mb boyutunda olması gerekmektedir) [Bilişim Destek Formu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=user) adresindeki formu doldurduktan sonra kurtarma e-posta adresiniz bizim tarafımızdan tanımlanacak (e-posta gönderdiğiniz adres ya da özellikle talep ettiğiniz bir adres varsa) ve şifre sıfırlama işlemlerini yukarda belirtildiği gibi gerçekleştirebiliyor olacaksınız.

Bu işlemler sonrası kurtarma e-posta adresinizi ve parolanızı dileğiniz zaman bu sistem üzerinden değiştirebilir veya sıfırlayabilirsiniz.