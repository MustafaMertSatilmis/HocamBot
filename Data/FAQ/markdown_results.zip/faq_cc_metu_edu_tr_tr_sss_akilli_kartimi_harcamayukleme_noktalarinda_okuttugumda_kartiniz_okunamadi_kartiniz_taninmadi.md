[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-harcamayukleme-noktalarinda-okuttugumda-kartiniz-okunamadi-kartiniz-taninmadi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-10-2021 **Görüntüleme:** 3688


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/when-i-tapscan-my-smartcard-paymentload-devices-i-get-error-message-says-your-card-has-not-been "When I tap/scan my smartcard to payment/load devices I get an error message says “your card has not been read” or “your card has not been recognized”. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartimi-harcamayukleme-noktalarinda-okuttugumda-kartiniz-okunamadi-kartiniz-taninmadi "Akıllı kartımı harcama/yükleme noktalarında okuttuğumda “kartınız okunamadı” / “kartınız tanınmadı” hatası almaktayım. Ne yapmalıyım?")

# Akıllı kartımı harcama/yükleme noktalarında okuttuğumda “kartınız okunamadı” / “kartınız tanınmadı” hatası almaktayım. Ne yapmalıyım?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Kartınızı harcama/yükleme terminallerine en fazla 3cm mesafe  (yaklaşık 2 parmak) olacak şekilde okutmanız gerekmektedir. Ayrıca kartınızın cihaz tarafından okunduğundan emin olmadan çekmeyiniz (yaklaşık 3sn).