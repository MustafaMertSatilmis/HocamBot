[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/oluruygunlukonay-gerektiren-yazilar-nasil-hazirlanir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 11593


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/oluruygunlukonay-gerektiren-yazilar-nasil-hazirlanir)

# Olur/Uygunluk/Onay gerektiren yazılar nasıl hazırlanır?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de evrak hazırlayan kullanıcılarımızın “Olur/Uygunluk/Onay” gerektiren evraklarını genellikle sadece birim yöneticisi imzası ile üst yöneticilere sevk ettikleri gözlenmektedir. Bu şekilde kendisine evrak gönderilmiş üst yöneticiler de ancak ilgili evrakın “Notlar” sekmesini kullanarak işlem yapabilmektedir.

"Notlar" sekmesi kullanılarak verilmiş “Olur/Uygunluk/Onay” lar birçok birimimizce Ekran Alıntı Aracı kullanmak gibi fazladan işlem yapılmasına ve bazı durumlarda ilgili süreçlerin devam ettirilememesine (örneğin, Strateji Geliştirme Daire Başkanlığı’nın Sayıştay’a sunduğu evrakların kabul edilmemesine) neden olabilmektedir.

Üzerinde “OLUR” (ONAY) verilmesi gereken her tür Kurum İçi/Kurum Dışı evrakın EBYS'de hazırlanması esnasında, evrakı hazırlayan kullanıcılarımızın “Onaylayacaklar” sekmesinden “İmzacı konumundaki yöneticiyi" ve “Olur veya Uygunluk vermesi istenen üst yöneticiyi" ayrı ayrı seçip, her defasında "Tamam" butonu ile evraka eklemesi gerekmektedir. Aşağıda, İmzacı seçimi, Olurcu seçimi ve bu seçimler sonucunda evrakın üzerinde görünecek onaycılar için örnek ekranlar görülebilir:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/imzaci-secimi.png)![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/olurcu-secimi.png)![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/onaycilar-onizle.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.