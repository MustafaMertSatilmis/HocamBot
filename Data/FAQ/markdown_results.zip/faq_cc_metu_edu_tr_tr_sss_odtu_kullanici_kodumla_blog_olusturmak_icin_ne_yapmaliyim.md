[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumla-blog-olusturmak-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8552


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-creating-blog-my-odtu-username "What should I do for creating a blog with my ODTÜ username?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumla-blog-olusturmak-icin-ne-yapmaliyim "ODTÜ kullanıcı kodumla blog oluşturmak için ne yapmalıyım?")

# ODTÜ kullanıcı kodumla blog oluşturmak için ne yapmalıyım?

[Blog Servisi](https://faq.cc.metu.edu.tr/tr/groups/blog-servisi)

ODTÜ Blog Servisi ile merkezi sunucular üzerinde tanımlı kullanıcı kodunuzu kullanarak **[http://blog.metu.edu.tr/](http://blog.metu.edu.tr/){kullanıcı kodunuz}** şeklinde ulaşılan blog sayfalarınızı oluşturabilirsiniz. ODTÜ Blog Servisi için _özel olarak bir kayıt aşaması gerekmemektedir_. Giriş yaptığınız anda blogunuz otomatik olarak oluşturulacak ve hemen kullanmaya başlayabileceksiniz.

ODTÜ Blog servisi;

- Web sayfası oluşturma konusunda teknik bilgiye gerek duymadan kolayca _kişisel sayfalarınızı_ ve/veya _bloglarınızı_ oluşturmanızı;
- Kullanıcı kodunun statüsüne göre _kişisel_ veya _kurumsal_ düzeyde sayfalar oluşturmanızı;
- Blog’larınızın _birden fazla dilde_ hazırlanabilmesini;
- Tercihinize göre, yayınladığınız blog sayfaları için _okuyucu yorumlarını_ alabilmenizi;
- _ODTÜ Kurumsal Kimlik Standartları_ ile uyumlu olarak hazırlanmış temayı kullanarak blog ve/veya kişisel sayfaları oluşturabilmenizi;
- Çeşitli tema seçeneklerinden dilediğinizi blog sayfalarınızda kullanabilmenizi,

sağlar.

Blog servisinden yararlanmak isteyen kullanıcılarımız [ODTÜ Blog Servisi Kullanım Kuralları](http://blog.metu.edu.tr/kullanim-kurallari/ "Kullanım Kuralları")‘nda belirtilen unsurlara uymakla yükümlüdür. Kapatılan kullanıcı kodlarına ait blog sayfaları da paralel olarak kapatılmaktadır.

_Blog servisi yardım videolarına_ [https://blog.metu.edu.tr/egitim-ve-tanitim-videolari/](https://blog.metu.edu.tr/egitim-ve-tanitim-videolari/) adresinden ulaşabilirsiniz.

Blog servisi ile ilgili soru ve sorunlarınızı [İletişim Formu](http://blog.metu.edu.tr/iletisim/ "İletişim")‘nu kullanarak bize iletebilirsiniz.