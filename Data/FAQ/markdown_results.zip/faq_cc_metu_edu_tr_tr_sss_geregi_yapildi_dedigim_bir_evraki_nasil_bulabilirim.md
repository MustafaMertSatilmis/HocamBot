[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/geregi-yapildi-dedigim-bir-evraki-nasil-bulabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4976


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/geregi-yapildi-dedigim-bir-evraki-nasil-bulabilirim)

# "Gereği Yapıldı" dediğim bir evrakı nasıl bulabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

[http://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir](http://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir) ve [http://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum...](http://faq.cc.metu.edu.tr/tr/sss/gecmis-bolumunden-evraklari-goremiyorum-nasil-gorebilirim) adresindeki bilgileri kullanarak evraklarınıza ulaşabilirsiniz. Sonlandırdığınız evrakı geri almak istiyorsanız [Evrak geri al](https://faq.cc.metu.edu.tr/tr/sss/sonlandirdigim-evraki-nasil-geri-alabilirim) menüsünden geri alabilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.