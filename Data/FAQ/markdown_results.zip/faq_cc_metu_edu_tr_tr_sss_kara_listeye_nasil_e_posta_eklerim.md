[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kara-listeye-nasil-e-posta-eklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 8502


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-add-e-mail-address-black-list "How can I add an e-mail address to the black list?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kara-listeye-nasil-e-posta-eklerim "Kara listeye nasıl e-posta eklerim?")

# Kara listeye nasıl e-posta eklerim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

E-posta adresine gelmesini istemediğiniz e-postaları kara listeye ekleyerek engelleyebilirsiniz. Bunun için lütfen aşağıdaki adımları uygulayın:

[https://horde.metu.edu.tr/login.php](https://horde.metu.edu.tr/login.php) adresine girin ve kullanıcı kodunuz ile şifrenizi ilgili yerlere yazarak giriş yapınız.

Bu özelliği kullanmak için Horde'a girildikten sonra önce "Posta" ikonuna, daha sonra "Süzgeçler" ikonuna tıklanmalıdır.

![](http://faq.cc.metu.edu.tr/tr/system/files/u2/horde_filter_rule_tr.png)

Soldaki menüden "Kara Liste" butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde-blacklist.png)

Kara liste için eylemler yazısının altındaki seçeneklerden birini seçiniz.

1) Eğer karalisteye ekleyeceğiniz adreslerden gelen mesajları tamamen silmek istiyorsanız “İletiyi tamamen sil” seçeneğini seçiniz.

2) Eğer karalisteye ekleyeceğiniz adreslerden gelen mesajları silmek yerine sadece işaretlemek istiyorsanız “İletiyi silinecek olarak işaretle” seçeneğini seçiniz.

3) Eğer karalisteye ekleyeceğiniz adreslerden gelen mesajları herhangi bir klasöre (Yeni dizin yarat, Gelen kutusu, drafts, send mail, Trash) taşımak istiyorsanız “İletiyi dizine Taşı:” seçeneğini seçiniz ve yanındaki açılır menüden uygun klasör ismine tıklayınız.

Alttaki metin kutucuğuna kara listeye eklemek istediğiniz e-mail adreslerini yazınız (Dikkat: Eklemek istediğiniz her e-mail adresini ayrı satırlara ekleyiniz.)

E-mail adreslerini yazmayı bitirdiğinizde "Kaydet" butonuna tıklayınız.

Değişiklikler kaydedildikten sonra yazmış olduğunuz e-mail adreslerine belirtmiş olduğunuz seçeneklere göre işlem yapılacaktır.