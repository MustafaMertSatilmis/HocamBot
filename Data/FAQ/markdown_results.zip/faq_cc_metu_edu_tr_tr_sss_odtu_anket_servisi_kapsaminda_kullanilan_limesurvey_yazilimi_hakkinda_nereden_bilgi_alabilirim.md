[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-kapsaminda-kullanilan-limesurvey-yazilimi-hakkinda-nereden-bilgi-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 8040


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-get-information-limesurvey-software "How can I get information on LimeSurvey software?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisi-kapsaminda-kullanilan-limesurvey-yazilimi-hakkinda-nereden-bilgi-alabilirim "ODTÜ Anket Servisi kapsamında kullanılan Limesurvey yazılımı hakkında nereden bilgi alabilirim?")

# ODTÜ Anket Servisi kapsamında kullanılan Limesurvey yazılımı hakkında nereden bilgi alabilirim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Limesurvey yazılımının orijinal yardım ve dokümantasyon sayfasına [buradaki adresten](https://manual.limesurvey.org/LimeSurvey_Manual) erişilebilir. Yazılımla ilgili destek forumları ise [buradaki adresten](https://forums.limesurvey.org/) konu başlıklarına göre erişilebilir durumdadır.

Limesurvey yazılımı yönetim arayüzü demo sayfasına ise [buradaki adresten](https://demo.limesurvey.org/index.php?r=admin/authentication/sa/login) adresinden (kullanıcı adı: demo, şifre: test) ulaşılabilir.

**Not:** Bağlantılarda sunulan içerik _İngilizce_'dir.