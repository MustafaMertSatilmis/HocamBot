[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-online-bakiye-yukleme-sisteminden-odtucard-para-yukledim-yukledigim-bakiye#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-05-2023 **Görüntüleme:** 11160


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-loaded-money-my-smartcard-online-balance-loading-sysytem-odtucard-amount-i-have-loaded "I have loaded money to my smartcard from online balance loading sysytem (odtucard), the amount I have loaded has not been transferred to my smartcard. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-online-bakiye-yukleme-sisteminden-odtucard-para-yukledim-yukledigim-bakiye "Akıllı kartıma online bakiye yükleme sisteminden (odtucard) para yükledim, yüklediğim bakiye kartıma aktarılmadı. Ne yapmalıyım?")

# Akıllı kartıma online bakiye yükleme sisteminden (odtucard) para yükledim, yüklediğim bakiye kartıma aktarılmadı. Ne yapmalıyım?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınıza yemek saatlerinde (11:00 dan sonra) yüklediğiniz bakiyeyi aktarabilmek için kartınızı yükleme/güncelleme terminaline veya Kiosk’a okutmanız gerekmektedir (resimleri aşağıdadır). Kartınızı bu cihazlara okuttuğunuz halde bakiyeniz aktarılmamışsa [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresi üzerinden kullanıcı hesabınız ile giriş yaparak sorununuzu bildirebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/kiosk.jpeg)![](https://faq.cc.metu.edu.tr/tr/system/files/u21699/bakiye-guncelleme.jpeg)