[Jump to navigation](https://faq.cc.metu.edu.tr/tr/office#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-03-2022 **Görüntüleme:** 89475


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/office "MICROSOFT OFFICE")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/office "MICROSOFT OFFICE")

# MICROSOFT OFFICE

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— MICROSOFT OFFICE** **2021** **—**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/office#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/office#aktivasyon)

* * *

**_\[1\] Personel için not:_** _Microsoft Office programları sadece personelin kullanımına açıktır._

**_\[2\] Öğrenciler için not:_** _Microsoft Office programlarını kullanabilmek için_ **[_bu sayfada_](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware)** _yer alan yönergeleri takip ederek Office 365 hizmetine metu.edu.tr uzantılı e-posta adresinizle kaydolunuz. Bu işlemden sonra ilgili yazılıma erişip kullanabilirsiniz._

**_\[3\] Windows kullanıcıları için not:_** _Kullanıcılarımız **“Office 2021”**_ _windows_ _sürümü aktivasyon işlemi için **“kms\_office2021\_client.bat”**_ _volume license_ _dosyasını lisanslı yazılımlar web sayfasından indirmeli ve dosyaya sağ tıklayarak_ **_“Run as administrator”_** _seçeneği ile çalıştırmalıdırlar. Bu işlemden sonra Microsoft Office Windows sürümü etkinleştirilmiş olmalıdır._

**_\[4\] Mac kullanıcıları için not:_** _Kullanıcılarımız_ **_“_** **_Office_** **_for Mac_** **_2021”_** _macOS_ _sürümü aktivasyon işlemi için_ **_“Office for Mac 2021 Serializer”_** _volume license_ _dosyasını lisanslı yazılımlar web sayfasından indirmeli ve yüklemeliler. Bu işlemden sonra Microsoft Office Mac sürümü etkinleştirilmiş olmalıdır._

**_\[5\] Aynı bilgisayarda Office’in farklı sürümlerini yükleme ve kullanma hakkında not:_** _"Microsoft 365 aboneliğiniz varsa veya Office Ev ve İş 2021, 2019, 2016 ya da 2013 gibi abonelik temelli olmayan bir sürüme sahipseniz, çoğu durumda bu sürümleri aynı bilgisayarda birlikte çalıştıramazsınız."_

* * *

**_ADIM-1 <<<KURULUM>>>_**

**_“install”_** _butonuna tıklayarak kurulumu başlatınız. (Gerekiyor ise install dosyasının üzerine sağ tıklayıp yönetici olarak çalıştırınız.)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_office_2021_step1.png)

**_ADIM-2_**

_Kurulum başladıktan sonra ekranda aşağıda yer alan iki pencere açılacaktır. Kurulum tamamlanana kadar bu pencereleri kapatmayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_office_2021_step2.1.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_office_2021_step2.2.png)

**_ADIM-3_**

**_“Close”_**_butonuna tıklayarak kurulum işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_office_2021_step3.png)

**_ADIM-4 <<<AKTİVASYON>>>_**

_Aktivasyon işlemi için **“kms\_office2021\_client.bat”**dosyasına sağ tıklayarak **“Run as administrator”**_ _seçeneği ile çalıştırınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_office_2021_step4.png)

**_ADIM-5_**

_Ekrana gelen pencerede **“Product activation successful”**_ _yazısını görüyor iseniz aktivasyon işlemi başarıyla tamamlanmış demektir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/microsoft_office_2021_step5.png)

* * *

_**Bize**_ _**ulaşın**_ _**:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *