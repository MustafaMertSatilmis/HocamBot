[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/dsclient-uygulamasinda-karsilasilabilen-uyarilar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-02-2024 **Görüntüleme:** 3766


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/dsclient-uygulamasinda-karsilasilabilen-uyarilar)

# EBYS'de E-imza Uygulaması DSClient'da Karşılaşılabilen Uyarılar

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS'de DSClient uygulamasının çalıştırılabilmesi için [https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-y...](https://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim-yeni-client) adresinde belirtilen ve ilgili işletim sistemi için gerekli olan Java, KamuSM akıllı kart sürücüleri ve DSClient kurulumlarının yapılmış olması gerekmektedir. Uygulamayı çalıştırırken hata alınıyorsa öncelikle bu sayfadan tüm uygulamaların son versiyonlarını indirip kurduğunuzdan emin olunuz.

Kurulumları yapmış olmanıza rağmen hata almaya devam ediyorsanız, karşılaştığınız uyarı için aşağıda önerilmiş olan yöntemi uygulayınız. Sorun devam ederse, kullandığınız işletim sistemi bilgisini ve aldığınız uyarının ekran görüntüsünü [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine ileterek destek isteyebilirsiniz.

* * *

**Uyarı mesajı:** DSClient application is not found. / Sistem belirtilen dosyayı bulamıyor. \[WINDOWS\]

**Önerilen yöntem:** Bilgisayarınızdaki kontrol panelinden kurulu bulunan tüm Java versiyonlarını kaldırınız. Bilgisayarınızı yeniden başlatıp yönetici yetkisi ile [https://www.java.com/](https://www.java.com/) adresinden erişilebilen Java 8 versiyonunu kurunuz. Windows Servisler bölümünden DSClientService servisini çalıştırıp e-imza işlemlerini tekrar deneyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsnotfound2.png)

* * *

**Uyarı mesajı:** DSClient application is not found. If DSClient is installed, please run it to continue the signing. \[WINDOWS\]

**Önerilen yöntem:** DSClient uygulamasının kurulumunda eksiklik olabilir. Bilgisayarınızda bu program kurulu görünüyorsa kaldırıp [https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilim...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-windows-3-adim-dsclient-yazilimini-nasil-yuklerim) adresinden güncel kurulum dosyasını indirip tekrar kurunuz ve e-imza işlemlerini tekrar deneyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsnotfound.png)

* * *

**Uyarı mesajı:** DSAPI 9999 Imza Atma Islemi Tamamlanamadı / DSAPI 10062 Akıllı kart bloke haldedir. \[TÜM İŞLETİM SİSTEMLERİ\]

**Önerilen yöntem:** E-imza PIN'iniz kilitlenmiş olabilir. PIN kilidini çözmek için [https://faq.cc.metu.edu.tr/tr/sss/e-imza-sim-kartimin-pin-parola-kodunu-...](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sim-kartimin-pin-parola-kodunu-nasil-olusturabilirim-pin-kilidini-nasil-cozebilirim) sayfasındaki adımları uygulayınız. Sonrasında imza işlemlerini tekrar deneyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dsapi10062.png)

* * *

**Uyarı mesajı:**\[object Object\]  \[TÜM İŞLETİM SİSTEMLERİ\]

**Önerilen yöntem:** Bu uyarı birden fazla durumda ortaya çıkabilir ancak en yaygın olan durum sizin adınızın yer almadığı bir evrakı vekaleten imzalamaya çalıştığınızda karşınıza çıkmasıdır. Yapılması gereken işlem evrakın iade edilip vekaleten sizin adınız seçilerek tekrar size imzalamanız için gönderilmesidir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/object.png)