[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-kopyalayabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 951


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-kopyalayabilirim)

# Roundcube'de iletileri farklı klasörlere nasıl kopyalayabilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

İletiyi görüntülerken "Diğer" butonuna tıklayıp açılacak menüden "Şuraya kopyala..." seçeneğiyle istediğiniz klasöre kopyalayabilirsiniz.