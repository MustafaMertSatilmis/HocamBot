[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gelen-e-postalari-nasil-filtreleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1558


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gelen-e-postalari-nasil-filtreleyebilirim)

# Roundcube'de gelen e-postaları nasıl filtreleyebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

İstenmeyen e-postaların "Gelen" klasöründe yer kaplamasını engellemek ya da belli kişilerden ve/veya belli konularda gelen e-postaları belirli klasörlere otomatik olarak taşımak için Roundcube'un "Süzgeçler" özelliği kullanılabilir.

Bu özelliği kullanmak için Roundcube'e girildikten sonra önce sol panelde yer alan "Ayarlar" butonuna, daha sonra "Süzgeçler" butonuna tıklanmalıdır.

Uyarı: ODTÜ webmail arayüzlerinden Horde arayüzünde tanımlanmış olan filtreler (süzgeçler), Roundcube arayüzünden de görüntülenebilmekte ve kullanılabilmektedir. Roundcube’de tanımlanacak olan yeni süzgeçler, daha önce Horde arayüzünde tanımlanmış olan süzgeç setine eklenir. Öte yandan, Roundcube’de süzgeç oluşturulmasından sonra tekrar Horde arayüzüne giriş yapılarak süzgeçler düzenlendiğinde Roundcube’de oluşturulmuş süzgeçler silinmektedir. Roundcube arayüzünün test aşaması tamamlandığında bu sorunun ortadan kaldırılması planlanmakla birlikte, kullanıcılarımızın bu konuda dikkatli olmalarını öneririz.