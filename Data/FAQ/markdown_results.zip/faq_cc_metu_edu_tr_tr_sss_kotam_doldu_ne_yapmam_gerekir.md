[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kotam-doldu-ne-yapmam-gerekir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 15713


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-over-quota-what-should-i-do "I am over quota, what should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kotam-doldu-ne-yapmam-gerekir "Kotam doldu, ne yapmam gerekir?")

# Kotam doldu, ne yapmam gerekir?

[Kota](https://faq.cc.metu.edu.tr/tr/groups/kota)

Kullanıcı hesabı sahiplerine merkezi sunucular üzerinde ayrılan disk alanına kota denir. ODTÜ kullanıcılarına dosya ve e-postaları için iki ayrı kota tanımlanmıştır. Dosya veya e-posta kotaları dolduğu zaman yapılması gereken işlemler birinden farklıdır.

**E-posta kotası için:**

Kullanıcıların e-postalarını tuttuğu alan için ayrı bir e-posta kotası tanımlanmaktadır. Bu kota %90 oranında dolduğunda kullanıcılara uyarı mesajı gönderilmektedir.

E-posta kotası uygulamalarında, kotanın aşılması durumunda gelen e-postaların geri dönmesi sözkonusu olduğundan, kullanıcılarımızın kendilerine tahsis edilmiş olan e-posta kotalarını kontrollü kullanmaları ve sistemden gelen uyarıları dikkate almaları önem taşımaktadır.

E-posta kotası aşıldığında ya da üst sınıra yaklaşıldığında;

- Gereksiz ve büyük boyutta olan e-postaları silmek,
- E-posta eklentilerini çalışılan bilgisayarın sabit diskinde saklamak

gibi yöntemlerle kullanılan e-posta kotası azaltılmalıdır.

**Dosya kotası için:**

Sunucu sistemler üzerinde yeni bir dosya oluşturulacağı ya da dışarıdan yeni bir/bir kaç dosya kopyalanacağı zaman "quota exceeded" mesajı ile karşılaşılıyorsa; sistem üzerinde, kullanıcıya ayrılmış olan disk alanının tamamının kullanıcı tarafından kullanıldığı anlamına gelir. Şu anda öğrenciler için 100 MB ve personel için 250 MB kullanım hakkı verilmektedir.

Bu durumla karşılaşmamak için belirli aralıklarla disk kullanımınızı ve kotanızın durumunu kontrol etmeniz gerekir. Disk kullanımınızı ve dosya kotanızı kontrol etmek için [quota](https://faq.cc.metu.edu.tr/tr/sss/kullandigim-disk-alanini-ve-kotamin-son-durumunu-nasil-ogrenebilirim) komutunu kullanabilirsiniz.

Disk kullanımının dosya kota limit değerine ulaşılması durumunda, kullanıcı hesabına girilemeyebilir. Blocks değeri, limit değerinden büyük olmamalıdır, tersi durumda "quota exceed" mesajı ile karşılaşılır.

Böyle bir durumda yapmanız gereken öncelikle büyük yer kaplayan dosyalarınızı belirleyerek bunları sıkıştırmak ya da gereksiz dosyalarınızı silmektir.

- dosyalarınızın kapladığı alanı görmek için;

ls -l

ls -l \|more
- dosyalarınızı sıkıştırmak için;

gzip
- sıkıştırılmış dosyalarınızı açmak için;

gunzip
- İlgili dizinin altına geçmek için;

cd _<dizin\_adı>_
komutlarını kullanabilirsiniz.

- dosyaları silmek için [buradan](https://faq.cc.metu.edu.tr/tr/sss/merkezi-sunucular-uzerinde-bulunan-dosyalarimi-nasil-silebilirim) yardım alabilirsiniz.