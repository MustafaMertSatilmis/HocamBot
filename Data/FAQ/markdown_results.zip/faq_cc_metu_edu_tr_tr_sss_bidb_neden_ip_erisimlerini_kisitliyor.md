[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidb-neden-ip-erisimlerini-kisitliyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 10179


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/why-would-cc-restrict-ip-access "Why would the CC restrict an IP access?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidb-neden-ip-erisimlerini-kisitliyor "BİDB neden IP erişimlerini kısıtlıyor?")

# BİDB neden IP erişimlerini kısıtlıyor?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

BİDB, ODTÜ yerleşke omurga ağına bağlı bilgisayarların IP erişimlerini, virüs vb. aktivitelerle karşılaştığı durumda, 24 Mart 2004 tarihinde duyurulan Bilişim Kaynakları Kullanım Politikaları metni doğrultusunda kısıtlamaktadır.

BİDB, IP erişimlerini aşağıda belirtilen nedenlerden dolayı kısıtlar:

- Birim bilgisayar koordinatörünün nedeni belirtilmiş isteği üzerine
- Virüs aktivitesi gözlenmesi üzerine
- İzinsiz işlem yapılması üzerine

- Spam e-posta kaynağı olarak belirlenmesi
- İzinsiz IP adresi değişikliğinin belirlenmesi