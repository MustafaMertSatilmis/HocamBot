[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imzami-kaybettimcalindi-kimlik-bilgim-guncellendi-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-02-2023 **Görüntüleme:** 9594


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-lost-my-e-signature-it-was-stolen-my-credentials-have-been-updated-what-should-i-do "I lost my e-signature / it was stolen, my credentials have been updated; what should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imzami-kaybettimcalindi-kimlik-bilgim-guncellendi-ne-yapmaliyim "E-imzamı kaybettim/çalındı, kimlik bilgim güncellendi; ne yapmalıyım? ")

# E-imzamı kaybettim/çalındı, kimlik bilgim güncellendi; ne yapmalıyım?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

**"Kayıp/Çalıntı" ya da "Kimlik Bilgisi Güncelleme" durumunda kullanıcı sertifika bedelini kendisi karşılamak durumundadır.**

**Kullanıcı kayıp veya çalıntı e-imza sertifika kartı için işlemleri [http://kamusm.gov.tr](http://kamusm.gov.tr/) sayfasından kendisi yapabilmektedir.**

\- [http://kamusm.gov.tr](http://kamusm.gov.tr/) sayfasına gidiniz. Sağ üst köşede bulunan Online İşlemler butonuna tıklayınız.

- **E-devlet** ile giriş yapınız.

\- **NES İşlemleri**'ne tıklayınız

\- **Bireysel İşlemler**'i seçiniz.

\- **Başvuru İşlemleri**'ni seçiniz.

\- **Kişi Ödemeli Başvurular**'ı seçiniz.

\- **TC. Yükseköğrenim Kurumu**'nu seçiniz.

\- Çıkan sayfada ilgili bilgileri temin ederek formu doldurunuz. (Sertifikam İnternetten yayınlansın mı için EVET seçilmelidir)