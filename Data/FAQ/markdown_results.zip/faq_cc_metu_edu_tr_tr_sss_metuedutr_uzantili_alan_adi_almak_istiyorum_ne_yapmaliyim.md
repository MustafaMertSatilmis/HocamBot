[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/metuedutr-uzantili-alan-adi-almak-istiyorum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-01-2023 **Görüntüleme:** 10647


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/metuedutr-uzantili-alan-adi-almak-istiyorum-ne-yapmaliyim)

# metu.edu.tr uzantılı alan adı almak istiyorum. Ne yapmalıyım?

[Web Servisleri](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri)

ODTÜ Bilgi İşlem Daire Başkanlığı tarafından işletilen sunucular üzerinde web sayfası oluşturmak için öncelikle web kullanıcı kodu almanız gerekmektedir. Bu işlem için [https://cc-form.metu.edu.tr/web/index.php?dil=\_tr&yer=\_ANK](https://cc-form.metu.edu.tr/web/index.php?dil=_tr&yer=_ANK) sayfasında yer alan formu doldurmanız gerekmektedir. Formda yer alan “tercih edilen alan adı” bölümüne talep ettiğiniz _metu.edu.tr_ uzantılı alan adını yazabilirsiniz.

Ancak, alan adı politikamız gereği bölüm/birim altında faaliyet gösteren laboratuvar, çalışma/araştırma grupları vb. yapılara ait web sayfalarının adreslerinin, ilgili alan adı altında, _proje\_adi-birim\_adi.metu.edu.tr_ formatına uygun olarak açılması gerekmektedir. Alan adı talebi yapılırken bu konuya dikkat edilmelidir.

_birim\_adi.metu.edu.tr_ şeklinde **1\. seviye** alan adı talepleri Rektörlük Makamı onayına tabidir. 1. seviye  alan adı taleplerinde bölüm/birimin bağlı olduğu üst birim tarafından (Enstitü/Dekanlık vb.) Rektörlük Makamına resmi yazı yazılması gerekmektedir. Alan adı tanımlama işlemi söz konusu resmi yazının onayına bağlı olarak yürütülmektedir.