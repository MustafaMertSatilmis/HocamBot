[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidb-hizmetlerinin-kapsami-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-09-2017 **Görüntüleme:** 7358


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidb-hizmetlerinin-kapsami-nedir)

# BİDB Hizmetlerinin Kapsamı Nedir?

[BİDB hakkında](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda)

**BİDB HİZMETLERİNİN KAPSAMI NEDİR?**

BİDB tarafından sağlanan tüm hizmetler 7 gün / 24 saat kullanılabilmektedir. Hizmetlerin barındığı tüm sistemler, görevli sistem operatörleri tarafından 7 / 24 gözlenmektedir. Herhangi bir uyarı durumunda ilgili sistemlerin sorumlularına bilgi aktarılmaktadır. Sistem operatörleri, sistem salonunun girişinde vardiya sistemiyle nöbet tutmakta, sunucular, ağ cihazları, iklimlendirme, yangın algılama - söndürme ve kesintisiz güç kaynağı sistemlerini devamlı gözlemlemektedir. Üniversite bilişim ağı, yüksek oranda kesintisiz güç kaynağı sistemleriyle beslenmekte olup tüm hizmetler her an ulaşılabilir durumdadır.