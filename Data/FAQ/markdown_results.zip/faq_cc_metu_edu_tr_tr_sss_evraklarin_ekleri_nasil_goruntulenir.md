[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/evraklarin-ekleri-nasil-goruntulenir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4480


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/evraklarin-ekleri-nasil-goruntulenir)

# Evrakların ekleri nasıl görüntülenir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Görüntülemekte olduğunuz evrakın sağ tarafında bulunan dikey sütundaki "Ekli Dosyalar" düğmesine basarak evrakın eklerini görüp indirebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ek.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.