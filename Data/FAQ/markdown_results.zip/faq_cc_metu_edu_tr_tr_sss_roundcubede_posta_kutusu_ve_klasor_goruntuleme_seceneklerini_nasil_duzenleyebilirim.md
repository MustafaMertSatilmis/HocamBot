[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-posta-kutusu-ve-klasor-goruntuleme-seceneklerini-nasil-duzenleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1249


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-posta-kutusu-ve-klasor-goruntuleme-seceneklerini-nasil-duzenleyebilirim)

# Roundcube'de posta kutusu ve klasör görüntüleme seçeneklerini nasıl düzenleyebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube'de "Ayarlar" ana menüsünde yer alan "Posta Kutusu Görünümü", "İleti Görünümü", "Yeni İleti Oluşturma" ve "Özel Klasörler" sekmelerinde bulunan seçenekler yardımıyla posta kutusu ve klasör görüntüleme ayarlarınızı değiştirebilirsiniz.

Ayrıca, "Ayarlar" ana menüsünden farklı olarak, herhangi bir posta kutusunu görüntülerken bu posta kutusunun sekmesinde belirecek olan "Ayarlar" butonuna tıklayarak da ilgili posta kutusunun "Liste seçenekleri"ni düzenleyebilirsiniz. İlgili posta kutusunda iletilerin hangi sütuna göre sıralanacağını, sıralama düzeninin (artan/azalan) nasıl olacağını ve liste kipini (Liste/sohbetler) buradan değiştirebilirsiniz.