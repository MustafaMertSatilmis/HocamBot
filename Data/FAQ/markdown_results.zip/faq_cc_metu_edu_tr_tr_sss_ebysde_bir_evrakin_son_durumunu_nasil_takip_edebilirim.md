[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bir-evrakin-son-durumunu-nasil-takip-edebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5559


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bir-evrakin-son-durumunu-nasil-takip-edebilirim)

# EBYS'de bir evrakın son durumunu nasıl takip edebilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Evrakı geçmiş bölümünden görüntüledikten sonra ( [http://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir](http://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir)), evrakın akış tarihçesinden evrakın ilerleyişini takip edebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.