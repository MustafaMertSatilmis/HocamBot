[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-dizin-listesinde-gorunmeyen-posta-kutularini-nasil-goruntuleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5511


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-dizin-listesinde-gorunmeyen-posta-kutularini-nasil-goruntuleyebilirim)

# Horde dizin listesinde görünmeyen posta kutularını nasıl görüntüleyebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Dizin listesinde görünmeyen posta kutularını nasıl görüntüleyebilirim?

Uygulamanın yeni sürümünde sadece üye olduğunuz posta kutuları listelenmektedir. Dizin listesinin üst kısmında yer alan Dizin Eylemleri menüsünde bulunan "Tüm Posta Kutularını Göster" seçeneği ile üye olmadığınız posta kutularının da görüntülenmesini sağlayabilirsiniz. Tüm posta kutularını görüntülediğinizde üyeliğiniz bulunmayan posta kutuları _italik_ olarak görüntülenecektir. Üye olmak istediğiniz posta kutusuna sağ tıklayarak "Üye Ol" seçeneği ile üyeliğinizi gerçekleştirebilirsiniz. Aynı zamanda üye olduğunuz herhangi bir posta kutusuna sağ tıklayarak "Üyelikten Çık" seçeneği ile üyeliğinizi iptal edebilirsiniz.

Dizin Eylemleri menüsünde "Üye Olunmayanları Gizle" seçeneği ile sadece üye olduğunuz posta kutularını görüntüleyebilirsiniz.