[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-evrak-icin-gelen-ebys-e-posta-bildirimindeki-baglantidan-diger-evraklarima-nasil-ulasirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4016


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-evrak-icin-gelen-ebys-e-posta-bildirimindeki-baglantidan-diger-evraklarima-nasil-ulasirim)

# Bir Evrak için Gelen EBYS E-posta Bildirimindeki Bağlantıdan Diğer Evraklarıma Nasıl Ulaşırım?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

EBYS'den her bir evrak özelinde gönderilen e-posta içeriklerinden "Dokümanı görüntüle" bağlantısına tıklandığında açılan sayfadan doğrudan ilgili evraka ulaşılmaktadır.

Aynı sayfadan EBYS'deki diğer evraklara ulaşmak için sisteme tekrar giriş yapmanız gerekmeden; ekranın sağ altında bulunan ev simgesini tıklayarak EBYS ana sayfanıza gidebilir ve bu ekranda üst kısımda bulunan "Onaylar" butonuna basarak onaylarınızda işlem yapabileceğiniz bütün evraklara ulaşabilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.