[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-kopyalayabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5209


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-kopyalayabilirim)

# Horde iletileri farklı klasörlere nasıl kopyalayabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### İletileri farklı klasörlere nasıl kopyalayabilirim?

Gelen kutusunda ileti satırını sürükle-bırak yöntemi ile taşırken klavyedeki CTRL tuşunu basılı tutmanız gerekmektedir.