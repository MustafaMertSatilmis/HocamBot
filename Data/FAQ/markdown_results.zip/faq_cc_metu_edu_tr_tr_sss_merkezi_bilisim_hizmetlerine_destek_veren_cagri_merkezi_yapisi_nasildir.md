[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/merkezi-bilisim-hizmetlerine-destek-veren-cagri-merkezi-yapisi-nasildir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-09-2017 **Görüntüleme:** 6096


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/merkezi-bilisim-hizmetlerine-destek-veren-cagri-merkezi-yapisi-nasildir)

# Merkezi Bilişim Hizmetlerine Destek Veren Çağrı Merkezi Yapısı Nasıldır?

[BİDB hakkında](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda)

**MERKEZİ BİLİŞİM HİZMETLERİNE DESTEK VEREN ÇAĞRI MERKEZİ YAPISI NASILDIR?**

ODTÜ bilişim hizmetleri kullanıcılarına yüz yüze, telefon ve elektronik ortamlarda genel destek hizmeti sağlanmaktadır.

Mesai saatleri içi: (0312) 210 3355 (pbx)

Çağrı yönetim sistemi aracılığıyla 4 personel eşliğinde kullanıcı bildirimleri bilişim destek yönetim yazılımında kayıt altına alınmaktadır.

Mesai saatleri dışı: (0312) 210 3318

Mesai saatleri dışında yapılan bildirimler ilgili hizmetin sorumlusu teknik personele aktarılmaktadır.