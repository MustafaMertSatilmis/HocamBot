[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/android-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 8963


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-android-smartphone "How can I find out the MAC (physical) address on an Android Smartphone?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/android-akilli-telefonda-mac-fiziksel-adresini-nasil-ogrenebilirim "Android Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Android Akıllı Telefonda MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

1\. Uygulamalar’ın altında ayarları seçin.

2.  Listenin en altında yer alan ‘Cihaz Hakkında’ (Android telefonlar Telefon Hakkında olarak gösterebilir) yı seçin.

3\. ‘Donanım Bilgisi’ni seçin.

4\. MAC Adresiniz Kablosuz(WiFi) MAC Adresi başlığı altında listelenmiştir.