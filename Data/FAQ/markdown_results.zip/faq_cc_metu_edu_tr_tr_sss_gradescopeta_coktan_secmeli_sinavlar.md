[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gradescopeta-coktan-secmeli-sinavlar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 14-11-2023 **Görüntüleme:** 1316


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/bubble-sheet-assignments-gradescope "Bubble Sheet Assignments in Gradescope ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gradescopeta-coktan-secmeli-sinavlar "Gradescope'ta Çoktan Seçmeli Sınavlar")

# Gradescope'ta Çoktan Seçmeli Sınavlar

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

# Bubble Sheet Assignments

Gradescope'un Bubble Sheet Assignments türü ödevleri, öğrencilerinizin gönderimlerinin otomatik olarak notlandırılması için çoktan seçmeli bir cevap anahtarı oluşturmanıza olanak tanır.

Öğrenci gönderimleri için Gradescope'un 200 soruluk bubble sheet şablonunu kullanmanız gerekir. Sağlanan PDF şablonu aşağıdaki alanları içerir:

- **Ad** \- yüklenen gönderimleri listenizdeki öğrencilerle otomatik olarak eşleştirmek için kullanılır
- **Kimlik** \- öğrenci kimliği; varsa, yüklenen gönderimleri listenizdeki öğrencilerle otomatik olarak eşleştirmek için kullanılabilir
- **Bölüm** \- varsa bir bölüm adı girin
- **Tarih** \- öğrencinin ödevi tamamladığı tarih
- **Sürüm** \- öğrencinin ödevin hangi sürümüne atandığını işaretlemesi için kullanılır
- **Diğer** \- öğrencilerinizden talep ettiğiniz diğer bilgileri gireceğiniz alandır
- **İki yüz cevap alanı** \- iki sayfa üzerinden sağlanır; yalnızca kullanılan sayfaları yükleyin

Şablon, soru/cevap içeriğini içerecek şekilde özelleştirilemez. Öğrencilere Gradescope dışında bir soru listesi ve çoktan seçmeli yanıtlar sağlamanız gerekecektir.

Bubble sheet ödevi oluşturmak için:

1. Kurs kontrol panelinize erişin ve soldaki gezinme menüsünden **Assignments**'ı seçin.
2. Sayfanın altındaki görev çubuğundan **Create Assignment** düğmesini seçin.
3. Ödev türleri listesinden **Bubble Sheet**'i seçin ve ardından sayfanın alt kısmındaki **Next**'i seçin.

Bubble sheet ödevleri hakkında daha fazla bilgi için lütfen [https://help.gradescope.com/article/gkwvq606fq-instructor-questment-bubb...](https://help.gradescope.com/article/gkwvq606fq-instructor-questment-bubble-sheets) adresini ziyaret edin.

**Taramaları Yükleme**

Cevap kağıtlarınızın PDF'lerini oluşturmak için herhangi bir tarayıcıyı kullanabilirsiniz. Gradescope'un [tarama ipuçlarına](https://help.gradescope.com/article/v7ay16jqvt-scanning-tips) göz atın.

1. PDF'lerinizi yüklemeye hazır hale getirdiğinizde Taramaları Yönet sayfasında PDF Dosyalarını Seç'e tıklayın.
2. Dosyalarınızı seçin, yüklenmeye başlayacaklar. Ayrıca gönderimleri doğrudan Taramaları Yönet sayfasına sürükleyip bırakabilirsiniz. Daha hızlı işleme için birden fazla öğrenci gönderimi içeren PDF'leri yüklemeniz önerilir.
3. Taramaları Yönet sayfasında gönderimler oluşturulduğunda Gradescope, Anahattı Düzenle adımında ayarladığınız Ad ve Kimlik bölgelerini kullanarak her gönderimi otomatik olarak listedeki bir öğrenciyle eşleştirmeye çalışır.

**Cevap anahtarı**

Cevap Anahtarı sayfasında ödeviniz için her numaralı soruya doğru cevapları verin. Aynı bubble sheet ödevinin, her biri ayrı cevap anahtarına sahip birden fazla versiyonunu oluşturabilirsiniz.