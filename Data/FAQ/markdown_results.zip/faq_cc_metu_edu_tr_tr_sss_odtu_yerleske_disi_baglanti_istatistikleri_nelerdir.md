[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-yerleske-disi-baglanti-istatistikleri-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-09-2015 **Görüntüleme:** 7392


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-about-metu-campus-connection-statistics "What about METU off-campus connection statistics?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-yerleske-disi-baglanti-istatistikleri-nelerdir "ODTÜ yerleşke dışı bağlantı istatistikleri nelerdir?")

# ODTÜ yerleşke dışı bağlantı istatistikleri nelerdir?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

ODTÜ Yerleşke Dışı Bağlantıları hakkında daha fazla bilgi almak için lütfen [tıklayınız.](https://bidb.metu.edu.tr/odtu-yerleske-disi-baglantilari)