[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/iphone-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-04-2022 **Görüntüleme:** 35815


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-eduroam-wireless-network-my-iphone "How can I connect to eduroam wireless network via my iPhone?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/iphone-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim "iPhone telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?")

# iPhone telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Konfigürasyon dosyasını alıp cihazınıza indirip çalıştırarak Eduroam'a baglanabilirsiniz.

Bunun için telefonun Safari web tarayıcısını kullanarak mobile.config dosyasını [indir](https://faq.cc.metu.edu.tr/tr/system/files/u2/metu_eduroam.mobileconfig)

İndirilen konfigürasyon dosyası (metu\_eduroam.mobileconfig) telefonun ayarlar bölümünde gözükecektir (ayarlar-genel-profil). Konfigürasyon dosyası yüklendikten sonra listelenen ağlarda eduroam seçilir.

User Account kısmında, kullanıcı\_adı@metu.edu.tr ve şifre girilmelidir.