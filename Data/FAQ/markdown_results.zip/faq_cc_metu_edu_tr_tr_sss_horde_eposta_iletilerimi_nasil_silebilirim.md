[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-eposta-iletilerimi-nasil-silebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7016


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-eposta-iletilerimi-nasil-silebilirim)

# Horde Eposta iletilerimi nasıl silebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Eposta iletilerimi nasıl silebilirim?

Bir veya birden fazla e-posta iletinizi silmek istiyorsanız, öncelikle iletilerin sol taraflarında bulunan kutucuklara tıklayarak silmek istediğiniz iletileri seçin. Sonra üst menüde görünen Sil butonuna tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5_sil.png)

Bu işlemden sonra sağ üstte bulunan Diğer seçeneğine tıklayın ve açılır menüden Silinecekleri Temizle butonuna tıklayın.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5_sil2.png)

Seçenekler / Posta altında bulunan "İletilerin Silinmesi ve Taşınması" başlığı ile Gelen kutusunda SİL seçeneğinin işlevini tanımlayabilirsiniz. Eposta mesajlarınızı doğrudan silerek Trash / Çöp kutusuna gönderebilir veya silinmesi için işaretleyebilirsiniz. Silmek için işaretlenen mesajlarınızı Gelen Kutusunda bulunan Diğer / Silinecekleri Temizle seçeneği ile silebilirsiniz. Çöp kutusuna gönderilen mesajları daha sonra çöp kutusundan geri alabilirsiniz ancak Silinecekleri Temizle düğmesine basarak silinen mesajların geri alınması mümkün değildir.

Önceki horde sürümünün aksine yeni horde sürümünde mesaj kutusundaki tüm iletiler tek bir sayfada görüntülenmektedir. TÜMÜNÜ SEÇ işlevi görüntülenen mesaj kutusundaki tüm iletileri seçmektedir. Tüm iletileri seçerek silme işlemi yapmamanız tavsiye edilmektedir.