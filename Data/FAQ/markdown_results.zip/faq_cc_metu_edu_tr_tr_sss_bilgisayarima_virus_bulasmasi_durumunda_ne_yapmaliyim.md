[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarima-virus-bulasmasi-durumunda-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-03-2024 **Görüntüleme:** 11200


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-i-do-case-virus-detectioninfection "What should I do, in case of virus detection/infection?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarima-virus-bulasmasi-durumunda-ne-yapmaliyim "Bilgisayarıma virüs bulaşması durumunda ne yapmalıyım?")

# Bilgisayarıma virüs bulaşması durumunda ne yapmalıyım?

[Virüs](https://faq.cc.metu.edu.tr/tr/groups/virus)

Bilgisayardan virüsü temizlemek için güncel bir antivirüs yazılımı ile tüm diskleri tarayın, virüsü temizleyin ve ardından tekrar virüs problemi olmaması için işletim sistemi güncellemelerini yapın.

Bu işlem için, [software.cc.metu.edu.tr](https://software.cc.metu.edu.tr/) adresinden ücretsiz olarak indirebileceğiniz Symantec antivirüs yazılımını yükleyin. Ağ bağlantı kablosunu çıkararak bilgisayarı güvenli kipte tekrar başlattıktan sonra güncellenmiş antivirüs yazılımı ile tarama yapın. Bu işlem sırasında bulunan virüsleri silin.

Eğer işletim sistemi güncel değilse, virüsler bilgisayarınızı yeniden etkileyebilecektir. Bu nedenle bilgisayarınızın işletim sistemini ve antivirüs yazılımını düzenli güncelleyin.