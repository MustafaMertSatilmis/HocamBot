[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# E-Liste Üyelik Soruları

|     |
| --- |
| [E-liste üyesi olarak E-Liste Servisi arayüzünü nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyesi-olarak-e-liste-servisi-arayuzunu-nasil-kullanabilirim) |
| ["abc-l" listesi üyeliğinden çıkmak istiyorum, nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesi-uyeliginden-cikmak-istiyorum-nasil-yapabilirim) |
| ["abc-l" listesine üye olduğum adresi üyelikten çıkmadan değiştirebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uye-oldugum-adresi-uyelikten-cikmadan-degistirebilir-miyim) |
| ["abc-l" listesine üyeyim fakat listeden bana mesaj gelmiyor. Neden?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-fakat-listeden-bana-mesaj-gelmiyor-neden) |
| ["abc-l" listesine üyeyim. Üyelik şifremi edinmek için e-posta adresimi yazıp şifre hatırlatıcısı butonuna tıkladım ancak şifre bana ulaşmadı. Neden olabilir?](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-uyelik-sifremi-edinmek-icin-e-posta-adresimi-yazip-sifre-hatirlaticisi) |
| ["genel-duyuru", "aras-gor-duyuru" ve/ya "ogr-uye-duyuru" listelerine üyeyim, fakat bu listelerden artık mesaj almak istemiyorum, ne yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/genel-duyuru-aras-gor-duyuru-veya-ogr-uye-duyuru-listelerine-uyeyim-fakat-bu-listelerden-artik) |
| [Bir listeye üye olmak için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bir-listeye-uye-olmak-icin-ne-yapmaliyim) |
| [E-liste üyelerinin gönderdikleri mesajların bir kopyasının kendilerine gelmemesini sağlamak için ne yapmalıyım ?](https://faq.cc.metu.edu.tr/tr/sss/e-liste-uyelerinin-gonderdikleri-mesajlarin-bir-kopyasinin-kendilerine-gelmemesini-saglamak-icin) |
| [Üye olduğum bir e-listenin şifresini hatırlamıyorum; nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-bir-e-listenin-sifresini-hatirlamiyorum-nasil-ogrenebilirim) |
| [Üye olduğum tüm e-listeler için nasıl ortak bir e-liste şifresi tanımlayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeler-icin-nasil-ortak-bir-e-liste-sifresi-tanimlayabilirim) |
| [Üye olduğum tüm e-listeleri nasıl görüntülerim?](https://faq.cc.metu.edu.tr/tr/sss/uye-oldugum-tum-e-listeleri-nasil-goruntulerim) |
| [Üyesi olduğum bir listeye gönderdiğim mesajlar neden dağılmıyor?](https://faq.cc.metu.edu.tr/tr/sss/uyesi-oldugum-bir-listeye-gonderdigim-mesajlar-neden-dagilmiyor) |
| [Üyesi olduğum herhangi bir listeye gönderilen mesajları toplu (digest) olarak almak istiyorum. Üyelik ayarlarımı nereden değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/uyesi-oldugum-herhangi-bir-listeye-gonderilen-mesajlari-toplu-digest-olarak-almak-istiyorum) |

[![Subscribe to E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/207/all/feed "Subscribe to E-Liste Üyelik Soruları")