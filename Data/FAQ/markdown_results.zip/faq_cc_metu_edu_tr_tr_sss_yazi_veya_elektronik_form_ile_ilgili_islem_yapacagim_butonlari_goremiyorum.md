[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yazi-veya-elektronik-form-ile-ilgili-islem-yapacagim-butonlari-goremiyorum#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 2567


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yazi-veya-elektronik-form-ile-ilgili-islem-yapacagim-butonlari-goremiyorum)

# Gelen bir yazı veya elektronik form ile ilgili işlem yapacağım butonları göremiyorum, ne yapmalıyım?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

Kullanıcılarımıza ulaşan yazı veya elektronik formlarla ilgili onayla, sevk et, imzaya gönder, indir, iade et, gereği yapılmıştır gibi işlemlerin yapılmasını ya da yazı/form ile ilgili akış tarihçesine, notlara vb. erişilmesini sağlayan aksiyon butonları yazı ya da elektronik formların hemen üst kısmındaki alanda görüntülenmektedir.

Eğer size gelen bir yazı ya da elektronik formla ilgili butonları göremiyorsanız bu alanı kapalı hale getirmiş olabilirsiniz. Butonları tekrar görebilmek için alanın sağ bölümünde bulunan oku kullanarak alanı tekrar açık hale getirmelisiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/aksiyon-butonlari_1.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/aksiyon-butonlari_2.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.