[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-gondericileri-karaliste-veya-beyaz-listeye-nasil-ekleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5378


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-gondericileri-karaliste-veya-beyaz-listeye-nasil-ekleyebilirim)

# Horde göndericileri karaliste veya beyaz listeye nasıl ekleyebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Göndericileri karaliste veya beyaz listeye nasıl ekleyebilirim?

Göndericileri kara liste ya da beyaz listeye eklemek için sağ üstte bulunan Diğer butonuna tıklayın. Açılır menüden Kara Liste ya da Beyaz Liste butonlarına tıklayarak açılan sayfada eklemek istediğiniz mail adreslerini yazınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde5_karaliste.png)