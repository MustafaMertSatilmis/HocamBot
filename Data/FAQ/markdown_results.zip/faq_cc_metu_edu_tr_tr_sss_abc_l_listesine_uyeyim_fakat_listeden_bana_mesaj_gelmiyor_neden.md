[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-fakat-listeden-bana-mesaj-gelmiyor-neden#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 9636


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-member-abc-l-list-i-can-not-receive-messages-sent-list-anymore-what-may-be-problem-turkish "I am a member of \"abc-l\" list but I can not receive the messages sent to the list anymore. What may be the problem? (in Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/abc-l-listesine-uyeyim-fakat-listeden-bana-mesaj-gelmiyor-neden "\"abc-l\" listesine üyeyim fakat listeden bana mesaj gelmiyor. Neden?")

# "abc-l" listesine üyeyim fakat listeden bana mesaj gelmiyor. Neden?

[E-Liste Üyelik Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-uyelik-sorulari)

Önceden mesajları alabiliyorken, belli bir tarihten sonra almamaya başladıysanız kullanıcı hesabınızın ve/ya liste üyeliğinizin ayarlarında değişiklik meydana gelmiş olabilir. Liste üyelik durumunuzu kontrol için **abc-l-owner![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr** adresinden liste yöneticisiyle iletişime geçerek liste üyelik durumunuzu, üyeliğinizin dondurulup dondurulmadığını kontrol ediniz.

Liste ayarları ile ilgili bir sorun yoksa kullanıcı hesabı ayarlarınızda farklı bir düzenleme gerçekleşmiş olabilir (yönlendirme, mesaj kutunuzun dolması, spam ayarlarında değişiklik vb.) Kullanıcı hesabı ayarlarınızın kontrolü için e-posta hizmeti aldığınız kurumun yetkilileriyle iletişime geçmeniz gerekmektedir. E-posta adresiniz **kullanici\_adi![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr** şeklindeyse [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresi üzerinden bizimle iletişime geçebilirsiniz.

(Yukarıda geçen "abc-l" ifadesi liste ismi için örnek olarak verilmiştir.)