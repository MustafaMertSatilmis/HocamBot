[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verilen-kisi-vekaleti-reddetme-hakkina-sahip-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4412


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/vekalet-verilen-kisi-vekaleti-reddetme-hakkina-sahip-mi)

# Vekalet verilen kişi vekaleti reddetme hakkına sahip mi?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Vekalet verilen kişi vekaleti reddetme hakkına sahip değildir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.