[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/roundcube#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Roundcube

|     |
| --- |
| [Roundcube ile e-postalarımı nasıl indirebilirim?](https://faq.cc.metu.edu.tr/faq/roundcube-ile-e-postalarimi-nasil-indirebilirim) |
| [Roundcube ile ODTÜ merkezi e-posta servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcube-ile-odtu-merkezi-e-posta-servisini-nasil-kullanabilirim) |
| [Roundcube'de adres defterimi nasıl oluşturabilir ve düzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-adres-defterimi-nasil-olusturabilir-ve-duzenleyebilirim) |
| [Roundcube'de bir iletinin tam başlık bilgisini nasıl görebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-bir-iletinin-tam-baslik-bilgisini-nasil-gorebilirim) |
| [Roundcube'de e-postalarımı nasıl silebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-e-postalarimi-nasil-silebilirim) |
| [Roundcube'de gelen e-postaları nasıl filtreleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gelen-e-postalari-nasil-filtreleyebilirim) |
| [Roundcube'de gönderdiğim e-postalarımın biçimini (HTML ya da düz metin) nasıl değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-gonderdigim-e-postalarimin-bicimini-html-ya-da-duz-metin-nasil-degistirebilirim) |
| [Roundcube'de iletilere nasıl imza ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletilere-nasil-imza-ekleyebilirim) |
| [Roundcube'de iletileri farklı klasörlere nasıl kopyalayabilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-kopyalayabilirim) |
| [Roundcube'de iletileri farklı klasörlere nasıl taşıyabilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletileri-farkli-klasorlere-nasil-tasiyabilirim) |
| [Roundcube'de iletilerimi nasıl görüntüleyebilirim?](https://faq.cc.metu.edu.tr/faq/roundcubede-iletilerimi-nasil-goruntuleyebilirim) |
| [Roundcube'de kullanıcı arayüzü ayarlarını (Dil, saat dilimi, saat biçimi, tarih biçimi vb.) nasıl değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-kullanici-arayuzu-ayarlarini-dil-saat-dilimi-saat-bicimi-tarih-bicimi-vb-nasil) |
| [Roundcube'de nasıl e-posta gönderebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-nasil-e-posta-gonderebilirim) |
| [Roundcube'de oluşturduğum bir iletiye nasıl dosya (eklenti) ekleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-olusturdugum-bir-iletiye-nasil-dosya-eklenti-ekleyebilirim) |
| [Roundcube'de posta kutusu ve klasör görüntüleme seçeneklerini nasıl düzenleyebilirim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-posta-kutusu-ve-klasor-goruntuleme-seceneklerini-nasil-duzenleyebilirim) |
| [Roundcube’de klasörlerimi nasıl düzenleyebilirim? Yeni bir klasör oluşturabilir ya da oluşturduğum klasörlerimi silebilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-klasorlerimi-nasil-duzenleyebilirim-yeni-bir-klasor-olusturabilir-ya-da-olusturdugum) |

[![Subscribe to Roundcube](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/389/all/feed "Subscribe to Roundcube")