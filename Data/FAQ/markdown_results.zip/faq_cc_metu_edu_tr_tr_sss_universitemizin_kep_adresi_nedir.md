[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/universitemizin-kep-adresi-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5048


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/universitemizin-kep-adresi-nedir)

# Üniversitemizin KEP Adresi nedir?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

Üniversitemizin Kayıtlı Elektronik Posta (KEP) adresi [odtu@hs01.kep.tr](mailto:odtu@hs01.kep.tr) dir.

KEP resmi yazışmaların elektronik ortamda mevzuata uygun, uluslararası standartlarda ve teknik olarak güvenli bir şekilde yapılmasına imkan sağlayan bir sistemdir. KEP, bilinen elektronik postaya ilave olarak elektronik postanın;

- Göndericisi görünen kişi/kuruluş tarafından gönderilip gönderilmediği,
- Alıcıya ulaşıp ulaşmadığını ve ne zaman ulaştığı,
- Alıcısı tarafından okunup okunmadığı ve
- İhtiyaç duyulması halinde elektronik postaya yeniden erişilebilmesi

ile ilgili delil hizmetlerini sunan bir sistemdir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.