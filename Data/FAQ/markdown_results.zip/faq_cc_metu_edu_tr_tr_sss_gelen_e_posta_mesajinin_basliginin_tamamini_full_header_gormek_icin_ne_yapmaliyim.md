[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-06-2023 **Görüntüleme:** 25146


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-do-i-view-full-header-incoming-e-mail-messages "How do I view the full header of incoming e-mail messages?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim "Gelen e-posta mesajının başlığının tamamını (full header) görmek için ne yapmalıyım?")

# Gelen e-posta mesajının başlığının tamamını (full header) görmek için ne yapmalıyım?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Mesajınızın "full header"ını (gelen mesaj başlığının tamamı) bir başkasına yönlendirmek istediğinizde eklenti yapmadan doğrudan ilgili adrese yönlendiriniz. Bu uygulamayı en çok, size gelen bir spam mail'i incelemek üzere ilgili sistem yöneticisine bildirirken kullanabilirsiniz.

Aşağıdaki bağlantılara tıklayıp yaygın kulllanılan e-posta okuma programlarında mesaj başlığının nasıl görüntülenebileceğinizi inceleyebilirsiniz:

- [Horde](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#Horde)
- [Gmail](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#Gmail)
- [Outlook](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#Outlook)
- [Outlook.com/Hotmail.com Web](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#OutlookWeb)
- [Mozilla Thunderbird](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#MozillaThunderbird)
- [Yahoo.com Web](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#YahooWeb)
- [Mail for Max OS X uygulaması](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#MailMacOSX)
- [Roundcube Webmail](https://faq.cc.metu.edu.tr/tr/sss/gelen-e-posta-mesajinin-basliginin-tamamini-full-header-gormek-icin-ne-yapmaliyim#rcube)

**Mobil cihazlardaki e-posta okuma uygulamalarında full header bilgisi görüntüle özelliği bulunmayabildiği için tam başlık bilgilerinin web ya da masaüstü tabanlı e-posta uygulamaları ile görüntülenip, incelenmek üzere Bilişim Destek Ekibi'ne gönderilmesi önerilmektedir.**

Bu sayfada bulamadığınız e-posta okuma programları için **[http://emailheaders.net/](http://emailheaders.net/)** sayfasında "Read Email Headers" sekmesi altındaki listeyi kontrol edebilirsiniz.

**Horde**

**Horde** E-Posta arayüzü kullanarak gelen mesajınızın başlığının tamamını (full header) görebilmek için, iletiyi görüntülerken **\+ işareti** (Diğer seçenekler) altındaki **Kaynağı Görüntüle** bağlantısını kullanabilirsiniz.

**Gmail**

**Gmail** E-Posta arayüzü kullanarak gelen mesajınızın başlığının tamamını (full header) görebilmek için, iletiyi görüntülerken sağ kısımdaki tarih bilgisinin en sağında bulunan aşağı ok **işareti** (Diğer seçenekler) altındaki **Orijinali Göster** bağlantısını kullanabilirsiniz. [https://support.google.com/mail/answer/29436?hl=tr](https://support.google.com/mail/answer/29436?hl=tr) adresindeki yardım sayfasından daha ayrıntılı bilgi alabilirsiniz.

**Outlook**

**Outlook** E-posta uygulaması kullanarak gelen mesajınızın başlığının tamamını (full header) görebilmek için, gelen e-postayı çift tıklayın ve **Dosya** menüsünden **Özellikler** seçeneğini tıklayınız. Açılan pencerede Internet Başlığı kısmında mesaj başlığının tamamını görüntüleyebilirsiniz. [http://emailheaders.net/outlook.html](http://emailheaders.net/outlook.html) adresindeki yardım sayfasından daha ayrıntılı bilgi alabilirsiniz.

**Outlook.com/Hotmail.com Web**

**Outlook.com/Hotmail.com Web** E-Posta arayüzü kullanarak gelen mesajınızın başlığının tamamını (full header) görebilmek için, iletiyi görüntülerken sağ kısımdaki bulunan aşağı ok işareti tıklanarak altındaki **İleti Kaynağını Görüntüle** bağlantısını kullanabilirsiniz. [http://emailheaders.net/hotmail.html](http://emailheaders.net/hotmail.html) adresindeki yardım sayfasından daha ayrıntılı bilgi alabilirsiniz.

**Mozilla Thunderbird**

**Mozilla Thunderbird** E-posta uygulaması kullanarak gelen mesajınızın başlığının tamamını (full header) görebilmek için, iletiyi görüntülerken Görüntüle (View) menüsünden Mesaj Kaynağı (Message Source)'nı seçebilirsiniz. Görüntüle (View) menüsünü ekranda göremiyorsanız, klayveden Alt tuşuna basabilir veya seçtiğiniz mesajınızın başlığının tamamını görüntülemek için Ctrl + U tuşlarına birlikte basabilirsiniz. [http://emailheaders.net/thunderbird.html](http://emailheaders.net/thunderbird.html) adresindeki yardım sayfasından daha ayrıntılı bilgi alabilirsiniz.

**Yahoo.com Web**

**Yahoo.com Web** E-Posta arayüzü kullanarak gelen mesajınızın başlığının tamamını (full header) görebilmek için, iletiyi görüntülerken üst kısımdaki Spam düğmesinin yanındaki üç nokta (...) düğmesine tıklanarak altındaki **View Raw Message** (Ham Metni Görüntüle) bağlantısını kullanabilirsiniz. [https://help.yahoo.com/kb/SLN22026.html](https://help.yahoo.com/kb/SLN22026.html) adresindeki yardım sayfasından daha ayrıntılı bilgi alabilirsiniz.

**Mail for Mac OS X**

Mac OS X işletim sistemlerindeki Posta uygulamasında ( **Mail for Mac OS X)** gelen mesajınızın başlığının tamamını (full header) görebilmek için Görüntüle (View) menüsü altındaki Mesaj (Message) kısmından Ham Kaynak (Raw Source) ya da Tüm Başlıklar (All Headers) seçeneklerini kullanabilirsiniz. [http://osxdaily.com/2016/04/06/show-long-email-header-mac-mail-osx](http://osxdaily.com/2016/04/06/show-long-email-header-mac-mail-osx) adresindeki yardım sayfasından daha ayrıntılı bilgi alabilirsiniz.

**Roundcube Webmail**

Roundcube webmail uygulamasında gelen mesajın tam başlık bilgisini öğrenmek için epostayı görüntüledikten sonra DİĞER ve "Kaynağı Görüntüle" seçeneklerini kullanabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/roundcube_baslik.png)