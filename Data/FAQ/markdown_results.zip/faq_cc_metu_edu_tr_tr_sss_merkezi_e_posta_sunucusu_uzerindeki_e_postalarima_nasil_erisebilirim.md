[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/merkezi-e-posta-sunucusu-uzerindeki-e-postalarima-nasil-erisebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 10484


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-access-my-e-mails-located-central-e-mail-server "How can I access to my e-mails located on the central e-mail server?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/merkezi-e-posta-sunucusu-uzerindeki-e-postalarima-nasil-erisebilirim "Merkezi e-posta sunucusu üzerindeki e-postalarıma nasıl erişebilirim?")

# Merkezi e-posta sunucusu üzerindeki e-postalarıma nasıl erişebilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

SquirrelMail, Horde ve bilgisayar üzerine kurulacak olan e-posta istemci yazılımlarından (Microsoft Outlook, Mozilla Thunderbird gibi) herhangi birini kullanarak merkezi e-posta sunucusu üzerindeki e-postalarınıza erişebilir, e-posta gönderebilirsiniz. Web tabanlı istemciler üzerinden e-postalarınızı okumak için [http://metumail.metu.edu.tr/](http://metumail.metu.edu.tr/) adresini ziyaret ediniz.

![Metu mail main](https://faq.cc.metu.edu.tr/tr/system/files/u2/metumail_main.png)