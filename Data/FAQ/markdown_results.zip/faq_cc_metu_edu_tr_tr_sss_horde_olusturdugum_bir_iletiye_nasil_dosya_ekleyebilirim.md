[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-olusturdugum-bir-iletiye-nasil-dosya-ekleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5495


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-olusturdugum-bir-iletiye-nasil-dosya-ekleyebilirim)

# Horde oluşturduğum bir iletiye nasıl dosya ekleyebilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Oluşturduğum bir iletiye nasıl dosya ekleyebilirim?

Yeni ileti düğmesine basarak yeni ileti yazma işlemini başlatınız. Dosya ekle düğmesine basarak iletinize eklemek istediğiniz dosyayı seçiniz. Başka bir dosya eklemek isterseniz aynı işlemi tekrarlayınız. Eklediğiniz bir dosyayı yanındaki OK işaretine basarak silebilirsiniz. İletinizin alıcısı, konusu ve içeriğini yazarak Gönder düğmesine basmanız yeterlidir.