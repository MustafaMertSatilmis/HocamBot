[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-bidb-ftp-servisi-var-midir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-09-2015 **Görüntüleme:** 8194


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/there-ftp-service-metu-cc "Is there a FTP Service of METU CC?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-bidb-ftp-servisi-var-midir "ODTÜ BİDB FTP Servisi var mıdır?")

# ODTÜ BİDB FTP Servisi var mıdır?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

ODTÜ BİDB FTP Servisi hakkında daha fazla bilgi almak için lütfen [tıklayınız.](https://bidb.metu.edu.tr/odtu-bidb-ftp-servisi)