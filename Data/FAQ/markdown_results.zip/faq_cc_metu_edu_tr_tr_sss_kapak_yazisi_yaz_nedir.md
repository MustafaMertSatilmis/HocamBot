[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kapak-yazisi-yaz-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5423


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kapak-yazisi-yaz-nedir "Kapak Yazısı Yaz nedir? ")

# Kapak Yazısı Yaz nedir?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

1. Çalıştığınız evrakın üzerinde bulunan "Kapak Yazısı Yaz" butonuna tıkladığınızda açık olan evrak sonlanacak ve yeni hazırlanacak evrak onay listenize düşecektir.
2. Onaylar listenizde bulunan bu evrağı açtığınızda önceki yazının ilgi kısmına otomatik olarak eklenmiş olduğunu görebilirsiniz.
3. Daha sonra yazının kalan kısımlarını doldurarak yazıyı bir sonraki birime gönderdiğinizde yazıyı alan birim, ilişkili evraklar sekmesinde ilgi olarak eklenmiş evraka ulaşabileceklerdir.

**Not:** Yanlışlıkla "Kapak yazısı yaz" butonuna tıklandığında veya vazgeçildiğinde evrakı onaylarınıza tekrar düşürmek için EBYS Menüsü altındaki "Evrak Geri Al" işlevi kullanılmalıdır.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.