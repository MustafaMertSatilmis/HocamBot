[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/meturoam#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-08-2023 **Görüntüleme:** 212235


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/meturoam "How can I connect to meturoam network?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/meturoam "meturoam ağına nasıl bağlanabilirim?")

# meturoam ağına nasıl bağlanabilirim?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Bir kablosuz cihazın ODTÜ kablosuz ağına bağlanabilmesi için WPA2 Kurumsal sistemini ve PEAP/MSCHAPv2 algoritmalarını desteklemesi gerekmektedir. meturoam yayını ile uyumlu OLMADIĞI bilinen popüler cihazlar için [bu bağlantıyı](https://faq.cc.metu.edu.tr/tr/sss/hangi-cihazlar-meturoam-baglantisini-desteklememektedir) ziyaret edebilirsiniz.

Meturoam kablosuz ağına bağlanmak için ODTÜ kullanıcı koduna ve meturoam şifresine ihtiyacınız vardır. meturoam şifreniz bulunuyorsa, [bağlantı ayarlarına](https://faq.cc.metu.edu.tr/tr/sss/meturoam#howto) geçebilirsiniz.

Eğer daha önce meturoam bağlantısı için şifre oluşturmadıysanız veya şifrenizi yenilemek istiyorsanız, [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) sayfasına giriş yaparak Wireless simgesi ve ardından **"m** **eturoam"** simgesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/meturoam_newlogo.jpg)

Meturoam sayfasında, netregister sayfasına giriş yaptığınız kullanıcı kodu ile bu hizmete özel kullanacağınız şifrenizi oluşturabilirsiniz. _(Bazı Android ve IOS cihazlarda, şifrede bulunan #, ', $, vb. özel karakterler bağlantı yapılmasına engel olabilmektedir. Eğer bilgisayardan meturoam bağlantısı yapabiliyor ancak Android veya IOS cihazınızla bağlantı sorunu yaşıyorsanız, şifrenizde bulunan özel karakterleri kontrol ediniz ve farklı karakterlerle değiştiriniz.)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/meturoam-password.png)

**Bağlantı ayarları**

- meturoam bağlantısı için şifre oluşturduktan sonra tüm kablosuz cihazlarınız ile meturoam yayınına bağlanabilirsiniz, her cihaz için ayrı bir şifre oluşturmanız gerekmemektedir.
- Bağlantı sırasında sorulması durumunda EAP yöntemi olarak **PEAP** ve Faz 2 doğrulama olarak da **MSCHAPv2** seçilmelidir. (Yeni nesil telefonlarda Faz 2 doğrulama seçeneği _Gelişmiş_ ayarlar altında bulunmaktadır.)
- ODTÜ merkezi kullanıcı kodunuz ve meturoam şifreniz ile bağlantı sağlayabilirsiniz. (Kullanıcı kodu olarak [ad.soyad@metu.edu.tr](mailto:ad.soyad@metu.edu.tr) eposta adresi yönlendirmesi yerine [e123456@metu.edu.tr](mailto:e123456@metu.edu.tr) şeklindeki kullanıcı kodunu kullanmanız gerekmektedir.)
- Windows 10 işletim sistemi için herhangi bir protokol seçilmeden sadece kullanıcı kodu ve şifre ile bağlantı kurulabilir. [Linux işletim sistemleri](https://faq.cc.metu.edu.tr/tr/system/files/u2/meturoam-ubuntu.png) ile Windows 10 öncesi işletim sistemlerinde **WPA2-Enterprise (WPA2-Kurumsal)** ve **AES** şifreleme elle seçilerek tanımlama yapılmalıdır.
- Mobil cihazlarınızın klavyesindeki otomatik tamamlama özelliğini kullanıyorsanız, kullanıcı kodunuzu yazarken son karaktere dikkat ediniz. Otomatik tamamlama sonrasında eklenen boşluk karakterini silmeniz gerekmektedir.
- Sertifika sorulursa "Doğrulama" seçeneğini işaretleyebilirsiniz. (Bazı Android cihazlarda sertifika alanı zorunlu olabilir, bu cihazlarda "Sistem Sertifikalarını Kullan" seçeneğini işaretleyerek border.metu.edu.tr netlogin.metu.edu.tr adresini yazabilirsiniz.)
- Anonim kimlik alanını boş bırakabilirsiniz. (Cihazınızda zorunlu olması durumunda [anonim@metu.edu.tr](mailto:anonim@metu.edu.tr) yazılabilir.)
- Raspberry pi cihazları için aşağıdaki ayarları wpa\_supplicant.conf dosyasına ekleyiniz.

network={

ssid="meturoam"

key\_mgmt=WPA-EAP

pairwise=CCMP

eap=PEAP

identity="< username >"

anonymous\_identity=" [anonymous@metu.edu.tr](mailto:anonymous@metu.edu.tr)"

password="< password >"

}

Sonrasında wpa\_supplicant yeniden başlatınız. Dosya adları ve adresleri kullandığınız sürüme göre değişiklik gösterebilir.

killall wpa\_supplicant

wpa\_supplicant -B -Dwext -i wlan0 -c /etc/wpa\_supplicant/wpa\_supplicant.conf -f /var/log/wpa\_supplicant.log


![](https://faq.cc.metu.edu.tr/tr/system/files/u2/meturoam-password2.png)

Meturoam şifrenizi unutursanız, yukarıdaki adımları takip ederek yeni bir şifre oluşturabilirsiniz.

Meturoam şifresi oluşturmak istemeyen kullanıcılarımız [eduroam](https://faq.cc.metu.edu.tr/tr/sss/eduroama-nasil-baglanilir) ağını da kullanabilirler.

**!!! Android 6 ve önceki sürümleri kullanan bazı Android cihazlarda kablosuz ağa bağlanma ile ilgili problemler yaşandığı tespit edildi. Zaman zaman bu cihazların ekranında kablosuz ağ bağlantısı kurulmuş olarak görünmesine rağmen cihaz İnternet'e erişememektedir. Bu sorun Android yazılımı içerisindeki bir hatadan kaynaklanmakta ve bu hata nedeniyle bahsi geçen cihazlar geçerlilik süresi dolmuş olmasına rağmen daha önceden DHCP üzerinden aldıkları ip adresini kullanmaya çalışmaktadır. Bu sorun ile karşılaştığınızda lütfen cihazınızın Wi-Fi bağlantısını kapatıp tekrar aktif hale getirin.**