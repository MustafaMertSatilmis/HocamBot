[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 7663


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm)

# EBYS yazılarında görünen telefon numaram alanı boş veya yanlış, nasıl ekler veya değiştiririm?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

[**EBYS'ye Telefon Numarası Ekleme**](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm#Ekle)

[**EBYS'deki Telefon Numarasını Değiştirme**](https://faq.cc.metu.edu.tr/tr/sss/ebys-yazilarinda-gorunen-telefon-numaram-alani-bos-veya-yanlis-nasil-ekler-veya-degistiririm#degistir)

* * *

**EBYS'ye Telefon Numarası Ekleme**

1- EBYS menüsünden telefon numaram alanına tıklayarak "Ekle" düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/telefonnumaram0.png)

2- Açılan sayfada isminizin altına EBYS'de görünmesini istediğiniz telefon numarasını +90312210xxxx formatında yazınız ve yukarıdaki "Onayla" düğmesine basınız. Telefon numaranız kaydolmuş durumdadır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/telefonnumaram1.png)

* * *

**EBYS'deki Telefon Numarasını Değiştirme**

1- EBYS menüsünden telefon numaram alanına tıklayınız. Ardından isminizin ve mevcut kayıtlı telefon numaranızın göründüğü satırdaki düzenleme simgesini tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/telefonnumaram2.png)

2- Açılan sayfada telefon numaranızda gerekli değişikliği yapınız. Telefon numaranızın +90312210xxxx formatında olmasına özen gösteriniz. Değişikliği yaptıktan sonra "Değişiklikleri Kaydet" düğmesine basınız ve formu sağ üstteki "x" işaretinden kapatınız. Numaranız güncellenmiştir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/telefonnumaram4.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.