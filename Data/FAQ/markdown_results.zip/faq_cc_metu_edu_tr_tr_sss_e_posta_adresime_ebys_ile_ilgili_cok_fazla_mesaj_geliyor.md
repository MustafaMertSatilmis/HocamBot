[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-posta-adresime-ebys-ile-ilgili-cok-fazla-mesaj-geliyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5341


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-posta-adresime-ebys-ile-ilgili-cok-fazla-mesaj-geliyor)

# E-posta adresime EBYS ile ilgili çok fazla mesaj geliyor, bu mesajları almamak için ne yapabilirim?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

EBYS'de oluşturularak akışa giren evrakların her bir durum değişikliğinde (havale edilmesi, imzalanması vb.), akışta yer alan kişilere bu durumları bildiren e-posta mesajları otomatik olarak iletilmektedir.

Otomatik gönderilen bu mesajların kapatılmasını sağlayan bir özellik henüz bulunmamaktadır.

Kullanıcılarımız e-posta hesaplarının Gelen Kutusuna (Inbox) EBYS ile ilgili çok fazla mesaj geldiğini düşünüyor ve bu mesajları görmek istemiyorlarsa, gelen mesajları filtreleyerek e-posta hesabı altında oluşturabilecekleri ayrı bir klasöre taşınmasını sağlayabilirler.

Bu şekilde düzenleme yapmak isteyen kullanıcılarımız [http://faq.cc.metu.edu.tr/tr/sss/gelen-e-postalari-nasil-filtreleyebilirim](http://faq.cc.metu.edu.tr/tr/sss/gelen-e-postalari-nasil-filtreleyebilirim) adresindeki bilgilerden faydalanabilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.