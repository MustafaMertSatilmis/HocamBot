[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/imzalanmis-bir-yazida-sonradan-farkedilen-bir-hatayi-nasil-duzeltebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4882


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/imzalanmis-bir-yazida-sonradan-farkedilen-bir-hatayi-nasil-duzeltebilirim)

# İmzalanmış bir yazıda sonradan farkedilen bir hatayı nasıl düzeltebilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

İmzalanmış bir belgede geri planda evrak üzerinde bir çok işlem yapılmış bulunmaktadır (e–imzanın yer alması, zaman damgası basılması, EYP paketinin oluşması ve ekleri varsa eklere imzaların basılması, evrakın değiştirilemez bir bütün olarak belge statütüsünün kazandırılması vb.).

Bu işlemler imza işlemi gerçekleştiği anda uygulanan işlemlerdir. Bu sebeple imza sonrası sekretere gelen yazılar değiştirilememekte; yazının baştan oluşturulması gerekmektedir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.