[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-e-postalarimi-nasil-silebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1274


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-e-postalarimi-nasil-silebilirim)

# Roundcube'de e-postalarımı nasıl silebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube kullanarak bir posta kutusundaki tüm iletileri ya da seçeceğiniz belirli iletileri silebilirsiniz.

Silmek istediğiniz e-postaları seçtikten sonra ekranda bulunan "Sil" butonuna tıkladığınızda, bu e-postalar "Çöp" klasörüne taşınır.

Hesabınızdan tamamen silmek istediğiniz e-postaları "Çöp" klasöründen de silmeniz gerekir. Ana menüde yer alan "İletiler" sekmesinde "Çöp" butonuna tıklayarak "Çöp" klasörüne ulaşabilirsiniz. "Çöp" klasöründe bulunan e-postalardan tamamen silmek istediklerinizi seçip "Sil" butonuna tıkladığınızda bu e-postalar başka bir klasöre taşınmadan doğrudan silinecektir.

"Çöp" klasörüne gönderdiğiniz e-postalarınızın oturumu kapattığınızda otomatik olarak silinmesini sağlayabilirsiniz. Bunun için ana menüde "Ayarlar" sekmesinde "Sunucu Ayarları" butonuna tıklayıp, "Bakım" bölümünde "Oturum kapatıldığında Çöp boşaltılsın" seçeneğini seçili duruma getirerek kaydediniz. Oturumunuz açıkken Gelen Kutusundan ya da diğer klasörlerinizden sildiğiniz ve Çöp kutusuna taşınmış olan e-postalarınız, oturumunuzu kapattığınızda Çöp kutusundan otomatik olarak silinecektir.