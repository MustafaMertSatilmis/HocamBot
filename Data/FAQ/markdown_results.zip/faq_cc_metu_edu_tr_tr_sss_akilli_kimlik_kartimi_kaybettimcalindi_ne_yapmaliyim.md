[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-kaybettimcalindi-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2021 **Görüntüleme:** 11279


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-smartcard-loststolen-what-should-i-do "My smartcard is lost/stolen. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-kaybettimcalindi-ne-yapmaliyim "Akıllı kimlik kartımı kaybettim/çalındı, ne yapmalıyım?")

# Akıllı kimlik kartımı kaybettim/çalındı, ne yapmalıyım?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kimlik kartınızı kaybettiğinizi/çalındığını fark ettiğinizde, cardinfo.metu.edu.tr adresinden kartınızı iptal etmelisiniz. Bu durumda akıllı kimlik kartınız sistem tarafından “iptal” edilir.