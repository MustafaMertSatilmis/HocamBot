[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/android-isletim-sistemi-yuklu-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-08-2023 **Görüntüleme:** 314350


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-eduroam-wireless-network-android-operating-system-installed-phone "How can I connect to eduroam wireless network via an Android operating system installed phone?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/android-isletim-sistemi-yuklu-telefonumdan-eduroam-kablosuz-agina-nasil-baglanabilirim "Android işletim sistemi yüklü telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?")

# Android işletim sistemi yüklü telefonumdan eduroam kablosuz ağına nasıl bağlanabilirim?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Eduroam kablosuz ağına bağlanmak için telefonunuzda **Ayarlar > Kablosuz ve ağ > Wi-Fi Ayarları** seçeneklerini izleyerek kablosuz ağların görüntülendiği ekrana gelin.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_eduroam_and01_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_eduroam_and02_tr.jpg) |

"eduroam" ağını seçtikten sonra açılan bağlantı ayarları menüsünde "EAP yöntemi" listesinden **TTLS**, "Faz 2 yetkilendirmesi" listesinden **PAP** seçeneğini seçin. "CA Sertifikası" ve "Kullanıcı Sertifikası" seçeneklerini **Belirsiz** şeklinde bırakın. "Kimlik" kutusuna e-posta adresinizi, "Şifre" kutusuna parolanızı yazın. "İsimsiz kimlik" kutusunu boş bırakıp **Bağlan** düğmesine tıklayın. Yeni nesil Android telefonlarda Faz 2 yetkilendirme seçenekleri Gelişmiş / Advanced menüsünde de bulunabilmektedir.

|     |     |     |
| --- | --- | --- |
| ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_eduroam_and03_tr.jpg) |  | ![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_eduroam_and04_tr.jpg) |

Bu işlemlerden sonra telefonun üst bildirim satırında bağlantının kuruluduğunu belirten simge görünür hale gelecektir.

User Account kısmında, kullanıcı\_adı@metu.edu.tr ve şifre girilmelidir.

Yeni cihazlarda " **alan adı**" kısmı bulunmaktadır. Bu kısma **"border.metu.edu.tr"**" **netlogin.metu.edu.tr**" bilgisini girebilirsiniz.

**!!! Android 6 ve önceki sürümleri kullanan bazı Android cihazlarda kablosuz ağa bağlanma ile ilgili problemler yaşandığı tespit edildi. Zaman zaman bu cihazların ekranında kablosuz ağ bağlantısı kurulmuş olarak görünmesine rağmen cihaz İnternet'e erişememektedir. Bu sorun Android yazılımı içerisindeki bir hatadan kaynaklanmakta ve bu hata nedeniyle bahsi geçen cihazlar geçerlilik süresi dolmuş olmasına rağmen daha önceden DHCP üzerinden aldıkları ip adresini kullanmaya çalışmaktadır. Bu sorun ile karşılaştığınızda lütfen cihazınızın Wi-Fi bağlantısını kapatıp tekrar aktif hale getirin.**