[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisimi-kisitlanmis-nedenini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 7521


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-ip-access-has-been-restricted-how-can-i-find-out-reason "My IP access has been restricted. How can I find out the reason?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisimi-kisitlanmis-nedenini-nasil-ogrenebilirim "Bilgisayarımın IP erişimi kısıtlanmış. Nedenini nasıl öğrenebilirim?")

# Bilgisayarımın IP erişimi kısıtlanmış. Nedenini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

Bilgisayarınızın erişim izninin kısıtlanma nedenini

[https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) -\> Restriction

menüsünden öğrenebilirsiniz.