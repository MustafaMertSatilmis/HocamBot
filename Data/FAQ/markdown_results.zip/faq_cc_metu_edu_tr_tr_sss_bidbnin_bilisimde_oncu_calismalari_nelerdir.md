[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-bilisimde-oncu-calismalari-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-04-2017 **Görüntüleme:** 6707


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bidbnin-bilisimde-oncu-calismalari-nelerdir)

# BİDB’nin Bilişimde Öncü Çalışmaları Nelerdir?

[BİDB hakkında](https://faq.cc.metu.edu.tr/tr/groups/bidb-hakkinda)

**BİDB’NİN BİLİŞİMDE ÖNCÜ ÇALIŞMALARI NELERDİR?**

_**1964**_ yılında ODTÜ Bilgisayar Merkezi kurulmuştur.

_**1967**_ yılında Elektronik Hesap Bilimleri Bölümü ismini almıştır.

**_1993_** yılında Türkiye’nin ilk İNTERNET bağlantısı sağlanmıştır.

Türkiye'nin “.tr” alanında çalışan ilk web sunucusu, ilk web sitesi: ODTÜ Bilgisayar Merkezi kurulmuştur.

Türkiye'nin ilk elektronik dergisi CISN (Computing & Information Services Newsletter).

Türkiye'de ilk defa dünya çapında ilk 500'e giren süper bilgisayar (376. sıra).

Anonim FTP servisini Türkiye'de ilk başlatan kurum.

_**1995-1996**_ yılı ilk döneminde bütün üniversite genelinde ilk "Etkileşimli Kayıt".

_**2000**_ yılında Türkiye üniversiteleri arasında ilk kablosuz ağ uygulaması.

_**2015**_ yılında ISO 27001:2013 Bilgi Güvenliği sertifikasına hak kazanılmıştır.