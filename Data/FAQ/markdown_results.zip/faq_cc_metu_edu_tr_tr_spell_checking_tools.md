[Jump to navigation](https://faq.cc.metu.edu.tr/tr/spell-checking-tools#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-10-2024 **Görüntüleme:** 2527


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/spell-checking-tools "ONLINE GRAMMAR & SPELL-CHECKING TOOLS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/spell-checking-tools "ÇEVRİMİÇİ DİLBİLGİSİ VE YAZIM DENETİMİ ARAÇLARI ")

# ÇEVRİMİÇİ DİLBİLGİSİ VE YAZIM DENETİMİ ARAÇLARI

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ÇEVRİMİÇİ DİLBİLGİSİ VE YAZIM DENETİMİ ARAÇLARI —**

_Üniversitemiz lisanslı yazılımlar servisi kapsamında sunulan Microsoft 365 paketi içinde yer alan Microsoft Editor aracı, yazım ve dil bilgisi denetimi ve iyileştirmeler almak için kullanılabilmektedir. Ek olarak Microsoft Editor uygulaması Microsoft Edge veya Google Chrome gibi tarayıcılar üzerine uzantı olarak eklenerek dilbilgisi ve yazım denetimi yapılabilmektedir. Bu araçlarla ilgili detaylı bilgi için [https://faq.cc.metu.edu.tr/tr/microsoft-editor](https://faq.cc.metu.edu.tr/tr/microsoft-editor) adresi ziyaret edilebilir._

_Microsoft’un sunduğu araçlar dışında aşağıda listelenen bazı araçlar da alternatif olarak kullanılabilir. Bu alternatifler hakkında daha fazla bilgi almak için ilgili web siteleri ziyaret edilebilir._

_**ÜCRETSİZ ALTERNATİFLER:**_

_**1.ChatGPT (Ücretsiz Sürüm):** Yazım konusunda yapay zekâ araçlarıyla metinlerin anlaşılırlığını ve okunabilirliğini geliştirmek amacıyla kullanılmaktadır._

_URL>> [https://chatgpt.com/](https://chatgpt.com/)_

_Çeşitli komutlar ile ChatGPT’den bu amaçla daha etkin yararlanmanızı sağlayacak makaleler bulunmaktadır. Örnek bir makale linki aşağıda yer almaktadır: [https://medium.com/geekculture/replace-grammarly-premium-with-openai-cha...](https://medium.com/geekculture/replace-grammarly-premium-with-openai-chatgpt-320049179c79)_

_**2.DeepL Write:** Bu yapay zeka (AI) yazma aracı yalnızca dilbilgisi yönüyle değil; ifade, ton, stil ve kelime seçimi konusunda öneriler sunarak yazınızın kontrolünü sağlamaktadır._

_URL>> [https://www.deepl.com/en/write](https://www.deepl.com/en/write)_

_**3.QuillBot (Ücretsiz Sürüm):** QuillBot'un ücretsiz çevrimiçi dilbilgisi kontrol aracı, metninizi dil bilgisi, yazım ve noktalama hataları açısından inceleyerek yazılarınızın iyileştirilmesine yardımcı olur._

_[https://quillbot.com/grammar-check](https://quillbot.com/grammar-check)_

_**4.Hemingway Editor (Ücretsiz Sürüm):** Anlam bütünlüğü ve okunabilirlik üzerinde odaklanan çevrimiçi bir yazılımdır._

_URL>> [https://hemingwayapp.com/](https://hemingwayapp.com/)_

_**5.ProWritingAid (Ücretsiz Sürüm):** Yazım denetimi, stil ve gramer kontrolü sağlayan bir araçtır._

_URL>> [https://prowritingaid.com/](https://prowritingaid.com/)_

_**6.Google Dokümanlar:** Bu  yerleşik yazım ve dilbilgisi denetleyicisi, basit metin düzenlemeleri için yeterlidir._

_URL>> [https://docs.google.com/](https://docs.google.com/)_

_**7.LanguageTool (Ücretsiz Sürüm):** Çok sayıda dilde yazım denetimi yapabilen açık kaynaklı bir araçtır._

_URL>> [https://languagetool.org/](https://languagetool.org/)_

_**8\. Grammarly ( _**Ücretsiz Sürüm**_):** Bu sürüm temel özellikleri barındıran ve kısıtlı bir yazım denetimi sağlamaktadır._

_URL>> [https://www.grammarly.com/](https://www.grammarly.com/)_

_**ÜCRETLİ ALTERNATİFLER:**_

_**1.Hemingway Editor (Plus):** Sade ve anlaşılır bir dil kullanmanıza yardımcı olan yapay zeka destekli daha gelişmiş bir editördür._

_URL>> [https://hemingwayapp.com/](https://hemingwayapp.com/)_

_**2.ProWritingAid (Premium):** Gelişmiş raporlar ve kapsamlı dilbilgisi denetimi sunan bir platformdur._

_URL>> [https://prowritingaid.com/](https://prowritingaid.com/)_

_**3.Ginger Software:** Gramer denetimi, çeviri, ve daha birçok özellik sunan bir araçtır._

_URL>> [https://www.gingersoftware.com/](https://www.gingersoftware.com/)_

_**4.WhiteSmoke:** Gramer ve yazım denetimi sağlayan, ayrıca farklı dillerde destek sunan bir yazılımdır._

_URL>> [https://www.whitesmoke.com/](https://www.whitesmoke.com/)_

_**5\. Grammarly _(Pro/Enterprise/Education)_:** Grammarly yazım kuralları, imla, noktalama işaretleri, netlik ve dilbilgisi hatalarını inceleyen bulut tabanlı bir yazma asistanıdır. Bulduğu hata için uygun bir ikame bulmak ve aramak için yapay zeka kullanır. Ayrıca yazma becerilerinin geliştirilmesine, doğru gözden geçirme alışkanlıklarının pekiştirilmesine ve intihalin önlenmesine yardımcı olan bir öğrenme aracıdır._

* * *

_**Bize ulaşın:** [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)_

* * *