[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/tubitak-proje-basvurularinda-e-imzami-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-09-2020 **Görüntüleme:** 4813


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-my-ces-e-signature-tubitak-applications "How can I use my CES (e-signature) in TÜBİTAK Applications?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/tubitak-proje-basvurularinda-e-imzami-nasil-kullanabilirim "TÜBİTAK proje başvurularında e-imzamı nasıl kullanabilirim?")

# TÜBİTAK proje başvurularında e-imzamı nasıl kullanabilirim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

TÜBİTAK proje başvuruları için **[Akis kart sürücüsünün](http://kamusm.gov.tr/islemler/surucu_yukleme_servisi/)** ve [**Java**](https://www.java.com/en/download/)'nınyüklü olması gerekmektedir.

TÜBİTAK proje başvuruları e-imza kullanımı aşağıda bağlantısı yer alan belgede tarif edilmiştir:

[https://www.tubitak.gov.tr/sites/default/files/281/ardeb\_e-imza\_yardim\_dokumani.pdf](https://www.tubitak.gov.tr/sites/default/files/281/ardeb_e-imza_yardim_dokumani.pdf)