[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-tasiyabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 5523


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-iletileri-farkli-klasorlere-nasil-tasiyabilirim)

# Horde iletileri farklı klasörlere nasıl taşıyabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### İletileri farklı klasörlere nasıl taşıyabilirim?

Gelen kutusunda ileti satırını sürükle-bırak yöntemi ile istediğiniz klasöre taşıyabilirsiniz.