[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mezun-oldum-iptal-edilen-kartimdaki-nakit-para-iade-edilebilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 8904


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-have-graduated-would-available-cash-my-revoked-card-be-returned-me "I have graduated. Would the available cash on my revoked card be returned to me?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mezun-oldum-iptal-edilen-kartimdaki-nakit-para-iade-edilebilir-mi "Mezun oldum, iptal edilen kartımdaki nakit para iade edilebilir mi?")

# Mezun oldum, iptal edilen kartımdaki nakit para iade edilebilir mi?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Hayır.