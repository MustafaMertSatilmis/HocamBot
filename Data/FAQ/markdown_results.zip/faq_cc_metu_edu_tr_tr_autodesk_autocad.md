[Jump to navigation](https://faq.cc.metu.edu.tr/tr/autodesk-autocad#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-04-2022 **Görüntüleme:** 35083


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/autodesk-autocad "AUTODESK AUTOCAD")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/autodesk-autocad "AUTODESK AUTOCAD")

# AUTODESK AUTOCAD

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

Öğrenciler için not: Öğrenci sürümüne [https://www.autodesk.com/education/edu-software/overview?sorting=feature...](https://www.autodesk.com/education/edu-software/overview?sorting=featured&filters=individual) adresinden erişebilirsiniz.

[Kurulum](https://faq.cc.metu.edu.tr/tr/autodesk-autocad#kurulum)

**Kurulum:**

Yazılım [https://yazilim.cc.metu.edu.tr/](https://yazilim.cc.metu.edu.tr/) sayfasından indirilebilir.

**1.Step**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad1.png)**

**2.Step**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad2.png)**

**3.Step**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad3.png)**

**4.Step:** Kullanılacak olan seri numarası ve ürün anahtarı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" sitesinden edinilebilir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad4.png)**

**5.Step:**"Configure" seçeneği seçilerek kurulum yapılandırması seçenekleri düzenlenir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad5.png)**

**6.Step:** Lisans sunucusu olarak "autodesk.cc.metu.edu.tr" girilir.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad6.png)**

**7.Step** Ekrana gelen uyarı ekranında "Yes" seçeneğine tıklayarak ilerleyiniz.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad-step-7.jpg)**

**8.Step**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad7.png)**

**9.Step**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ss9.png)

**10.Step**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad9.png)**

**11.Step**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/autocad10.png)**

**NOT: Kurulum işlemi tamamlandıktan sonra [yazılım.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/) adresindeki güncellemeleri (updates) sırasıyla yükleyiniz! Güncellemeleri yüklemeye çalışırken ekrana hata mesajı gelecektir. Bu hata ekranını geçmek ve kurulumu yapmak için aşağıdaki adımları izleyiniz. Aşağıdaki adımları 2 güncelleme için de sırasıyla uygulayınız.**

**Adım-1 Güncellemeleri kurmaya başladığınızda ekrana gelen aşağıdaki uyarıyı kapatınız ve ikinci adıma geçiniz.**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ss1_0.png)**

**Adım-2 Görev Yöneticisi (Task Manager)  > Dosya (File) > Yeni Görevi Çalıştır (Run new task)**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ss2_0.png)**

**Adım-3  Gözat (Browse) > Güncellemeyi (Update) bilgisayarınıza indirdiğiniz konumdan seçiniz > Bu Görevi Yönetici ayrıcalıkları ile oluştur (Create this task with administrator privileges) kutucuğunu işaretleyiniz. > Tamam (OK) butonuna tıklayarak kurulum işleminiz yapınız.**

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ss3.jpg)**

**Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**