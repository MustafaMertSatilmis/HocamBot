[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sim-kartimin-pin-parola-kodunu-nasil-olusturabilirim-pin-kilidini-nasil-cozebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 30-09-2024 **Görüntüleme:** 31726


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-generate-pin-password-code-my-e-signature-sim-card-how-can-i-unlock-pin "How can I generate the PIN (password) code of my e-signature SIM card? How can I unlock the PIN?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-sim-kartimin-pin-parola-kodunu-nasil-olusturabilirim-pin-kilidini-nasil-cozebilirim "E-imza SIM kartımın PIN (parola) kodunu nasıl oluşturabilirim? PIN kilidini nasıl çözebilirim?")

# E-imza SIM kartımın PIN (parola) kodunu nasıl oluşturabilirim? PIN kilidini nasıl çözebilirim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Yeni bir NES (Nitelikli Elektronik Sertifika) kartınız geldi ve **PIN oluşturmak istiyorsanız**, mevcut NES'inizin **PIN kodunu bilmiyorsanız** ya da **PIN'ininizi 3 kere hatalı girip kilitledi** iseniz Kilit çözme işlemi yapmanız gerekmektedir.

Konu ile ilgili KamuSM Kilit Çözme Yardım sayfası linki:

[https://kamusm.bilgem.tubitak.gov.tr/dokumanlar/yonergeler/nes/nes\_kilit...](https://kamusm.bilgem.tubitak.gov.tr/dokumanlar/yonergeler/nes/nes_kilit_cozme/?info=1)

Yapılaçak işlem adımları şöyledir:

1\. [http://kamusm.gov.tr](http://kamusm.gov.tr/) adresinde sağ üst köşede kırmızı ile işaretlenmiş "**ONLINE İŞLEMLER**" sekmesine  tıklayınız.

2.  **"E-devlet ile Giriş"** ve sonrasında "**E-devlet Kapısına Git**" linklerine tıklayınız . (Burada E-devlet parolası, mobil imza ya da e-imza ile giriş yapmak mümkündür)

3\. Açılan sayfada "**NES İşlemleri**"ni seçiniz.

4\. "**PIN Oluşturma/Kilit Çözme**" seçeneği ile ilerleyiniz.

5\. Bundan sonraki adım için bilgisayarınızda [**Java**](https://www.java.com/en/download/) ve [**Akis**](http://kamusm.bilgem.tubitak.gov.tr/islemler/surucu_yukleme_servisi/) kurulumu olması gerekmektedir. (İlgili açıklamalar ve kurulum linkleri açılan sayfada mevcuttur)

6\. Sayfadaki adımları takip ederek **KamuSMeImzaUygulamasi.jar** dosyasını çalıştırınız ve aynı sayfadaki **onay kodunu** kopyalayıp açılan **KamuSMeImzaUygulamasi.jar** uygulamasında ilgili yere kopyalayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u127225/screen_shot_2020-09-17_at_14.49.29.png)

**MAC OS İşletim Sistemi Kullanıcıları için ÖNEMLİ NOT:**

**\- MAC Os işletim sistemlerinde KamuSMEimzaUygulamasi.jar uygulaması indirilip açıldığında işletim sisteminin güvenlik önlemleri çerçevesinde uygulamanın çalıştırılması engellenmektedir. (Aşağıdaki iki uyarın ekranı ile karşılaşmanız olasıdır)**

**![](https://faq.cc.metu.edu.tr/system/files/u127225/screen_shot_2020-11-23_at_15.14.53.png)**

![](https://faq.cc.metu.edu.tr/system/files/u127225/screen_shot_2020-11-23_at_15.15.24.png)

**\- Uygulamayı çalıştırabilmek için şu adımların takip edilmesi gerekmektedir.**

**\-\- Sol üst köşedeki elma ikonu tıklanır ve burada System Preferences seçilir.**

**\-\- Açılan sayfada General sekmesi açık olmalıdır.**

**![](https://faq.cc.metu.edu.tr/system/files/u127225/screen_shot_2020-11-23_at_15.19.32.png)**

**\-\- Yukarıdaki imajda görüldüğü üzere Allow apps downloaded from seçeneğinde KamuSMeImzaUygulamasi.jar dosyasının açılmasına izin verilmelidir.**

7\. Uygulamada açılan sayfada sertifikanızı seçtikten sonra yeni NES için PIN oluşturabilir ya da kilitlenmiş PIN için yeni kod oluşturabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u127225/screen_shot_2020-09-17_at_15.01.47.png)