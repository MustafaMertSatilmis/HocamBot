[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mac-os-x-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-05-2020 **Görüntüleme:** 35462


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-vpn-service-mac-os-x-installed-devices "How can i use METU VPN Service on MAC OS X installed devices?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mac-os-x-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim "MAC OS X işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?")

# MAC OS X işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?

[VPN Hizmeti](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti)

ODTÜ VPN hizmeti ile birlikte, mensup ve öğrencilerimiz yerleşke dışında bulundukları sürelerde kullandıkları kişisel bilgisayarlara ya da mobil cihazlara kuracakları küçük bir paket program vasıtasıyla (VPN Client), üniversitemiz yerleşke içi ağ kaynaklarına erişebileceklerdir.

Önemli Uyarı: VPN üzerinden bağlanan kullanıcılarımızın bağlantı hızları kullanıcı başına 8 Mbps olarak şekillendirilmektedir. Bu nedenle VPN bağlantısına ihtiyacınız kalmadığı durumlarda VPN bağlantınızı sonlandırmanızı öneririz.

MAC OS X işletim sistemi yüklü cihazınızla VPN hizmetini kullanabilmeniz için:

Netregister.metu.edu.tr adresine giriş yaptıktan sonra VPN service bağlantısında gelen işletim sisteminize uygun yazılımı indirdikten sonra kurulumu çalıştırınız. **MacOS Mojave ve Catalina işletim sistemine sahip kullanıcıların App Store üzerinde yayınlanan en güncel Aruba Via yazılımını indirmeleri gerekmektedir.**

Kurulum esnasında İleri (Continue) tuşu seçilemez durumda olması işletim sisteminizin güvenlik ayarlarından kaynaklanıyor olabilir. Kuruluma devam edebilmek için Sistem Ayarları'ndan (System Preferences) Güvenlik ve Gizlilik (Security & Privacy) ayarlarına tıklamanız ve gelen ekranda İndirilen uygulamaları izin ver: (Allow applications downloaded from) bölümünden Herhangi bir yer (Anywhere) seçilmelidir. Bu alanın tümü seçilemez durumda ise açmak için sayfanın altındaki kilit simgesine basılmalı ve bilgisayarın şifresi girilmelidir. Ardından kurulum devam ettirilebilir.

Kurulum sonlandığında karşınıza gelen ekranda Remote Server kısmına border.metu.edu.tr, Username ve Password kısmına da ODTÜ kullanıcı adı ve şifrenizi girerek Login (Giriş)’e basınız. **default** profili seçiniz.

![Profile Selection](https://faq.cc.metu.edu.tr/system/files/u21699/profile_page.png)

**Bilgisayarınıza indirdiğiniz VPN Client programına tıkladığınızda kurulum başlamıyor, bunun yerine bilgisayarınız dosyayı Metin Düzenleme vb. bir program ile açmaya çalışıyor ise, sorun büyük olasılıkla, dosyanın yanlış uzantılı ya da uzantısız olarak inmiş olmasından kaynaklıdır. Kurulumun düzgün olarak çalışması için indirdiğiniz dosyanın uzantısını .dmg olarak değiştiriniz.**