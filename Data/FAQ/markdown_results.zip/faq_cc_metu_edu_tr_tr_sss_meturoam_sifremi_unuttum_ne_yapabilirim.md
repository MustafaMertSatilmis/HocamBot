[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/meturoam-sifremi-unuttum-ne-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 27919


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-forgot-meturoam-password-what-can-i-do "I forgot meturoam password, what can I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/meturoam-sifremi-unuttum-ne-yapabilirim "meturoam şifremi unuttum, ne yapabilirim?")

# meturoam şifremi unuttum, ne yapabilirim?

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Yeni bir şifre oluşturmanız gerekmektedir. Lütfen [https://faq.cc.metu.edu.tr/tr/sss/meturoam](https://faq.cc.metu.edu.tr/tr/sss/meturoam) sayfasındaki adımları takip ediniz.