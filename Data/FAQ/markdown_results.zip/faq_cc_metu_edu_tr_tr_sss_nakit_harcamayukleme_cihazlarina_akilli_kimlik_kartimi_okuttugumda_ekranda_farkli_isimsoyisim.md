[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/nakit-harcamayukleme-cihazlarina-akilli-kimlik-kartimi-okuttugumda-ekranda-farkli-isimsoyisim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2021 **Görüntüleme:** 7700


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/information-displayed-screen-cash-paymentload-devices-does-not-belong-me-what-reason "The information displayed on the screen of the Cash payment/load devices does not belong to me. What is the reason?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/nakit-harcamayukleme-cihazlarina-akilli-kimlik-kartimi-okuttugumda-ekranda-farkli-isimsoyisim "Nakit harcama/yükleme cihazlarına akıllı kimlik kartımı okuttuğumda ekranda farklı isim/soyisim görüyorum. Bunun sebebi nedir?")

# Nakit harcama/yükleme cihazlarına akıllı kimlik kartımı okuttuğumda ekranda farklı isim/soyisim görüyorum. Bunun sebebi nedir?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Nakit harcama veya yükleme noktalarında akıllı kartınızı okuttuğunuzda kartınızda yazan isim/soyisimden farklı bir isim/soyisim görüyorsanız kart yanlış formatlanmış olabilir. Personel iseniz Personel Daire Başkanlığı'na, öğrenci iseniz Öğrenci İşleri Daire Başkanlığı'na başvurarak akıllı kimlik kartınızı kontrol ettirebilir, gerekirse kart değişim talebinizi iletebilirsiniz.