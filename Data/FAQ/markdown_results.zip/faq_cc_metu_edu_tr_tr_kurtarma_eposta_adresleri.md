[Jump to navigation](https://faq.cc.metu.edu.tr/tr/kurtarma_eposta_adresleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-03-2021 **Görüntüleme:** 72147


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/recovery_email_addresses "What is a recovery e-mail address?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/kurtarma_eposta_adresleri "Kurtarma e-posta adresi nedir, kurtarma e-postasını kullanıcı hesabımda nasıl tanımlarım?")

# Kurtarma e-posta adresi nedir, kurtarma e-postasını kullanıcı hesabımda nasıl tanımlarım?

[Parola](https://faq.cc.metu.edu.tr/tr/groups/parola)

**Kurtarma e-posta adresi nedir, kurtarma e-postasını kullanıcı hesabımda nasıl tanımlarım?**

Şifrenizi unutmanız halinde kendinize yeni şifre belirleyebilmeniz için kullanıcı hesabınızda kurtarma e-postanızın tanımlı olması gerekmektedir. Eğer kullanıcı hesabınızda kurtarma e-postası tanımlı değil ise şifrenizi unutmanız halinde kendinize yeni şifre belirleyemezsiniz.

“Şifremi Unuttum” işlemini yaparken, belirlemiş olduğunuz ODTÜ dışı kurtarma e-posta adresinize (gmail  vb.) talebiniz doğrultusunda “yeni şifre oluşturma linki” gönderilir. Bu linkte yer alan bağlantı üzerinden 24 saat içinde yeni şifrenizi oluşturmanız beklenir.

**A-** **Kurtarma e-postası tanımlamak için (ODTÜ Kullanıcı Hesabı şifresini bilenler):**

1. [https://useraccount.metu.edu.tr/](https://useraccount.metu.edu.tr/) adresine giriniz,
2. Kullanmakta olduğunuz şu anki kullanıcı kodu-şifre ile giriş yapınız,
3. Gelen sayfada KURTARMA EPOSTASI BELİRLE düğmesine tıklayınız,
4. Kurtarma e-postanızı yazıp GÜNCELLE düğmesine tıklayınız.

**B-** **Kullanıcı hesabı şifrenizi unuttuğunuz için k** **endiniz kurtarma e-postası tanımlayamıyorsanız:**

**1\.** Öncelikle ODTÜ kimliğinizi ve T.C. nüfus cüzdanınızın ön yüzünü (ikisi birlikte) tarayıcıda taratınız veya cep telefonunuz uygun ise, cep telefonunuzdan fotoğrafını çekiniz.  (dosya yüklemek için fotoğrafın pdf, png, jpeg, gif dosya türlerinden biri olması ve maksimum 2mb boyutunda olması gerekmektedir),

**2\.** [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresine giriniz.

**3\.** Gelen sayfada “Bilişim Destek Formu Doldur” düğmesine tıklayınız.

**4\.** Gelen ekranda istenilen bilgileri doldurunuz.

**5\.** Aynı ekranın altında “Dosya Yükle” düğmesine tıklayınız. Eğer düğme “Off” konumunda ise Off yazısının üzerine tıklayarak “On” konumuna getiriniz. Ve kimlik görselinizi yükleyiniz.

**6\.** Sayfanın en altındaki doğrulama kodunu da girdikten sonra “Gönder” düğmesine tıklayınız.

**7\.** Talebiniz bize ulaştıktan sonra kurtarma e-posta adresiniz bizim tarafımızdan tanımlanacaktır. (e-posta gönderdiğiniz adres ya da belirtmişseniz özellikle talep ettiğiniz bir adres)

**C-** **Sistemde kayıtlı olan kurtarma e-postanızın ne olduğunu unuttuğunuz için “Şifremi Unuttum” işlemi _sırasında  “Kurtarma E-Posta adresi uyumsuz. Lütfen kayıtlı kurtarma e-posta adresinizi girdiğinize emin olunuz.”_ uyarısı ile karşılaşıyorsanız:**

Sistemde kayıtlı kurtarma e-postanızın ne olduğunu hatırlamıyorsanız ODTÜ kullanıcı hesabı şifrenizi de unutmuş olduğunuz için kurtarma e-postanızı göremezsiniz veya kendiniz yeni kurtarma e-postası belirleyemezsiniz. Bu durumda:

1-      [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresindeki formu doldurarak sistemde kayıtlı olan kurtarma e-postanızı sorunuz.

2-      Size dönülen yanıtta sistemde kayıtlı olan kurtarma e-posta adresiniz bildirilecektir.

3-      Öğrendiğiniz e-posta kurtarma adresinizle “Şifre Değiştir” işlemini [http://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri](http://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodu-sifre-ve-kurtarma-e-postasi-islemleri) adresindeki adımları izleyerek kendinize yeni şifre belirleyebilirsiniz.

**D-** **Sistemde kayıtlı kurtarma e-postası hesabınıza erişim sorunu yaşıyorsanız:**

Eğer sistemde kayıtlı kurtarma e-postanıza erişim sorunu (şifresini unutma) yaşıyorsanız ve ODTÜ kullanıcı kodu şifrenizi de unutmuşsanız, kendinize yeni şifre belirleyemezsiniz. Bu durumda kullanıcı hesabınız için, bizim tarafımızdan yeni bir kurtarma e-postası tanımlanması gerekeceği için **B bölümündeki** adımları takip ediniz.