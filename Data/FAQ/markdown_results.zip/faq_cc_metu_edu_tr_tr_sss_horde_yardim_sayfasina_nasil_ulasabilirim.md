[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/horde-yardim-sayfasina-nasil-ulasabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 6384


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/horde-yardim-sayfasina-nasil-ulasabilirim)

# Horde Yardım sayfasına nasıl ulaşabilirim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

### Yardım sayfasına nasıl ulaşabilirim?

Posta uygulamasında menü satırında bulunan çark işareti altından Yardım sayfasına ulaşabilirsiniz.