[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listeye-gonderilen-mesajlarda-boyut-sinirlarini-nasil-duzenleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-06-2019 **Görüntüleme:** 7566


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-size-messages-sent-list-can-be-limited "How the size of the messages sent to the list can be limited?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yoneticisi-oldugum-listeye-gonderilen-mesajlarda-boyut-sinirlarini-nasil-duzenleyebilirim "Yöneticisi olduğum listeye gönderilen mesajlarda boyut sınırlarını nasıl duzenleyebilirim?")

# Yöneticisi olduğum listeye gönderilen mesajlarda boyut sınırlarını nasıl duzenleyebilirim?

[E-Liste Yönetim Soruları](https://faq.cc.metu.edu.tr/tr/groups/e-liste-yonetim-sorulari)

**Listeye gönderilen mesajların boyutlarının sınırlandırılması için:**

**(a)** _Genel Seçenekler_ > _Ek ayarlar_ > _Mesaj gövdesinin kilobayt (KB) olarak maksimum uzunluğu. Sınır koymamak için 0 kullanın._ alanına eklenti dosya dahil olmak üzere gönderilebilecek maksimum mesaj boyutu KB cinsinden yazılır. 0 yazılırsa mesaj boyu sınırsız olur. Ancak özellikle üye sayısının 50'den fazla olduğu listelerde mesaj gönderim limitinin 2048 K dan yüksek olması önerilmemektedir.