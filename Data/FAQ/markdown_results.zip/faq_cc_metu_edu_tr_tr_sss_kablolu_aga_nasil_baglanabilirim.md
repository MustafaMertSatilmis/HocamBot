[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kablolu-aga-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 27-04-2022 **Görüntüleme:** 15083


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-connect-wired-network "How to connect Wired Network?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kablolu-aga-nasil-baglanabilirim "Kablolu Ağa Nasıl Bağlanabilirim? ")

# Kablolu Ağa Nasıl Bağlanabilirim?

[Kablolu Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablolu-ag)

Yurtlardan kablolu ağa bağlanmak için [tıklayınız.](https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim)

Lojmanlardan kablolu ağa bağlanmak için [tıklayınız.](https://faq.cc.metu.edu.tr/tr/sss/lojmanlardan-internete-nasil-baglanabilirim)

Diğer bölüm/birimlerden kablolu ağa bağlanmak için ilgili [birim ağ yöneticileri](http://coordinators.metu.edu.tr/) ile iletişime geçilmesi gerekmektedir.