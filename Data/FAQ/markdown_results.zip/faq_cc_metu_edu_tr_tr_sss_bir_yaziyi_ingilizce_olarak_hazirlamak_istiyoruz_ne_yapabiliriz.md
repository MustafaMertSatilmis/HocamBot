[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-yaziyi-ingilizce-olarak-hazirlamak-istiyoruz-ne-yapabiliriz#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4651


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-yaziyi-ingilizce-olarak-hazirlamak-istiyoruz-ne-yapabiliriz)

# Bir yazıyı İngilizce olarak hazırlamak istiyoruz, ne yapabiliriz?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

"Belgede Görüntülenecek Muhatap Alanını Güncelle" özelliğini kullanarak evrak üzerindeki hitap alanını İngilizce olarak değiştirebilirsiniz.

Ancak konu, sayı, e-imzalıdır gibi alanlar henüz sadece Türkçe olabilmektedir. İngilizce olarak hazırlanabilmesi gelişme planları arasındadır.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.