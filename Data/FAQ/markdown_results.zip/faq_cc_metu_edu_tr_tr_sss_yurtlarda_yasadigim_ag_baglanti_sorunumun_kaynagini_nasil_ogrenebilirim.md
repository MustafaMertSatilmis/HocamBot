[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yurtlarda-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-12-2021 **Görüntüleme:** 13217


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-about-source-my-network-connection-failure-dormitories "How can I find out about the source of my network connection failure at the Dormitories?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yurtlarda-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim "Yurtlarda yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?")

# Yurtlarda yaşadığım ağ bağlantı sorunumun kaynağını nasıl öğrenebilirim?

[ODTÜKENT/Yurtlar/Lojmanlar](https://faq.cc.metu.edu.tr/tr/groups/odtukentyurtlarlojmanlar)

**Yurtlarda yaşadığınız kablolu ağ bağlantı sorununuzu çözmek için aşağıdaki bilgileri lütfen inceleyiniz.**

1\. Bağlantı sorununuzu çözüme ulaştırmak için, ilk olarak aşağıdaki durumları okuyunuz.

1.1.    İnternet kullanımı ile ilgili kurallara aykırı hareket etmeleri durumunda öğrencilerin internet erişimleri, Bilgi İşlem Daire Başkanlığı tarafından engellenebilmektedir. Bu tür durumlarda tarafınıza bilgilendirme amaçlı mail gönderilir. Lütfen ODTÜ hesabınıza tanımlı olan mail adresinizin gelen kutusunu kontrol ediniz. Aynı zamanda [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) adresine giriş yaptığınızda "Restrictions" bölümünden bilgi alabilir, erişim kısıtlamanız varsa bilgisayarınızda gerekli düzeltmeleri yaptıktan sonra kısıtlamayı kaldırabilirsiniz.

1.2.    [https://netregister.metu.edu.tr/](https://netregister.metu.edu.tr/) adresine gidiniz ve kendi kullanıcı bilgilerinizi kullanarak giriş yapınız. İnternet bağlantısı sorunu olan cihazınızın KABLOLU / ETHERNET fiziksel adresinin (MAC adresinin) sisteme kayıtlı olup olmadığını kontrol ediniz. Kayıtlı değil ise cihazınızın fiziksel adresini öğreniniz ve sisteme kayıt ediniz. Cihazınızın MAC adresini nasıl öğreneceğinizi bilmiyorsanız aşağıdaki bağlantılar faydalı olacaktır.

[https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim](http://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim)

[https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim)

1.3.    Orta Doğu Teknik Üniversitesi tarafından sağlanan internet bağlantısı ODTÜ Bilişim Kaynakları Kullanım Politikaları çerçevesinde kullanılmalıdır. (Bkz. [http://bilisim-etigi.metu.edu.tr/](http://bilisim-etigi.metu.edu.tr/) ) Bu duruma aykırı yapılan işlemler öğrencilerin internet erişimlerinin engellenmesine veya cezai yaptırımlara sebep olabilir. Hotspot veya diğer yazılımlar aracılığı ile internet paylaşımı en sık yapılan kural ihlallerindendir ve bu tür ihlaller öğrencilerin bağlantılarının engellenmesindeki bir başka sebep olabilir.

1.4.    Cihazınızı, internet bağlantısı sorunu olmadığından emin olduğunuz başka bir internet kablosu veya priz aracılığı ile internete bağlamayı deneyiniz.

- Kendi prizinizde farklı bir internet kablosu ile bağlantı yapılabiliyorsa kablonuz arızalıdır, kablonuzu yenilemeniz gerekmektedir.
- Kendi kablonuz ile farklı bir prizde bağlantı kurabiliyorsanız, kendi ağ prizinizin kontrol ettirilmesi için Yurt Danışmasını bilgilendiriniz.

1.5.    Cihazınızın virüs veya kötü amaçlı yazılım içermediğinizden emin olunuz. Her türlü duruma karşı cihazınıza virüs taraması yaptırınız. Cihazınız halen virüs yazılımı içeriyorsa sistem geri yüklemeyi deneyebilirsiniz. İşletim sistemi olarak bir Microsoft ürünü kullanıyorsanız aşağıdaki bağlantıyı inceleyiniz.

- [https://support.microsoft.com/tr-tr/help/17127/windows-back-up-restore](https://support.microsoft.com/tr-tr/help/17127/windows-back-up-restore)
- Mac için [https://support.apple.com/tr-tr/HT201250](https://support.apple.com/tr-tr/HT201250)

2\. Bilgisayarınızın internete bağlanması için USB veya Thunderbolt girişini kullanıyorsanız, Ethernet – USB veya Ethernet – Thunderbolt dönüştürücünüzün bağlı ve çalışır durumda olduğundan emin olunuz. Eğer bu tür dönüştürücülerin kullanımı için yetkili firma tarafından sürücü sağlanıyorsa sürücünün yüklü ve güncel olduğundan emin olunuz. Ayrıca sistemde kayıtlı MAC adresinizin kullandığınız Ethernet dönüştürücüsünün MAC adresi ile aynı olduğunu kontrol ediniz. Cihazınızın Ethernet girişi mevcut ise Ethernet kartınızın takılı ve etkin durumda olduğunu, varsa sürücüsünün yüklü ve güncel olduğunu kontrol ediniz.  Telefon hattının bağlı olduğu kart Ethernet kartı değildir. Ethernet girişi 8 tellidir ve telefon hattının bağlı olduğu modem girişi 2 tellidir. Sorun çözülmezse 2.1’i takip ediniz.

2.1 Bilgisayarınızın Ethernet kartı bulunmuyorsa tercihen “Tak ve Çalıştır” (Plug and Play) özellikli bir PCI Ethernet kartı veya USB - Ethernet dönüştürücü satın alınız. Eğer Ethernet kartı bulunuyorsa, bilgisayarınızın aygıt yöneticisi (Device Manager) ekranında Ethernet kartınızın sorunsuz bir şekilde çalıştığını kontrol ediniz. Bu ekranı Denetim Masası\\Sistem ve Güvenlik\\Sistem\\Aygıt yöneticisi yoluyla görüntüleyebilirsiniz. Ethernet kartınızda sorun olması durumunda teknik destek veya donanım yardımı alınız.

3\. Başlat menüsünde ‘çalıştır’ masaüstü uygulamasına gidin. Programda açılan pencereye CMD yazınız ve komut istemi ekranına gidiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_01.png)

Daha sonra ekrana  “ping 127.0.0.1” komutunu yazınız ve aşağıdaki ekranı gördüğünüzden emin olunuz. Ekranı görememeniz durumunda 2.1’de yazan işlemleri denetleyiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_02.png)

3.1.    Ping işlemi sonucunda belirletilen ekranı göremiyorsanız aşağıdaki maddeleri kontrol ediniz.

- Komutu yazarken hata yapmış olabilirsiniz. “ping” ifadesinden sonra bir karakter boşluk bulunduğuna, IP adresi kısımlarında nokta işaretlerine dikkat ediniz.
- Bilgisayarınız “ping” komutunu bulamamış olabilir. “Başlat(start) menüsünden “Ara” (search) kısmından “ping.exe” dosyasını arayınız. Dosyayı bulduğunuz dizinin içinde bu komutu çalıştırınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_03.png)

- Ethernet kartınız bilgisayarınızda düzgün yapılandırılmamış olabilir. Kartınızla beraber disket ya da CD içinde gelen yazılımları kullanarak kartınızı tekrar bilgisayarınızda tanıtmayı deneyiniz. Eğer herhangi bir disket ya da CD yoksa bilgisayarınıza ait sürücüleri üreticinin web sayfasında arayınız.

4\. İnternet hattının bilgisayarınıza taşınmasını sağlayan ara kabloyu çıkardığınızda, kablonun bilgisayarınıza bağlandığı yerdeki ışık söndüğünü ve kabloyu tekrar taktığınızda ışığın yandığını ve ekranın sağ alt köşesinde bulunan, ağ durumunuzu gösteren ikonunu kontrol ediniz. Bağlantı sorununuzun olmadığını gösteren ikon aşağıdaki gibidir. Bağlantı sorununuz varsa bu ikonun üzerinde ünlem işareti bulunur. ![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_04.png)

Ethernet kartınızın modeline göre üzerinde birden fazla ışık olabilir. Bu ışıklardan bir tanesi, ara kablo çıkarsa bile devamlı yanık durumda durabilir. Test edilecek olan ışık, kablo takılı olmadığı durumda sönük olan diğer ışıktır. Ethernet kartınızın ışığı bahsedildiği gibi yanmıyorsa aşağıdaki maddeleri uygulayınız.

4.1 Işık devamlı sönük durumdaysa ara kablonuz arızalı olabilir. Ara kablonuzu çalıştığını bildiğiniz bir duvar prizine takarak deneyiniz. Eğer ışık yine yanmıyorsa ara kablonuzu değiştiriniz. Işık bu durumda yanmaya başlamışsa, çalıştığını bildiğiniz diğer bir bilgisayarı, kendi ara kablosuyla beraber odanızdaki duvar prizine takınız. Diğer bilgisayarın ışığı bu durumda yanmıyorsa odanızdaki duvar prizinizin ya da odanıza gelen internet bağlantı kablosunun arızalı olma ihtimali yüksektir. Bu durumda Yurt Danışmasını bilgilendirerek Yurtlar Müdürlüğü Teknik Personelinden destek alabilirsiniz.

4.2 Çalıştığına emin olduğunuz ara kablo ile çalıştığını bildiriniz bir odadaki duvar prizine takarak denediğinizde ışık yanmıyorsa Ethernet girişiniz veya Ethernet kartınız bozulmuş olabilir, bilgisayar üreticiniz ile iletişime geçiniz.

5\. Bilgisayarı açık ve size yakın bir odada fakat aynı binada olan bir arkadaşınızın IP adreslerini öğreniniz. IP adresini nasıl öğreneceğinizi bilmiyorsanız aşağıdaki linke göz atınız.

[http://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim](http://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim)

Arkadaşınızın IP adresinin ilk altı hanesi 144.122 şeklindedir. Arkadaşınızın bilgisayarının açık, internet bağlantısının olduğuna emin olun ve varsa güvenlik duvarı (Firewall) özellikli yazılımları geçici olarak kapatın.

Daha sonra 2. adımda olduğu gibi kendi bilgisayarınızdan “Başlat” (Start) menüsünden “Çalıştır” (Run) kısmına CMD yazarak komut istemi ekranına gidin. Bu ekrana arkadaşınızın IP adresini içeren ping komutunu yazınız.  (ping 144.122.###.### ). Bilgisayarınız ping işleminin başarısız olması durumuna aşağıdaki ekranı görüntüleyecektir. Bu durumda 5.3 adımında bulunan önerileri inceleyiniz.

5.1 Açık durumda bulunan birkaç bilgisayar için komutu denediğinizde hepsinde ekranda istek zamanaşımına uğradı/(Request timed out) şeklinde bir yazı görüyorsanız bilgisayarınızın internet bağlantısının ayarlarında, binanın içinde bağlı olduğunuz ağ bağlantı cihazlarında ya da bilgisayarınızın işletim sistemine özel bir problem olabilir. Aşağıda bu duruma ait bir örnek gösterilmekledir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_05.png)

Eğer bu adım sizin durumunuza uyuyorsa 5.2’ye, uymuyorsa 5.3’e devam ediniz.

5.2 Problem, sizin bilgisayarınız dışında oda olarak size yakın olan tüm bilgisayarların çalışmaması gibi diğer kişilerde de bulunuyorsa, internet bağlantınızı sağlayan cihaz problemli olabilir. Yurt danışma görevlilerinizden binada elektrik kesintisi olup olmadığını, bina ağ altyapısını sağlayan cihazlarda elektrik olup olmadığını kontrol etmelerini isteyebilirsiniz. Daha sonrasında 5 numaralı maddede yazılı olan işlemleri tekrar uygulayınız, bu maddeyi geçemezseniz durumu bildirmek için [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/)  adresinden veya doğrudan [Bilişim Destek Formu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=ycoord) üzerinden vaka kaydı oluşturabilirsiniz.

5.3 Problem, sizin bilgisayarınız dışında oda olarak size yakın olan tüm bilgisayarların çalışmaması gibi diğer kişilerde de bulunmuyorsa, aşağıda listelenen tüm maddeleri kontrol ediniz ya da uygulayınız.

- Modem bağlantısını kullanmıyorsanız, bilgisayarınızın “Ağ Bağlantılarım” (Network Connections) kısmındaki Çevirmeli ağ bağdaştırıcısını (Dial up adapter) kaldırınız.
- Bilgisayarınızın Ağ ayarlarının Otomatik olarak ayarlandığından emin olunuz.
- Ethernet kartınızı kaldırıp tekrar tanıtmayı deneyiniz.
- 5 numaralı maddeyi tekrar uygulayınız. Sorun düzelmediyse 5. maddenin, bilgisayarınızda çalıştığını bildiğiniz başka birkaç odadaki hatlarda, çalıştığını bildiğiniz bir ara kabloyla deneyiniz. Gerektiğinde en son yüklediğiniz programları kaldırınız, bilgisayarınızı “Güvenli kip network destekli” (safe mode with networking ) şeklinde başlatınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_06.png)

- Bu işlem diğer işletim sistemleri için  “Güvenli kip network destekli” (safe mode with networking) şeklindeki seçenekler aracılığı ile de yapılabilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_07.png)

- Bilgisayarınızın donanım ayarlarında Ethernet kartınızın düzgün tanıtıldığından emin olunuz. Bunlara rağmen 5 numaralı maddeyi geçemezseniz işletim sistemi ya da Ethernet kartınız için BİDB'den destek alabilirsiniz.

        (Bilgisayarınızla birlikte BİDB B-14 numaralı odaya gelebilirsiniz.)

6\. 5. adımda ping işleminin başarılı olması durumunda, farklı bir binada bulunan ve internet bağlantısı olan arkadaşınızın IP adresini öğreniniz. IP adresini nasıl öğreneceğinizi bilmiyorsanız aşağıdaki linke göz atınız.

[http://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim](http://faq.cc.metu.edu.tr/tr/sss/ip-adresimi-nasil-ogrenebilirim)

Daha sonra 5 numaralı maddede tekrarlandığı gibi arkadaşınızın IP adresi için ping komutu çalıştırınız.

6.1 Ping işleminin başarısız olması durumunda bağlantı problemine sahip başka arkadaşlarınızın olup olmadığını araştırınız. Sizin gibi bağlantı sorunu yaşayan başka arkadaşlarınız mevcut ise durumu BİDB'ye bildiriniz. Bilgisayarınızın IP adresini ve aynı probleme sahip birçok bilgisayar olduğu bilgisini vermeyi unutmayınız. ( [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/)  adresinden veya doğrudan [Bilişim Destek Formu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=ycoord) üzerinden vaka kaydı oluşturabilirsiniz.)

6.2 Benzer sorun yaşayan arkadaşınız bulunmuyorsa aşağıdaki tüm maddeleri kontrol ediniz ve ya uygulayınız.

- MAC Adresi bilgisini IP tahsis sistemine doğru verdiğiniz kontrol ediniz. IP tahsis sisteminde kaydınızın ONAYLI kısmında bulunduğuna emin olunuz.
- IP Adresinizin [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) adresindeki ağ erişimini kısıtlanan IP’ler listesinde olup olmadığını internete bağlanabilen başka bir bilgisayardan kontrol ediniz. P2P kullanımı gerekçesiyle kapalıysa “ODTÜ Bilişim Kaynakları Kullanım Politikaları” gereği bağlantınız süreli kısıtlanmış olabilir. Kısıtlamaya neden olan durumu ortadan kaldırdıktan sonra 24 saat içerisinde [http://netregister.metu.edu.tr/](http://netregister.metu.edu.tr/) sayfasına girip kısıtlamayı kaldırabilirsiniz. Kısıtlamayı kaldırma hakkınız tek seferlik tanımlıdır. Konu hakkında

[https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisiminin-yeniden-acilmasi-icin-ne-yapmaliyim](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ip-erisiminin-yeniden-acilmasi-icin-ne-yapmaliyim)

sayfasından da bilgi alabilirsiniz.

- “Alt ağ maskesi” (Subnet mask) ve “Ağ geçidi” (Gateway) kısmındaki bilgilerin OTOMATİK olarak ayarlandığından emin olunuz.
- Modem bağlantısını kullanmıyorsanız, bilgisayarınızın “Ağ Bağlantılarım” (Network Connections) kısmındaki Çevirmeli ağ bağdaştırıcısı (Dial up adapter) kaldırınız.
- Otomatik IP ayarlarının bilgisayarınızın “Ağ Bağlantılarım” (Network Connections) kısmında yalnızca “Yerel Ağ Bağlantısı” (Local Area Connection) altına girdiğinize emin olunuz.
- Varsa Güvenlik duvarı (Firewall) özellikli programlarınızı, kapatıp bağlantı kurmayı deneyiniz. Bağlanabiliyorsanız bu programların ayarlarını kontrol ediniz.

Yukarıdaki işlemlere rağmen sorununuz çözülmediyse, IP ve MAC adresiniz ve bu şemada geçemediğiniz yeri BİDB'ye bildiriniz. ( [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/)  adresinden veya doğrudan [Bilişim Destek Formu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=ycoord) üzerinden vaka kaydı oluşturabilirsiniz. Ayrıca bilgisayarınızla birlikte BİDB B-14 numaralı odaya gelebilirsiniz.)

7\. 6. adımda ping işleminin başarılı olması durumunda, aşağıdaki ekrana benzer ekran göreceksiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_08.png)

Bu durumda 5. Maddede anlatılan ping işlemini ODTÜ dışında başka bir web sayfasının adresi için tekrarlayınız. (Örn. ping [www.google.com](http://www.google.com/)) Bu işlemin başarılı olması durumunda aşağıdaki ekrana benzer bir sonuç göreceksiniz.  Bu durumda bilgisayarın ağ bağlantısı düzgün ve çalışır durumdadır. Web sayfalarına bağlanamıyorsanız önbellek (proxy) ayarlarınızı kontrol ediniz. IP ayarlarınızda DNS adresi kısmına yazdığınız numaraları kontrol ediniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/ag_sorunu_09.png)

7.1 Ping işleminin başarısız olması durumunda Bilgisayarınızın “Yerel Alan Ağı Özellikleri” (Local Area Connection Properties) Bölümündeki “TCP/IP” kısmına DNS adresi olarak 144.122.199.90 ve 144.122.199.20 giriniz.

8\. Bilgisayarınızla duvar prizi arasında herhangi bir cihaz kullanılmaması önerilmektedir.