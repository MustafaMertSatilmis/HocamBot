[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/beyaz-listeye-e-posta-adreslerini-nasil-eklerim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 11783


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-add-someone-white-list "How can I add someone to the white list?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/beyaz-listeye-e-posta-adreslerini-nasil-eklerim "Beyaz listeye e-posta adreslerini nasıl eklerim?")

# Beyaz listeye e-posta adreslerini nasıl eklerim?

[Horde](https://faq.cc.metu.edu.tr/tr/groups/horde)

[https://horde.metu.edu.tr/login.php](https://horde.metu.edu.tr/login.php) adresine girin ve kullanıcı kodunuz ile şifrenizi ilgili yerlere yazarak giriş yapınız.

Giriş yapıldıktan sonra önce "Posta" ikonuna, daha sonra "Süzgeçler" ikonuna tıklanmalıdır.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde_filter_en.png)

Soldaki menüden "Beyaz Liste" butonuna tıklayınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/horde-whitelist.png)

Açılan sayfadaki metin kutusunda beyaz listeye eklemek istediğiniz e-mail adreslerini yazınız. (Dikkat: Eklemek istediğiniz her e-mail adresini ayrı satırlara ekleyiniz.)

E-mail adreslerini yazmayı bitirdiğinizde "Kaydet" butonuna tıklayınız.

Değişiklikler kaydedilmiştir. Yazdığınız e-mail adresleri artık beyaz listede bulunmaktadır, SPAM kutusuna iletilmeyecektir.