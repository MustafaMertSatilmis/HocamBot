[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ayni-anda-birden-fazla-kisiye-vekalet-verilebilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 25390


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ayni-anda-birden-fazla-kisiye-vekalet-verilebilir-mi)

# Aynı anda birden fazla kişiye vekalet verilebilir mi?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Sistemsel olarak bu mümkündür. Ancak gerekmedikçe verilmemesi tavsiye edilmektedir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.