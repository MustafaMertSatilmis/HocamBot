[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirmek-istedigimde-kartimda-bulunan-para-yeni-kimligime-aktarilir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-04-2022 **Görüntüleme:** 7980


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/case-need-change-my-smart-id-card-would-virtual-money-my-old-card-be-transferred-my-new-id-card "In case of the need to change my Smart ID card, would the virtual money on my old card be transferred to my new ID card?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kimlik-kartimi-degistirmek-istedigimde-kartimda-bulunan-para-yeni-kimligime-aktarilir-mi "Akıllı kimlik kartımı değiştirmek istediğimde kartımda bulunan para yeni kimliğime aktarılır mı?")

# Akıllı kimlik kartımı değiştirmek istediğimde kartımda bulunan para yeni kimliğime aktarılır mı?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınızı çeşitli nedenlerle (kayıp, çalıntı, kırılma, bozulma vb.) değiştirdiğinizde yeni kartınıza eski kartınızda bulunan bakiye otomatik olarak aktarılır. Bunun için yeni kartınızı nakit yükleme Kiosk'larından birine okutmanız yeterli olcaktır.

Herhangi bir sorun yaşamanız halinde [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/) adresinde kullanıcı hesabınızla giriş yaptıktan sonra durumunuzu belirterek ilgili birimlerce inceleme yapılmasını sağlayabilrisiniz.