[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketleri-yayinlamadan-test-edebilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6283


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-test-surveys-publication "Can I test the surveys before publication?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/olusturdugum-anketleri-yayinlamadan-test-edebilir-miyim "Oluşturduğum anketleri yayınlamadan test edebilir miyim?")

# Oluşturduğum anketleri yayınlamadan test edebilir miyim?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Oluşturduğunuz anketlerinizi, "Anket Önizlemesi" ikonuna tıklayarak önizleyebilir ve anketlerinizi test edebilirsiniz.