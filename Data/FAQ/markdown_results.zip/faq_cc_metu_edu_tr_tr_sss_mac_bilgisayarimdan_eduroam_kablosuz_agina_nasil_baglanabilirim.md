[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mac-bilgisayarimdan-eduroam-kablosuz-agina-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 19-04-2022 **Görüntüleme:** 23599


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-eduroam-wireless-network-using-my-mac-computer "How can I connect to eduroam wireless network using my Mac computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mac-bilgisayarimdan-eduroam-kablosuz-agina-nasil-baglanabilirim "Mac bilgisayarımdan eduroam kablosuz ağına nasıl bağlanabilirim?")

# Mac bilgisayarımdan eduroam kablosuz ağına nasıl bağlanabilirim?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Konfigürasyon dosyasını cihazınıza indirip çalıştırarak Eduroam'a bağlanabilirsiniz.

mobile.config dosyasını [indir](https://faq.cc.metu.edu.tr/tr/system/files/u2/metu_eduroam.mobileconfig)

User Account kısmında, kullanıcı\_adı@metu.edu.tr ve şifre girilmelidir.

Konfigürasyon dosyasını kendiniz oluşturmak isterseniz aşagıdaki adımları takip etmeniz gerekmektedir.

MacOS-Yosemite yüklü bilgisayarınızla eduroam kablosuz ağına bağlanmak için **Apple Configurator programını** indirip, kurunuz.

![](https://faq.cc.metu.edu.tr/system/files/u2/e1.jpg)

Programı çalıştırınız, Start Preparing Devices’a tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u2/e2.jpg)

Supervision aktif hale getirin. (ON yapın)

![](https://faq.cc.metu.edu.tr/system/files/u2/e3.jpg)

![](https://faq.cc.metu.edu.tr/system/files/u2/e4.jpg)

Apple Configurator programının alttında yer alan **+** düğmesine tıklayınca açılan menüden **Create New Profile** şeçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/e5.jpg)

Açılan pencerede önce **Wifi’a** ardından **configure**’e tıklayınız.

![](https://faq.cc.metu.edu.tr/system/files/u2/e7.jpg)

Bağlanmak istediğiniz network kısmına **eduroam** yazınız. Security Type’dan **WPA/WPA2 Enterprise** seçiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/e8.jpg)

Accepted EAP types başlığının altında bulunan **TTLS’** i seçiniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/e9.jpg)

User name ve password kısımlarını doldurup, Inner Authentication başlığı altında bulunan **PAP**’I seçiniz ve **Save**’e tıklayarak profile kaydediniz.

![](https://faq.cc.metu.edu.tr/system/files/u2/e10.jpg)

Profile’a isminin üzerine tıklayınız ve altta bulunan **+** işaretinin yanındaki simge ile (export profile) profilin bilgisayarınıza aktarılmasını sağlayınız.

![](https://faq.cc.metu.edu.tr/system/files/u2/e11.jpg)

![](https://faq.cc.metu.edu.tr/system/files/u2/e12.jpg)

Profilin dışa aktarıldığı yere gidip üzerine çift tıklayarak bilgisayarınıza kurulmasını sağlayınız.

![](https://faq.cc.metu.edu.tr/system/files/u2/e13.jpg)

![](https://faq.cc.metu.edu.tr/system/files/u2/e14.jpg)

![](https://faq.cc.metu.edu.tr/system/files/u2/e15.jpg)

![](https://faq.cc.metu.edu.tr/system/files/u2/e16.jpg)

![](https://faq.cc.metu.edu.tr/system/files/u2/e17_1.jpg)