[Jump to navigation](https://faq.cc.metu.edu.tr/tr/turnitin#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 16-09-2024 **Görüntüleme:** 27094


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/turnitin "TURNITIN")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/turnitin "TURNITIN")

# TURNITIN

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **TURNIT** **IN** **—**

**_TURNIT_** **_IN_** _intihal tespit hizmeti veren web tabanlı bir yazılımdır._

* * *

**_\[1\] Not:_** _**Uyarı!** Tezler, makaleler yüklenirken ad, soyad vb. bilgilerin çok dikkatli girilmesi gerekmektedir. Yanlış girilen bilgiler intihal oranını doğru olmayan bir biçimde yüksek gösterebilirler._

**_\[2\] Not:_** [**_Turnitin_** **_İntihal Tespit Yazılımına Üyelik Başvurularının Alınması Süreci Aydınlatma Metni_**](https://kvkk.metu.edu.tr/tr/system/files/aydinlatma_metinleri/BIDB/bidb_turnitin_intihal_tespit_yazilimina_uyelik_basvurularinin_alinmasi_sureci.pdf)

**_**_\[3\] Not:_**_** _Turnitin hesaplarıyla ilgili sorun (sınıf oluşturamama, belge yükleyememe, hesabınızın kilitlenmesi vb. durumlarda) yaşayan kullanıcılarımız [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) sistemi üzerinden karşılaştıkları problemleri iletebilirler._

* * *

**Hesap – Nasıl üye olurum?**

Turnitin servisini kullanmak isteyen akademik personelin (sadece ODTÜ Öğretim Üyeleri ve Görevlileri başvurabilir) **_[https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/)_** adresinde ad/soyad, akademik/idari pozisyon ve bölüm bilgilerini içeren bir vaka oluşturmaları gerekmektedir.

Araştırma görevlileri ancak bir ders kapsamında öğrencilere ödev/makale/tez kontrolü yapmaları gerektiğinde yukarıda belirtildiği şekilde Turnitin hesabı açılmış olan Öğretim Üyeleri ve Görevlileri tarafından TA (Teaching Assistant) olarak sisteme eklenebilmekte ve bu şekilde ödev/makale/tezleri denetleyebilmektedir. Bu nedenle araştırma görevlilerinin Turnitin hesap başvuruları değerlendirilmemektedir.

Kayıt sonrasında Turnitin'den gelecek olan e-posta takip edilip işlemler gerçekleştirilerek, öğretim üyeleri/görevlileri gerekli gördükleri yayınları intihal açısından taratabileceklerdir.

**_Yazılımın kullanımı ile ilgili olarak aşağıdaki kaynaklardan yararlanabilirsiniz:_**

- [_Turnitin_ _Kılavuz ve Rehberler_](https://help.turnitin.com/Home.htm)
- [_Turnitin_ _Yardım Merkezi_](https://www.turnitin.com/self-service/support-wizard.html)
- [_Turnitin Guides_](https://guides.turnitin.com/hc/en-us/articles/24008452116749-Welcome-to-Turnitin-Guides)
- [_Turnitin_ _Öğretmen Kılavuzu_](https://faq.cc.metu.edu.tr/system/files/u16319/tii_ogretmen_kilavuzu.pdf)
- [_Turnitin_ _Öğrenci Kılavuzu_](https://faq.cc.metu.edu.tr/system/files/u16319/tii_ogrenci_kilavuzu.pdf)

**Belge Silinmesi Hakkında**

**15 Ağustos 2022**'den itibaren, belge silme istekleri, mevcut otomatik belge silme iş akışı kullanılarak Turnitin sayfanızda tamamen sizin tarafınızdan yönetilecektir. Bu basitleştirilmiş süreç, Turnitin ile iletişime geçmek zorunda kalmadan hesabınızın veri gizliliğinin kontrolünü elinize almanızı sağlar. Bu değişiklik, daha önce kullanmış olabileceğiniz manuel çok adımlı işlemin yerini alacak ve kurumsal belgelerinizi Turnitin hesabınızdan hızlı ve verimli bir şekilde silmenizi sağlayacaktır.

Yukarıdakiler dikkate alındığında, Teknik Destek ekibi bu tarihten itibaren belge silme talepleri için artık destek sağlamayacaktır. Yukarıda belirtilen tarihten itibaren Turnitin Destek'e bir belge silme talebi gönderilirse, yeni belge silme iş akışına yönlendirileceksiniz.

_**Öğretim elemanı için belge silme aracı kılavuzu;**_

**[https://guides.turnitin.com/hc/en-us/articles/23453068441613-Requesting-paper-deletions](https://guides.turnitin.com/hc/en-us/articles/23453068441613-Requesting-paper-deletions)**

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *