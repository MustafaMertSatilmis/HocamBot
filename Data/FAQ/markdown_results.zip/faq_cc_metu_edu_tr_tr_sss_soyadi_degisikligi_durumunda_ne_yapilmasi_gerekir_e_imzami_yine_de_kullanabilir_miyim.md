[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/soyadi-degisikligi-durumunda-ne-yapilmasi-gerekir-e-imzami-yine-de-kullanabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-09-2020 **Görüntüleme:** 8328


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-should-be-done-case-change-surname-can-i-still-use-my-e-signature "What should be done in case of a change of surname? Can I still use my e-signature?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/soyadi-degisikligi-durumunda-ne-yapilmasi-gerekir-e-imzami-yine-de-kullanabilir-miyim "Soyadı değişikliği durumunda ne yapılması gerekir? E-imzamı yine de kullanabilir miyim?")

# Soyadı değişikliği durumunda ne yapılması gerekir? E-imzamı yine de kullanabilir miyim?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Soyadı değişikliği durumunda e-imza kitinizi kullanamazsınız. Bilgi güncelleme talebi ile e-imza kitinizi yenilemeniz gerekmektedir.

[http://faq.cc.metu.edu.tr/tr/sss/e-imzami-kaybettimcalindi-kimlik-bilgim-guncellendi-ne-yapmaliyim](http://faq.cc.metu.edu.tr/tr/sss/e-imzami-kaybettimcalindi-kimlik-bilgim-guncellendi-ne-yapmaliyim) linkinden ilgili bilgileri edinebilirsiniz.