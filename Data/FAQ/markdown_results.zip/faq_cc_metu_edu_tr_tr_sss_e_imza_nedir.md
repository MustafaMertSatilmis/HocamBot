[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-nedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-02-2022 **Görüntüleme:** 4526


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-e-signature "What is E-Signature?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-nedir "E-imza nedir?")

# E-imza nedir?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

E-imza veya Nitelikli Elektronik Sertifika (NES), tüm web sayfalarında kullanılan ıslak imzanın elektronik ortamdaki eşdeğeridir.Ek olarak, çeşitli elektronik ortamlarda (çevrimiçi veya çevrimdışı) bir kimlik doğrulama aracı olarak da kullanılabilir.

15 Ocak 2004 tarihli ve 5070 sayılı Elektronik İmza Kanununa göre yetkili Elektronik Sertifika Hizmet Sağlayıcıları tarafından verilen güvenli elektronik imza, ıslak imza ile aynı hukuki sonuçlara sahiptir.

Yasaya uygun olarak oluşturulan e-imza, bilgisayar veya elektronik doküman onay süreçleri için yasal bir zemin sağlar ve kağıdı kaldırır.

Niyet beyanında bulunmak isteyen kişi, kurumun belge akış sisteminde, web hizmetlerinde veya e-devlet hizmetlerinde e-imzayı kullanabilir.

```

```