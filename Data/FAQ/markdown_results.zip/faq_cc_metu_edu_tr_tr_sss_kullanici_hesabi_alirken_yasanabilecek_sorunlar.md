[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-alirken-yasanabilecek-sorunlar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 05-05-2022 **Görüntüleme:** 17426


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/problems-user-accounts "Problems with User Accounts")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullanici-hesabi-alirken-yasanabilecek-sorunlar "Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar")

# Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

[https://useraccount.metu.edu.tr](https://useraccount.metu.edu.tr/) adresinden kullanıcı hesabı alırken sorunla karşılaşırsanız aşağıdaki olası çözüm yollarını deneyebilirsiniz.

Mezunlarımız, alumniaccount sayfasında sorun yaşıyorlarsa mezunkart @ metu.edu.tr adresi ile iletişim kurabilirler.

**CODE 103: Kullanıcı hesabı yaratılamadı hatası alan öğrencilerimiz farklı bir tarayıcı ile tekrar deneyebilirler.**

**CODE 182: Lütfen doğru programı seçtiğinizi kontrol ediniz.**(Ankara ve Kıbrıs kampuslerindeki programların isim farklılıklarına dikkat ediniz.) Ayrıca ÖİDB tarafından dönem kaydınızın oluşturulduğundan da emin olunuz.

**CODE 183: Kullanıcı hesabınız oluşturulurken teknik bir hata oluşmuştur, lütfen kullanıcı bilgileriniz ile Bilişim Destek Ekibimize ODTÜ BİDB ana sayfasındaki “Bize Ulaşın” bağlantısından iletişime geçebilirsiniz.**

**Özel öğrenciler [https://useraccount.metu.edu.tr/newstudent/](https://useraccount.metu.edu.tr/newstudent/) adresine giriş yaptıklarında kayıt bulunamadı hatası (hata no:182) alıyorlarsa kayıtları sistem tarafından açıldıktan sonra tekrar kullanıcı kodu almayı deneyebilirler.**

**Başvurunuz sırasında mümkünse hotmail.com, outlook.com, live.com dışında bir eposta adresi kullanınız. Microsoft e-posta hizmetlerine gönderimlerde sıkıntı yaşanabilmektedir.**

**Eğer bu adreslerden birini kullandığınızda etkinleştirme mesajı size ulaştıysa işleminize devam edebilirsiniz. Gereksiz e-posta / Junk / Spam gibi klasörlerde de etkinleştirme mesajını bulamadıysanız öğrenci numaranız (veya TC Kimlik numaranız) ile birlikte Bilişim Destek Ekibimize ODTÜ BİDB ana sayfasındaki “Bize Ulaşın” bağlantısından ulaşabilirsiniz.**

**Mevcut Öğrenciler**

Mevcut öğrencilerimizin bu sayfayı kullanarak tekrar hesap yaratmalarına gerek yoktur. Geçerli kullanıcı adı ve şifrelerini kullanabilirler.