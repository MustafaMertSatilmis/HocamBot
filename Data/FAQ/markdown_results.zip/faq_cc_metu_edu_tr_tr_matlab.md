[Jump to navigation](https://faq.cc.metu.edu.tr/tr/matlab#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 31-01-2023 **Görüntüleme:** 145779


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/matlab "MATLAB")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/matlab "MATLAB")

# MATLAB

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**MATLAB ACADEMIC **—** TOTAL HEADCOUNT**

* * *

**_Uyarı!_****_Kişisel kullanım için_****_“MATLAB Individual”_** **_, kampüs içerisindeki laboratuvar bilgisayarları için_** **_“MATLAB Concurrent”_** **_kurulmalıdır._**

* * *

|     |     |
| --- | --- |
| ****MATLAB********R2022a******/ INDIVIDUAL** | **MATLAB **R2022a** /** **CONCURRENT **\[for lab use only\]**** |
| [**KURULUM**](https://faq.cc.metu.edu.tr/tr/matlab#individual) | [**KURULUM**](https://faq.cc.metu.edu.tr/tr/matlab#concurrent) |
| [**AKTİVASYON**](https://faq.cc.metu.edu.tr/tr/matlab#individual-aktivasyon) | [**AKTİVASYON**](https://faq.cc.metu.edu.tr/tr/matlab#concurrent-aktivasyon) |
| [**HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER**](https://faq.cc.metu.edu.tr/tr/matlab#individual-hata) | [**HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER**](https://faq.cc.metu.edu.tr/tr/matlab#concurrent-hata) |
| [**ÜNİVERSİTE LİSANSINI MATHWORKS HESABINA BAĞLAYIN**](https://faq.cc.metu.edu.tr/tr/matlab#link-license) |  |

_Orta Doğu Teknik Üniversitesi tüm Öğrencilere, Akademisyenlere ve Araştırmacılara sınırsız MATLAB ve Simulink ürünleri sağlamaktadır._

_Orta Doğu Teknik Üniversitesi kampüsü geneli için MATLAB, Simulink ve ilgili bütün eklentiler mevcuttur. Akademisyenler, araştırmacılar ve öğrenciler bütün ürünleri öğrenim alma, öğretme ve araştırma için kullanabilir. Sahip olduğunuz lisans hem üniversiteye bağlı bilgisayarlara hem de kişisel bilgisayarlara yüklenebilir._

**_MATLAB ve Simulink Hakkında_**

_MATLAB, teknik bir programlama dilidir ve algoritma geliştirme, data analizi yapma, görselleştirme ve sayısal hesaplama yapmakta için kullanılır. Simulink ise simülasyon, model tasarımları, çoklu alan dinamiği ve gömülü sistemler için kullanılan bir görsel ortamdır. MathWorks data analizi, görüntü işleme ve yapay zekâ gibi neredeyse 100’e yakın konu için özel ekstra ürün sunmaktadır._

**_Lisans Yükleme ve Aktive Etme (Öğrenciler, Bölüm ve Görevli)_**

_Yazılımı yüklemek ve diğer kaynakları kullanmak için örneğin, online eğitim ve öğretici kaynaklar, üniversitenin portal sayfasına erişmeniz gerekmektedir._

_Eğer MATLAB’da yeniyseniz, MATLAB Onramp online kursu ile 2 saatte basit kullanımı öğrenebilirsiniz._

**_Yardıma mı İhtiyacınız var?_**

[_Kampüs Geneli Lisansı İçin Hızlı Başlangıç_](https://www.mathworks.com/academia/campus/resources/quick-start.html) _ya da_ [_MathWorks Destek_](https://www.mathworks.com/support/contact_us.html?s_tid=tah_po_helpbutton) _sayfalarından erişebilirsiniz._

**_Başlangıç: Yetenekler ve Yazılımı Kullanma hakkında öğrenme_**

_▪_ [_Kampüs Geneli İnternet Üzerinden Eğitimler_](https://www.mathworks.com/academia/targeted/online-learning.html?s_tid=tah_po_mlacad)

_▪_ [_MATLAB ve Simulink ile İnternet Üzerinden Eğitim_](https://in.mathworks.com/academia/online-teaching.html)

_▪_ [_MATLAB Merkezi_](https://in.mathworks.com/matlabcentral/)

_▪_ [_MATLAB Paralel Sunucu_](https://in.mathworks.com/products/matlab-parallel-server/campus.html)

_▪  [Matlab Academy (Self-Paced Online Courses)](https://matlabacademy.mathworks.com/)_

_[_▪ MATLAB Kampüs Lisansı Başlangıç Kılavuzu_](https://faq.cc.metu.edu.tr/tr/system/files/u16319/campus-wide_license_quick_start_guide-tr.pdf)_

* * *

**— MATLAB** **R2022a** **/ INDIVIDUAL** **—**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/matlab#individual)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/matlab#individual-aktivasyon)

[**_HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER_**](https://faq.cc.metu.edu.tr/tr/matlab#individual-hata)

[**_ÜNİVERSİTE LİSANSINI MATHWORKS HESABINA BAĞLAYIN_**](https://faq.cc.metu.edu.tr/tr/matlab#link-license)

**_ADIM-1 <<<KURULUM-INDIVIDUAL>>>_**

_Orta Doğu Teknik Üniversitesi tarafından sağlanan **MATLAB Portal**’ına gidiniz._

**_URL >>_** [_https://www.mathworks.com/academia/tah-portal/orta-dogu-teknik-universitesi-31483888.html_](https://www.mathworks.com/academia/tah-portal/orta-dogu-teknik-universitesi-31483888.html)

**_“Get MATLAB and Simulink”_** _altındaki **“Sign in to get started”**_ _butonuna tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step1.png)

**_ADIM-2_**

_Karşınıza gelen ekranda ilgili alanlara ODTÜ kullanıcı adı ve şifrenizi yazınız. Daha sonra **"Login"** butonuna tıklayarak_ _ilerleyiniz_ _._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_sso_1.png)_

**_ADIM-3_**

_Karşınıza gelen ekranda kullanım sözleşmesini **"I accept the terms of use"** seçeneğini seçerek işaretleyerek kabul ediniz ve **"Submit"** butonuna tıklayarak_ _ilerleyiniz_ _._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_sso_2.png)_

**_ADIM-4_**

_Bu servis tarafından tedarik edilecek bilgiler ekranında varsayılan seçeneği işaretleyiniz ve **“Accept”** butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_sso_3.png)

**_ADIM-5_**

_Eğer MathWorks hesabınız varsa, giriş yapmak için üniversite email adresinizi kullanarak **“Sign In”** butonuna tıklayınız._

_Eğer MathWorks hesabınız yoksa, oluşturmak için üniversite email adresinizi kullanarak **“Create"** butonuna tıklayınız._

_Oluşturmuş olduğunuz üniversite lisansınızla ilişkili MathWorks hesabınıza giriş yapın. ( **"metu.edu.tr"** uzantılı mailiniz ile giriş yapmanız gerekmektedir.)_

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_sso_4.png)_

**_ADIM-6_**

**_"Download Installer"_** _butonuna tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step4.png)

**_ADIM-7_**

_Mevcut sürümü (R2022a) indirmek için **“Download for Windows”**_ _butonuna tıklayınız. **(Sisteminize uygun desteklenen bir platform seçiniz!)**_

**_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step5.png)_**

**_ADIM-8_**

_İndirmiş olduğunuz yükleme dosyasını çalıştırınız ve açılan ekranda MathWorks hesabıyla ilişkili email adresinizi ve parolanızı tekrar giriniz. Daha sonra_ **_"Next"_** _butonuna tıklayarak ilerleyiniz. (Yükleyicide, MathWorks Hesabı ile giriş yapın seçeneğini belirleyin!)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step6.png)

**_ADIM-9_**

_Lisans koşullarını kabul etmek için **"Yes"** seçeneğini işaretleyiniz ve **"Next"** butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step7.png)

**_ADIM-10_** **_<<<AKTİVASYON-INDIVIDUAL >>>_**

**_"Select license"_** _kısmında yer alan seçeneklerden **“Licenses”** seçeneğini işaretleyiniz **\[MATLAB (Individual) Academic-Total Headcount\]** ve **"Next"** butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step8.png)

**_ADIM-11_**

_Ekranda gösterilen bilgileri kontrol ediniz ve **“Windows User Name”** başlığı altındaki boş alana bilgisayarınızın Windows kullanıcı adını yazınız. Daha sonra **"Next"**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step9.png)

**_ADIM-12_**

**_"Next_** **_"_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step10.png)

**_ADIM-13_**

_Kullanmak istediğiniz MATLAB toolbox ürünlerini seçiniz ve **"Next"**butonuna tıklayarak ilerleyiniz. **(MATLAB ürününün mutlaka seçili olması tavsiye edilmektedir!)**_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step11.png)

**_ADIM-14_**

**_"Next_** **_"_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step12.png)

**_ADIM-15_**

**_"Begin Install"_**_butonuna tıklayarak kurulumu başlatınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step13.png)

**_ADIM-16_**

**_"Close"_**_butonuna tıklayarak kurulumu bitiriniz. Artık yazılımı kullanmaya başlayabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_individual_step14.png)

* * *

**HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER**

**\[1\]**MATLAB TAH lisansında, kullanıcılarımızın MATLAB’ı açtıklarında “lisansınız XX gün sonra sona erecektir” uyarısını almamaları için aşağıdaki linkler üzerinden bireysel olarak ilgili güncellemeyi tamamlamaları gerekmektedir.

**URL-1>>** [https://www.mathworks.com/videos/update-your-campus-wide-license-1600159973683.html](https://www.mathworks.com/videos/update-your-campus-wide-license-1600159973683.html)

**URL-2>>** [https://www.mathworks.com/support/search.html/answers/100222-why-do-i-receive-a-message-that-matlab-will-expire-in-xx-days.html](https://www.mathworks.com/support/search.html/answers/100222-why-do-i-receive-a-message-that-matlab-will-expire-in-xx-days.html)

* * *

**ÜNİVERSİTE LİSANSINI MATHWORKS HESABINA BAĞLAYIN**

MathWorks Hesabınızı geçerli bir lisansa bağlamak için aşağıdaki talimatlar geçerlidir.

**_ADIM-1_**

**mathworks.com**'da oturum açın (iş veya okul e-posta adresinizi kullanın).

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_link_step1.png)

**_ADIM-2_**

**“Link a License”** başlığı altındaki **“Link”** butonuna tıklayınız. (Sağ üst köşede yeralan Hesap simgenizin altındaki açılır menüden “Hesabım”ı seçerekte aynı yere ulaşabilirsiniz.)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_link_step2.png)

**_ADIM-3_**

Üniversitenize ait MATLAB lisansı (**40901578**) MathWorks Hesabınıza bağlanmıştır. Artık yazılımı kullanmaya başlayabilirsiniz.

**![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_link_step3.png)**

* * *

* * *

* * *

* * *

* * *

* * *

* * *

* * *

* * *

* * *

**— MATLAB** **R2022a** **/ CONCURRENT** **—**

**\[for lab use only\]**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve aktivasyon işlemlerini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/matlab#concurrent)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/matlab#concurrent-aktivasyon)

[**_HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER_**](https://faq.cc.metu.edu.tr/tr/matlab#concurrent-hata)

* * *

**_\[1\] Not:_** _MATLAB Akademik Kampus Lisansı modeli kapsamında, MathWorks firması tarafından sağlanan **MATLAB**_ **_Concurrent_** _Lisansı bilgisayar laboratuvarları gibi kampüs içerisinde kontrol edilen yerlerde kullanabilen bir lisans tipidir. **Bu lisansın kullanım amacı "LAB Bilgisayarları" ile sınırlıdır.** Merkezi lisans sunucu üzerinden lab bilgisayarları IP adreslerine erişim izni tanımlanabilmesi için [Bilişim Destek](https://bilisimdestek.metu.edu.tr/) üzerinden başvurulması gerekmektedir._

* * *

**_ADIM-1 <<<KURULUM-CONCURRENT>>>_**

**_“setup”_**_dosyasını yönetici olarak çalıştırınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step1.png)

**_ADIM-2_**

**_“Advanced Options”_**_başlığı altında **“I have a File Installation Key”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step2.png)

**_ADIM-3_**

_Lisans koşullarını kabul etmek için **"Yes"**_ _seçeneğini işaretleyiniz ve **"** **Next**_**_"_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step3.png)

**_ADIM-4_** **_<<<AKTİVASYON-CONCURRENT>>>_**

**_“Enter File Installation Key”_**_başlığı altındaki alana indirdiğiniz **“R2022a\_file\_installation\_key.txt”**_ _dosyası içerisinde yer alan yükleme anahtarını bu alana giriniz. Daha sonra **“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step4.png)

**_ADIM-5_**

_**"Browse**_ **_”_** _butonuna tıklayarak indirdiğiniz_**_“license.dat”_** _dosyasının yolunu gösteriniz._ _Daha sonra_**_“Next”_**_butonuna tıklayarak ilerleyiniz._

**_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step5.png)_**

**_ADIM-6_**

**_"_** **_Next_** **_"_**_butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step6.png)_

**_ADIM-7_**

**_"Next_** **_"_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step7.png)

**_ADIM-8_**

**_"Next_** **_"_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step8.png)

**_ADIM-9_**

**_"Begin Install"_**_butonuna tıklayarak kurulumu başlatınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step9.png)

**_ADIM-10_**

**_"Close"_**_butonuna tıklayarak kurulumu bitiriniz. Artık yazılımı kullanmaya başlayabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/matlab_r2022a_concurrent_step10.png)

* * *

**HATA MESAJLARI & ÖNERİLEN ÇÖZÜMLER**

**\[1\]**Internet bağlantısının mevcut olduğu kontrol edildikten sonra, **"C:\\Program Files\\MATLAB\\(SurumNo)\\licenses\\network.lic"** konumundaki **“network.lic”** dosyası notepad ile görüntülenmeli ve aşağıdaki gibi olması sağlanmalıdır.

SERVER matlab.cc.metu.edu.tr 27005

USE\_SERVER

**\[2\]** Kurulum esnasında 7. adımında **"License Manager"** seçeneğinin işaretli olmaması gerekmektedir. İşaretleyerek kurulum yaptıysanız, kurulumu kaldırıp doğru şekilde kurmanız gerekmektedir.

* * *

_**Bize**_ _**ulaşın**_ _**:**_[**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *

_ilerleyiniz_