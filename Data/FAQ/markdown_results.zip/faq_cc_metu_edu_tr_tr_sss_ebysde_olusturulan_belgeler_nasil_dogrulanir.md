[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-olusturulan-belgeler-nasil-dogrulanir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-02-2024 **Görüntüleme:** 25835


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-olusturulan-belgeler-nasil-dogrulanir)

# EBYS'de Oluşturulan Belgeler Nasıl Doğrulanır?

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

EBYS'de oluşturulan kurum içi yazıların EBYS'de sunulan belge doğrulama özelliği ile geçerli bir belge olup olmadığı kontrol edilebilmektedir.

Belge doğrulama yapılabilmesi için oluşturulan yazıların alt bölümünde görünen "Kare Kod" veya "Belge Doğrulama Kodu" kullanılabilir.

**Kurum içi yazılarda belge doğrulama bilgilerinin görünümü:**

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/kurum-ici-dogrulama.png)

Belge doğrulamak için;

- **"Kare Kod"** kullanılacaksa, bir kare kod okuyucu cihaz ya da akıllı telefonlara yüklenebilecek bir kare kod okuyucu (QR code reader) uygulama ile;
- **"Belge Doğrulama Kodu"** kullanılacaksa, belirtilen kodu doğrudan üzerine tıklayarak ya da bir web tarayıcı programın adres satırına kopyalayarak/elle yazarak,

**Belge E-imza Doğrulama Ekranına** ulaşılır:

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/belge-eimza-dogrulama-ekrani.png)

Gelen ekranda doğrulanacak belgeye ait doğrulama kodu otomatik olarak görünecektir.

Bu ekrandaki **"Resim Doğrulama"** alanına resimde belirtilen harf ya da rakamlar doğru şekilde girilip **"Sorgula"** butonuna tıklandığında, belge ile ilgili doğrulama bilgileri aşağıdaki şekilde görünecektir. Bu ekrandan belgenin içeriği, belgedeki imzalar **(\*)**, varsa belgenin ekleri, belgenin tarihi, belgenin sayısı ve tüm bu bilgileri içeren E-yazışma paketi (eyp) ekrandaki ilgili sekmelere tıklandığında görüntülenebilecektir. Bu ekrana ulaşılarak belirtilen bilgileri görüntülenebilen belge doğrulanmış bir belgedir.

_**(\*) Not:** Kurum içi oluşturulan belgelerin, belge doğrulama ekranından ziyade EBYS içinden görüntülenmesi esastır ve bir belgedeki tüm elektronik imzalar EBYS'den kontrol edildiğinde görülebilmektedir. Belge doğrulama ekranından tüm imzaların görülebilmesi için kurum içi belgelerin e-mühür ile mühürlenmesi gerekmektedir (EYP 2.0); ancak üniversitemizdeki mevcut işleyişte kurum içi belgeler mühürlenmeden (EYP 1.3) gönderilmektedir. Bu nedenle birden fazla imzacı içeren kurum içi belgeler belge doğrulama ekranından kontrol edildiğinde, sadece son imzacının bilgisi görülebilmektedir._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/belge-eimza-dogrulama-ekrani-2.png)

"Resim Doğrulama" alanına girilen harf ya da rakamlar eksik/doğru şekilde girilmediği takdirde, "Güvenlik Kodunu Giriniz" veya "Güvenlik Kodunu Kontrol Ediniz" şeklinde uyarı görüntülenecektir. Böyle bir durumda, resmin yanındaki ok simgesine tıklanarak resimdeki harf ve rakamların yenilenmesi sağlanabilir ve bu bilgiler "Resim Doğrulama" alanına girilip tekrar deneme yapılabilir. Bu alana girilen harf ve rakamlar doğru olmasına rağmen sorgulama sonucunda hata alınıyorsa, ya belgede görünen "Kare Kod"/"Belge Doğrulama Linki" hatalıdır; ya da belge geçerli bir belge değil demektir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.