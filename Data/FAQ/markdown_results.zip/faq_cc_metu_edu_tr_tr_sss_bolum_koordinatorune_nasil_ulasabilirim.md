[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bolum-koordinatorune-nasil-ulasabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-04-2022 **Görüntüleme:** 9362


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-reach-department-coordinator "How can I reach to department coordinator?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bolum-koordinatorune-nasil-ulasabilirim "Bölüm koordinatörüne nasıl ulaşabilirim?")

# Bölüm koordinatörüne nasıl ulaşabilirim?

[Bölüm Koordinatörlüğü](https://faq.cc.metu.edu.tr/tr/groups/bolum-koordinatorlugu)

Bölüm/birim koordinatörlerinin listesine [http://coordinators.metu.edu.tr/](http://coordinators.metu.edu.tr/) adresinden erişebilirsiniz.