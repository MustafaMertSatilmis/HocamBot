[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-saglik-raporlari-formunu-nasil-doldurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 14-06-2024 **Görüntüleme:** 2613


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-saglik-raporlari-formunu-nasil-doldurabilirim)

# EBYS'de sağlık raporları formunu nasıl doldurabilirim?

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

Üniversitemiz bünyesinde sağlık raporları için Personel Daire Başkanlığı tarafından belirlenen kurallar doğrultusunda EBYS'de yer alan Sağlık Raporları Formu doldurularak işlem yapılması gerekmektedir.

Form, sağlık raporunun personelin bağlı çalıştığı bölüm/birim sekreterliğine iletilmesinin ardından sekreterlik tarafından doldurulur. Sekreterlik olmayan yerlerde formu birim amiri dolduracaktır.

Form doldurulmadan önce [https://pdb.metu.edu.tr/tr/ebys-uzerinden-doldurulacak-saglik-raporlari-icin-bilgilendirme](https://pdb.metu.edu.tr/tr/ebys-uzerinden-doldurulacak-saglik-raporlari-icin-bilgilendirme) adresindeki kuralların gözden geçirilmesi önem arz etmektedir.

EBYS Sağlık Raporları Formu erişim ve kullanım yöntemi aşağıda tarif edilmiştir:

- EBYS'de oturum açınız.
- Sol menüden "Elektronik Formlar" seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_goruntusu_2024-04-04_144303.png)

- Açılan bölümden "Sağlık Raporları Formu" seçeneğini seçiniz.
- Form üzerinde gerekli bütün açıklamalar bulunmaktadır. Formu doldurup "Gönder" düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_goruntusu_2024-03-25_155737.png)

Sağlık (iş göremezlik) raporu formunda yer alan personel bilgileri (Gönderen Kişi, Statü, Birim) İnsan Kaynakları Yönetim Sisteminden (İKYS) anlık olarak aktarılarak gösterilir.

Sekreter/amir, form üzerinde;

- Rapor Kurumu,
- Rapor Türü,
- Protokol No,
- Rapor Süresi,
- Rapor Başlangıç Tarihi,
- Rapor Bitiş Tarihi
- Raporun Görseli

alanlarını iletilen sağlık raporuna uygun şekilde doldurur.

- Doldurduğunuz formun hangi aşamada olduğunu geçmiş ekranınızdan ilgili formun akış tarihçesine ulaşarak takip edebilirsiniz.

**Sağlık Raporu Formu Doldurulurken Dikkat Edilecek Hususlar**

1. Personel tipine göre iş akışında değişiklik olmayacaktır.
2. İlk amirin sağlık raporunu iade ve onay yetkisi olacaktır. Amir, raporun hatalı doldurulduğunu düşünüyorsa iade edebilecektir.
3. Rapor türü “Tek Hekim Raporu” olarak seçildiğinde, süre 10 günden fazla ise sistem uyarı verecektir.
4. Rapor türü “Heyet Raporu” olarak seçildiğinde, süre 10 gün veya 10 günden daha az belirtilirse sistem uyarı verecektir.
5. Girilen rapor "Tek Hekim Raporu" türündeyse, cari yıl içerisinde tek hekim kanalıyla alınacak toplam rapor süresinin ana ekranda giriş yapan personele de bilgi amaçlı gösterilecektir. Cari yıl içinde alınan ve toplamı 40 günü aşan raporların sisteme işlenmesine izin verilmeyecektir. Toplamı 40 günü aşan raporlar için sağlık kurulu onayı sonrası söz konusu sağlık raporları Personel Daire Başkanlığına resmi yazı ile bildirilecektir.
6. “Rapor Kurumu” alanı, "ODTÜ SRM" olarak işaretlendiyse protokol numarası alanı pasif olacak; değilse girilmesi zorunlu alan olacaktır.
7. Sağlık raporunun alındığı tarihte ilgili birime ulaştırılması (fiziksel iletimi mümkün olmasa dahi e-posta, anlık haberleşme kanalı vb. çevrimiçi ortamda) gerekmektedir.
8. Yıllık izinli olunan dönemlerde “Sağlık Raporu” alındığında yıllık izinin iptal edilip raporlu olunan tarihlere göre yeniden düzenlenmesi gerekmektedir. Göreve başlama tarihi geçen yıllık izin formları iptal edilememektedir.
9. Personelin sağlık hizmeti sunucusundan almış olduğu sağlık (iş göremezlik) raporları, talep edilmesi durumunda Personel Daire Başkanlığına iletilmek üzere bölüm/birimlerde saklanacaktır.

Sağlık Raporları Formu ile ilgili sorular için [https://pdb.metu.edu.tr/tr/iletisim](https://pdb.metu.edu.tr/tr/iletisim) sayfasındaki bilgileri kullanarak Personel Daire Başkanlığı ile iletişime geçebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.