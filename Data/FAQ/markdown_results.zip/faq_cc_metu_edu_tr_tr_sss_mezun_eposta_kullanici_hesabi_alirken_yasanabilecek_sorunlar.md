[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-kullanici-hesabi-alirken-yasanabilecek-sorunlar#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 14-12-2021 **Görüntüleme:** 3848


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/problems-alumni-user-accounts "Problems with Alumni User Accounts")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-kullanici-hesabi-alirken-yasanabilecek-sorunlar "Mezun Eposta Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar")

# Mezun Eposta Kullanıcı Hesabı Alırken Yaşanabilecek Sorunlar

[Mezun E-posta](https://faq.cc.metu.edu.tr/tr/groups/mezun-e-posta)

[https://alumniaccount.metu.edu.tr/](https://alumniaccount.metu.edu.tr/ "alumniaccount.metu.edu.tr") adresinden mezun eposta kullanıcı hesabı alırken sorunla karşılaşırsanız aşağıdaki olası çözüm yollarını deneyebilirsiniz.

**CODE 182: Uygulama bulunamadı. Lütfen başvurunuzda kullandığınız bilgilerin aynısını girdiğinizden emin olun.**

**CODE 183: Mezun kullanıcı kodunuzu oluştururken bir hata oluştu, lütfen daha sonra tekrar deneyiniz.**

****CODE 18** 4: Girilen e-posta, başvurunuzda kullanılan e-posta ile eşleşmiyor. Lütfen başvurunuzda kullandığınız bilgilerin aynısını girdiğinizden emin olun.**

****CODE 18**5: Hesabınızı zaten oluşturdunuz.**

**Başvurunuz sırasında mümkünse hotmail.com, outlook.com, live.com dışında bir eposta adresi kullanınız. Microsoft e-posta hizmetlerine gönderimlerde sıkıntı yaşanabilmektedir.**