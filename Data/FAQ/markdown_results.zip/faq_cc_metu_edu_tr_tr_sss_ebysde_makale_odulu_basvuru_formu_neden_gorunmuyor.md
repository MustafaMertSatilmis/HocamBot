[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-makale-odulu-basvuru-formu-neden-gorunmuyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 3164


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-makale-odulu-basvuru-formu-neden-gorunmuyor)

# EBYS'de Makale Ödülü başvuru formu neden görünmüyor?

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

Makale ödülü başvurularının 1 Ekim 2020 tarihinden itibaren Akademik Performans Değerlendirme Süreç Yönetim Sistemi ( [https://apsis.metu.edu.tr/](https://apsis.metu.edu.tr/)) üzerinden yapılacak olması nedeniyle EBYS Makale Ödülü Başvuru Formu erişime kapatılmıştır. Konuyla ilgili sorular Akademik Programlar ve Eğitim Koordinatörlüğüne e-posta yoluyla ( [apek@metu.edu.tr](mailto:apek@metu.edu.tr)) iletebilir.

ODTÜ Geliştirme Vakfı Yayın Ödülleri Öğrenci, İdari Personel, Emekli Öğretim Elemanı, Konuk Araştırmacı (ÖYP, DOSAP vb) başvuruları için [https://apek.metu.edu.tr/tr/odtu-gelistirme-vakfi-yayin-odulleri-ogrenci...](https://apek.metu.edu.tr/tr/odtu-gelistirme-vakfi-yayin-odulleri-ogrenci-idari-personel-emekli-ogretim-elemani-basvurulari) adresinden bilgi alınabilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.