[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yaz-okulu-servis-dersleri-uygulamasi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 22-06-2017 **Görüntüleme:** 7519


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yaz-okulu-servis-dersleri-uygulamasi)

# Yaz Okulu Servis Dersleri uygulaması

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

**YAZ OKULUNDA AÇILAN MATEMATİK SERVİS DERSLERİNE KAYIT**

Matematik Bölümü tarafından verilen servis derslerinde kontenjanlar sınırlıdır. Taleplerin tümünün karşılanması mümkün olmayacaktır.

Belirtilen derslerde yazokuluna mahsus olmak üzere aşağıda belirtilen uygulama yapılacaktır.

Bu kapsamdaki dersleri yazokulunda aldığı takdirde yazokulu sonunda mezuniyet durumunda olan öğrencilere öncelik verilecektir. Bu kapsamdaki öğrenciler ÖİDB’den mezuniyet durumunda olduklarına dair yazı alacak ve bir dilekçe ekinde ilgili Bölüm Başkanlığı’na verecektir. Bölüm başkanlığı tarafından bu öğrencilerin ilgili derse kayıt olmaları sağlanacaktır.

28 Haziran 2017 tarihinde açılacak 2016-3 dönemi yaz okulu kayıtlarında MATH 118 (2360118) ve MATH 120 (2360120) dersleri için “seanslı kayıt” uygulaması yapılacaktır. Bu uygulama Matematik Bölümü Başkanlığı tarafından istenmekte olup amaç öğrenciler arası ders satışlarına engel olmaktır.

Uygulama, bir öğrencinin dersi bırakıp aynı anda bir arkadaşının dersi almasına engel olacak şekilde kurgulanmıştır. Buna göre:

1) Sabah 9:00’da kayıtlar başladığı anda ders kapasiteleri dolana kadar “önce gelen alır” prensibiyle kayıtlar yapılacaktır. Bölüm tarafından section kapasitesi olarak belirlenen sayıda öğrenci dersi aldığı anda ilgili section’a veritabanında “kilit” atılır ve bir öğrencinin dersi bırakmasından dolayı boşalan kontenjanın alınması veya bölüm tarafından section’un kontenjanının artırılması ancak saat 13.00’de gerçekleşebilir.

2) Saat 13.00’de artan kontenjan veya dersi bırakanlardan kaynaklı olarak açığa çıkan uygun kapasite yine “ilk gelen alır” prensibine göre kayıt edilir. Section bazında kontenjanların dolmasıyla veritabanına tekrar kilit atılır. Sonrasında yapılan kontenjan artışları veya dersi bırakanlardan kaynaklı açığa çıkan kontenjanlar saat 16.00’da alınabilir olur.

3) Saat 16.00’dan sonra aynı şekilde kontenjanlar doldurulduğunda veritabanına ilgili section için “kilit atılır ve aynı şekilde ertesi gün saat 9.00’a kadar açığa çıkan kontenjanlar kullanılamaz. Kayıt süresince bu durum her gün 9.00, 13.00 ve 16.00’da tekrarlanır.

4) Bölümlere tanınan yetki doğrultusunda, (yaz okulunda dersi aldığında mezun olabilme durumu gibi.) Bölümler belli bir öğrenciye yaz okulunda dersi alma, kontenjan ayırma, belli bir section’a kayıt olma hakkı verebilir. Bu durumda ilgili öğrenci ilgili section’a diğer öğrenciler ile ilk gelen olma yarışına katılmadan kendini kayıt edebilir. Bu durum, bölümün İdari bir kararı olup bir sistem problemi değildir. Yaz okulu kayıtlarında sıklıkla yaşanan “ kontenjanlar doldu, ben alamadım, benden sonra bir arkadaşım gelip kayıt olabilmiş” şeklinde gelen bildirimlerin temel sebebi budur. Bu konuda ilgili Bölüm yetkilileriyle konuşmak gerekmektedir.

5) Kontenjan artışları, kurulan otomasyonlar dahilinde Bölümler tarafından yapılmaktadır. BİDB’nin kontenjan artışı veya azaltma konusunda herhangi bir yetkisi ve uygulaması yoktur. Bölümler tarafından yapılan kontenjan artışları her gün 9.00, 13.00 ve 16.00 saatlerinde gerçekleştirilmektedir.

6) Yaz okulunda Matematik derslerine yönelik talep yoğunluğu sebebiyle kayıtlar çok çabuk dolmaktadır. Öğrenciler arasında milisaniye düzeyinde farklılılar ile bir öğrenci dersi alabilirken diğer öğrenci alamamaktadır.

Aynı süreçler grup değişiklikleri için de geçerlidir.

Yaz okulunda açılan ilgili bölümlerin servis derslerine kayıt konusunda detaylı bilgilere (açılacak dersler, dersin alınma kriterleri, kapasite vb.) aşağıdaki adresten ulaşılabilir.

[http://oibs3.metu.edu.tr/View\_Program\_Course\_Details\_64/](http://oibs3.metu.edu.tr/View_Program_Course_Details_64/)

Matematik Bölüm başkanlığı duyurularına aşağıdaki web adreslerinden ulaşılabilir.

[http://math.metu.edu.tr/](http://math.metu.edu.tr/)