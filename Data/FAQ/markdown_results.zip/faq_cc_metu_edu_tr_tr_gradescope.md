[Jump to navigation](https://faq.cc.metu.edu.tr/tr/gradescope#main-menu)

﻿

-A+A

**Son Güncelleme:** 14-11-2023 **Görüntüleme:** 9373


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/gradescope "GRADESCOPE")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/gradescope "GRADESCOPE")

# GRADESCOPE

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— GRADESCOPE —**

**_Gradescope_** _, yüksek öğrenim için çevrimiçi ve yapay zekâ destekli not verme araçları sunar._ _Gradescope_ _yazılımı, yazılı sınavları, ev ödevlerini ve gönderilen kodu otomatik olarak derecelendirmek için araçlar sunar._ _Gradescope_ _, eğitmenlerin çevrimiçi veya sınıfta tüm değerlendirmelerini sorunsuz bir şekilde yönetmelerine ve not vermelerine yardımcı olur._ _Gradescope_ _, değişken uzunluklu ödevleri (problem setleri ve projeler) ve sabit şablonlu ödevleri (çalışma sayfaları, testler, optik cevap kağıdı ve sınavlar) destekler._

* * *

**Hesap - Nasıl erişebilirim?**

Hesabınızı oluşturmak için lütfen aşağıdaki adımları izleyiniz:

1. [https://www.gradescope.com/](https://www.gradescope.com/) adresine gidiniz
2. "Sign Up" düğmesini tıklayın ve "Eğitmen" veya "Öğrenci" olarak kaydolun
3. Gradescope'tan gelen bir e-posta için gelen kutunuzu kontrol edin
4. “set your password” bağlantısını tıklayın ve parolanızı oluşturun
5. Artık hesabınıza erişebilirsiniz.

Ayrıca Gradescope uygulamasıyla ODTÜClass arasında entegrasyon sağlanmıştır. ODTÜClass'ta ders aktivitesi ekleyerek de kullanım sağlayabilirsiniz.

**Kaynaklar & Bağlantılar**

Gradescope ile ilgili ayrıntılı yardım belgeleri/talimatları için lütfen aşağıdaki makalelere ve kısa videolara bakınız.

- [Get Started Page](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly93d3cuZ3JhZGVzY29wZS5jb20vZ2V0X3N0YXJ0ZWQjZ3Jvb3Zlc3VtOjE3MDY5MTE4MTQ%3D) \- Kısa nasıl yapılır videoları serisi
- [Help Center](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9oZWxwLmdyYWRlc2NvcGUuY29tLyNncm9vdmVzdW06LTI0MTYzODkzNg%3D%3D) \- Arama yapılabilir yardım merkezinde bulunan yazılı yardım belgeleri ve SSS makaleleri
- [Remote Assessment FAQ Guide](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9oZWxwLmdyYWRlc2NvcGUuY29tL2NhdGVnb3J5L2VsbzVrOHk3bmUtcmVtb3RlLWZhcSNncm9vdmVzdW06LTE0MDIzNjk4MjA%3D) \- Değerlendirmeleri uzaktan yapmak için sık sorulan sorulara yönelik kılavuz ve yanıtlar
- [Recorded Gradescope Workshop](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9ncmFkZXNjb3BlLndpc3RpYS5jb20vbWVkaWFzLzVjMGNvc25xcGojZ3Jvb3Zlc3VtOjE2Nzg5MzgwNDI%3D) \- Kolayca gezinmek için bölümler içeren önceki bir "Uzaktan Değerlendirme için Gradescope ile Başlayın" kaydı
- [Monthly Open Workshops](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9pbmZvLmdyYWRlc2NvcGUuY29tL2VtZWEtd2Vla2x5LXdvcmtzaG9wI2dyb292ZXN1bTotMjA5MjQyODM4NQ%3D%3D) \- Her Çarşamba 15:00 BST'de düzenlenen Başlarken Atölyemize herkes kaydolabilir.
- [User Experience Videos](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9pbmZvLmdyYWRlc2NvcGUuY29tL2VtZWEvbGVhcm4tZnJvbS1mZWxsb3ctZWR1Y2F0aW9uLXByb2Zlc3Npb25hbHMjZ3Jvb3Zlc3VtOi0xNzE1NTUwMzYz) \- Gradescope kullanma deneyimlerini paylaşan bir dizi eğitmen
- [Student Walkthrough of Gradescope](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9oZWxwLmdyYWRlc2NvcGUuY29tL2NhdGVnb3J5L2N5azRpajJkd2ktc3R1ZGVudC13b3JrZmxvdyNncm9vdmVzdW06MTE5NzgyNjc2OQ%3D%3D) \- Kolayca gezinmek için bölümlerle birlikte öğrenci deneyimine ilişkin 15 dakikalık inceleme
- [Bubble sheet assignments](https://groove.turnitin.com/url/19tr5xe2vekhhkovplng3zt/aHR0cHM6Ly9oZWxwLmdyYWRlc2NvcGUuY29tL2FydGljbGUvZ2t3dnE2MDZmcS1pbnN0cnVjdG9yLWFzc2lnbm1lbnQtYnViYmxlLXNoZWV0cyNncm9vdmVzdW06LTEzMDkyMTY0MzA%3D) \- Çoktan seçmeli sınavların nasıl uygulanabileceğine ilişkin kılavuz
- [Gradescope ile çoktan seçmeli sınav uygulaması](https://faq.cc.metu.edu.tr/tr/sss/gradescopeta-coktan-secmeli-sinavlar)

Gradescope kullanıcı eğitimi - YouTube

ODTÜ Bilişim Destek

No subscribers

[Gradescope kullanıcı eğitimi](https://www.youtube.com/watch?v=0XTE0onKPfY)

ODTÜ Bilişim Destek

Search

Info

Shopping

Tap to unmute

If playback doesn't begin shortly, try restarting your device.

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

CancelConfirm

Share

Include playlist

An error occurred while retrieving sharing information. Please try again later.

Watch later

Share

Copy link

Watch on

0:00

0:00 / 1:15:13•Live

•

[Watch on YouTube](https://www.youtube.com/watch?v=0XTE0onKPfY "Watch on YouTube")

**_\[1\] Not: **_Gradescope ile ilgili yardım ve destek talepleriniz için_** **_[help@gradescope.com](mailto:help@gradescope.com)_** **_adresine e-posta gönderebilirsiniz._**_**

**_**_**_\[2\] Not:**_Dil menüsünden tercih ettiğiniz dili Türkçe olarak seçebilirsiniz. ( [https://www.gradescope.com/account/edit](https://www.gradescope.com/account/edit))_**_**_**_**

**_**_**_**_\[3\] Not: Gradescope üzerinde yüklenen bir essay ödevi için "similarity check" yapılmamaktadır. Hocalarımız, benzerlik raporu almak için, ya turnitin.com üzerindeki hesaplarını kullanabilirler ya da Moodle-Turnitin entegrasyonundan faydalanarak, Moodle üzerinde Turnitin ödevi oluşturmaları gerekmektedir._**_**_**_**

* * *

**_Bize ulaşın_** **_:_****_[https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)_**

* * *