[Jump to navigation](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-05-2022 **Görüntüleme:** 95536


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/outsourced-software "OUTSOURCED SOFTWARE OPPORTUNITIES FOR METU PERSONNEL AND STUDENTS")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/OutsourcedSoftware "ODTÜ Personel ve Öğrencilerine Sağlanan Dışarıdan İndirilen Yazılım Olanakları")

# ODTÜ Personel ve Öğrencilerine Sağlanan Dışarıdan İndirilen Yazılım Olanakları

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

|     |     |
| --- | --- |
| **[Abaqus](http://faq.cc.metu.edu.tr/tr/abaqus)** | Öğrenci sürümüne [https://edu.3ds.com/en/software/abaqus-student-edition](https://edu.3ds.com/en/software/abaqus-student-edition) adresinden erişebilirsiniz. |
| [**Adobe Acrobat**](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi) | PDF'leri görüntülemek, dönüştürmek, sıkıştırmak veya imzalamak için Adobe Acrobat eklentisini tarayıcınıza ekleyerek ücretsiz olarak kullanabilirsiniz. Detaylı bilgi için [tıklayınız.](https://faq.cc.metu.edu.tr/tr/adobe-acrobat-tarayici-uzantisi) |
| **[Ansys](http://faq.cc.metu.edu.tr/tr/ansys)** | Öğrenci sürümüne [https://www.ansys.com/academic/students](https://www.ansys.com/academic/students) adresinden erişebilirsiniz. |
| **[Autodesk/Autocad](http://faq.cc.metu.edu.tr/tr/autodesk-autocad)** | Öğrenci sürümüne [https://www.autodesk.com/education/edu-software/overview?sorting=feature...](https://www.autodesk.com/education/edu-software/overview?sorting=featured&filters=individual) adresinden erişebilirsiniz. |
| [**MATLAB**](http://faq.cc.metu.edu.tr/tr/matlab) | Eğitim materyallerine kendi hesabınız ile password oluşturup "license number 40901578" kullanarak [https://www.mathworks.com](https://www.mathworks.com/) adresinden erişebilirsiniz. |
| **Office 365** | Microsoft tarafından sunulan Office 365 Eğitim Hizmeti, bir akademik kuruma kayıtlı olan öğrencilere ücretsiz sunulmaktadır. Öğrencilerin, öğrencilik hayatları süresince hizmetten ücretsiz olarak yararlanabilmeleri için, .edu uzantılı bir e-posta adresine (örnek: xxx @ xxx.edu.tr) sahip olmaları gerekmektedir. Office 365 ile ilgili daha detaylı bilgi [https://www.microsoft.com/tr-tr/education/products/office](https://www.microsoft.com/tr-tr/education/products/office) adresinden edinilebilir. |
| **Öğretim için Azure Geliştirici Araçlar** | Daha önce Microsoft Imagine Standard ve Premium olarak bilinen Öğretim için Azure Geliştirici Araçları, onaylı okullara ve bölümlere yönelik olan ve bilim, teknoloji, mühendislik ve matematik (FeTeMM) programlarında yaygın olarak kullanılan araçlara erişim sunan abonelik temelli bir tekliftir. Bu teklif, öğretim üyelerimize ve öğrencilerimize Microsoft’un profesyonel geliştirici ve tasarımcı araçlarını, yazılımlarını ve hizmetlerini sunar. Öğrencilere ilham kaynağı olabilecek ve onlara heyecan verebilecek en yeni teknolojileri ve bulut hizmetlerini içerir. Ayrıca eğitimcilere, yeni yöntemleri kullanarak öğrencilere zorlayıcı hedefler vermeye ve onları motive edip katılımlarını sağlamaya yönelik çeşitli kaynaklar sunar.<br>Bu program eğitimcilerin ve öğrencilerin Microsoft ürünlerine ve teknolojilerine erişimi sağlar.<br>Öğretim için Azure Geliştirici Araçları aboneliğinizle edinilen yazılım yalnızca eğitim ve araştırma amaçlarına yöneliktir. Bu yazılımı bir bölümün altyapısını çalıştırmak için kullanamazsınız.<br>Azure Dev Tools For Teaching içeriğine erişebilmek için aşağıdaki adımları izleyiniz:<br>1- Bir Microsoft hesabınız yoksa (outlook.com, live.com, hotmail.com ..vb), öncelikle bir Microsoft Hesabı için kayıt olunuz.<br>2- Microsoft hesabınız ile aşağıdaki adrese giriş yapınız.<br>[https://portal.azure.com/#blade/Microsoft\_Azure\_Education/EducationMenuB...](https://portal.azure.com/#blade/Microsoft_Azure_Education/EducationMenuBlade/quickstart)<br>3- Giriş yaptıktan sonra eğitim kurumu hesabı olduğunuzu kanıtlamak için açılan sayfada hata mesajına tıklayınız. ( **Eğer bir uyarı mesajı göremiyorsanız hesabınızdan çıkış yapıp (Logout) sonrasında [https://signup.azure.com/studentverification?offerType=3](https://signup.azure.com/studentverification?offerType=3) adresine gidiniz ve "Enter your school email address" yazısı altındaki alana metu.edu.tr uzantılı e-posta adresinizi giriniz. E-posta hesabınıza gelecek Doğrulama işlemlerini tamamlayınız.**)<br>4- Açılan sayfada istendiğinde "metu.edu.tr" hesabınızı girip talimatları takip ediniz.<br>Bu işlemlerden sonra yazılımlara yukarıdaki adresten erişebilirsiniz. |
| **Microsoft Teams** | [http://faq.cc.metu.edu.tr/tr/MicrosoftTeams](http://faq.cc.metu.edu.tr/tr/MicrosoftTeams) adresini ziyaret ediniz. |
| **MSC** | MSC yazılımının öğrenci sürümlerine [http://www.mscsoftware.com/student-editions](http://www.mscsoftware.com/student-editions) adresinden erişilebilir. |
| **[Visual Studio](http://faq.cc.metu.edu.tr/tr/microsoft-visual-studio)** | Yazılıma [https://visualstudio.microsoft.com/tr/free-developer-offers/](https://visualstudio.microsoft.com/tr/free-developer-offers/) adresinden erişebilirsiniz. |

Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.