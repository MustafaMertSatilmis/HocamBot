[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglantim-surekli-kesiliyor-baglanamiyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 9692


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-frequently-disconnectcan-not-connect-eduroam-network "I frequently disconnect/can not connect to the eduroam network?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-agina-baglantim-surekli-kesiliyor-baglanamiyor "eduroam ağına bağlantım sürekli kesiliyor / bağlanamıyor?")

# eduroam ağına bağlantım sürekli kesiliyor / bağlanamıyor?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

eduroam bağlantısını sağlıklı bir şekilde kullanabilmeniz için bilgisayarınızdaki kablosuz ağ bağdaştırıcısı sürücüsünün güncel olması gerekmektedir.Ağ bağdaştırıcınızın marka ve modeline göre destek sağlayıcınızdan bilgi alın.