[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# PC Salonları

|     |
| --- |
| [BİDB tarafından işletilen PC salonlarında kullanıcı kodum ile giriş yapamıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/bidb-tarafindan-isletilen-pc-salonlarinda-kullanici-kodum-ile-giris-yapamiyorum-ne-yapmaliyim) |
| [Ders kayıtları için hangi PC Salonlarını kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ders-kayitlari-icin-hangi-pc-salonlarini-kullanabilirim) |
| [PC Salon Görevlilerinin Görev ve Sorumlulukları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salon-gorevlilerinin-gorev-ve-sorumluluklari) |
| [PC Salonları Çalışma Saatleri Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-calisma-saatleri) |
| [PC Salonları Donanım Bilgileri Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-donanim-bilgileri) |
| [PC Salonları Haritasına Nasıl Erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-haritasi) |
| [PC Salonları Kullanım Kuralları Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-kullanim-kurallari) |
| [PC Salonlarına Uygulama Kurabilir Miyim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarina-uygulama-kurabilir-miyim) |
| [PC salonlarında öğrenci asistan olarak görev almak istiyorum, nereye başvurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-ogrenci-asistan-olarak-gorev-almak-istiyorum-nereye-basvurabilirim) |
| [PC Salonlarında Yüklü Yazılımlar Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarinda-yuklu-yazilimlar-nelerdir) |
| [PC salonlarındaki bilgisayarlara kampüs dışından nasıl erişebilirim?](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlarindaki-bilgisayarlara-kampus-disindan-nasil-erisebilirim) |

[![Subscribe to PC Salonları](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/176/all/feed "Subscribe to PC Salonları")