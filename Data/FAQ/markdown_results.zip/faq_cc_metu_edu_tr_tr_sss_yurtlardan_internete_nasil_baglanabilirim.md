[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 21-07-2023 **Görüntüleme:** 53837


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-connect-internet-dormitories "How can I connect to INTERNET from dormitories?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/yurtlardan-internete-nasil-baglanabilirim "Yurtlardan İnternete nasıl bağlanabilirim?")

# Yurtlardan İnternete nasıl bağlanabilirim?

[ODTÜKENT/Yurtlar/Lojmanlar](https://faq.cc.metu.edu.tr/tr/groups/odtukentyurtlarlojmanlar)

Yurtlarda kalıp kablolu ağ bağlantısından yararlanmak isteyen kullanıcılarımızın öncelikle yurtlar otomasyon sistemine kayıtlarının yapılmış olması gerekmektedir. Bu işlem kalınan yurt müdürü tarafından kullanıcının yurt kaydı sırasında yapılmaktadır. Kayıt işleminin üzerinden **15 dakika** süre geçmesi beklendikten sonra, kullanıcı [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) adresine giderek, merkezi sistem kullanıcı kodu ve şifre ikilisi ile giriş yapmalıdır. **Wired Network** bağlantısı üzerinden MAC adresi bilgisini girerek kablolu ağa bağlanabilirler.

_Yaz dönemi yurtlarında kalanlar ise kaydının doğru yurda yapıldığından emin olmalıdır. Bunun için kaldığı yurdun müdürü ile görüşebilir veya Yurtlar Müdürlüğü'ne (2. Yurt Binası) gidip bilgi alabilir. Kişilerin herhangi bir yurda kaydı yoksa veya kaydı doğru yurda yapılmamışsa netregister arayüzünden_ _( [https://netregister.metu.edu.tr/](https://netregister.metu.edu.tr/)) kendi kablolu ağ kaydını yapamayacaklardır._

**Not:** Tüm yurtlarda TCP/IP ayarları DHCP ile dağıtıldığı için, yurtlarda ikamet eden kullanıcılarımız MAC kayıt işlemini doğru bir şekilde yaptıklarında otomatik olarak internete erişim sağlayabilirler. Ayrıca yurtlarda ikamet eden kullanıcılarımız binalardaki kablolu ağ üzerinden bilgisayarları kayıtsız iken de [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) arayüzüne erişebilir ve kayıt işlemini yapabilirler. Bağlantı ayarlarının otomatik olarak ayarlanması için aşağıdaki adımlar izlenmelidir:

**1.** Bilgisayarınızın ethernet kartını tanıdığından emin olmalısınız. Örneğin bunun için Windows işletim sistemlerinde masaüstünde bilgisayarım ikonuna sağ tıklayarak, buradan özellikleri seçip, daha sonra aygıt yöneticisi sekmesini açıp, buradan ağ kartınızı bulmalısınız. Ağ kartınız bilgisayarınız tarafından tanınmışsa, yani doğru sürücüler yüklenmişse, sorunsuz bir şekilde devam edebilirsiniz. Eğer aygıtın üzerinde ünlem işareti varsa bu kartın sistem tarafından tanınmadığına işaret eder ve doğru sürücülerin yüklenmesi gerekir.

**2.** Bir sonraki aşama TCP/IP ayarlarının yapılmasıdır. Bunun için masaüstünde ağ bağlantıları ikonuna sağ tıklayarak, özellikleri seçip, burdan TCP/IP ayarları seçilerek özellikler ikonuna tıklanmalıdır. Buradaki IP adresi ve DNS bölümlerinin OTOMATİK olarak tanımlandığından emin olunuz. Bütün Windows işletim sistemlerinde TCP/IP ayarları aşağı yukarı aynı şekilde yapılmaktadır.

**3.** Son olarak fiziksel bağlantıyı sağlamak amacı ile bilgisayar malzemeleri satan mağazalardan UTP ara kablo temin etmeniz gerekmektedir. Bu kabloyu satın almadan önce sorun yaşamamak için bilgisayarınızın bulunduğu konumla priz arasındaki mesafeyi ölçmenizi öneririz. Temin ettiğiniz UTP ara kabloyu bilgisayarınıza ve odanızdaki ilgili prize taktıktan sonra bağlantı işlemini tamamlamış olursunuz.

**4.** Yurtlar bölgesinde ağ bağlantısından faydalanan kullanıcılarımızın [Yurt Odaları Bilgisayar Ağı Kullanım Kurallarını](https://faq.cc.metu.edu.tr/tr/sss/odtu-yurt-odalari-bilgisayar-agi-kullanim-kurallari-nelerdir) mutlaka okumasını öneririz.

Sorunlar ve sorular için öncelikle [https://faq.cc.metu.edu.tr/tr/sss/yurtlarda-yasadigim-ag-baglanti-sorunu...](https://faq.cc.metu.edu.tr/tr/sss/yurtlarda-yasadigim-ag-baglanti-sorunumun-kaynagini-nasil-ogrenebilirim) adresindeki adımları takip ediniz. Sorununuz devam ediyorsa [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden veya doğrudan [Bilişim Destek Formu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=ycoord) üzerinden vaka kaydı oluşturabilirsiniz.