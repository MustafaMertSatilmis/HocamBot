[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 08-02-2018 **Görüntüleme:** 42702


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-ethernet-adapter-my-computer "How can I find out the MAC (physical) address of the Ethernet adapter of my computer?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bilgisayarimin-ethernet-kartinin-mac-fiziksel-adresini-nasil-ogrenebilirim "Bilgisayarımın Ethernet kartının MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Bilgisayarımın Ethernet kartının MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

MAC (Media Access Control) adresi, bilgisayar ağında bir cihazın ağ donanımını tanımaya yarayan, 0-9 arası rakamlar ve A-F arası harflerden oluşan ifadedir. Her ağ arayüzünün (ethernet, kablosuz, bluetooth vb.) kendine özel, benzersiz birer MAC adresi vardır.

ODTÜ yerleşkesinde kurulu olan kablolu ağlarda MAC adresi tabanlı kimlik doğrulama sistemi çalışmaktadır.

Yurtlarda ikamet ediyorsanız kablolu ağ hizmetinden yararlanmak için [https://netregister.metu.edu.tr](https://netregister.metu.edu.tr/) adresinden bilgisayarınızın Ethernet kartının MAC adresini sisteme tanıtmanız gerekmektedir.

- **Windows işletim sistemlerinde;**

Başlat > Programlar > Donatılar > Komut İstemi

yoluyla ya da;

Başlat > Çalıştır > cmd

yazıp **Tamam** düğmesine tıklayınca açılan komut istemi ekranında **getmac /v** komutunu girerek Enter tuşuna basın. **Yerel Ağ Bağlantısı** satırında **Fiziksel Adres** kolonunun altında Ethernet kartınızın MAC adresini görebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac01_tr.jpg)

Komut istemi ekranında **ipconfig /all** komutuyla da **Ethernet bağdaştırıcısı Yerel Ağ Bağlantısı** altında yer alan **Fiziksel Adres** satırında Ethernet kartınızın MAC adresini görebilirsiniz. Bu komutla IP adresi vb. diğer ağ bilgilerine de ulaşabilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac02_tr.jpg)

- **MAC OSX işletim sistemlerinde;**

Apple > System Preferences > Network

yoluyla açılan pencerede sol taraftaki bağlantı noktaları arasından **Ethernet** seçeneğini seçip **Advanced** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac03.jpg)

**Ethernet** sekmesi altındaki **Ethernet ID** satırında Ethernet kartınızın MAC adresini görebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_ag_mac04.jpg)

- **UNIX/Linux işletim sistemlerinde;**

Ethernet bağdaştırıcıları bge0, ie0, eth0 vb. şekillerde ifade edilir. Sisteme root kullanıcısıyla bağlandıktan sonra komut satırına **ifconfig -a** yazıp Enter tuşuna basın. **HWaddr** ya da **ether** satırında Ethernet kartınızın MAC adresini görebilirsiniz.