[Jump to navigation](https://faq.cc.metu.edu.tr/tr/arcgis-desktop#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-09-2022 **Görüntüleme:** 29139


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/arcgis-desktop "ARCGIS DESKTOP")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/arcgis-desktop "ARCGIS DESKTOP")

# ARCGIS DESKTOP

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ARCGIS DESKTOP** **10.8.2** **—**

**_ArcGIS Desktop_** _haritalar oluşturmanıza, mekansal analiz gerçekleştirmenize ve verileri yönetmenize olanak tanıyan eksiksiz bir masaüstü GIS yazılım paketidir._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve lisanslama işlemini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/arcgis-desktop#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/arcgis-desktop#aktivasyon)

* * *

**_\[1\] Not:_** _ArcGIS Desktop yazılımı lisans anlaşması gereği hem personele hem de öğrencilere sunulmaktadır._

* * *

**_ADIM-1 <<<KURULUM>>>_**

_Kurulum için iso dosyası içerinde year alan “ArcGIS\_Desktop\_1082\_180378.exe” kurulum dosyasına tıklayıp çalıştırınız ve_**_“Next”_**_butonuna tıklayarak ilerleyiniz._

**_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step1.png)_**

**_ADIM-2_**

**_“I accept the master agreement”_**_seçeneğini işaretleyiniz. Daha sonra**“Next”**_ _butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step2.png)_

**_ADIM-3_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step3.png)

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step4.png)

**_ADIM-5_**

**_“Next”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step5.png)

**_ADIM-6_**

**_“Install”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step6.png)

**_ADIM-7_**

**_“Finish”_**_butonuna tıklayarak tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step7.png)

**_ADIM-8 <<<AKTİVASYON>>>_**

_Kurulum bittikten sonra **“ArcGIS Administrator Wizard”** penceresi açılacaktır. Kullanılacak yazılımı seçmek için ArcGIS Desktop başlığı altındaki **“Adavanced (ArcInfo) Concurrent Use”**seçeneğini işaretleyiniz. Daha sonra aktivasyon işlemi için License Manager başlığı altındaki alana lisans sunucusu olarak **"arcgis.cc.metu.edu.tr"** adresini yazınız ve **"OK"**butonuna tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step8.png)

**_ADIM-9_**

_Bu Pencerede kurmuş olduğunuz yazılım hakkında ve mevcut lisans bilgilerine erişebilirsiniz. **“OK”**butonuna tıklayarak pencereyi kapatabilirsiniz ve yazılımı kullanmaya başlayabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_desktop_10_8_2_step9.png)

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *