[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/hangi-standart-dosya-planini-sdp-secmem-gerekiyor#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 6822


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/hangi-standart-dosya-planini-sdp-secmem-gerekiyor)

# Hangi Standart Dosya Planını (SDP) seçmem gerekiyor?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Kamu kurum ve kuruluşlarınca elektronik ortamda veya evrak düzeninde oluşturulan belgelerin dosyalanmasında genel bir yöntem belirlenerek, ihtiyaç halinde bu belgelere kolay ve hızlı bir şekilde erişim imkanı sağlamak amacıyla; 2005/7 sayılı Standart Dosya Planı konulu Başbakanlık Genelgesi yayımlanmıştır. Buna göre **; Dosya**, aynı konuyu ihtiva eden yazılar grubudur. **Dosya Planı**, kurum ve kuruluşların iş ve işlemleri sonucunda teşekkül eden belgelerin, sistemli bir şekilde dosyalanmasını sağlamak üzere önceden hazırlanmış konu ve konu numaraları envanteridir.

Yükseköğretim kurumları için hazırlanan **Yükseköğretim Üst Kuruluşları ve Yükseköğretim Kurumları Saklama Süreli Standart Dosya Planı** tüm üniversitelerde üretilen ve alınan belgeler için bir dosyalama uygulaması standardıdır. Genel bir ifadeyle “standart dosya planı”, üretilen belgeleri konusal olarak gruplamaya ve gerektiğinde aynı konudaki belgeleri bir arada bulmaya yarayan bir uygulamadır. Bu uygulama sayesinde tüm kamu kurum ve kuruluşlarında üretilen aynı konulu belgeler aynı numaralarla kodlanmış olacaktır.

Üniversitemizde yazışmaların çağımızın koşulları ve yasal hükümler doğrultusunda, etkin biçimde gerçekleştirilmesi, bütünsel bir dosya sisteminin oluşturulması, belge değerlendirme - ayıklama - imha işlemlerinin mevzuata uygun olarak yürütülmesi, belge ve arşiv işlemlerinin, belge yönetimi ve arşivcilik ilke ve yöntemlerine göre yürütülmesi için SDP ile belirlenmiş konu kodlarının doğru belirlenmesi/seçilmesi **BÜYÜK ÖNEM** arz etmektedir.

[https://www.yok.gov.tr/Documents/Universiteler/Standart\_Dosya\_Plani.pdf](https://www.yok.gov.tr/Documents/Universiteler/Standart_Dosya_Plani.pdf) adresinde Yükseköğretim Kurumu'nun Standart Dosya Planı bulunmaktadır. Bu dokümandan uygun SDP'yi seçme konusunda yardım alabilirsiniz.

Ayrıntılı yardım için Evrak ve Arşiv Müdürlüğüne de ulaşabilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.