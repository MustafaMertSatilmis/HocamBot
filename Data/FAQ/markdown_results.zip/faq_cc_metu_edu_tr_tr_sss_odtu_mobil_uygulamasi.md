[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-mobil-uygulamasi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 29-04-2022 **Görüntüleme:** 5318


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-mobil-uygulamasi)

# ODTÜ Mobil Uygulaması

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

BİDB tarafından geliştirilen ODTÜ mobil uygulamasını Android, iOS ve macOS işletim sistemli cihazlarınıza indirerek kullanabilirsiniz.

Ayrıntılı bilgi için: [https://mobile.metu.edu.tr/](https://mobile.metu.edu.tr/)

Android Play Store: [https://play.google.com/store/apps/details?id=tr.edu.metu.mobile&hl=tr](https://play.google.com/store/apps/details?id=tr.edu.metu.mobile&hl=tr)

iOS App Store: [https://itunes.apple.com/tr/app/orta-do%C4%9Fu-teknik-%C3%BCniversitesi/...](https://itunes.apple.com/tr/app/orta-do%C4%9Fu-teknik-%C3%BCniversitesi/id1206857420?l=tr)

mac App Store: [https://apps.apple.com/tr/app/orta-do%C4%9Fu-teknik-%C3%BCniversitesi/id...](https://apps.apple.com/tr/app/orta-do%C4%9Fu-teknik-%C3%BCniversitesi/id1490852940?l=tr)

Huawei App Gallery: [https://appgallery.huawei.com/#/app/C102844077](https://appgallery.huawei.com/#/app/C102844077)

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/odtu_mobil.jpg)