[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-epostalarimi-ve-adres-defterimi-farkli-bir-eposta-sistemine-nasil-aktarabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-07-2020 **Görüntüleme:** 3892


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-epostalarimi-ve-adres-defterimi-farkli-bir-eposta-sistemine-nasil-aktarabilirim)

# ODTÜ epostalarımı ve adres defterimi farklı bir eposta sistemine nasıl aktarabilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

ODTÜ eposta adresinizde bulunan tüm epostaları almak için aşağıdaki Gmail yardım sayfalarını inceleyebilirsiniz.

[https://support.google.com/mail/answer/21289?co=GENIE.Platform%3DDesktop&hl=tr](https://support.google.com/mail/answer/21289?co=GENIE.Platform%3DDesktop&hl=tr)

Tüm iletileri alma, 2. Adım - Gmail ayarlarınızı değiştirin bölümündeki adımları takip ederek Gelen Kutusu'ndaki tüm epostaların Gmail'e aktarılmasını sağlayabilirsiniz.

Adres defterinizi aktarmak için öncelikle horde.metu.edu.tr adresine ODTÜ kullanıcı kodu ve parolanız ile giriş yapınız. "Adres Defteri"ni seçiniz. Sol taraftaki menüden "İçeri/Dışarı Aktar" ve sağ bölümden "virgülle ayrılmış" - Dışarı aktar seçenekleri ile adres defterinizi "contacts.csv" olarak kaydedebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/adresdefteri.png)

Kaydettiğiniz dosyadaki adresleri Gmail hesabınıza eklemek için aşağıdaki bağlantıdaki Kişi Ekleme - Bir dosyadan bölümündeki adımlarını takip ediniz.

[https://support.google.com/contacts/answer/1069522?co=GENIE.Platform%3DDesktop&hl=tr](https://support.google.com/contacts/answer/1069522?co=GENIE.Platform%3DDesktop&hl=tr)