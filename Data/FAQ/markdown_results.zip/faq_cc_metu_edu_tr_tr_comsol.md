[Jump to navigation](https://faq.cc.metu.edu.tr/tr/comsol#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-01-2022 **Görüntüleme:** 24564


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/comsol "COMSOL")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/comsol "COMSOL")

# COMSOL

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **COMSOL** **6.0** **—**

**_COMSOL_** _bir çoklu fizik ve sonlu eleman analizi (FEA) yazılımıdır._ _Comsol Akademik lisansımız aşağıdaki modülleri içermektedir._

**_COMSOL Multiphysics_**

**_-  CFD Module_**

**_-  Chemical Reaction Engineering Module_**

**_-  Heat Transfer Module_**

**_-  LiveLink for MATLAB_**

_Aşağıdaki adımları takip ederek yazılımın kurulum ve lisanslama işlemini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/comsol#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/comsol#aktivasyon)

* * *

**_\[1\] Öğrenciler için not:_** _Comsol yazılımı lisans anlaşması gereği öğrencilere sunulamamaktadır. Öğrencilerimiz yazılımı [PC lablarında](http://faq.cc.metu.edu.tr/tr/groups/pc-salonlari) kullanabilirler._

* * *

**_ADIM-1 <<<KURULUM>>>_**

_Kurulum için istediğiniz dil seçeneğini işaretleyiniz ve_**_“Next_** **_”_**_butonuna tıklayarak ilerleyiniz. (Bu kurulumda varsayılan dil olarak **“English”** seçilecektir.)_

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step1.png)

**_ADIM-2_**

**_“New COMSOL 6.0 Installation_** **_”_**_butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step2.png)_

**_ADIM-3 <<<AKTİVASYON>>>_**

_Bu aşamada öncelikli olarak lisans sözleşmesinin şartlarını kabul etmelisiniz. Lisans formatı başlığının yanındaki alanı **“<port number>@<host name>”**olarak seçiniz.Port numarası alanına **“1718”** ve hostname alanına **“comsol.cc.metu.edu.tr”** yazınız. Daha sonra **“Next”**_ _butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step3.png)_

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step4.png)

**_ADIM-5_**

**_“Next”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step5.png)

**_ADIM-6_**

**_“Next”_** _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step6.png)

**_ADIM-7_**

**_“Install”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step7.png)

**_ADIM-8_**

**_“Close”_**_butonuna tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/comsol_6_0_step8.png)

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *