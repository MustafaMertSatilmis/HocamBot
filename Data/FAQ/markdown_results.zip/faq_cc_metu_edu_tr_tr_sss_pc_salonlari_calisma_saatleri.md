[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-calisma-saatleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 17-01-2022 **Görüntüleme:** 18078


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/pc-rooms-working-hours "What are the PC Rooms Working Hours?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/pc-salonlari-calisma-saatleri "PC Salonları Çalışma Saatleri Nelerdir?")

# PC Salonları Çalışma Saatleri Nelerdir?

[PC Salonları](https://faq.cc.metu.edu.tr/tr/groups/pc-salonlari)

Tüm salonlar mesai saatlerinde, belirtilen ders, temizlik ve bakım saatleri dışında, genel kullanıma açıktır.

| **Salon** | **Saat** | **Gün** | **Temizlik ve Genel Bakım Saatleri** |
| --- | --- | --- | --- |
| Beşeri Bilimler PC Salonu | 09:00 - 17:00<br>Ders programları <br>PC Salonunda duyurulmaktadır. | Pazartesi - Cuma | Temizlik<br>Salı 09:00 - 10:00 |
| 1\. Yurt PC Salonu | 09:00 - 06:00 | Dersler devam ettiği sürece her gün<br>Dönem aralarında 09:00 - 17:00 arası | Her gün<br>Temizlik 07:00-09:00 |
| 2\. Yurt PC Salonu - 2 | 09:00 - 06:00 | Dersler devam ettiği sürece her gün<br>Dönem aralarında 09:00 - 17:00 arası | Her gün<br>Temizlik 07:00-09:00 |
| 2\. Yurt PC Salonu - 3 | Bu salon eğitim ve seminer amacıyla kullanılmaktadır. | Her gün | Her gün<br>Temizlik 07:00-09:00 |
| Isa Demiray Yurdu PC Salonu | 09:00 - 01:00 | Dersler devam ettiği sürece her gün | Her gün<br>Temizlik 07:00-09:00 |
| Faika Demiray Yurdu PC Salonu | 09:00 - 01:00 | Dersler devam ettiği sürece her gün | Her gün<br>Temizlik 07:00-09:00 |
| Refika Aksoy Yurdu PC Salonu | 09:00 - 01:00 | Dersler devam ettiği sürece her gün | Her gün<br>Temizlik 07:00-09:00 |
|  |  |  |  |

**_Yaz döneminde sadece Yurtlar Müdürlüğü tarafından açık tutulan yurt binalarındaki PC salonları hizmet vermektedir._**