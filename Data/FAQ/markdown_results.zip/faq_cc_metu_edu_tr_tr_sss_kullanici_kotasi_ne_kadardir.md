[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullanici-kotasi-ne-kadardir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 13205


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-size-user-account-quota "What is the size of a user account quota?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullanici-kotasi-ne-kadardir "Kullanıcı kotası ne kadardır?")

# Kullanıcı kotası ne kadardır?

[Kota](https://faq.cc.metu.edu.tr/tr/groups/kota)

Kullanıcı hesabı sahiplerine merkezi sunucular üzerinde ayrılan disk alanına kota denir. ODTÜ kullanıcılarına dosya ve e-postaları için iki ayrı kota tanımlanmıştır. Bu kota miktarları birbirinden bağımsızdır.

ODTÜ kullanıcıları bulundukları sınıfa göre sunucular üzerinde aşağıdaki belirtilen değerde e-posta kotasına sahiptir:

- **Öğrenciler:** 250 MB
- **İdari ODTÜ mensupları ve Araştırma Görevlileri:** 750 MB
- **Akademik ODTÜ mensupları:** 1.5 GB

Kullanılan e-posta kotası %90 oranında dolduğunda kullanıcılara uyarı mesajı gönderilmektedir.

E-posta kotası uygulamalarında, kotanın aşılması durumunda gelen e-postaların geri dönmesi sözkonusu olduğundan, kullanıcılarımızın kendilerine tahsis edilmiş olan e-posta kotalarını kontrollü kullanmaları ve sistemden gelen uyarıları dikkate almaları önem taşımaktadır.

ODTÜ kullanıcılarının bulundukları sınıfa göre sunucular üzerinde sahip oldukları dosya kotaları ise aşağıdaki gibidir:

- **Öğrenciler:** 100 MB
- **ODTÜ mensupları:** 250 MB
- **EİS Projesi kapsamındaki birimler:** 250 MB
- **Öğrenci toplulukları:** 250 MB
- **Web kullanıcıları:** 250 MB

Dosya ve e-posta kotası artırımı gereken zorunlu durumlarda, [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresine hangi tür kotayı arttırmak istediğinizi gerekçenizi de belirterek başvurabilirsiniz.