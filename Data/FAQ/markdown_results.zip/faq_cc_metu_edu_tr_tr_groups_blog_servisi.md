[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/blog-servisi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Blog Servisi

|     |
| --- |
| [ODTÜ kullanıcı kodumla blog oluşturmak için ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-kodumla-blog-olusturmak-icin-ne-yapmaliyim) |

[![Subscribe to Blog Servisi](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/37/all/feed "Subscribe to Blog Servisi")