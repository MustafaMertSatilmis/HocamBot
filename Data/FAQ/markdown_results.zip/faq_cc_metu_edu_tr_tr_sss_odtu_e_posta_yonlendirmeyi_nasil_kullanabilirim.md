[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 11-10-2024 **Görüntüleme:** 34374


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-e-mail-forwarding "How can I use METU e-mail forwarding?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim "ODTÜ e-posta yönlendirmeyi nasıl kullanabilirim?")

# ODTÜ e-posta yönlendirmeyi nasıl kullanabilirim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Mezunlarımız ve üniversiteden ayrılan personelimiz ODTÜ e-posta adreslerine gönderilecek e-posta mesajlarını süresiz olarak belirtecekleri farklı bir e-posta adresine yönlendirebilirler. Yarı zamanlı, sözleşmeli personel, proje personeli, diğer kamu personeli gibi kadrolu ODTÜ personeli kullanıcı tipinde açılmamış hesaplar için ayrılma sonrası yönlendirme işlemi yapılamamaktadır.

Akademik ve İdari ODTÜ personeli statüsünde iken görevinden ayrılanlara yönlendirme hakkı 19.03.2019 tarihli senato kararı ile verilmiştir ve uygulama tarihi olarak 20.03.2019 belirlenmiştir. Bu tarihten önce kapanan hesaplar için yönlendirme hizmeti uygulaması bulunmamaktadır. İlgili karar BIDB ana sayfasında e-kimlik işleyiş kuralları olarak yayınlanmıştır.

Kullanıcı kodları kapatılmadan 30 gün önce ODTÜ e-posta adreslerine kullanıcı kodlarının kapatılacağına ve e-posta yönlendirme hizmetinden faydalanabileceklerine dair bilgilendirme e-postası gönderilmektedir. E-posta yönlendirme işleminizi kullanıcı hesabınızın kapatılma tarihine 15 gün kala veya hesabınız kapatıldıktan sonra herhangi bir zamanda kullandığınız son parolayla gerçekleştirebilirsiniz. Bu süreden önceki giriş denemelerinizde "parola/kullanıcı hatası" mesajı alacaksınız. Bu nedenle yönlendirme işleminizi lütfen son 15 gün içerisinde veya kapatılma işleminden sonraki günlerde yapınız. Yönlendirme işlemi için ODTÜ Portal üzerinden "e-posta yönlendirme" hizmetine ulaşabilirsiniz. Ayrıca [https://yonlendir.metu.edu.tr](https://yonlendir.metu.edu.tr/) adresinden de yönlendirme işleminizi gerçekleştirebilirsiniz.

E-posta yönlendirme işlevi, mevcut e-postalarınız için geçerli değildir. Mevcut e-postalarınızı arşivlemek için [bu bağlantıyı](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim) inceleyebilirsiniz. ODTÜ kullanıcı kodunuz son 4 hafta içinde kapatılmışsa eski e-postalarınıza ulaşmak için [yedek başvurusu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=backup) yapabilirsiniz.

Yönlendirme tanımlamanızı ODTÜ kullanıcı kodu ve parolanız ile giriş yaptıktan sonra göreceğiniz aşağıdaki ekrandan yapabilirsiniz. **Yönlendirme adresi ekle ya da değiştir** metin kutusuna ODTÜ e-posta adresinizi yönlendirmek istediğiniz bir e-posta adresinizi yazarak **Güncelle** düğmesine basabilirsiniz. Yönlendirme tanımınız yapılmıştır. E-postaların yönlendirilmesini iptal etmek için **Yönlendirme etkinleştir ya da kapat** düğmesini kullanabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/tr_epostayonlendir.png)

**ODTÜ kullanıcı kodunuza erişemiyorsanız ne yapmalısınız?**

Kullanıcı kodları kapatılmış ya da son kullandığı parolasını hatırlamayan kullanıcılarımızın, nüfus cüzdanının ön yüzünün fotokopisini, öğrenci numarasını/sicil numarasını ve talep ettikleri yönlendirme adresini [Bilişim Destek Formu](https://itsupport.metu.edu.tr/Inc/it_support/tr/it_support?mapkey=fwd) aracılığı ile iletmeleri gerekmektedir. (dosya yüklemek için fotoğrafın pdf, png, jpeg, gif dosya türlerinden biri olmalı ve maksimum 2mb boyutunda olmalıdır.) Gerekli bilgiler gönderildikten sonra e-posta adresiniz e-posta yönlendirme sistemine Bilişim Destek Ekibi tarafından tanımlanacaktır. Tanımlama işlemi yapıldıktan sonra belirttiğiniz yönlendirme adresine otomatik bilgilendirme mesajı gönderilecektir.

E-posta yönlendirme hizmeti ile sadece ODTÜ e-posta adreslerine gönderilecek olan e-posta mesajları farklı bir adresinize yönlendirilmektedir. ODTÜ e-posta adresiniz ile e-posta gönderme işlemi yapılamamaktadır.