[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-ile-odtu-e-posta-servisini-nasil-kullanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 03-06-2024 **Görüntüleme:** 50255


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-use-metu-e-mail-services-microsoft-outlook "How can I use METU E-Mail Services with Microsoft Outlook?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/microsoft-outlook-ile-odtu-e-posta-servisini-nasil-kullanabilirim "Microsoft Outlook ile ODTÜ e-posta servisini nasıl kullanabilirim?")

# Microsoft Outlook ile ODTÜ e-posta servisini nasıl kullanabilirim?

[E-posta Programları](https://faq.cc.metu.edu.tr/tr/groups/e-posta-programlari)

_Microsoft Office paketinde bulunan Outlook_ programıyla e-posta okumak ve göndermek için merkezi e-posta sunucusu ayarlarını yapmanız gereklidir. Windows işletim sisteminde Mail uygulamasının yerine geçen New Outlook uygulaması IMAP ve POP protokollerini henüz desteklememektedir. Ayrıntılı bilgi için [tıklayınız](https://support.microsoft.com/tr-tr/office/yeni-windows-i%C3%A7in-outlook-u-kullanmaya-ba%C5%9Flama-66b195df-08b9-48bd-b464-d6edf95813e4#:~:text=%C3%96nemli%3A%C2%A0Yeni,da%C4%9F%C4%B1t%C4%B1mlar%C4%B1n%C4%B1%20da%20desteklememektedir.)

Bunun için, **Dosya** sekmesine tıklayınca açılan ekranda **Hesap Ekle** düğmesine tıklayın. Açılan pencerede ODTÜ e-posta adresinizi [kullanicikodu@metu.edu.tr](mailto:kullanicikodu@metu.edu.tr) şeklinde girmeniz gerekmektedir. (Öğrencilerimizin kullanıcı kodları e123456 şeklindedir.)

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/outlook1.png)

Öncelikle ayarları otomatik olarak tanımlamayı deneyebilirsiniz. Bağlan düğmesine bastığınızda gerekli sunucu bilgileri otomatik olarak ayarlanacak ve ODTÜ parolanızı girmeniz istenecektir.

**Açılacak pencerede Kullanıcı Adı / User Name kutusundaki @metu.edu.tr bölümünü silerek TAMAM / OK düğmesine basarak ODTÜ e-posta adresinizi Outlook uygulamasına ekleyebilirsiniz.**

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/outlook4.png)

Eğer otomatik sunucu tanımlaması başarılı olmazsa IMAP bağlantı yöntemini seçip gelen ve giden eposta sunucu ayarlarınızı aşağıdaki şekilde tanımlayabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/outlook2.png)![](https://faq.cc.metu.edu.tr/tr/system/files/u2/outlook3.png)

Daha sonra sunucu ayarlarını değiştirmeniz gerekirse Dosya / Hesap Ayarları / E-posta seçeneklerini kullanarak E-posta ayarlarınızın ayrıntılarına ulaşabilir veya e-posta adresinizi elle ekleyebilirsiniz. Dosya / Hesap Ayarları / Sunucu Ayarları bölümünde sunucu ayarları aşağıdaki şekilde olmalıdır:

**Gelen sunucu:** imap.metu.edu.tr Bağlantı noktası: 993 Şifreleme yöntemi SSL/TLS

**Giden sunucu:** smtp.metu.edu.tr veya mail.metu.edu.tr Bağlantı noktası: 465 Şifreleme yöntemi SSL/TLS

_Giden sunucum (SMTP) için kimlik doğrulaması gerekiyor_ onay kutusu işaretli olmalı ve _Gelen posta sunucum ile aynı ad ayarlarını kullan_ seçilmelidir.

**Outlook 2010 ile ilgili ekran görüntüleri**

"Hesap Ayarları" penceresinde "E-posta" sekmesindeki **Yeni** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook01_tr.jpg)

Açılan "Yeni Hesap Ekle" penceresinde "Sunucu ayarlarını veya ek sunucu türlerini el ile yapılandır" seçeneğini işaretleyerek **İleri** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook02_tr.jpg)

Bir sonraki ekranda "Internet E-posta" seçeneğini işaretleyerek **İleri** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook03_tr.jpg)

Daha sonraki ekranda adınızı, e-posta adresinizi, kullanıcı adınızı ve parolanızı yazın. Parolanızın hatırlanmasını istiyorsanız "Parolayı anımsa" kutucuğunu işaretleyin.

Mesajlarınıza ve sunucu üzerindeki klasörlerinize birden fazla bilgisayardan ulaşmak isterseniz hesap türünü "IMAP" seçin. Gelen kutunuzu tek bir bilgisayara indirip mesajlarınıza yalnızca bu bilgisayardan ulaşmak isterseniz ve sunucu üzerindeki klasörlere erişmenize gerek yoksa hesap türünü "POP3" seçin.

- **IMAP Ayarları:**

Gelen posta sunucusunu **imap.metu.edu.tr**, giden posta sunucusunu **smtp.metu.edu.tr** olarak yazın ve **Diğer Ayarlar** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook04_tr.jpg)

Güvenli IMAP bağlantısı kullanmak için "Internet E-posta Ayarları" penceresinde "Giden Sunucusu" sekmesindeki "Giden sunucum (SMTP) için kimlik doğrulaması gerekiyor" kutucuğunu işaretleyin.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook05_tr.jpg)

"Gelişmiş" sekmesinde gelen sunucu için bağlantı noktası numarası **993**, şifreleme türü **SSL**, giden sunucu için bağlantı noktası numarası **465**, şifreleme türü **SSL** olmalıdır.

- **POP3 Ayarları:**

Gelen posta sunucusunu **pop3.metu.edu.tr**, giden posta sunucusunu **smtp.metu.edu.tr** olarak yazın ve **Diğer Ayarlar** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook07_tr.jpg)

Güvenli POP3 bağlantısı kullanmak için "Internet E-posta Ayarları" penceresinde "Giden Sunucusu" sekmesindeki "Giden sunucum (SMTP) için kimlik doğrulaması gerekiyor" kutucuğunu işaretleyin.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook08_tr.jpg)

"Gelişmiş" sekmesinde gelen sunucu için bağlantı noktası numarası **995**, şifreleme türü **SSL**, giden sunucu için bağlantı noktası numarası **465**, şifreleme türü **SSL** olmalıdır. Sunucudaki tüm mesajları o an bilgisayara indirmek istemezseniz "İletinin bir kopyasını sunucuda bırak" kutucuğunu işaretleyin.


Ayarları girdikten sonra "Yeni Hesap Ekle" penceresinde **İleri** düğmesine tıkladığınızda ayarlarınızı denetlemek için bir test e-postası gönderilir.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook10_tr.jpg)

Yaptığınız ayarları daha sonra görmek ya da değiştirmek isterseniz "Hesap Ayarları" penceresinde "E-posta" sekmesindeki **Değiştir** düğmesine tıklayın.

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_eposta_outlook12_tr.jpg)

_**Not:** Bu doküman Microsoft Outlook 2010 sürümü dikkate alınarak hazırlanmıştır. Menüler ve seçenekler önceki sürümlerle farklılık gösterebilir._