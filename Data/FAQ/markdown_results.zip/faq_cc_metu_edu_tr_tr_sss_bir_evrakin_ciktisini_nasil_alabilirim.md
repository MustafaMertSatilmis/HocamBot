[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/bir-evrakin-ciktisini-nasil-alabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 25-10-2024 **Görüntüleme:** 6159


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/bir-evrakin-ciktisini-nasil-alabilirim)

# Bir evrakın çıktısını nasıl alabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

[Resmi yazışmalarda uygulanacak usul ve esaslar hakkında yönetmelik](https://www.mevzuat.gov.tr/MevzuatMetin/21.5.2646.pdf) doğrultusunda EBYS'de oluşturulan evrakların ancak elektronik imzalama ve onay işlemleri tamamlandıktan sonra çıktısının alınabilmesi için yapısal düzenlemeye gidilmiştir.

Buna göre, EBYS'de oluşturulan bir evrak üzerindeki imza, koordinasyon, olur, uygunluk gibi çeşitli başlıklarda olabilecek bütün e-imzaların ve takip eden onayların tamamlanıp tamamlanmadığı sürecin bitmesiyle kontrol edilmekte ve e-imzaları tamamlanmış bir süreç bittiğinde "Profil" sekmesindeki parafsız, paraflı ve antetsiz çıktı oluşturma butonları aktif hale gelmektedir. Bu şekilde tamamlanan evrakların çıktısını alabilmek için İş Akış Yönetimi > Geçmiş bölümünden ilgili evraklara erişilip "Profil" sekmesinden çıktıları alınabilir.

![](https://faq.cc.metu.edu.tr/system/files/u16319/tarihlicikti.png)

EBYS ilgili sorular [ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr) adresine iletilebilir.