[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/dagitim-onayi-ozelligi-nasil-kullanilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 02-11-2022 **Görüntüleme:** 5763


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/dagitim-onayi-ozelligi-nasil-kullanilir)

# Dağıtım Onayı Özelliği nasıl kullanılır?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de amir onayı alınarak başka birim ya da kişilere havale edilmesi gereken yazılar için **"Sevk Et" yerine** "Dağıtım Onayı" özelliğinin kullanılması önerilmektedir. "Dağıtım Onayı" yerine "Sevk Et" özelliğinin seçilmesi durumunda amirin dağıtım notu girmesi için birden fazla işlem yapması gerekebilmekte, bu da süreci uzatabilmektedir. Amirlerin dağıtım gerektiren yazılar için daha az işlem yapmasını sağlamak amacıyla "Dağıtım Onayı" özelliğinin nasıl kullanıldığı aşağıda tarif edilmiştir:

1. Birim sekreteri birime ulaşan yazı için "Dağıtım Onayı" butonuna tıklar.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/butonlar.png)

2. Sekreter, açılan "Havale Edilecek Kullanıcı Seçim Formu" ekranından dağıtımın onayını verecek birim amirini "Dağıtım Yapacak Kullanıcı" listesinden seçerek "Tamam"a tıklar. Böylece yazı amire iletilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/havale-secim.png)

3. Birim amiri kendisine ulaşan yazıyı inceledikten sonra dağıtımını uygun görüyorsa "Onayla" butonuna tıklar. Bu işlem sırasında dağıtım yapılacak birim/kişileri belirtmesi vb. bir neden/açıklama girmesi için "Onayla - Neden" ekranı açılır. Amir buraya gerekli açıklamayı girip "Kaydet"e tıkladıktan sonra yazı tekrar sekretere gelir. Birim amiri eğer yazının dağıtım yapılmasını istemiyorsa "İade Et" butonuna tıklayarak iade nedenini yazar. Böylece evrak birim sekreterine geri döner.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2022-11-02_11.31.44.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/onayla-neden.png)

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ekran_resmi_2022-11-02_11.41.34.png)

4. Sekreter kendisine geri gelen yazı için, amirin girdiği dağıtım notunu ilgili evrakın listelendiği ekrandaki "Neden" sütunu altında görerek "Sevk Et" butonuna tıklar. Tekrar açılan "Havale Edilecek Kullanıcı Seçim Formu"nda amirin dağıtım notuna göre ilgili birimleri veya kişileri seçerek "Tamam" a tıklar ve yazının seçilen birim ya da kişilere havalesi tamamlanmış olur. Dağıtımı yapılmayacak evraklar için ise "Gereği Yapılmıştır" butonunu seçerek süreci sonlandırabilir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/neden-sutunu.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.