[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/linux-tabanli-isletim-sistemleri-viruslerden-etkilenir-mi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-03-2024 **Görüntüleme:** 7846


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-linux-based-operating-systems-be-affected-viruses "Can Linux based operating systems be affected by viruses?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/linux-tabanli-isletim-sistemleri-viruslerden-etkilenir-mi "Linux tabanlı işletim sistemleri virüslerden etkilenir mi?")

# Linux tabanlı işletim sistemleri virüslerden etkilenir mi?

[Virüs](https://faq.cc.metu.edu.tr/tr/groups/virus)

Linux tabanlı işletim sistemleri de virüslerden etkilenebilir, ancak yoğun bir virüs aktivitesi bulunmamaktadır. Genelde çekirdek ya da kullanılan yazılımların açıklarından faydalanmaya çalışan virüslere karşı güncelleme yapılması yeterli önlem olarak görülmektedir.