[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yukleme-yaptigim-banka-karti-e-ticarete-acik-degil-ne-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-10-2021 **Görüntüleme:** 3819


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-cashcredit-card-does-not-have-e-commerce-property-what-should-i-do "My cash/credit card does not have e-commerce property, what should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/akilli-kartima-yukleme-yaptigim-banka-karti-e-ticarete-acik-degil-ne-yapabilirim "Akıllı kartıma yükleme yaptığım banka kartı e-ticarete açık değil, ne yapabilirim?")

# Akıllı kartıma yükleme yaptığım banka kartı e-ticarete açık değil, ne yapabilirim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Akıllı kartınıza para yükleyebilmeniz için kullandığınız kredi veya banka kartının e-ticarete açık oması gerekmektedir. Kartınızı e-ticarete açtırmak için bankanızla görüşebilirsiniz.