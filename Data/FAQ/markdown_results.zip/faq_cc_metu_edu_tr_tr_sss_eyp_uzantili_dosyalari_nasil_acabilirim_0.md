[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eyp-uzantili-dosyalari-nasil-acabilirim-0#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 157455


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eyp-uzantili-dosyalari-nasil-acabilirim-0)

# EYP uzantılı dosyaları nasıl açabilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EYP uzantılı dosyalar Winrar gibi ücretli veya ücretsiz çeşitli 3. parti sıkıştırılmış paket açıcı programlar aracılığı ile açılabilmenin yanı sıra TÜBİTAK tarafından geliştirilen İmzager isimli yazılımla da açılabilmektedir. Tavsiyemiz ücretsiz ve resmi yazılım olan İmzager'in kullanılmasıdır.

İmzager yazılımının bilgisayarınıza uygun versiyonunu [https://yazilim.kamusm.gov.tr/?q=/node/143](https://yazilim.kamusm.gov.tr/?q=/node/143) adresinden indirebilir ve [https://kamusm.bilgem.tubitak.gov.tr/urunler/yazilim/imzagerkurumsalkurulumsureci.jsp](https://kamusm.bilgem.tubitak.gov.tr/urunler/yazilim/imzagerkurumsalkurulumsureci.jsp) adresinde tarif edildiği gibi kolaylıkla kurabilirsiniz.

Kurulum sonrası programı açtıktan sonra açmak istediğiniz EYP uzantılı dosyayı sol tarafta bulunan dosya listesinden seçebilir veya sürükle bırak yöntemi ile İmzager programı üzerine bırakabilirsiniz. EYP dosyası içindeki bilgiler görünecektir. İlgili evrakı PDF olarak açmak için dosya adına tıklamanız gerekmektedir.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dosyaacma.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.