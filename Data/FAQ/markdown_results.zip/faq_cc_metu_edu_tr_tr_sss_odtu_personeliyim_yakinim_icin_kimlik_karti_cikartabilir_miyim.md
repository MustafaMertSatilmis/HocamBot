[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-yakinim-icin-kimlik-karti-cikartabilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-10-2021 **Görüntüleme:** 11172


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-metu-staff-can-i-get-id-card-my-relatives "I am a METU staff. Can I get an ID card for my relatives?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-yakinim-icin-kimlik-karti-cikartabilir-miyim "ODTÜ personeliyim. Yakınım için kimlik kartı çıkartabilir miyim?")

# ODTÜ personeliyim. Yakınım için kimlik kartı çıkartabilir miyim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Evet, Akademik ve İdari personel eşine ve çocuklarına personel yakını olarak kimlik kartı çıkartabilmektedir. Gerekli bilgilere[https://ihm.metu.edu.tr/tr/akilli-kart](https://ihm.metu.edu.tr/tr/akilli-kart) internet adresinden ulaşabilirsiniz.