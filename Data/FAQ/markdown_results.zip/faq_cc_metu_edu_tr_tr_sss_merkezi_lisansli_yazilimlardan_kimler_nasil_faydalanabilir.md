[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/merkezi-lisansli-yazilimlardan-kimler-nasil-faydalanabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 28-01-2022 **Görüntüleme:** 22668


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/who-can-make-use-of-central-licensed-software-and-how "WHO CAN MAKE USE OF CENTRAL LICENSED SOFTWARE, AND HOW?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/merkezi-lisansli-yazilimlardan-kimler-nasil-faydalanabilir "MERKEZI LISANSLI YAZILIMLARDAN KIMLER, NASIL FAYDALANABILIR?")

# MERKEZI LISANSLI YAZILIMLARDAN KIMLER, NASIL FAYDALANABILIR?

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**—** **LİSANSLI YAZILIMLAR:** **KİMLER, NASIL FAYDALANABİLİR?****—**

_ODTÜ Bilgi İşlem Daire Başkanlığı, kullanıcılarımızın ihtiyaçları ve talepleri doğrultusunda yerleşke genelinde kullanılmak üzere lisanslı yazılım temin etmektedir. Yazılım lisansları her yıl yenilenmektedir. Kullanıcılarımız lisansı alınan her yazılımın son sürümlerini kullanma imkanına sahiptir._

* * *

**_\[1\] Not:_** **_Uyarı!_** **_Yapılan lisans anlaşmaları gereğince lisanslı yazılımlar sitesi sadece ODTÜ yerleşke ağı içinden üniversite akademik ve idari personelinin erişimine açıktır._**

**_\[2\] Not:_** **_Bu yazılımların lisans koşullarını ihlal edecek şekilde kullanımları "5846 sayılı Fikir ve Sanat Eserleri Kanunu" ve "Türk Ceza Kanunu'nun 525/a maddesi" uyarınca yasaktır._**

* * *

Lisanslı olarak Üniversitemizin kullanımına sunulmakta olan yazılımların, [ODTÜ Bilişim Kaynakları Kullanım Politikaları Belgesi](https://www.metu.edu.tr/tr/bilisim-etigi)'nin 3, 5 ve 7. maddelerine uygun şekilde kullanılması esastır. Bu çerçevede, yazılımların lisanslama koşullarına uyulması ve yazılımların kurulmasında kullanılan lisans anahtarlarının ("license key") 3. kişilerle paylaşılmaması gerekmektedir. Bu kurallara uygun hareket etmeyenler için 5. madde uygulanır.

**Lisanslı Yazılımlar – Nasıl erişirim?**

Lisanslı yazılımlara aşağıdaki link yoluyla erişebilirsiniz.

**_URL>> [https://yazilim.cc.metu.edu.tr/](https://yazilim.cc.metu.edu.tr/)_**

**Lisanslı Yazılımlar – Nasıl yardım alırım?**

Sorularınızı aşağıdaki link üzerinden iletebilirsiniz.

**_URL>> [https://bilisimdestek.metu.edu.tr/](https://bilisimdestek.metu.edu.tr/)_**

**Lisanslı Yazılımlar – Yazılım Listesi**

Lisanslı yazılımlar listesine aşağıdaki link üzerinden erişebilirsiniz.

**_URL>> [https://yazilim.cc.metu.edu.tr/liste.php](https://yazilim.cc.metu.edu.tr/liste.php)_**

**Lisanslı Yazılımlar – Kurulum Rehberi**

Lisanslı yazılımların kurulum rehberlerine aşağıdaki link üzerinden erişebilirsiniz.

**_URL>> [https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)_**

* * *

_**Bize**_ _**ulaşın**_ _**:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *