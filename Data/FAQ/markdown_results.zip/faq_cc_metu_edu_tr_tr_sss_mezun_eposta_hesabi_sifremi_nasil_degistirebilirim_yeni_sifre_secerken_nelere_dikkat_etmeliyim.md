[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-hesabi-sifremi-nasil-degistirebilirim-yeni-sifre-secerken-nelere-dikkat-etmeliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 14-12-2021 **Görüntüleme:** 5459


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-change-my-alumni-account-password-what-should-i-beware-picking-new-password "How can I change my Alumni Account password? What should I beware of in picking a new password?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mezun-eposta-hesabi-sifremi-nasil-degistirebilirim-yeni-sifre-secerken-nelere-dikkat-etmeliyim "Mezun Eposta Hesabı şifremi nasıl değiştirebilirim? Yeni şifre seçerken nelere dikkat etmeliyim?")

# Mezun Eposta Hesabı şifremi nasıl değiştirebilirim? Yeni şifre seçerken nelere dikkat etmeliyim?

[Mezun E-posta](https://faq.cc.metu.edu.tr/tr/groups/mezun-e-posta)

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

Merkezi Sunucular üzerinde bulunan kullanıcı kodunuzun parolasını değiştirmek için:

**Kullanıcı Hesap Yönetimi Sayfasından:**

Kullanıcı Hesap Yönetimi sayfasına; [https://alumniaccount.metu.edu.tr/](https://alumniaccount.metu.edu.tr/ "alumniaccount.metu.edu.tr") adresinden mevcut parolanızla giriş yaptıktan sonra "Şifre Değiştir" düğmesine tıklayarak kullanıcı kodu parolanızı değiştirebilirsiniz.

**Kullanıcılarımız parolalarını aşağıdaki kurallara göre oluşturmalıdır:**

**Zorunlu unsurlar:**

- Şifre tam olarak 8 karakter olmalıdır. 8 karakterden fazla ya da eksik olmadığına dikkat ediniz.
- Şifre en az bir büyük harf (ABCD….Z) içermelidir.
- Şifre en az bir küçük harf (abcd…z) içermelidir.
- Şifre en az bir sayı (1234567890) içermelidir.
- Şifre sadece parantez içindeki (\[ % ( ) \* + , - . / : ; < > ^ \_ { \| } ~ \]) özel karakterlerden en az bir tanesini içermelidir.

**Şifrede bulunmaması gereken unsurlar:**

- Şifre boşluk karakteri içeremez.
- Şifre 1900’lü veya 2000’li yılları içeremez. (1978, 1999, 2001 vb.)
- Şifre 4 ya da daha fazla karakterli ardışık sayı içeremez. (1234, 2345, 5678 vb.)
- Şifre kendisini 2 defadan fazla tekrar eden karakter içeremez (AAA, zzz vb.)
- Şifre Türkçe karakter içeremez. (ç, ğ, İ, ö, ş, ü…)
- ASCII karakteri olmayan karakter içeremez. (ä, é, Ý, Ð, Π vb.)
- Şifre tamamı büyük ya da tamamı küçük harf olan kolay tahmin edilebilir sözcük veya sözlük kelimesi içeremez. (Seçtiğiniz şifre sözlükte bulunmaktadır uyarısı alırsanız, şifrenizdeki harflerin çoğunluğunu ünsüz veya ünlü harflerden oluşturmanız önerilir.)
- Yeni şifre, son 5 şifre ile aynı olamaz.

Örnek Parolalar:

- Polut36\*
- Dem70:ka
- 2K/mReD
- 2F,646(w
- EO\*A(/5y
- .g1>4YjT
- o)5aDA-9