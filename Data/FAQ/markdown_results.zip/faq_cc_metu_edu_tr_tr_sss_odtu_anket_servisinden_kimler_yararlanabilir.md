[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisinden-kimler-yararlanabilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 26-04-2022 **Görüntüleme:** 6754


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/who-can-use-metu-survey-service "Who can use METU Survey Service?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-anket-servisinden-kimler-yararlanabilir "ODTÜ anket servisinden kimler yararlanabilir?")

# ODTÜ anket servisinden kimler yararlanabilir?

[Anket Servisi](https://faq.cc.metu.edu.tr/tr/groups/anket-servisi)

Servisten yüksek lisans - doktora öğrencileri ve halen çalışmakta olan ODTÜ personeli yararlanabilmektedir.