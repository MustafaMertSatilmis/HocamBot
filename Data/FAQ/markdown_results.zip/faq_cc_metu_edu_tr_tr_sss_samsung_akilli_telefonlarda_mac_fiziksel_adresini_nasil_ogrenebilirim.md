[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/samsung-akilli-telefonlarda-mac-fiziksel-adresini-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 18-03-2015 **Görüntüleme:** 85532


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-mac-physical-address-samsung-smartphone "How can I find out the MAC (physical) address on a Samsung Smartphone?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/samsung-akilli-telefonlarda-mac-fiziksel-adresini-nasil-ogrenebilirim "Samsung Akıllı Telefonlarda MAC (fiziksel) adresini nasıl öğrenebilirim?")

# Samsung Akıllı Telefonlarda MAC (fiziksel) adresini nasıl öğrenebilirim?

[IP ve MAC](https://faq.cc.metu.edu.tr/tr/groups/ip-ve-mac)

WiFi/Kablosuz-etkin Samsung akıllı telefonunuzda MAC adresi bulmak için aşağıdaki basamakları takip edin.

1. Ana ekrandan ‘Menü’yü seçin.
2. Ayarları seçin.
3. Kablosuzu seçin.
4. Aç Açık Ağları seçin.
5. Seçenekleri/Gelişmişi seçin.
6. Ayrıntıları Gösteri seçin.
7. MAC Adresine gelin.

Not: Burada açıklanan basamaklar sahip olduğunuz cihaza göre değişiklik gösterebilir. Daha detaylı bilgi için, lütfen akıllı telefonunuzun yanında verilen kılavuzu inceleyiniz.