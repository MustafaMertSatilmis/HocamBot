[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kayit-sayfasindaki-robot-resim-dogrulama-ben-robot-degilim-hakkinda-nereden-bilgi-edinebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 23-09-2022 **Görüntüleme:** 9364


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/where-can-i-find-information-about-recaptcha-image-validation-im-not-robot-registration-page "Where can I find information about ReCaptcha image validation (I'm not a robot) on the registration page?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kayit-sayfasindaki-robot-resim-dogrulama-ben-robot-degilim-hakkinda-nereden-bilgi-edinebilirim "Kayıt sayfasındaki robot resim doğrulama (ben robot değilim) hakkında nereden bilgi edinebilirim?")

# Kayıt sayfasındaki robot resim doğrulama (ben robot değilim) hakkında nereden bilgi edinebilirim?

[Diğer](https://faq.cc.metu.edu.tr/tr/groups/diger)

Kayıt sayfasında ders seçimi ekranında otomatik ders seçimlerini engellemek amacıyla robot resim doğrulama sistemi kullanılmaktadır.

Google ReCaptcha servisi kullanıcının tarayıcısına Google tarafından otomatik eklenmekte ve doğrulanmaktadır. Ayrıca bu servisin bir zaman aşımı olduğundan ekrandaki gösterilen resimlerden doğru olanlar seçilip bir süre beklenince doğrulama kendi kendine zaman aşımına uğrayabilmektedir.

Bunların yanı sıra farklı IP adreslerinden çok sayıda erişim, tarayıcıda kullanılan bazı eklentiler, gizli sekmede çok sayıda sayfanın açılması, ReCaptcha servisinin sunduğu resimlerde yanlış seçimler sonraki doğrulamalar da robot olmadığının kanıtlanması için daha fazla bilgi istenmesine ve doğrulama resimleri gösterilmesine sebep olabilmektedir.

Google ReCaptcha servisinin kayıt sayfası dışında nasıl çalıştığını deneyimlemek için tarayıcınızdan

[https://www.google.com/recaptcha/api2/demo?invisible=false](https://www.google.com/recaptcha/api2/demo?invisible=false) adresine erişip denemeler yapabilir ayrıca gizli bir sekme ile de aynı adresi açıp ekrana gelecek resim doğrulama servisini deneyimleyebilirsiniz.

Bazı durumlarda resim doğrulama servisinin ekranda istediği bilgiler ile ekranda gösterilen resimler arasında uyumsuzluklar olmaktadır. Örneğin doğrulamada yangın musluğu seçiniz derken, gösterilen resimlerde yangın musluğu bulunmamaktadır. Böyle bir durumda atla (skip) diyerek sonraki doğrulamaya geçilmesi gerekmektedir. Kayıt sayfamızda kullanılan Google ReCaptcha doğrulama hizmetine bir müdahalemiz bulunmamaktadır.