[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/adsoyadmetuedutr-bicimindeki-e-posta-adresimi-degistirebilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 02-11-2021 **Görüntüleme:** 16773


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-change-my-e-mail-address-consists-my-name-and-surname-format-namesurnamemetuedutr "Can I change my e-mail address that consists of my name and surname in the format 'name.surname@metu.edu.tr'?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/adsoyadmetuedutr-bicimindeki-e-posta-adresimi-degistirebilir-miyim "'ad.soyad@metu.edu.tr' biçimindeki e-posta adresimi değiştirebilir miyim?")

# 'ad.soyad@metu.edu.tr' biçimindeki e-posta adresimi değiştirebilir miyim?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

[https://useraccount.metu.edu.tr](https://useraccount.metu.edu.tr/) adresindeki Kullanıcı Hesap Yönetimi sayfasında seçmiş olduğunuz **ad.soyad![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr** biçimindeki e-posta adresiniz normal şartlarda değiştirilememektedir.

[isim.soyisim@metu.edu.tr](https://sqrl.metu.edu.tr/src/compose.php?send_to=isim.soyisim%40metu.edu.tr)  şeklinde alias  tanımlamaları 2010-2011 eğitim yılı  sonrasında öğrenciliği başlayanlara  verilmekte  daha öncesinde eğitime başlayanlara tanımlama yapılmamaktadır.

Ancak evlenme ve boşanma nedeniyle ya da mahkeme kararıyla ad veya soyad değişikliği yaptıysanız, ilgili belgeler ile öğrenciyseniz Öğrenci İşleri Daire Başkanlığı'na, personelseniz Personel Daire Başkanlığı'na başvurmanız gerekmektedir. PDB ve ÖİDB tarafından yapılan güncellemeler sonrasında sistemlerimizdeki bilgileriniz de güncellenecektir.

Eğer size verilecek yeni e-posta adresi başka bir kullanıcı tarafından kullanılıyorsa, yeni bir adres belirlemek üzere sizinle iletişime geçilecektir.

Adres değişikliği yapıldıktan sonra eski e-posta adresine gelen e-postalar hiçbir şekilde yeni adrese yönlendirilmeyecek, gönderen kişiye geri dönecektir. Bununla ilgili bilgilendirme vb. işlemler kullanıcının sorumluluğundadır.