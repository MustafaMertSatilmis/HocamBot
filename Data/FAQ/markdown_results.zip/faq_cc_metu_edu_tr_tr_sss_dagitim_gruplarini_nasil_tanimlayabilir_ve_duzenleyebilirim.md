[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/dagitim-gruplarini-nasil-tanimlayabilir-ve-duzenleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 6642


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/dagitim-gruplarini-nasil-tanimlayabilir-ve-duzenleyebilirim)

# Dağıtım gruplarını nasıl tanımlayabilir ve düzenleyebilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de sürekli aynı birimlere/bölümlere/kişilere evrak gönderiyorsanız bu birimleri " **Dağıtım Grubunu Kaydet**" düğmesi ile isimlendirip bir dağıtım grubu olarak kaydedebilirsiniz. Daha sonra benzer evrakların gönderiminde " **Kayıtlı Dağıtım Grupları**" açılır listesi ile sadece bu dağıtım grubunun ismini seçerek önceden belirlemiş olduğunuz birimlerin ya da kişilerin isminin gelmesini sağlayabilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/dagitimkayit.png)

Oluşturduğunuz dağıtım listelerinde daha sonra düzenleme yapmanız ya da tamamıyla silmeniz mümkündür.

**Listeden birini çıkarmak için**

- **EBYS -> Sistem Parametreleri -> Gelen Evrak Dağıtım Gruplarını Düzenle** isimli bölümden ilgili dağıtım grubuna tıklanır.
- **"Değişiklik yap"** düğmesine bastıktan sonra çarpı işaretleri ile satırlar silinir.
- Ardından " **Değişiklikleri Kaydet**" düğmesine basılarak listenin son hali kaydedilir.

**Listeyi tamamen silmek için**

- **EBYS -> Sistem Parametreleri -> Gelen Evrak Dağıtım Gruplarını Düzenle** isimli bölümden ilgili dağıtım grubunun sağ tarafında görülen kırmızı çarpı işaretiyle dağıtım grubu silinebilmektedir.

**Listeye ekleme yapmak için**

- Yukarıda resmi bulunan sevk ekranında değişiklik yapmak istediğiniz listeyi " **Kayıtlı Dağıtım Grupları**" açılır listesi ile seçiniz.
- Liste ekrana yüklendikten sonra yapmak istediğiniz eklemeleri yapınız.
- Ardından " **Dağıtım Grubunu Kaydet**" düğmesi ile yeni bir isim vererek grubu kaydediniz.
- Önceki grubu silmek isterseniz yukarıdaki **Listeyi tamamen silme** bölümündeki talimatı izleyebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.