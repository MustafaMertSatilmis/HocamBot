[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarafima-bir-evrak-iletildi-ne-yapmaliyim-seceneklerim-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 7041


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-tarafima-bir-evrak-iletildi-ne-yapmaliyim-seceneklerim-nelerdir)

# EBYS'de tarafıma bir evrak iletildi, ne yapmalıyım? Seçeneklerim nelerdir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de evraklar çeşitli durumlarda ve statülerde size iletilebilmektedir. Bunlara yapılabilecek işlemler de birbirinden farklı olacaktır.

İlgili evrak türünde yapabileceğiniz işlemler, evrakın üst tarafındaki düğmelerle ifade edilmiştir.

**Sevk Et:** Evrakı çeşitli birimlere ve veya kişilere sevk edebilirsiniz.

**Gereği Yapılmıştır:** Gereği için gelen evrakın sizdeki kopyasının sonlandırılması. (Başka kişilere de gönderilmişse, onlarda evrak işlemleri devam edecektir.)

**Bilgi Edinilmiştir:** Bilgi için gelen evrakın sizdeki kopyasının sonlandırılması. (Başka kişilere de gönderilmişse, onlarda evrak işlemleri devam edecektir.)

**İade Et:** Yalnızca belirli birkaç durumda iade etme imkanı vardır. Bu düğme görülüyorsa basıldığında evrak sizden bir önceki adıma dönecektir.

**Cevap Yaz:** Evrakı ilgi haline getirerek evraka cevap hazırlanır.

**Kapak Yazısı Yaz:** Evrakı ilgi haline getirip kapak yazısı başlatır ve söz konusu evrak sonlandırılır. (Detaylı bilgi: [https://faq.cc.metu.edu.tr/tr/sss/kapak-yazisi-yaz-nedir](https://faq.cc.metu.edu.tr/tr/sss/kapak-yazisi-yaz-nedir))

**Dağıtım Onayı:** Evrakın dağıtılacağı birim ve kişilerin girişi yaparak dağıtımı onaylayacak kullanıcıya göndermenizi sağlar.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.