[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtude-kablosuz-bilgisayar-agi-var-mi-nasil-faydalanabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 05-11-2024 **Görüntüleme:** 16012


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/there-wireless-network-metu-how-can-i-connect "Is there a wireless network in METU, how can I connect?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtude-kablosuz-bilgisayar-agi-var-mi-nasil-faydalanabilirim "ODTÜ'de kablosuz bilgisayar ağı var mı, nasıl faydalanabilirim?")

# ODTÜ'de kablosuz bilgisayar ağı var mı, nasıl faydalanabilirim?

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

**ODTÜ'de Kablosuz Ağın Tarihçesi**

Orta Doğu Teknik Üniversitesi 802.11 standardındaki kablosuz ağların Türkiye'de Üniversiteler arasında ilk uygulayıcısı olmuştur. 2000 yılında kurulan ve noktadan noktaya kripte çalışan bu ilk ağ, 802.11b standardındadır ve bu ağ konvansiyonel yöntemlerle kablolanarak bağlantısı sağlanamayan bölümlerin/birimlerin kampüs omurga bağlantısını sağlamak için kullanılmıştır. Bu yöntemle 4 bölüm/birimin ağ bağlantısı sağlanmıştır.

Acil durumlarda bağlantı sağlamak üzere de bir set kablosuz ağ ekipmanı BİDB binasında bulundurulmuş ve bu set bağlantısı beklenmedik şekilde kesilen bölümlerin, bağlantısı normal yollardan sağlanana kadar ağ bağlantısını geçici olarak sağlamak amacı ile kullanılmıştır.

2003 senesinde, mobil kullanıcıların ağ bağlantılarını sağlamak amacı ile Merkez Mühendislik binası tepesinde ilk çalışma grubu kipinde çalışan kablosuz ağ servisi hizmet vermeye başlamıştır.

**ODTÜ 'de Kablosuz Ağın Bugünü**

2005 yılında kablosuz ağ istemcilerin sayısındaki artış ile birlikte, ODTÜ yerel alan ağında varolan çalışma grubu kipinde çalışan kablosuz ağ servisi hemen hemen her bölümü ve idari birimi kapsayacak şekilde genişletilmiştir. Her bölümde ya da birimde mobil kullanıcıların yoğun olduğu bölgeler ve noktalar belirlenerek 802.11g kablosuz erişim cihazları yerleştirilmiş ve kapsama alanları yaratılmıştır. Şu anda bütün bölümlere ek olarak yurtların bir kısmı, Kütüphane ve Dokümantasyon Dairesi Başkanlığı ve Kültür ve Kongre Merkezi'nin tüm salonları ve misafirhaneler 802.11g kablosuz ağ kapsamı altındadır. Kablosuz ağ erişim noktalarının haritasına [buradan](http://harita.odtu.edu.tr/kategori/24/kablosuz-internet-alanlari) ulaşabilirsiniz.

Şu anda her erişim noktasında en az bir SSID yayını bulunmaktadır. Herhangi bir şifreleme ile çalışmayan ng2k yayını 2018 yılında sonlandırılmış ve [meturoam](https://faq.cc.metu.edu.tr/tr/sss/meturoam) yayınına geçilmiştir. RADIUS tabanlı 802.1x kimlik doğrulama ile çalışan ve **[EDUROAM](http://www.eduroam.org/)** ağının bir parçası olan ikinci bir SSID yayını ( **eduroam**) daha bulunmaktadır. Kurumlar arası kablosuz ağ dolaşımı sağlayan **EDUROAM** hakkında daha fazla bilgiye sahip olmak için [eduroam](http://eduroam.metu.edu.tr/) sayfasını ziyaret edebilirsiniz.