[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/eduroam-sifremi-unuttum-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 16262


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-forgot-eduroam-password-what-can-i-do "I forgot eduroam password, what can I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/eduroam-sifremi-unuttum-ne-yapmaliyim "eduroam şifremi unuttum, ne yapmalıyım?")

# eduroam şifremi unuttum, ne yapmalıyım?

[eduroam](https://faq.cc.metu.edu.tr/tr/groups/eduroam)

[Ağ](https://faq.cc.metu.edu.tr/tr/groups/ag)

Eduroam yayınına bağlanabilmek için ODTÜ kullanıcı kodu ve şifrenizi kullanmanız gerekmektedir. Eğer ODTÜ şifrenizi hatırlamıyorsanız, [https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-koduma-ait-sifremi-unut...](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-koduma-ait-sifremi-unuttum-nereden-ogrenebilirim) sayfasını ziyaret edebilirsiniz.