[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gelen-bilgilendirmeler-nasil-goruntulenir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 5321


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gelen-bilgilendirmeler-nasil-goruntulenir)

# EBYS’de gelen bilgilendirmeler nasıl görüntülenir?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Fonksiyonel Özellikler](https://faq.cc.metu.edu.tr/tr/groups/fonksiyonel-ozellikler)

Sağ üstte bulunan "i" logosuna tıklayarak gelen bilgilendirmeleri görebilirsiniz. Bilgilendirme sebebini anlamak için evrakın akış tarihçesini inceleyebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/bilgilendirmeler_2.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.