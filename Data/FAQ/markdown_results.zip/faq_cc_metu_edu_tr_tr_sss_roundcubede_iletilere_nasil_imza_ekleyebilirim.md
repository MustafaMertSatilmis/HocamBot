[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletilere-nasil-imza-ekleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1839


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-iletilere-nasil-imza-ekleyebilirim)

# Roundcube'de iletilere nasıl imza ekleyebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

Roundcube web arayüzünde ana menüde yer alan "Ayarlar" butonuna, ardından "Kimlikler" butonuna tıklayınız. Kullanıcı adınızı seçtikten sonra "İmza" başlıklı form alanına, e-postalarınıza otomatik olarak eklenmesini istediğiniz imza metnini yazdıktan sonra "Kaydet" butonuna tıklayarak kaydediniz.

İmzanızı kaydettikten sonra, imza ayarları için tekrar "Ayarlar" sekmesinden "Yeni İleti Oluşturma" seçeneğini tıklayınız. Açılacak düzenleme ekranında "İmza Ayarları" bölümünde yazacağınız e-postalarınıza imza eklenirken dikkate alınacak seçenekleri düzenleyebilirsiniz.