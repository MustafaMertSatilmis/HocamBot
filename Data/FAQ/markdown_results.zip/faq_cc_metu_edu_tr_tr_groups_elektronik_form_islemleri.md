[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Elektronik Form İşlemleri

|     |
| --- |
| [EBYS İzin Formları ile ilgili Sıkça Sorulanlar](https://faq.cc.metu.edu.tr/tr/sss/ebys-izin-formlari) |
| [EBYS İzin Formları ile ilgili Yönetici ve Sekreterlere Sunulan Raporlar](https://faq.cc.metu.edu.tr/tr/ebys-izin-formlari-raporlar) |
| [EBYS üzerinden taşıt istem formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebys-uzerinden-tasit-istem-formunu-nasil-doldurabilirim) |
| [EBYS'de bakım, onarım, imalat, tadilat ve çevre düzenleme formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-bakim-onarim-imalat-tadilat-ve-cevre-duzenleme-formunu-nasil-doldurabilirim) |
| [EBYS'de fiziksel posta gönderim formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-fiziksel-posta-gonderim-formunu-nasil-doldurabilirim) |
| [EBYS'de Makale Ödülü başvuru formu neden görünmüyor?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-makale-odulu-basvuru-formu-neden-gorunmuyor) |
| [EBYS'de ODTÜ Geliştirme Vakfı yayın ödüllerine nasıl başvurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-odtu-gelistirme-vakfi-yayin-odullerine-nasil-basvurabilirim) |
| [EBYS'de sağlık raporları formunu nasıl doldurabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ebysde-saglik-raporlari-formunu-nasil-doldurabilirim) |
| [Vekalet aldığımda başkasının yerine elektronik form onaylarını nasıl yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/vekalet-aldigimda-baskasinin-yerine-elektronik-form-onaylarini-nasil-yapabilirim) |

[![Subscribe to Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/215/all/feed "Subscribe to Elektronik Form İşlemleri")