[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gelen-bir-yaziyi-tum-birim-personeline-duyuru-seklinde-gonderebilir-miyiz#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4249


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gelen-bir-yaziyi-tum-birim-personeline-duyuru-seklinde-gonderebilir-miyiz)

# Gelen bir yazıyı tüm birim personeline duyuru şeklinde gönderebilir miyiz?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Şu anda EBYS'de bu özellik bulunmamaktadır. Yazıyı pdf olarak indirip bölüm e-posta listesi ile bölüm personeline gönderebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.