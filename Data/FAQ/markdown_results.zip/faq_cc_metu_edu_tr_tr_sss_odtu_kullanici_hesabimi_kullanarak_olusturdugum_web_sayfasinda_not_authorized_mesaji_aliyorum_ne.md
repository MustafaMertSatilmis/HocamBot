[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-olusturdugum-web-sayfasinda-not-authorized-mesaji-aliyorum-ne#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 9130


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/i-am-getting-not-authorized-message-web-page-i-have-created-using-my-metu-user-account-what "I am getting a “not authorized” message on the web page I have created by using my METU user account. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-olusturdugum-web-sayfasinda-not-authorized-mesaji-aliyorum-ne "ODTÜ kullanıcı hesabımı kullanarak oluşturduğum web sayfasında \"not authorized\" mesajı alıyorum. Ne yapmalıyım?")

# ODTÜ kullanıcı hesabımı kullanarak oluşturduğum web sayfasında "not authorized" mesajı alıyorum. Ne yapmalıyım?

[Kullanıcı Hesapları](https://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari)

ODTÜ kullanıcı hesabınızı kullanarak oluşturduğunuz web sayfasında "not authorized" mesajı alıyorsanız sayfaya erişim haklarında bir sorun olduğu anlamına gelmektedir. Bu sorunu aşağıdaki yöntemlerden birini kullanarak düzeltebilirsiniz;

- **Horde ile:**
Horde'a giriş yaptıktan sonra üst menüden ya da sol menüde bulunan hesabım başlığı altından ulaşacağınız dosya yöneticisi butonuna basınız. Burada wwwhome dizinini seçiniz ve eylemler başlığı altında bulunan izinleri değiştir seçeneğine tıklayınız ve izinleri aşağıdaki şekilde görüldüğü gibi değiştiriniz. Ayrıca kullanıcı ev dizininin erişim haklarını da ilgili dizinin yanındaki bölümden kontrol edebilirsiniz.

![](https://faq.cc.metu.edu.tr/system/files/horde_izin.jpg)

- **Ssh ile sunucu sistemlere bağlanarak:**
**wwwhome** dizininin erişim haklarını kontrol etmek için:

ls -ald wwwhome

komutunu çalıştırınız. Bu komut sonrasında ekranınıza aşağıdakine benzer bir satır gelecektir. Bu satırdaki ilk 10 karakter (drwxr-xr-x), **wwwhome** dizinine erişim haklarını belirtmekte olup aşağıdaki değerlerle aynı olmalıdır.

drwxr-xr-x 14 uid gid 1536 Sep 20 12:10 wwwhome

Farklı olması durumunda aşağıdaki komutları çalıştırarak **wwwhome** dizininin erişim yetkilerini tanımlayınız.

chmod og=rx wwwhome

Daha sonra, kullanıcı home dizininizin erişim haklarını kontrol etmek için,

ls -ald ~

komutunu yazınız. Bu komut sonrasında ekranınıza gelecek satırın ilk 10 karakterinin aşağıdaki değerlerle aynı olup olmadığını kontrol ediniz:

drwx--x--x 14 uid gid 1536 Sep 20 12:10 kullanici-kodu

Eğer değerler yukarıdaki gibi değilse aşağıdaki komutu çalıştırınız:

chmod a+x ~

Bu işlemler tamamlandığında, web sayfası hazırlayabilmeniz için gerekli dizin yapısı kurulmuş olur.