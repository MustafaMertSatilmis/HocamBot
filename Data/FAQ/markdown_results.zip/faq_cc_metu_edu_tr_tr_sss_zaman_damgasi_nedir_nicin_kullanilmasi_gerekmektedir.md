[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/zaman-damgasi-nedir-nicin-kullanilmasi-gerekmektedir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 12901


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/what-time-stamp-why-it-have-be-used-turkish "What is Time Stamp, why is it have to be used? (In Turkish)")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/zaman-damgasi-nedir-nicin-kullanilmasi-gerekmektedir "Zaman damgası nedir, niçin kullanılması gerekmektedir?")

# Zaman damgası nedir, niçin kullanılması gerekmektedir?

[Bilgi Güvenliği](https://faq.cc.metu.edu.tr/tr/groups/bilgi-guvenligi)

**Zaman damgası nedir?**

Zaman damgası, elektronik ortamda log, doküman ve sözleşme gibi elektronik verilerin, belirli bir zamandan önce var olduğunu kanıtlamak için kullanılır. Mesela bir log dosyasının, kayıt altına alındıgı tarihte orjinal haliyle var oldugunu, sonradan değiştirilmediğini ispatlamak amacıyla zaman damgasından yararlanılabilir.

**Niçin Kullanılması Gerekmektedir?**

30 Kasım 2007 tarih ve 26716 sayılı Resmi Gazete'de yayınlanan "İnternet Ortamında Yapılan Yayınların Düzenlenmesine Dair Usul Ve Esaslar Hakkında Yönetmelik" gereğince yer sağlayıcılar, _"Yer sağlayıcı trafik bilgisini altı ay saklamakla, bu bilgilerin doğruluğunu, bütünlüğünü oluşan verilerin dosya bütünlük değerlerini zaman damgası ile birlikte saklamak ve gizliliğini temin etmekle"_ yükümlüdürler. Bu kapsamda, mesela bir web sayfası bulunduran sunucunun trafik bilgisi loglarının kanunen zaman damgası ile damgalanması zorunludur.

**Log Bilgileri Nasıl Zaman damgası ile damgalanır?**

Aşağıdaki çizim, bir log dosyasının üretildiği tarihten sonra değistirilmediğini gösteren zaman damgası ile damgalama yöntemlerinden birisidir. Bu yöntemle, ileriki bir tarihte oluşturulan zaman dosyasının değiştirilmediğini göstermek için benzer işlemin tekrarı yapılır, sonuç özet (hash) değerleri aynı bulunursa, dosyanın orjinal, zaman damgalandığı tarihten itibaren değişmediği sonucu çıkar.

![](https://faq.cc.metu.edu.tr/system/files/zmn.jpg)