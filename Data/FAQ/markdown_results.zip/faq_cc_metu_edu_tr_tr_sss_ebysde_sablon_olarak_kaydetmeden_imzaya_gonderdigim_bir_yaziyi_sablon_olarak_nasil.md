[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-sablon-olarak-kaydetmeden-imzaya-gonderdigim-bir-yaziyi-sablon-olarak-nasil#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 4404


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-sablon-olarak-kaydetmeden-imzaya-gonderdigim-bir-yaziyi-sablon-olarak-nasil)

# EBYS'de şablon olarak kaydetmeden imzaya gönderdiğim bir yazıyı şablon olarak nasıl kaydedebilirim?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

Bir yazıyı imzaya gönderdikten sonra şablon olarak kaydetmeniz mümkün değildir; imzaya göndermeden önce kaydetmelisiniz. İmzaya gönderdiğiniz kişi yazıyı size imzalamadan geri gönderirse, ancak o zaman şablon olarak kaydetmeniz mümkün olabilir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.