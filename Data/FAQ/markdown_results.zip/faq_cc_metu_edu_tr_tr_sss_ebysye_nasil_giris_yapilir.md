[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysye-nasil-giris-yapilir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 114624


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysye-nasil-giris-yapilir)

# EBYS'ye nasıl giriş yapılır?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

- [https://ebys.metu.edu.tr](https://ebys.metu.edu.tr/) adresinde yer alan Elektronik Belge Yönetim Sistemine Üniversitemiz Akademik ve İdari personeli girebilmektedir.
- Öğrencilerimiz bu hizmetten yararlanamamaktadır.
- EBYS'ye aşağıda görünen giriş ekranı üzerinden "@metu.edu.tr" uzantılı kullanıcı adı/parolası ile ya da E-imza kullanılarak giriş yapılabilir.
- "@metu.edu.tr" uzantılı kullanıcı adı tanımlı olmayan Akademik ve İdari personel [http://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-nasil-kullanici-kodu-...](http://faq.cc.metu.edu.tr/tr/sss/odtu-personeliyim-nasil-kullanici-kodu-alabilirim) adresinde tarif edildiği şekilde kullanıcı kodu başvurusu yapmalıdır. Yeni tanımlanan kullanıcı kodları, tanımlamanın ertesi günü EBYS'ye girişte kullanılabilecektir.
- Kullanıcı adı/parola ile giriş yapılacaksa, gerekli bilgiler doldurulduktan sonra "Giriş" butonuna basılır. Sistemin kullanıcı adı bilgisini hatırlaması için "Beni hatırla" seçeneği kullanılabilir. Sayfada Dil seçeneği değiştirilebilir.
- Kullanıcı adı/parola ikilisi ile sisteme girişte sorun yaşanıyorsa [http://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari](http://faq.cc.metu.edu.tr/tr/groups/kullanici-hesaplari) adresindeki bilgiler incelenebilir.
- Sisteme E-imza ile giriş konusunda bilgi almak için [http://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim](http://faq.cc.metu.edu.tr/tr/sss/ebysde-e-imzayi-nasil-kullanabilirim) adresi ziyaret edilebilir.

![EBYS Giriş Ekranı](https://faq.cc.metu.edu.tr/tr/system/files/u16319/ebys_giris_ekrani.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.