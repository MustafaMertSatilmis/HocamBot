[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/odtude-kullanilan-lisansli-bir-antivirus-programi-var-mi-varsa-nereden-edinebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-03-2024 **Görüntüleme:** 12854


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/there-licensed-antivirus-software-metu-if-so-where-can-i-downloadget-it "Is there a licensed antivirus software at METU? If so, where can I download/get it from?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/odtude-kullanilan-lisansli-bir-antivirus-programi-var-mi-varsa-nereden-edinebilirim "ODTÜ'de kullanılan lisanslı bir antivirüs programı var mı? Varsa nereden edinebilirim?")

# ODTÜ'de kullanılan lisanslı bir antivirüs programı var mı? Varsa nereden edinebilirim?

[Virüs](https://faq.cc.metu.edu.tr/tr/groups/virus)

ODTÜ'de yerleşke geneline lisanslı Symantec AntiVirus yazılımı kullanılmaktadır. Yazılımı;

[https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/) adresinden ya da bölüm koordinatörünüzden edinebilirsiniz.

[https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/) adresi bütün ODTÜ mensuplarına açıktır. Bu adrese merkezi sunucu sistemler üzerinde bulunan kullanıcı kodu ve şifrenizle girebilirsiniz.

Symantec AntiVirus ile ilgili Sıkça Sorulan Sorular sayfasına [http://faq.cc.metu.edu.tr/tr/symantec](http://faq.cc.metu.edu.tr/tr/symantec) adresinden erişebilirsiniz.