[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 6742


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-gecmis-akislar-nasil-goruntulenir)

# EBYS’de geçmiş akışlar nasıl görüntülenir?

[EBYS](https://faq.cc.metu.edu.tr/tr/groups/ebys)

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

- Öncelikle EBYS'de oturum açınız.
- Sol menüden "İş Akış Yönetimi" seçeneğini tıklayınız.
- Açılan bölümden "Geçmiş" seçeneğini tıklayınız.
- Açılan bölümden evrak türlerine tıklayarak ilgili evrakları listeleyebilirsiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u2/gecmis-akislar.png)

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.