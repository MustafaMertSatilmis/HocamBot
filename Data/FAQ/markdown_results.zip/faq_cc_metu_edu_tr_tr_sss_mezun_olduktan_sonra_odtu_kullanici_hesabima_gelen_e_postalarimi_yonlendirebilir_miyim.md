[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/mezun-olduktan-sonra-odtu-kullanici-hesabima-gelen-e-postalarimi-yonlendirebilir-miyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 29952


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/can-i-forward-my-e-mails-arrive-my-metu-user-account-after-i-graduate "Can I forward my e-mails that arrive at my METU user account after I graduate?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/mezun-olduktan-sonra-odtu-kullanici-hesabima-gelen-e-postalarimi-yonlendirebilir-miyim "Mezun olduktan sonra ODTÜ kullanıcı hesabıma gelen e-postalarımı yönlendirebilir miyim?")

# Mezun olduktan sonra ODTÜ kullanıcı hesabıma gelen e-postalarımı yönlendirebilir miyim?

[E-Posta](https://faq.cc.metu.edu.tr/tr/groups/e-posta)

**Yönlendirme servisi** kapsamında, öğrencilerin exxxxxx![](http://faq.cc.metu.edu.tr/system/files/u16319/et_b.gif)metu.edu.tr formatındaki e-posta adresleri mezuniyetlerini takip eden 1 Öğretim Yarıyılı (1 Dönem) boyunca (Haziran dönemi mezunları için bir sonraki yılın Mart ayı; Şubat dönemi mezunları için aynı yılın Kasım ayı sonuna kadar) açık tutularak, bu sürenin sonunda, mezun tarafından bildirilenen yeni bir e-posta adresine süresiz olarak yönlendirilmektedir.

Mezuniyet durumundaki öğrencilere, kullanıcı hesapları kapatılmadan **6 ay önce**, kullanıcı hesaplarının kapatılacağına dair bir bilgilendirme e-postası ve 1 ay önce ise hatırlatma e-postası gönderilmektedir. Öğrenciler, bu kapatılma e-postasını aldıktan ya da hesapları kapatıldıktan sonra herhangi bir zamanda bu yönlendirmeyi yapabilmektedirler.

Kullanıcı e-posta adreslerinin yönlendirilmesi için [https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim](https://faq.cc.metu.edu.tr/tr/sss/odtu-e-posta-yonlendirmeyi-nasil-kullanabilirim) adresinden bilgi alabilirsiniz.