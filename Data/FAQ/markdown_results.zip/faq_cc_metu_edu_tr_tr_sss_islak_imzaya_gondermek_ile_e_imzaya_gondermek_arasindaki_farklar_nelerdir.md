[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/islak-imzaya-gondermek-ile-e-imzaya-gondermek-arasindaki-farklar-nelerdir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 9959


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/islak-imzaya-gondermek-ile-e-imzaya-gondermek-arasindaki-farklar-nelerdir)

# Islak imzaya göndermek ile e-imzaya göndermek arasındaki farklar nelerdir?

[Evrak İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/evrak-islemleri)

EBYS'de esas olan işlemleri elektronik imza ile tamamlamaktır. Bu sayede evrak tamamen elektronik ortamda oluşturulacak ve iç birimlere/dış kurumlara elektronik olarak iletilecek ve geçerli olacaktır.

Ancak imzalayacak kişilerin e-imzalarının olmaması/bozulması gibi durumlarda evrak ıslak imza ile hazırlanabilir.

Islak imza ile hazırlanmış evrakın çıktısının alınarak, imzacı olarak kimler tanımlanmışsa imzalatılması ve kurum içinde eski usullerle (evrakın fiziksel iletimi), kurum dışında posta yoluyla iletilmesi gereklidir. E-imzalanmamış veya çıktısı alınarak ıslak imza atılmamış evrakların geçerliliği bulunmamaktadır.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.