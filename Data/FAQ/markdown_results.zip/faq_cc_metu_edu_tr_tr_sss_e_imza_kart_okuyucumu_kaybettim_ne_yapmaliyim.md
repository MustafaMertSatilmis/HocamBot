[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/e-imza-kart-okuyucumu-kaybettim-ne-yapmaliyim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 13-12-2019 **Görüntüleme:** 9064


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/ive-lost-my-e-signature-card-reader-what-should-i-do "I've lost my e-signature card reader. What should I do?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/e-imza-kart-okuyucumu-kaybettim-ne-yapmaliyim "E-imza kart okuyucumu kaybettim. Ne yapmalıyım? ")

# E-imza kart okuyucumu kaybettim. Ne yapmalıyım?

[E-imza](https://faq.cc.metu.edu.tr/tr/groups/e-imza)

Mevcut kart okuyucunuzu kaybettiyseniz, KamuSM aracılığı ile aşağıdaki adresten, bireysel olarak yeni kart okuyucu talebinde bulunabilirsiniz

[https://ebasvuru.kamusm.gov.tr/kartokuyucu](https://ebasvuru.kamusm.gov.tr/kartokuyucu)

Kart okuyucu ücreti kişisel olarak ödenecek, kurum tarafından karşılanamayacaktır.