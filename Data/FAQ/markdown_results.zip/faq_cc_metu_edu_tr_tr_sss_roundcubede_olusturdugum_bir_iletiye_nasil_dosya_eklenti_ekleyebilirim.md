[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-olusturdugum-bir-iletiye-nasil-dosya-eklenti-ekleyebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-07-2022 **Görüntüleme:** 1162


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/roundcubede-olusturdugum-bir-iletiye-nasil-dosya-eklenti-ekleyebilirim)

# Roundcube'de oluşturduğum bir iletiye nasıl dosya (eklenti) ekleyebilirim?

[Roundcube](https://faq.cc.metu.edu.tr/tr/groups/roundcube)

"İleti Gönder" butonuna tıklayarak yeni bir ileti oluşturmaya başladığınızda ya da posta kutunuza gelen bir ileti için "Yanıtla" veya “İlet” butonuna tıkladığınızda, ileti düzenleme ekranı açılacaktır. Bu ekranda görüntülenecek olan "Ayarlar ve Dosya Ekleri" sekmesinde yer alan "Dosya Ekle" butonuna tıklayarak, göndereceğiniz iletinize dosya eki ekleyebilirsiniz.