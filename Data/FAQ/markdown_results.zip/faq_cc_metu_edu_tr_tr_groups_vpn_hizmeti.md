[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/vpn-hizmeti#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# VPN Hizmeti

|     |
| --- |
| [ODTÜ VPN Hizmeti Kullanım Politikası](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmeti-kullanim-politikasi) |
| [VPN Servisi Nedir?](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisi-nedir) |
| [Android yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/android-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim) |
| [Farklı VPN yazılımları kullanarak ODTÜ VPN servisinden faydalanabilir miyim?](https://faq.cc.metu.edu.tr/tr/sss/farkli-vpn-yazilimlari-kullanarak-odtu-vpn-servisinden-faydalanabilir-miyim) |
| [iPhone ya da iPad ile ODTÜ VPN servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/iphone-ya-da-ipad-ile-odtu-vpn-servisini-nasil-kullanabilirim) |
| [MAC OS X işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/mac-os-x-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim) |
| [ODTÜ VPN Hizmetinden aynı anda toplam kaç kullanıcı faydalanabilmektedir?](https://faq.cc.metu.edu.tr/tr/sss/odtu-vpn-hizmetinden-ayni-anda-toplam-kac-kullanici-faydalanabilmektedir) |
| [Ubuntu işletim sistemi yüklü cihazımla ODTÜ VPN hizmetini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/ubuntu-isletim-sistemi-yuklu-cihazimla-odtu-vpn-hizmetini-nasil-kullanabilirim) |
| [VPN Hizmeti ile ilgili sorun yaşıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/vpn-hizmeti-ile-ilgili-sorun-yasiyorum-ne-yapmaliyim) |
| [VPN Profil Silme Nasil Yapilir?](https://faq.cc.metu.edu.tr/tr/sss/vpn-profil-silme-nasil-yapilir) |
| [VPN Servisine bağlanırken şifre sormuyor. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-baglanirken-sifre-sormuyor-ne-yapmaliyim) |
| [VPN Servisine bilgilerimi doğru girmeme rağmen bağlanamıyorum. Sorun ne olabilir?](https://faq.cc.metu.edu.tr/tr/sss/vpn-servisine-bilgilerimi-dogru-girmeme-ragmen-baglanamiyorum-sorun-ne-olabilir) |
| [VPN uygulaması kurulumunda sorun yaşıyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasi-kurulumunda-sorun-yasiyorum-ne-yapmaliyim) |
| [VPN uygulamasını nasıl indiririm?](https://faq.cc.metu.edu.tr/tr/sss/vpn-uygulamasini-nasil-indiririm) |
| [Windows işletim sistemi kurulu cihazımla ODTÜ VPN servisini nasıl kullanabilirim?](https://faq.cc.metu.edu.tr/tr/sss/windows-isletim-sistemi-kurulu-cihazimla-odtu-vpn-servisini-nasil-kullanabilirim) |

[![Subscribe to VPN Hizmeti](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/67/all/feed "Subscribe to VPN Hizmeti")