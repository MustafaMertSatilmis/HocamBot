[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir-0#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 09-12-2024 **Görüntüleme:** 3188


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/my-internet-connection-very-slow-what-could-be-problem "My internet connection is very slow. What could be the problem?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/internet-baglantim-cok-yavas-sorun-ne-olabilir-0 "İnternet bağlantım çok yavaş. Sorun ne olabilir?")

# İnternet bağlantım çok yavaş. Sorun ne olabilir?

[Kablosuz Ağ](https://faq.cc.metu.edu.tr/tr/groups/kablosuz-ag)

Kablosuz internet bağlantınızda yavaşlık olması durumunda aşağıdaki maddeleri gözden geçirebilirsiniz;

\- Bilgisayarın kablosuz ağ kartı sürücülerinin doğru modelde ve güncel olmaması

\- Mobil cihazların veya bilgisayarın antenlerini kapatacak koruyucuların kullanılması (özellikle metal olanlar)

\- Kablosuz ağ cihazına uzak şekilde cihazın kullanılması ( mesafe ve araya giren engeller performası düşürecektir)

\- Kullanıcı yoğunluğu fazla olan yerlerde internet erişiminin olması ( kablosuz ağ erişim cihazı üzerindeki kullanıcı sayısı arttırkça performans düşecektir). Bunun için kablosuz ağ kullanırken mümkünse etrafta daha az kullanıcının olduğu yerler tercih edilebilir.

\- Kablosuz ağ kullanırken gereksiz uygulamaların ve indirme/yükleme işlemlerin olması (örneğin Zoom kullanırken bir yandan dosya indirmek )

\- Meturoam/Eduroam sanal kablosuz ağ yayınlarıdır ve her ikisi de fiziksel olarak aynı kablosuz ağ cihazlarından yayınlanmaktadır. Farklı kripto teknolojileri kullandığı için bazı cihazlarda sorun yaşanabilmektedir. Alternatif olarak diğeri ile bağlantı denenebilir.

\- Kablosuz ağlarda mobil cihazlar mevcut yayınlar içerisinde daha iyi olanı tercih edecek şekilde “roaming” yaptığı için iki tane benzer yayın arasında kalmak bağlantı sorunlarına yol açabilir. Mümkünse bir tanesine daha yakın olacak şekilde yer değiştirmek bu sorunları ortadan kaldırmanıza yardımcı olacaktır.

\- Mevcut wifi teknolojileri 2.4 ve 5Ghz bantlarında çalışır. 2.4Ghz duvar geçişleri ve uzaklık açısından çok daha iyi bir performans sergiler. Fakat bant genişliği ve kullanıcı sayısı dikkate alındığında 5Ghz çok daha iyi çalışır. Cihazınızın özellikleri uygunsa hangisinden bağlandığınızı kontrol edebilirsiniz. Bazı cihazlarda bir tanesine öncelik verilebilmekte veya cihaz bunlardan sadece bir tanesini kullanmaya zorlanabilmektedir. Kablosuz ağ erişim cihazına yakın olduğunuz durumlarda 5Ghz tercih edecek şekilde bağlantı sağlamanız performans artışı sağlayacaktır. Cihaza mecburen daha uzak olduğunuz veya arada duvarlar olduğu durumda 2.4Ghz tercih edecek şekilde ayar yapmanız daha stabil bir bağlantı sağlayacaktır.

Kablosuz ağ bağlantı hızınızın yavaşlığı yukarıdaki kontrol maddelerinde belirtilen hususlardan herhangi biri nedeniyle olabilir. Buna ek olarak, bilgisayarınızdan kaynaklı sorun nedeniyle de (ağ arayüz kartınızla ilgili sorunlar, virüs vb.) bağlantı hızınız yavaş olabilir.

“İnternet hızımda sorun var” denildiğinde sorunu doğru tanımlamak çözüm için oldukça önemlidir. Bağlanmaya çalışılan sayfa, bağlantı sırasında kullanılan cihaz (işletim sistemi ve MAC/IP adres bilgileri), bağlantı saat aralığı, bağlanılan kullanıcı kodu gibi bilgiler hızlı çözüm için oldukça önemlidir. Bağlantı hızı yavaşlığını tespit etmek ve anlık hızı görmek adına [https://speedtest.metu.edu.tr/](https://speedtest.metu.edu.tr/) adresi kullanılabilir.