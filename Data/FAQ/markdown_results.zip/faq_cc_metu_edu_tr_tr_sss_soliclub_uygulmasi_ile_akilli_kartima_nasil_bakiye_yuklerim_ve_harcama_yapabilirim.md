[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/soliclub-uygulmasi-ile-akilli-kartima-nasil-bakiye-yuklerim-ve-harcama-yapabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 20-10-2022 **Görüntüleme:** 8663


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-load-and-spend-money-soliclub-application "How can I load and spend money with SoliClub application? ")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/soliclub-uygulmasi-ile-akilli-kartima-nasil-bakiye-yuklerim-ve-harcama-yapabilirim "SoliClub uygulması ile akıllı kartıma nasıl bakiye yüklerim ve harcama yapabilirim?")

# SoliClub uygulması ile akıllı kartıma nasıl bakiye yüklerim ve harcama yapabilirim?

[Akıllı Kart](https://faq.cc.metu.edu.tr/tr/groups/akilli-kart)

Utarit firmasının geliştirmiş olduğu **SoliClub** uygulaması ile akıllı kartınıza (kampüs kart) bakiye yükleyebilir, yemekhanede bulunan turnikelerden uygulama aracılığı ile karekod okutarak geçiş sağlayabilirisiniz. SoliClub aracılığı ile bakiye yüklemesi veya harcama yapabilmek için kredi kartınızı veya vadesiz hesap kartınızı BKM Ekspres ile  eşlemeniz gerekmektedir. Bu sayede eşli banka kartınız üzerinden bakiye yüklemesi veya harcama yapabilirsiniz. Yüklenen bakiyelerin karta aktarılması için akıllı kartınızı kafeteryada bulunan kiosk veya bakiye güncelleme terminaline okutmanız gerekmektedir. SoliClub uygulaması ile yükleme ve harcama yapabilmek için aktif bir akıllı kartınızın olması gerekmektedir. Kart yenileme sürecinde iseniz ve yeni kartınızı teslim almadıysanız bu uygulamayı kullanamazsınız. Yeni kartınız 3 ila 5 iş günü içerisinde teslim edilmektedir. Herhangi bir aksama durumunda öğrenci iseniz öğrenci işleri ile, personel iseniz personel daire başkanlığı ile iletişime geçebilirsiniz.  Aşağıdaki linkler üzerinden uygulamanın kullanımı hakkında bilgi alabilirsiniz.

[SoliClub Uygulama Kullanımı](https://www.youtube.com/watch?v=_dU8860H9ic)

[SoliClub Bakiye Yükleme](https://faq.cc.metu.edu.tr/tr/system/files/u21699/soliclub_bakiye_yukleme.pdf)