[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/dosya-transferi#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Dosya Transferi

|     |
| --- |
| [Horde ile tüm e-postalarımı nasıl indirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/horde-ile-tum-e-postalarimi-nasil-indirebilirim) |
| [ODTÜ kullanıcı hesabım ve bilgisayarım arasında güvenli modda (SFTP) nasıl dosya transferi yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-guvenli-modda-sftp-nasil-dosya-transferi) |
| [ODTÜ kullanıcı hesabım ve bilgisayarım arasında Horde dosya yöneticisi ile nasıl dosya transferi yapabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabim-ve-bilgisayarim-arasinda-horde-dosya-yoneticisi-ile-nasil-dosya-transferi) |

[![Subscribe to Dosya Transferi](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/57/all/feed "Subscribe to Dosya Transferi")