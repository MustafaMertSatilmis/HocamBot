[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/kullandigim-disk-alanini-ve-kotamin-son-durumunu-nasil-ogrenebilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-12-2019 **Görüntüleme:** 10818


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/faq/how-can-i-find-out-about-final-status-disk-space-and-my-quota-i-have-used "How can I find out about the final status of the disk space and my quota I have used up?")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/kullandigim-disk-alanini-ve-kotamin-son-durumunu-nasil-ogrenebilirim "Kullandığım disk alanını ve kotamın son durumunu nasıl öğrenebilirim?")

# Kullandığım disk alanını ve kotamın son durumunu nasıl öğrenebilirim?

[Kota](https://faq.cc.metu.edu.tr/tr/groups/kota)

Kullanıcı hesabı sahiplerine merkezi sunucular üzerinde ayrılan disk alanına kota denir. ODTÜ kullanıcılarına dosya ve e-postaları için iki ayrı kota tanımlanmıştır. Bu kota miktarları birbirinden bağımsızdır. Horde servisi ile her iki kotanın da son durumunu öğrenmek mümkünken, SSH ve benzeri terminal programları ile sadece dosya kotasının son durumu öğrenilebilmektedir.

**_Horde servisi ile kota bilgisine erişim:_**

Öncelikle [https://horde.metu.edu.tr/](https://horde.metu.edu.tr/) adresinden Horde sistemine giriş yapılarak, sol menüde bulunan "Hesabım" başlığı altındaki Dosya Yöneticisi seçeneği seçilmelidir. Üst menüde bulunan **Kotayı Kontrol Et** düğmesine basılarak hem e-posta, hem de dosya kotası bilgilerine erişilebilmektedir.

E-posta kotası uygulamalarında, kotanın aşılması durumunda gelen e-postaların geri dönmesi sözkonusu olduğundan, kullanıcılarımızın kendilerine tahsis edilmiş olan e-posta kotalarını kontrollü kullanmaları ve sistemden gelen uyarıları dikkate almaları önem taşımaktadır.

**_Kabuk istemci yazılımları (SSH vb.) ile dosya kotası bilgisine erişim:_**

SSH gibi bir terminal programı aracılığıyla merkezi sunucu sistemler üzerindeki kullanıcı hesabınıza bağlandıktan sonra;

quota

komutunu yazıp _Enter_ tuşuna bastığınızda dosya kotanızın son durumunu öğrenebilirsiniz. Karşınıza aşağıdaki ekran çıkacaktır:

![](https://faq.cc.metu.edu.tr/system/files/imgfaq_hesap_10_1.jpg)

Bu ekranda;

**blocks** dosya kotanızın KB cinsinden kullanılan miktarını,

**quota** dosya kotanızın KB cinsinden limitini,

**limit** dosya kotanızın KB cinsinden en fazla olabileceği değeri,

**grace** dosya kotanızın kalan kullanım süresini,

**files** dosya kotanızda yüklü bulunan dosya sayısını gösterir.