[Jump to navigation](https://faq.cc.metu.edu.tr/tr/arcgis-pro#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 05-03-2024 **Görüntüleme:** 16610


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/arcgis-pro "ARCGIS PRO")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/arcgis-pro "ARCGIS PRO")

# ARCGIS PRO

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

**— ARCGIS PRO** **3.2** **—**

**_ArcGIS Pro_** _Coğrafi Bilgi Sistemleri için gerekli özelliklerin bir araya getirildiği bir program grubudur. Arcgis for Desktop un yeni versiyonu olarak bilinmektedir._

_Aşağıdaki adımları takip ederek yazılımın kurulum ve lisanslama işlemini gerçekleştirebilirsiniz._

[**_KURULUM_**](https://faq.cc.metu.edu.tr/tr/arcgis-pro#kurulum)

[**_AKTİVASYON_**](https://faq.cc.metu.edu.tr/tr/arcgis-pro#aktivasyon)

* * *

**_\[1\] Not:_**_ArcGIS Pro yazılımı lisans anlaşması gereği hem personele hem de öğrencilere sunulmaktadır._

* * *

**_ADIM-1 <<<KURULUM>>>_**

_Kurulum için iso dosyası içerinde year alan “ **ArcGIS Pro\_32\_188049.exe**” kurulum dosyasına tıklayıp çalıştırınız ve_**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step1.png)

**_ADIM-2_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

_![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step2.png)_

**_ADIM-3_**

**_“I accept the master agreement”_**_seçeneğini işaretleyiniz. Daha sonra **“Next”**_ _butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step3.png)

**_ADIM-4_**

**_“Next”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step4_0.png)

**_ADIM-5_**

**_“Install”_**_butonuna tıklayarak ilerleyiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step5.png)

**_ADIM-6_**

**_“Finish”_** _butonuna tıklayarak tıklayarak yükleme işlemini bitiriniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step6.png)

**_ADIM-7 <<<AKTİVASYON>>>_**

_Kurulum bittikten sonra ArcGIS Pro başlayacaktır. Lisanslama seçeneklerini ayarlamak için sol tarafta yer alan menüden **"Settings"**butonuna tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step7.png)

**_ADIM-8_**

_Sol tarafta yer alan menüden **“Licensing”**seçeneğinin içerisinde bulunan **"Configure your licensing options"**butonuna tıklayınız._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step8.png)

**_ADIM-9_**

_Açılan pencerede **"Concurrent Use License"**seçeneğini seçiniz ve **“License Manager”**olarak ilgili alana **"arcgis.cc.metu.edu.tr"**yazınız. Aktif olan alanlardan hangi özellikleri kullanmak istiyorsanız seçip yazılımı kullanmaya başlayabilirsiniz._

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/arcgis_pro_3_2_step9.png)

* * *

_**Bize ulaşın:**_ [**_https://bilisimdestek.metu.edu.tr/_**](https://bilisimdestek.metu.edu.tr/)

* * *