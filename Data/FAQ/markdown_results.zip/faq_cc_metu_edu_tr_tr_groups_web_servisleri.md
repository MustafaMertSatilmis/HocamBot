[Jump to navigation](https://faq.cc.metu.edu.tr/tr/groups/web-servisleri#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

# Web Servisleri

|     |
| --- |
| [Birim ve Topluluk Web Sayfaları için Zorunlu ve Önerilen İçerikler Nelerdir?](https://faq.cc.metu.edu.tr/tr/sss/birim-ve-topluluk-web-sayfalari-icin-zorunlu-ve-onerilen-icerikler-nelerdir) |
| [Bölüm, Birim, Merkez, Laboratuvar, Öğrenci Topluluğu web sayfası nasıl yapılır?](https://faq.cc.metu.edu.tr/tr/sss/bolum-birim-merkez-laboratuvar-ogrenci-toplulugu-web-sayfasi-nasil-yapilir) |
| [metu.edu.tr uzantılı alan adı almak istiyorum. Ne yapmalıyım?](https://faq.cc.metu.edu.tr/tr/sss/metuedutr-uzantili-alan-adi-almak-istiyorum-ne-yapmaliyim) |
| [ODTÜ kullanıcı hesabımı kullanarak nasıl web sayfası oluşturabilirim?](https://faq.cc.metu.edu.tr/tr/sss/odtu-kullanici-hesabimi-kullanarak-nasil-web-sayfasi-olusturabilirim) |
| [Unix işletim sisteminde 'chmod' komutu ile dosya ve dizin haklarını nasıl değiştirebilirim?](https://faq.cc.metu.edu.tr/tr/sss/unix-isletim-sisteminde-chmod-komutu-ile-dosya-ve-dizin-haklarini-nasil-degistirebilirim) |
| [Web Kullanıcı Kodunun şifresini unuttum nasıl öğrenebilirim?](https://faq.cc.metu.edu.tr/tr/sss/web-kullanici-kodunun-sifresini-unuttum-nasil-ogrenebilirim) |

[![Subscribe to Web Servisleri](https://faq.cc.metu.edu.tr/misc/feed.png)](https://faq.cc.metu.edu.tr/tr/taxonomy/term/169/all/feed "Subscribe to Web Servisleri")