[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/ebysde-fiziksel-posta-gonderim-formunu-nasil-doldurabilirim#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 24-02-2023 **Görüntüleme:** 1642


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/ebysde-fiziksel-posta-gonderim-formunu-nasil-doldurabilirim)

# EBYS'de fiziksel posta gönderim formunu nasıl doldurabilirim?

[Elektronik Form İşlemleri](https://faq.cc.metu.edu.tr/tr/groups/elektronik-form-islemleri)

Üniversitemiz bünyesinde fiziksel olarak gönderimi yapılan zarf, paket vb. resmi postalar için Evrak ve Arşiv Müdürlüğü tarafından belirlenen kurallar doğrultusunda EBYS'de yer alan Fiziksel Posta Gönderim Formu doldurularak işlem yapılması gerekmektedir.

Form doldurulmadan ve fiziksel posta gönderimi süreci başlatılmadan önce [https://eam.metu.edu.tr/tr/system/files/posta\_gonderim\_kurallari.pdf](https://eam.metu.edu.tr/tr/system/files/posta_gonderim_kurallari.pdf) adresindeki kuralların mutlaka gözden geçirilerek gerekli hazırlıkların yapılması önem arz etmektedir.

EBYS Fiziksel Posta Gönderim Formu erişim ve kullanım yöntemi aşağıda tarif edilmiştir:

- EBYS'de oturum açınız.
- Sol menüden "Elektronik Formlar" seçeneğini seçiniz.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/fp01.png)

- Açılan bölümden "Fiziksel Posta Gönderim Formu" seçeneğini seçiniz.
- Form üzerinde gerekli bütün açıklamalar bulunmaktadır. Formu doldurup "Gönder" düğmesine basınız.

![](https://faq.cc.metu.edu.tr/tr/system/files/u16319/fp02.png)

- Doldurduğunuz formun hangi aşamada olduğunu geçmiş ekranınızdan ilgili formun akış tarihçesine ulaşarak takip edebilirsiniz.
- Fiziksel Posta Gönderim Formu ile ilgili sorular için [https://eam.metu.edu.tr/tr/iletisim](https://eam.metu.edu.tr/tr/iletisim) sayfasındaki bilgileri kullanarak Evrak ve Arşiv Müdürlüğü ile iletişime geçebilirsiniz.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.