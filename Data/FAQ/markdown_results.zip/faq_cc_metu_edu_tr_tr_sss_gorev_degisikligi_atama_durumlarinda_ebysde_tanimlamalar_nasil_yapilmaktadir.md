[Jump to navigation](https://faq.cc.metu.edu.tr/tr/sss/gorev-degisikligi-atama-durumlarinda-ebysde-tanimlamalar-nasil-yapilmaktadir#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 06-07-2022 **Görüntüleme:** 3001


Aranacak olan kelimeyi giriniz

- English
- [Türkçe](https://faq.cc.metu.edu.tr/tr/sss/gorev-degisikligi-atama-durumlarinda-ebysde-tanimlamalar-nasil-yapilmaktadir)

# Görev Değişikliği / Atama durumlarında EBYS'de tanımlamalar nasıl yapılmaktadır?

[Giriş ve Yetkilendirme](https://faq.cc.metu.edu.tr/tr/groups/giris-ve-yetkilendirme)

Görev tanımları Personel Daire Başkanlığı Özlük Müdürlüğü tarafından yapılmaktadır. Personel Daire Başkanlığı Özlük Müdürlüğü gerekli tanımlamaları yaptıktan sonra EBYS bu bilgileri otomatik olarak çekmektedir. Görev değişikliği ve atamanın henüz işlenmediğini düşünüyorsanız PDB ile iletişime geçebilirsiniz: [https://pdb.metu.edu.tr/tr/iletisim](https://pdb.metu.edu.tr/tr/iletisim)

Not: Öğleden önce yapılan değişiklikler öğlen, öğleden sonra yapılan değişiklikler gece işlenmektedir.

EBYS ilgili sorular **[ebys-destek@metu.edu.tr](mailto:ebys-destek@metu.edu.tr)** adresine iletilebilir.