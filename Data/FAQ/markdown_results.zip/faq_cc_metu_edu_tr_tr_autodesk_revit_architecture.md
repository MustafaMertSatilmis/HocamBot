[Jump to navigation](https://faq.cc.metu.edu.tr/tr/autodesk-revit-architecture#main-menu)

﻿

[-A](javascript:;) [+A](javascript:;)

**Son Güncelleme:** 12-01-2022 **Görüntüleme:** 11531


Aranacak olan kelimeyi giriniz

- [English](https://faq.cc.metu.edu.tr/autodesk-revit-architecture "AUTODESK REVIT ARCHITECTURE")
- [Türkçe](https://faq.cc.metu.edu.tr/tr/autodesk-revit-architecture "AUTODESK REVIT ARCHITECTURE")

# AUTODESK REVIT ARCHITECTURE

[Lisanslı Yazılımlar](https://faq.cc.metu.edu.tr/tr/groups/lisansli-yazilimlar)

Mimarlar, yapım mühendisleri, MEP mühendisleri, tarasımcılar ve yükleniciler için yapı bilgi modelleme(BIM) yazılımıdır.Autodesk Revit programı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" adresinden temin edilebilir.

[Kurulum](https://faq.cc.metu.edu.tr/tr/autodesk-revit-architecture#kurulum)

Kurulum:

**1\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit1.png)**

**2\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit2.png)**

**3\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit3.png)**

**4\. Step:** Kullanılacak olan seri numarası ve ürün anahtarı " [https://yazilim.cc.metu.edu.tr](https://yazilim.cc.metu.edu.tr/)" sitesinden edinilebilir.

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit4.png)**

**5\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit5.png)**

**6\. Step:** Lisans sunucusu olarak "autodesk.cc.metu.edu.tr" girilir.

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit6.png)**

**7\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit7.png)**

**8\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit8.png)**

**9\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit9.png)**

**10\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit10.png)**

**11\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit11.png)**

**12\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit12.png)**

**13\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit13.png)**

**14\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit14.png)**

**15\. Step:**

**![](https://faq.cc.metu.edu.tr/system/files/u16319/revit15.png)**

**Lisanslı yazılımlarla ilgili soru ve sorunlarınızı [https://bilisimdestek.metu.edu.tr](https://bilisimdestek.metu.edu.tr/) adresinden iletebilirsiniz.**